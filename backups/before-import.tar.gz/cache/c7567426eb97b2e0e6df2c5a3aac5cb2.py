# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/addresswidget.pt'

__tokens = {667: (u'python:request.form.get(fieldName, accessor())', 14, 33), 752: (u' here/getPossibleAddresse', 15, 37), 814: (u"y python:addr.get('country', '", 16, 34), 879: (u"te python:addr.get('state',", 17, 31), 944: (u"ict python:addr.get('district'", 18, 33), 1008: (u"city python:addr.get('city", 19, 28), 1067: (u"  zip python:addr.get('zi", 20, 26), 1129: (u"ddress python:addr.get('addre", 21, 29), 1198: (u'country python:country or widget.getDefaultC', 22, 31), 1340: (u'context/@@authenticator/authenticator', 24, 41), 1565: (u'string:${fieldName}_country', 29, 41), 1879: (u'python:widget.getCountries()', 34, 43), 1737: (u'string:${fieldName}.country:record', 32, 45), 1806: (u' string:${fieldName}.countr', 33, 33), 1999: (u'values', 36, 43), 2116: (u'python:value[1]', 38, 50), 2182: (u" python:value[1] == country and 'selected' or (country=='' and value[0] == defcountry and 'selected' or ''", 39, 49), 2049: (u'python:value[1]', 37, 41), 2481: (u'widget/showCopyFrom', 46, 51), 2815: (u'string:${fieldName}.selection', 52, 45), 2942: (u'possibles', 54, 56), 3052: (u'python:possible != fieldName', 56, 45), 3134: (u'possible', 57, 52), 2997: (u'possible', 55, 43), 3464: (u'string:${fieldName}_state', 68, 41), 3771: (u'python:widget.getStates(defcountry)', 73, 43), 3633: (u'string:${fieldName}.state:record', 71, 45), 3700: (u' string:${fieldName}.stat', 72, 33), 3897: (u'values', 75, 43), 4014: (u'python:value[2]', 77, 50), 4080: (u" python:value[2] == state and 'selected' or '", 78, 49), 3947: (u'python:value[2]', 76, 41), 4339: (u'widget/showDistrict', 86, 55), 4473: (u'string:${fieldName}_district', 88, 41), 4792: (u'python:widget.getDistricts(defcountry, state)', 93, 43), 4648: (u'string:${fieldName}.district:record', 91, 45), 4718: (u' string:${fieldName}.distric', 92, 33), 4933: (u'python:[val[2] for val in values]', 95, 48), 5013: (u' python:district and district not in district', 96, 45), 5102: (u'missing', 97, 41), 5159: (u'python:district', 98, 48), 5215: (u'python:district', 99, 39), 5323: (u'values', 101, 43), 5440: (u'python:value[2]', 103, 50), 5506: (u" python:value[2] == district and 'selected' or '", 104, 49), 5373: (u'python:value[2]', 102, 41), 5764: (u'widget/showCity', 112, 55), 5894: (u'string:${fieldName}_city', 114, 41), 6072: (u'city', 117, 45), 6111: (u' string:${fieldName}.city:recor', 118, 33), 6175: (u'd string:${fieldName}.ci', 119, 30), 6335: (u'widget/showPostalCode', 124, 55), 6471: (u'string:${fieldName}_zip', 126, 41), 6655: (u'zip', 129, 45), 6693: (u' string:${fieldName}.zip:recor', 130, 33), 6756: (u'd string:${fieldName}.z', 131, 30), 6911: (u'widget/showAddress', 136, 55), 7160: (u'string:${fieldName}.address:record', 140, 47), 7231: (u' string:${fieldName}.addres', 141, 35), 7300: (u'address', 142, 39), 544: (u'field_macro | here/widgets/field/macros/edit', 12, 26), 544: (u'field_macro | here/widgets/field/macros/edit', 12, 26), 7600: (u'here/widgets/string/macros/edit', 155, 26), 7600: (u'here/widgets/string/macros/edit', 155, 26), 227: (u'field/innerJoin', 6, 42), 285: (u' field/outerJoi', 7, 41), 347: (u's python:field.getSubfieldViews(here,innerJoi', 8, 44), 439: (u'python:outerJoin.join(subfieldViews)', 9, 43)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757074883216 = {u'class': u'col-sm-10', }
_static_135757150220048 = {u'id': u'string:${fieldName}.country', u'class': u'form-control', u'name': u'string:${fieldName}.country:record', }
_static_135756868131216 = {u'value': u'', }
_static_135757152964816 = {u'class': u'border p-3 mb-4', }
_static_135757153180944 = {u'class': u'col-sm-10', }
_static_135757153155024 = {u'class': u'form-group row', }
_static_135757109780624 = u'edit'
_static_135757074886352 = {u'class': u'col-sm-2 col-form-label', u'for': u'string:${fieldName}_zip', }
_static_135756868936080 = {u'id': u'string:${fieldName}.state', u'class': u'form-control', u'name': u'string:${fieldName}.state:record', }
_static_135757109778704 = {u'selected': u"python:value[2] == state and 'selected' or ''", u'value': u'python:value[2]', }
_static_135757109863760 = {u'class': u'col-sm-10', }
_static_135757109864848 = {u'class': u'col-sm-2 col-form-label', }
_static_135757071471504 = {u'class': u'input-group-prepend', }
_static_135757150218128 = {u'class': u'col-sm-4', }
_static_135757153179536 = {u'id': u'string:${fieldName}.city', u'type': u'text', u'class': u'form-control', u'value': u'city', u'name': u'string:${fieldName}.city:record', }
_static_135757151845712 = {u'class': u'col-sm-2 col-form-label', u'for': u'string:${fieldName}_state', }
_static_135757074884240 = {u'id': u'string:${fieldName}.zip', u'type': u'text', u'class': u'form-control', u'value': u'zip', u'name': u'string:${fieldName}.zip:record', }
_static_135757109864976 = {u'id': u'string:${fieldName}.address', u'rows': u'3', u'class': u'form-control', u'name': u'string:${fieldName}.address:record', }
_static_135757109825808 = {u'selected': u'selected', u'value': u'python:district', }
_static_135757151844240 = {u'class': u'col-sm-10', }
_static_135757075195408 = u'edit'
_static_135756867980752 = {u'class': u'col-sm-10', }
_static_135757075681488 = {u'selected': u"python:value[1] == country and 'selected' or (country=='' and value[0] == defcountry and 'selected' or '')", u'value': u'python:value[1]', }
_static_135757327983760 = {}
_static_135757151869776 = {u'class': u'form-group row', }
_static_135756869582288 = {u'id': u'string:${fieldName}.district', u'class': u'form-control', u'name': u'string:${fieldName}.district:record', }
_static_135756869581136 = {u'value': u'', }
_static_135757071456144 = {u'value': u'', }
_static_135756869579664 = {u'class': u'form-group row', }
_static_135757244280656 = __compile_zt_expr
_static_135757071473104 = {u'class': u'input-group input-group-sm', }
_static_135757074933328 = {u'class': u'col-sm-2 col-form-label', u'for': u'string:${fieldName}_country', }
_static_135757074846736 = {u'class': u'col-sm-6', }
_static_135757072928656 = {u'class': u'form-control', u'id': u'string:${fieldName}.selection', }
_static_135757072928208 = {u'class': u'input-group-text', }
_static_135756868129488 = {u'class': u'form-group row', }
_static_135757075835280 = {u'class': u'col-sm-2 col-form-label', u'for': u'string:${fieldName}_city', }
_static_135757075854160 = {u'value': u'possible', }
_static_135756867981264 = {u'class': u'col-sm-2 col-form-label', u'for': u'string:${fieldName}_district', }
_static_135757109825872 = {u'selected': u"python:value[2] == district and 'selected' or ''", u'value': u'python:value[2]', }
_static_135757075856464 = {u'class': u'form-group row', }
_static_135757074932560 = {u'class': u'form-group row', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109781712
            __attrs_135757109781712 = _static_135757327983760
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109783632
            __attrs_135757109783632 = _static_135757327983760
            __backup_macroname_135757111906864 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786a4de090> name=None at 7b786a4de050> -> __value
            __value = _static_135757109780624
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109781456
                __attrs_135757109781456 = _static_135757327983760
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148695376
                __attrs_135757148695376 = _static_135757327983760
                __backup_addr_135757109783568 = get('addr', __marker)

                # <Value u'python:request.form.get(fieldName, accessor())' (14:33)> -> __value
                __token = 667
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'request.form.get(fieldName, accessor())', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['addr'] = __value
                __backup_possibles_135757109783376 = get('possibles', __marker)

                # <Value u'here/getPossibleAddresses' (15:37)> -> __value
                __token = 752
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'here/getPossibleAddresses', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['possibles'] = __value
                __backup_country_135757075196432 = get('country', __marker)

                # <Value u"python:addr.get('country', '')" (16:34)> -> __value
                __token = 814
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('country', '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['country'] = __value
                __backup_state_135757075194064 = get('state', __marker)

                # <Value u"python:addr.get('state','')" (17:31)> -> __value
                __token = 879
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('state','')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['state'] = __value
                __backup_district_135757075194832 = get('district', __marker)

                # <Value u"python:addr.get('district','')" (18:33)> -> __value
                __token = 944
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('district','')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['district'] = __value
                __backup_city_135757075196176 = get('city', __marker)

                # <Value u"python:addr.get('city','')" (19:28)> -> __value
                __token = 1008
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('city','')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['city'] = __value
                __backup_zip_135757075197392 = get('zip', __marker)

                # <Value u"python:addr.get('zip','')" (20:26)> -> __value
                __token = 1067
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('zip','')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['zip'] = __value
                __backup_address_135757075193936 = get('address', __marker)

                # <Value u"python:addr.get('address','')" (21:29)> -> __value
                __token = 1129
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"addr.get('address','')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['address'] = __value
                __backup_defcountry_135757075195984 = get('defcountry', __marker)

                # <Value u'python:country or widget.getDefaultCountry()' (22:31)> -> __value
                __token = 1198
                try:
                    __zt_tmp = __attrs_135757148695376
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'country or widget.getDefaultCountry()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['defcountry'] = __value
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b786ce0d0d0> name=None at 7b786ce0dd50> -> __attrs_135757152966864
                __attrs_135757152966864 = _static_135757152964816

                # <fieldset ... (0:0)
                # --------------------------------------------------------
                __append(u'<fieldset class="border p-3 mb-4">\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074935632
                __attrs_135757074935632 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074934160
                __default_135757074934160 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (24:41)> -> __cache_135757074932816
                __token = 1340
                try:
                    __zt_tmp = __attrs_135757074935632
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074932816 = _static_135757244280656('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (24:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683a2c50> -> __condition
                __expression = __cache_135757074932816

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_135757074932816
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n\n            <!-- Country -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b78683a2350> name=None at 7b78683a2e50> -> __attrs_135757074935056
                __attrs_135757074935056 = _static_135757074932560

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="form-group row">\n              ')

                # <Static value=<_ast.Dict object at 0x7b78683a2650> name=None at 7b78683a2950> -> __attrs_135757150217296
                __attrs_135757150217296 = _static_135757074933328

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="col-sm-2 col-form-label"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150216912
                __default_135757150216912 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_country' (29:41)> -> __attr_for
                __token = 1565
                try:
                    __zt_tmp = __attrs_135757150217296
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_135757244280656('string', u'${fieldName}_country', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_135757074931792 = []
                __append_135757074931792 = __stream_135757074931792.append
                __append_135757074931792(u'Country')
                __msgid_135757074931792 = __re_whitespace(''.join(__stream_135757074931792)).strip()
                if __msgid_135757074931792:
                    __append(translate(__msgid_135757074931792, mapping=None, default=__msgid_135757074931792, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n              ')

                # <Static value=<_ast.Dict object at 0x7b786cb6e790> name=None at 7b786cb6e250> -> __attrs_135757150219152
                __attrs_135757150219152 = _static_135757150218128

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="col-sm-4">\n                ')

                # <Static value=<_ast.Dict object at 0x7b786cb6ef10> name=None at 7b786cb6ea90> -> __attrs_135757074508560
                __attrs_135757074508560 = _static_135757150220048
                __backup_values_135757152967184 = get('values', __marker)

                # <Value u'python:widget.getCountries()' (34:43)> -> __value
                __token = 1879
                try:
                    __zt_tmp = __attrs_135757074508560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.getCountries()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select class="form-control"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150218960
                __default_135757150218960 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.country:record' (32:45)> -> __attr_name
                __token = 1737
                try:
                    __zt_tmp = __attrs_135757074508560
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('string', u'${fieldName}.country:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075274832
                __default_135757075274832 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.country' (33:33)> -> __attr_id
                __token = 1806
                try:
                    __zt_tmp = __attrs_135757074508560
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}.country', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b7868051790> name=None at 7b7868051e10> -> __attrs_135757149893840
                __attrs_135757149893840 = _static_135757071456144

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option value=""></option>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074848464
                __attrs_135757074848464 = _static_135757327983760
                __backup_value_135757074509712 = get('value', __marker)

                # <Value u'values' (36:43)> -> __iterator
                __token = 1999
                try:
                    __zt_tmp = __attrs_135757074848464
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757074847632, ) = getitem('repeat')(u'value', __iterator)
                econtext['value'] = None
                for __item in __iterator:
                    econtext['value'] = __item
                    __append(u'\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78684590d0> name=None at 7b7868459210> -> __attrs_135757071472912
                    __attrs_135757071472912 = _static_135757075681488

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071471568
                    __default_135757071471568 = _DEFAULT_MARKER

                    # <Substitution u'python:value[1]' (38:50)> -> __attr_value
                    __token = 2116
                    try:
                        __zt_tmp = __attrs_135757071472912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('python', u'value[1]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071473296
                    __default_135757071473296 = _DEFAULT_MARKER

                    # <Boolean u"python:value[1] == country and 'selected' or (country=='' and value[0] == defcountry and 'selected' or '')" (39:49)> -> __attr_selected
                    __token = 2182
                    try:
                        __zt_tmp = __attrs_135757071472912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_selected = _static_135757244280656('python', u"value[1] == country and 'selected' or (country=='' and value[0] == defcountry and 'selected' or '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (__attr_selected is _DEFAULT_MARKER):
                        __attr_selected = None
                    else:
                        if __attr_selected:
                            __attr_selected = u'selected'
                        else:
                            __attr_selected = None
                    if (__attr_selected is not None):
                        __append((u' selected="%s"' % __attr_selected))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075684048
                    __default_135757075684048 = _DEFAULT_MARKER

                    # <Value u'python:value[1]' (37:41)> -> __cache_135757075683280
                    __token = 2049
                    try:
                        __zt_tmp = __attrs_135757071472912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075683280 = _static_135757244280656('python', u'value[1]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:value[1]' (37:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868459a10> -> __condition
                    __expression = __cache_135757075683280

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                    ')
                    else:
                        __content = __cache_135757075683280
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>\n                  ')
                    ____index_135757074847632 -= 1
                    if (____index_135757074847632 > 0):
                        __append('')
                if (__backup_value_135757074509712 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_135757074509712
                __append(u'\n                </select>')
                if (__backup_values_135757152967184 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135757152967184
                __append(u'\n              </div>\n\n              <!-- Copy From -->\n              ')

                # <Static value=<_ast.Dict object at 0x7b786838d410> name=None at 7b786838ded0> -> __attrs_135757071472592
                __attrs_135757071472592 = _static_135757074846736

                # <Value u'widget/showCopyFrom' (46:51)> -> __condition
                __token = 2481
                try:
                    __zt_tmp = __attrs_135757071472592
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/showCopyFrom', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="col-sm-6">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78680559d0> name=None at 7b7868055bd0> -> __attrs_135757071471888
                    __attrs_135757071471888 = _static_135757071473104

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group input-group-sm">\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b7868055390> name=None at 7b7868055690> -> __attrs_135757072927056
                    __attrs_135757072927056 = _static_135757071471504

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78681b8dd0> name=None at 7b78681b8310> -> __attrs_135757072925968
                    __attrs_135757072925968 = _static_135757072928208

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')
                    __stream_135757072928272 = []
                    __append_135757072928272 = __stream_135757072928272.append
                    __append_135757072928272(u'Copy from')
                    __msgid_135757072928272 = __re_whitespace(''.join(__stream_135757072928272)).strip()
                    if __msgid_135757072928272:
                        __append(translate(__msgid_135757072928272, mapping=None, default=__msgid_135757072928272, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\n                  </div>\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b78681b8f90> name=None at 7b78681b8410> -> __attrs_135757072927952
                    __attrs_135757072927952 = _static_135757072928656

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select class="form-control"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072928400
                    __default_135757072928400 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.selection' (52:45)> -> __attr_id
                    __token = 2815
                    try:
                        __zt_tmp = __attrs_135757072927952
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}.selection', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075855632
                    __attrs_135757075855632 = _static_135757327983760

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option></option>\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075855376
                    __attrs_135757075855376 = _static_135757327983760
                    __backup_possible_135757074848208 = get('possible', __marker)

                    # <Value u'possibles' (54:56)> -> __iterator
                    __token = 2942
                    try:
                        __zt_tmp = __attrs_135757075855376
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'possibles', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757075856592, ) = getitem('repeat')(u'possible', __iterator)
                    econtext['possible'] = None
                    for __item in __iterator:
                        econtext['possible'] = __item
                        __append(u'\n                      ')

                        # <Static value=<_ast.Dict object at 0x7b7868483350> name=None at 7b7868483f50> -> __attrs_135757075856976
                        __attrs_135757075856976 = _static_135757075854160

                        # <Value u'python:possible != fieldName' (56:45)> -> __condition
                        __token = 3052
                        try:
                            __zt_tmp = __attrs_135757075856976
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'possible != fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <option ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<option')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075853712
                            __default_135757075853712 = _DEFAULT_MARKER

                            # <Substitution u'possible' (57:52)> -> __attr_value
                            __token = 3134
                            try:
                                __zt_tmp = __attrs_135757075856976
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('path', u'possible', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))
                            __append(u'>')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075855568
                            __default_135757075855568 = _DEFAULT_MARKER

                            # <Value u'possible' (55:43)> -> __cache_135757075854096
                            __token = 2997
                            try:
                                __zt_tmp = __attrs_135757075856976
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757075854096 = _static_135757244280656('path', u'possible', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'possible' (55:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78684831d0> -> __condition
                            __expression = __cache_135757075854096

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                pass
                            else:
                                __content = __cache_135757075854096
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</option>')
                        __append(u'\n                    ')
                        ____index_135757075856592 -= 1
                        if (____index_135757075856592 > 0):
                            __append('')
                    if (__backup_possible_135757074848208 is __marker):
                        del econtext['possible']
                    else:
                        econtext['possible'] = __backup_possible_135757074848208
                    __append(u'\n                  </select>\n                </div>\n              </div>')
                __append(u'\n            </div>\n\n\n            <!-- State -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b7868483c50> name=None at 7b7868483e10> -> __attrs_135757072928528
                __attrs_135757072928528 = _static_135757075856464

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="form-group row">\n              ')

                # <Static value=<_ast.Dict object at 0x7b786ccfbd50> name=None at 7b786ccfb910> -> __attrs_135757151842576
                __attrs_135757151842576 = _static_135757151845712

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="col-sm-2 col-form-label"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151844944
                __default_135757151844944 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_state' (68:41)> -> __attr_for
                __token = 3464
                try:
                    __zt_tmp = __attrs_135757151842576
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_135757244280656('string', u'${fieldName}_state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_135757151842448 = []
                __append_135757151842448 = __stream_135757151842448.append
                __append_135757151842448(u'State')
                __msgid_135757151842448 = __re_whitespace(''.join(__stream_135757151842448)).strip()
                if __msgid_135757151842448:
                    __append(translate(__msgid_135757151842448, mapping=None, default=__msgid_135757151842448, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n              ')

                # <Static value=<_ast.Dict object at 0x7b786ccfb790> name=None at 7b786ccfbc10> -> __attrs_135756868938384
                __attrs_135756868938384 = _static_135757151844240

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="col-sm-10">\n                ')

                # <Static value=<_ast.Dict object at 0x7b785bf2e190> name=None at 7b785bf2e650> -> __attrs_135756868938192
                __attrs_135756868938192 = _static_135756868936080
                __backup_values_135757150219408 = get('values', __marker)

                # <Value u'python:widget.getStates(defcountry)' (73:43)> -> __value
                __token = 3771
                try:
                    __zt_tmp = __attrs_135756868938192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.getStates(defcountry)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select class="form-control"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868938896
                __default_135756868938896 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.state:record' (71:45)> -> __attr_name
                __token = 3633
                try:
                    __zt_tmp = __attrs_135756868938192
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('string', u'${fieldName}.state:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868936144
                __default_135756868936144 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.state' (72:33)> -> __attr_id
                __token = 3700
                try:
                    __zt_tmp = __attrs_135756868938192
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}.state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b785be69990> name=None at 7b785be69690> -> __attrs_135756868131792
                __attrs_135756868131792 = _static_135756868131216

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u"<option value=''></option>\n                  ")

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868130064
                __attrs_135756868130064 = _static_135757327983760
                __backup_value_135757074506960 = get('value', __marker)

                # <Value u'values' (75:43)> -> __iterator
                __token = 3897
                try:
                    __zt_tmp = __attrs_135756868130064
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756868129744, ) = getitem('repeat')(u'value', __iterator)
                econtext['value'] = None
                for __item in __iterator:
                    econtext['value'] = __item
                    __append(u'\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b786a4dd910> name=None at 7b78684836d0> -> __attrs_135756867979024
                    __attrs_135756867979024 = _static_135757109778704

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868128912
                    __default_135756868128912 = _DEFAULT_MARKER

                    # <Substitution u'python:value[2]' (77:50)> -> __attr_value
                    __token = 4014
                    try:
                        __zt_tmp = __attrs_135756867979024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('python', u'value[2]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868130192
                    __default_135756868130192 = _DEFAULT_MARKER

                    # <Boolean u"python:value[2] == state and 'selected' or ''" (78:49)> -> __attr_selected
                    __token = 4080
                    try:
                        __zt_tmp = __attrs_135756867979024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_selected = _static_135757244280656('python', u"value[2] == state and 'selected' or ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (__attr_selected is _DEFAULT_MARKER):
                        __attr_selected = None
                    else:
                        if __attr_selected:
                            __attr_selected = u'selected'
                        else:
                            __attr_selected = None
                    if (__attr_selected is not None):
                        __append((u' selected="%s"' % __attr_selected))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868131152
                    __default_135756868131152 = _DEFAULT_MARKER

                    # <Value u'python:value[2]' (76:41)> -> __cache_135756868132688
                    __token = 3947
                    try:
                        __zt_tmp = __attrs_135756867979024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756868132688 = _static_135757244280656('python', u'value[2]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:value[2]' (76:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785be69b10> -> __condition
                    __expression = __cache_135756868132688

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                    ')
                    else:
                        __content = __cache_135756868132688
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>\n                  ')
                    ____index_135756868129744 -= 1
                    if (____index_135756868129744 > 0):
                        __append('')
                if (__backup_value_135757074506960 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_135757074506960
                __append(u'\n                </select>')
                if (__backup_values_135757150219408 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135757150219408
                __append(u'\n              </div>\n            </div>\n\n            <!-- District -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b785be692d0> name=None at 7b785be69e90> -> __attrs_135756867980624
                __attrs_135756867980624 = _static_135756868129488

                # <Value u'widget/showDistrict' (86:55)> -> __condition
                __token = 4339
                try:
                    __zt_tmp = __attrs_135756867980624
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/showDistrict', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-group row">\n              ')

                    # <Static value=<_ast.Dict object at 0x7b785be44fd0> name=None at 7b785be44b10> -> __attrs_135756867978640
                    __attrs_135756867978640 = _static_135756867981264

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="col-sm-2 col-form-label"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867977872
                    __default_135756867977872 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_district' (88:41)> -> __attr_for
                    __token = 4473
                    try:
                        __zt_tmp = __attrs_135756867978640
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_135757244280656('string', u'${fieldName}_district', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_135756867978320 = []
                    __append_135756867978320 = __stream_135756867978320.append
                    __append_135756867978320(u'District')
                    __msgid_135756867978320 = __re_whitespace(''.join(__stream_135756867978320)).strip()
                    if __msgid_135756867978320:
                        __append(translate(__msgid_135756867978320, mapping=None, default=__msgid_135756867978320, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n              ')

                    # <Static value=<_ast.Dict object at 0x7b785be44dd0> name=None at 7b785be44890> -> __attrs_135757155132496
                    __attrs_135757155132496 = _static_135756867980752

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="col-sm-10">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b785bfcbdd0> name=None at 7b785bfcb610> -> __attrs_135756869582544
                    __attrs_135756869582544 = _static_135756869582288
                    __backup_values_135757152967120 = get('values', __marker)

                    # <Value u'python:widget.getDistricts(defcountry, state)' (93:43)> -> __value
                    __token = 4792
                    try:
                        __zt_tmp = __attrs_135756869582544
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'widget.getDistricts(defcountry, state)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['values'] = __value

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select class="form-control"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869582224
                    __default_135756869582224 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.district:record' (91:45)> -> __attr_name
                    __token = 4648
                    try:
                        __zt_tmp = __attrs_135756869582544
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('string', u'${fieldName}.district:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869581584
                    __default_135756869581584 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.district' (92:33)> -> __attr_id
                    __token = 4718
                    try:
                        __zt_tmp = __attrs_135756869582544
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}.district', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b785bfcb950> name=None at 7b785bfcb290> -> __attrs_135756869580816
                    __attrs_135756869580816 = _static_135756869581136

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u"<option value=''></option>\n                  ")

                    # <Static value=<_ast.Dict object at 0x7b786a4e9110> name=None at 7b786a4e9850> -> __attrs_135757109828432
                    __attrs_135757109828432 = _static_135757109825808
                    __backup_districts_135757153167312 = get('districts', __marker)

                    # <Value u'python:[val[2] for val in values]' (95:48)> -> __value
                    __token = 4933
                    try:
                        __zt_tmp = __attrs_135757109828432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'[val[2] for val in values]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['districts'] = __value
                    __backup_missing_135757075856528 = get('missing', __marker)

                    # <Value u'python:district and district not in districts' (96:45)> -> __value
                    __token = 5013
                    try:
                        __zt_tmp = __attrs_135757109828432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'district and district not in districts', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['missing'] = __value

                    # <Value u'missing' (97:41)> -> __condition
                    __token = 5102
                    try:
                        __zt_tmp = __attrs_135757109828432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'missing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option selected="selected"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109826576
                        __default_135757109826576 = _DEFAULT_MARKER

                        # <Substitution u'python:district' (98:48)> -> __attr_value
                        __token = 5159
                        try:
                            __zt_tmp = __attrs_135757109828432
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('python', u'district', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109826640
                        __default_135757109826640 = _DEFAULT_MARKER

                        # <Value u'python:district' (99:39)> -> __cache_135756869580112
                        __token = 5215
                        try:
                            __zt_tmp = __attrs_135757109828432
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135756869580112 = _static_135757244280656('python', u'district', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:district' (99:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfcbe90> -> __condition
                        __expression = __cache_135756869580112

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135756869580112
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>')
                    if (__backup_missing_135757075856528 is __marker):
                        del econtext['missing']
                    else:
                        econtext['missing'] = __backup_missing_135757075856528
                    if (__backup_districts_135757153167312 is __marker):
                        del econtext['districts']
                    else:
                        econtext['districts'] = __backup_districts_135757153167312
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109827344
                    __attrs_135757109827344 = _static_135757327983760
                    __backup_value_135757075247568 = get('value', __marker)

                    # <Value u'values' (101:43)> -> __iterator
                    __token = 5323
                    try:
                        __zt_tmp = __attrs_135757109827344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757109825616, ) = getitem('repeat')(u'value', __iterator)
                    econtext['value'] = None
                    for __item in __iterator:
                        econtext['value'] = __item
                        __append(u'\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b786a4e9150> name=None at 7b786a4e9c90> -> __attrs_135757075834960
                        __attrs_135757075834960 = _static_135757109825872

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075834192
                        __default_135757075834192 = _DEFAULT_MARKER

                        # <Substitution u'python:value[2]' (103:50)> -> __attr_value
                        __token = 5440
                        try:
                            __zt_tmp = __attrs_135757075834960
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('python', u'value[2]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075836368
                        __default_135757075836368 = _DEFAULT_MARKER

                        # <Boolean u"python:value[2] == district and 'selected' or ''" (104:49)> -> __attr_selected
                        __token = 5506
                        try:
                            __zt_tmp = __attrs_135757075834960
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_selected = _static_135757244280656('python', u"value[2] == district and 'selected' or ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_selected is _DEFAULT_MARKER):
                            __attr_selected = None
                        else:
                            if __attr_selected:
                                __attr_selected = u'selected'
                            else:
                                __attr_selected = None
                        if (__attr_selected is not None):
                            __append((u' selected="%s"' % __attr_selected))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109827728
                        __default_135757109827728 = _DEFAULT_MARKER

                        # <Value u'python:value[2]' (102:41)> -> __cache_135757109827536
                        __token = 5373
                        try:
                            __zt_tmp = __attrs_135757075834960
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757109827536 = _static_135757244280656('python', u'value[2]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:value[2]' (102:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a4e9ad0> -> __condition
                        __expression = __cache_135757109827536

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                    ')
                        else:
                            __content = __cache_135757109827536
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>\n                  ')
                        ____index_135757109825616 -= 1
                        if (____index_135757109825616 > 0):
                            __append('')
                    if (__backup_value_135757075247568 is __marker):
                        del econtext['value']
                    else:
                        econtext['value'] = __backup_value_135757075247568
                    __append(u'\n                </select>')
                    if (__backup_values_135757152967120 is __marker):
                        del econtext['values']
                    else:
                        econtext['values'] = __backup_values_135757152967120
                    __append(u'\n              </div>\n            </div>')
                __append(u'\n\n            <!-- City -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b785bfcb390> name=None at 7b786a4e9590> -> __attrs_135757075833680
                __attrs_135757075833680 = _static_135756869579664

                # <Value u'widget/showCity' (112:55)> -> __condition
                __token = 5764
                try:
                    __zt_tmp = __attrs_135757075833680
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/showCity', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-group row">\n              ')

                    # <Static value=<_ast.Dict object at 0x7b786847e990> name=None at 7b786847e290> -> __attrs_135757153179792
                    __attrs_135757153179792 = _static_135757075835280

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="col-sm-2 col-form-label"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075834448
                    __default_135757075834448 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_city' (114:41)> -> __attr_for
                    __token = 5894
                    try:
                        __zt_tmp = __attrs_135757153179792
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_135757244280656('string', u'${fieldName}_city', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_135757075836624 = []
                    __append_135757075836624 = __stream_135757075836624.append
                    __append_135757075836624(u'City')
                    __msgid_135757075836624 = __re_whitespace(''.join(__stream_135757075836624)).strip()
                    if __msgid_135757075836624:
                        __append(translate(__msgid_135757075836624, mapping=None, default=__msgid_135757075836624, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n              ')

                    # <Static value=<_ast.Dict object at 0x7b786ce41d10> name=None at 7b786ce41110> -> __attrs_135757153181584
                    __attrs_135757153181584 = _static_135757153180944

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="col-sm-10">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b786ce41790> name=None at 7b786ce41210> -> __attrs_135757153155984
                    __attrs_135757153155984 = _static_135757153179536

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="text" class="form-control"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153155216
                    __default_135757153155216 = _DEFAULT_MARKER

                    # <Substitution u'city' (117:45)> -> __attr_value
                    __token = 6072
                    try:
                        __zt_tmp = __attrs_135757153155984
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'city', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153155792
                    __default_135757153155792 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.city:record' (118:33)> -> __attr_name
                    __token = 6111
                    try:
                        __zt_tmp = __attrs_135757153155984
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('string', u'${fieldName}.city:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153153744
                    __default_135757153153744 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.city' (119:30)> -> __attr_id
                    __token = 6175
                    try:
                        __zt_tmp = __attrs_135757153155984
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}.city', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u' />\n              </div>\n            </div>')
                __append(u'\n\n            <!-- Postal Code -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b786ce3b7d0> name=None at 7b786ce3bc50> -> __attrs_135757153154640
                __attrs_135757153154640 = _static_135757153155024

                # <Value u'widget/showPostalCode' (124:55)> -> __condition
                __token = 6335
                try:
                    __zt_tmp = __attrs_135757153154640
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/showPostalCode', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-group row">\n              ')

                    # <Static value=<_ast.Dict object at 0x7b7868396ed0> name=None at 7b7868396450> -> __attrs_135757074885520
                    __attrs_135757074885520 = _static_135757074886352

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="col-sm-2 col-form-label"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074885072
                    __default_135757074885072 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_zip' (126:41)> -> __attr_for
                    __token = 6471
                    try:
                        __zt_tmp = __attrs_135757074885520
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_135757244280656('string', u'${fieldName}_zip', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_135757071862416 = []
                    __append_135757071862416 = __stream_135757071862416.append
                    __append_135757071862416(u'Postal code')
                    __msgid_135757071862416 = __re_whitespace(''.join(__stream_135757071862416)).strip()
                    if __msgid_135757071862416:
                        __append(translate(__msgid_135757071862416, mapping=None, default=__msgid_135757071862416, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n              ')

                    # <Static value=<_ast.Dict object at 0x7b7868396290> name=None at 7b7868396390> -> __attrs_135757074886032
                    __attrs_135757074886032 = _static_135757074883216

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="col-sm-10">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b7868396690> name=None at 7b7868396f10> -> __attrs_135757151870928
                    __attrs_135757151870928 = _static_135757074884240

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="text" class="form-control"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151870480
                    __default_135757151870480 = _DEFAULT_MARKER

                    # <Substitution u'zip' (129:45)> -> __attr_value
                    __token = 6655
                    try:
                        __zt_tmp = __attrs_135757151870928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'zip', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151869264
                    __default_135757151869264 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.zip:record' (130:33)> -> __attr_name
                    __token = 6693
                    try:
                        __zt_tmp = __attrs_135757151870928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('string', u'${fieldName}.zip:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151867600
                    __default_135757151867600 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.zip' (131:30)> -> __attr_id
                    __token = 6756
                    try:
                        __zt_tmp = __attrs_135757151870928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}.zip', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u' />\n              </div>\n            </div>')
                __append(u'\n\n            <!-- Address -->\n            ')

                # <Static value=<_ast.Dict object at 0x7b786cd01b50> name=None at 7b786cd01f10> -> __attrs_135757151870608
                __attrs_135757151870608 = _static_135757151869776

                # <Value u'widget/showAddress' (136:55)> -> __condition
                __token = 6911
                try:
                    __zt_tmp = __attrs_135757151870608
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/showAddress', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-group row">\n              ')

                    # <Static value=<_ast.Dict object at 0x7b786a4f2990> name=None at 7b786a4f2650> -> __attrs_135757109865808
                    __attrs_135757109865808 = _static_135757109864848

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="col-sm-2 col-form-label">')
                    __stream_135757109864720 = []
                    __append_135757109864720 = __stream_135757109864720.append
                    __append_135757109864720(u'Address')
                    __msgid_135757109864720 = __re_whitespace(''.join(__stream_135757109864720)).strip()
                    if __msgid_135757109864720:
                        __append(translate(__msgid_135757109864720, mapping=None, default=__msgid_135757109864720, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n              ')

                    # <Static value=<_ast.Dict object at 0x7b786a4f2550> name=None at 7b786a4f2490> -> __attrs_135757109863312
                    __attrs_135757109863312 = _static_135757109863760

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="col-sm-10">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b786a4f2a10> name=None at 7b786a4f2a50> -> __attrs_135756868168720
                    __attrs_135756868168720 = _static_135757109864976

                    # <textarea ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<textarea class="form-control" rows="3"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868169552
                    __default_135756868169552 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.address:record' (140:47)> -> __attr_name
                    __token = 7160
                    try:
                        __zt_tmp = __attrs_135756868168720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('string', u'${fieldName}.address:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868167184
                    __default_135756868167184 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}.address' (141:35)> -> __attr_id
                    __token = 7231
                    try:
                        __zt_tmp = __attrs_135756868168720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}.address', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109863248
                    __default_135757109863248 = _DEFAULT_MARKER

                    # <Value u'address' (142:39)> -> __cache_135757109863696
                    __token = 7300
                    try:
                        __zt_tmp = __attrs_135756868168720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757109863696 = _static_135757244280656('path', u'address', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'address' (142:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a4f2190> -> __condition
                    __expression = __cache_135757109863696

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                ')
                    else:
                        __content = __cache_135757109863696
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</textarea>\n              </div>\n            </div>')
                __append(u'\n\n          </fieldset>\n        ')
                if (__backup_defcountry_135757075195984 is __marker):
                    del econtext['defcountry']
                else:
                    econtext['defcountry'] = __backup_defcountry_135757075195984
                if (__backup_address_135757075193936 is __marker):
                    del econtext['address']
                else:
                    econtext['address'] = __backup_address_135757075193936
                if (__backup_zip_135757075197392 is __marker):
                    del econtext['zip']
                else:
                    econtext['zip'] = __backup_zip_135757075197392
                if (__backup_city_135757075196176 is __marker):
                    del econtext['city']
                else:
                    econtext['city'] = __backup_city_135757075196176
                if (__backup_district_135757075194832 is __marker):
                    del econtext['district']
                else:
                    econtext['district'] = __backup_district_135757075194832
                if (__backup_state_135757075194064 is __marker):
                    del econtext['state']
                else:
                    econtext['state'] = __backup_state_135757075194064
                if (__backup_country_135757075196432 is __marker):
                    del econtext['country']
                else:
                    econtext['country'] = __backup_country_135757075196432
                if (__backup_possibles_135757109783376 is __marker):
                    del econtext['possibles']
                else:
                    econtext['possibles'] = __backup_possibles_135757109783376
                if (__backup_addr_135757109783568 is __marker):
                    del econtext['addr']
                else:
                    econtext['addr'] = __backup_addr_135757109783568
                __append(u'\n      ')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | here/widgets/field/macros/edit' (12:26)> -> __macro
            __token = 544
            try:
                __zt_tmp = __attrs_135757109783632
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'field_macro | here/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 544
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757111906864 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757111906864
            __append(u'\n  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109782288
            __attrs_135757109782288 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152966736
            __attrs_135757152966736 = _static_135757327983760
            __backup_macroname_135757111907504 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b78683e2610> name=None at 7b786ce0d190> -> __value
            __value = _static_135757075195408
            econtext['macroname'] = __value

            # <Value u'here/widgets/string/macros/edit' (155:26)> -> __macro
            __token = 7600
            try:
                __zt_tmp = __attrs_135757152966736
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/widgets/string/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 7600
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757111907504 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757111907504
            __append(u'\n  </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074899600
            __attrs_135757074899600 = _static_135757327983760
            __backup_innerJoin_135757074902608 = get('innerJoin', __marker)

            # <Value u'field/innerJoin' (6:42)> -> __value
            __token = 227
            try:
                __zt_tmp = __attrs_135757074899600
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/innerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['innerJoin'] = __value
            __backup_outerJoin_135757074900688 = get('outerJoin', __marker)

            # <Value u'field/outerJoin' (7:41)> -> __value
            __token = 285
            try:
                __zt_tmp = __attrs_135757074899600
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/outerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['outerJoin'] = __value
            __backup_subfieldViews_135757074902800 = get('subfieldViews', __marker)

            # <Value u'python:field.getSubfieldViews(here,innerJoin)' (8:44)> -> __value
            __token = 347
            try:
                __zt_tmp = __attrs_135757074899600
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.getSubfieldViews(here,innerJoin)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['subfieldViews'] = __value

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074902160
            __default_135757074902160 = _DEFAULT_MARKER

            # <Value u'python:outerJoin.join(subfieldViews)' (9:43)> -> __cache_135757074900880
            __token = 439
            try:
                __zt_tmp = __attrs_135757074899600
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757074900880 = _static_135757244280656('python', u'outerJoin.join(subfieldViews)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'python:outerJoin.join(subfieldViews)' (9:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786839abd0> -> __condition
            __expression = __cache_135757074900880

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757074900880
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            if (__backup_subfieldViews_135757074902800 is __marker):
                del econtext['subfieldViews']
            else:
                econtext['subfieldViews'] = __backup_subfieldViews_135757074902800
            if (__backup_outerJoin_135757074900688 is __marker):
                del econtext['outerJoin']
            else:
                econtext['outerJoin'] = __backup_outerJoin_135757074900688
            if (__backup_innerJoin_135757074902608 is __marker):
                del econtext['innerJoin']
            else:
                econtext['innerJoin'] = __backup_innerJoin_135757074902608
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074901392
            __attrs_135757074901392 = _static_135757327983760
            __previous_i18n_domain_135757074902544 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html>\n\n  ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u"\n\n  <!-- Use string field's search macro for consistency -->\n  ")
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n</html>')
            __i18n_domain = __previous_i18n_domain_135757074902544
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_view': render_view, 'render': render, }