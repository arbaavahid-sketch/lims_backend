# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/worksheets/templates/view.pt'

__tokens = {408: (u'view/icon | nothing', 10, 28), 463: (u'view/icon', 11, 33), 514: (u'view/title', 12, 37), 618: (u'python:view.can_add()', 16, 26), 837: (u'string:${context/absolute_url}/add_worksheet', 22, 37), 1448: (u'view/getAnalysts', 35, 38), 1584: (u'alist', 37, 42), 1651: (u'python:option', 39, 33), 1707: (u'python:option', 40, 40), 1754: (u'python:alist.getValue(option)', 41, 31), 2207: (u'view/getWorksheetTemplates', 50, 42), 2358: (u'wstlist', 52, 44), 2438: (u'python:option', 54, 42), 2487: (u'python:wstlist.getValue(option)', 55, 33), 2993: (u'view/getInstruments', 65, 44), 3139: (u'instrlist', 67, 44), 3221: (u'python:option', 69, 42), 3270: (u'python:instrlist.getValue(option)', 70, 33), 3524: (u'python:view.context_actions.keys()', 76, 48), 3699: (u'add_item', 79, 44), 3744: (u' add_ite', 80, 34), 3788: (u"f python:view.context_actions[add_item]['url", 81, 32), 4050: (u'context/@@authenticator/authenticator', 88, 40), 4282: (u'view/contents_table', 96, 34), 179: (u'here/main_template/macros/master', 4, 23), 179: (u'here/main_template/macros/master', 4, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133987186712528 = {u'value': u'', }
_static_133987186754576 = {u'class': u'input-group input-group-append', }
_static_133987276028048 = __compile_zt_expr
_static_133987186646544 = {u'action': u'string:${context/absolute_url}/add_worksheet', u'method': u'POST', u'enctype': u'multipart/form-data', u'class': u'form form-inline', u'name': u'worksheet-add-form', }
_static_133987186748112 = {u'value': u'python:option', }
_static_133987186763984 = {u'class': u'input-group input-group-append', }
_static_133987184390672 = {u'src': u'view/icon', }
_static_133987186705488 = {u'data-style': u'dropdown-toggle btn-sm btn-light border rounded-0', u'data-live-search': u'true', u'name': u'analyst', u'class': u'analyst selectpicker', }
_static_133987186708816 = {u'data-style': u'dropdown-toggle btn-sm btn-light border rounded-0', u'data-live-search': u'true', u'name': u'template', u'class': u'template selectpicker', }
_static_133987276028432 = __C2ZContextWrapper
_static_133987186749136 = {u'type': u'hidden', u'name': u'submitted', u'value': u'1', }
_static_133987186622992 = {u'id': u'folderlisting-main-table', }
_static_133987186717072 = {u'class': u'input-group-prepend', }
_static_133987186707088 = {u'class': u'input-group-text', }
_static_133987186717648 = {u'class': u'input-group input-group-sm flex-nowrap d-inline-flex w-auto', }
_static_133987359720592 = {}
_static_133987182757584 = {u'data-style': u'dropdown-toggle btn-sm btn-light border rounded-0', u'data-live-search': u'true', u'name': u'instrument', u'class': u'instrument selectpicker form-control form-control-sm', }
_static_133987184239760 = u'master'
_static_133987186801232 = {u'value': u'', }
_static_133987167355792 = {u'value': u'', }
_static_133987186667664 = {u'href': u"python:view.context_actions[add_item]['url']", u'type': u'submit', u'class': u'btn btn-sm btn-primary', u'value': u'add_item', u'name': u'add_item', }
_static_133987186756560 = {u'value': u'python:option', }
_static_133987186644368 = {u'class': u'worksheet_add_controls mb-2', }
_static_133987186798736 = {u'class': u'input-group input-group-append', }
_static_133987186764944 = {u'value': u'python:option', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184240208
            __attrs_133987184240208 = _static_133987359720592
            __previous_i18n_domain_133987184239440 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_133987151384160 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79dc52856490> name=None at 79dc52856110> -> __value
            __value = _static_133987184239760
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186686928
                __attrs_133987186686928 = _static_133987359720592
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186686544
                __attrs_133987186686544 = _static_133987359720592

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1>\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc5287b210> name=None at 79dc52aab990> -> __attrs_133987167006864
                __attrs_133987167006864 = _static_133987184390672

                # <Value u'view/icon | nothing' (10:28)> -> __condition
                __token = 408
                try:
                    __zt_tmp = __attrs_133987167006864
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'view/icon | nothing', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987166309648
                    __default_133987166309648 = _DEFAULT_MARKER

                    # <Substitution u'view/icon' (11:33)> -> __attr_src
                    __token = 463
                    try:
                        __zt_tmp = __attrs_133987167006864
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_src = _static_133987276028048('path', u'view/icon', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_src is not None):
                        __append((u' src="%s"' % __attr_src))
                    __append(u'/>')
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186644432
                __attrs_133987186644432 = _static_133987359720592

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186643536
                __default_133987186643536 = _DEFAULT_MARKER

                # <Value u'view/title' (12:37)> -> __cache_133987186644048
                __token = 514
                try:
                    __zt_tmp = __attrs_133987186644432
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186644048 = _static_133987276028048('path', u'view/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/title' (12:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52aa1150> -> __condition
                __expression = __cache_133987186644048

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span/>')
                else:
                    __content = __cache_133987186644048
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n      </h1>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52aa1590> name=None at 79dc52aabed0> -> __attrs_133987186645904
                __attrs_133987186645904 = _static_133987186644368

                # <Value u'python:view.can_add()' (16:26)> -> __condition
                __token = 618
                try:
                    __zt_tmp = __attrs_133987186645904
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('python', u'view.can_add()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="worksheet_add_controls mb-2">\r\n\r\n        ')

                    # <Static value=<_ast.Dict object at 0x79dc52aa1e10> name=None at 79dc52aa1e50> -> __attrs_133987186718480
                    __attrs_133987186718480 = _static_133987186646544

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form class="form form-inline"               name="worksheet-add-form"               method="POST"               enctype="multipart/form-data"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186716816
                    __default_133987186716816 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}/add_worksheet' (22:37)> -> __attr_action
                    __token = 837
                    try:
                        __zt_tmp = __attrs_133987186718480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('string', u'${context/absolute_url}/add_worksheet', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab33d0> name=None at 79dc52ab35d0> -> __attrs_133987186719184
                    __attrs_133987186719184 = _static_133987186717648

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group input-group-sm flex-nowrap d-inline-flex w-auto">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab3190> name=None at 79dc52ab3e10> -> __attrs_133987186720080
                    __attrs_133987186720080 = _static_133987186717072

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab0a90> name=None at 79dc52ab09d0> -> __attrs_133987186704720
                    __attrs_133987186704720 = _static_133987186707088

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')
                    __stream_133987186707216 = []
                    __append_133987186707216 = __stream_133987186707216.append
                    __append_133987186707216(u'\r\n                Create new worksheet\r\n              ')
                    __msgid_133987186707216 = __re_whitespace(''.join(__stream_133987186707216)).strip()
                    if __msgid_133987186707216:
                        __append(translate(__msgid_133987186707216, mapping=None, default=__msgid_133987186707216, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\r\n            </div>\r\n            <!-- Analyst -->\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab0450> name=None at 79dc52ab0410> -> __attrs_133987186704464
                    __attrs_133987186704464 = _static_133987186705488
                    __backup_alist_133987186718608 = get('alist', __marker)

                    # <Value u'view/getAnalysts' (35:38)> -> __value
                    __token = 1448
                    try:
                        __zt_tmp = __attrs_133987186704464
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133987276028048('path', u'view/getAnalysts', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    econtext['alist'] = __value

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select name="analyst"                     class="analyst selectpicker"                     data-style="dropdown-toggle btn-sm btn-light border rounded-0"                     data-live-search="true">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5183c390> name=None at 79dc52ab0c10> -> __attrs_133987186755664
                    __attrs_133987186755664 = _static_133987167355792

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option value="">')
                    __stream_133987186706448 = []
                    __append_133987186706448 = __stream_133987186706448.append
                    __append_133987186706448(u'Select analyst')
                    __msgid_133987186706448 = __re_whitespace(''.join(__stream_133987186706448)).strip()
                    if __msgid_133987186706448:
                        __append(translate(__msgid_133987186706448, mapping=None, default=__msgid_133987186706448, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</option>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186755472
                    __attrs_133987186755472 = _static_133987359720592
                    __backup_option_133987186707600 = get('option', __marker)

                    # <Value u'alist' (37:42)> -> __iterator
                    __token = 1584
                    try:
                        __zt_tmp = __attrs_133987186755472
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_133987276028048('path', u'alist', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    (__iterator, ____index_133987186753808, ) = getitem('repeat')(u'option', __iterator)
                    econtext['option'] = None
                    for __item in __iterator:
                        econtext['option'] = __item
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79dc52abcbd0> name=None at 79dc52abcfd0> -> __attrs_133987186757520
                        __attrs_133987186757520 = _static_133987186756560

                        # <Value u'python:option' (39:33)> -> __condition
                        __token = 1651
                        try:
                            __zt_tmp = __attrs_133987186757520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_133987276028048('python', u'option', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        if __condition:

                            # <option ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<option')

                            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186757264
                            __default_133987186757264 = _DEFAULT_MARKER

                            # <Substitution u'python:option' (40:40)> -> __attr_value
                            __token = 1707
                            try:
                                __zt_tmp = __attrs_133987186757520
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_133987276028048('python', u'option', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))
                            __append(u'>')

                            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186754192
                            __default_133987186754192 = _DEFAULT_MARKER

                            # <Value u'python:alist.getValue(option)' (41:31)> -> __cache_133987186756048
                            __token = 1754
                            try:
                                __zt_tmp = __attrs_133987186757520
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_133987186756048 = _static_133987276028048('python', u'alist.getValue(option)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                            # <BinOp left=<Value u'python:alist.getValue(option)' (41:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52abc8d0> -> __condition
                            __expression = __cache_133987186756048

                            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                pass
                            else:
                                __content = __cache_133987186756048
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</option>')
                        __append(u'\r\n              ')
                        ____index_133987186753808 -= 1
                        if (____index_133987186753808 > 0):
                            __append('')
                    if (__backup_option_133987186707600 is __marker):
                        del econtext['option']
                    else:
                        econtext['option'] = __backup_option_133987186707600
                    __append(u'\r\n            </select>')
                    if (__backup_alist_133987186718608 is __marker):
                        del econtext['alist']
                    else:
                        econtext['alist'] = __backup_alist_133987186718608
                    __append(u'\r\n            <!-- Worksheet Template -->\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52abc410> name=None at 79dc52abc710> -> __attrs_133987186754320
                    __attrs_133987186754320 = _static_133987186754576

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group input-group-append">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab1150> name=None at 79dc52ab1190> -> __attrs_133987186710416
                    __attrs_133987186710416 = _static_133987186708816
                    __backup_wstlist_133987186755216 = get('wstlist', __marker)

                    # <Value u'view/getWorksheetTemplates' (50:42)> -> __value
                    __token = 2207
                    try:
                        __zt_tmp = __attrs_133987186710416
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133987276028048('path', u'view/getWorksheetTemplates', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    econtext['wstlist'] = __value

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select name="template"                       class="template selectpicker"                       data-style="dropdown-toggle btn-sm btn-light border rounded-0"                       data-live-search="true">\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab1fd0> name=None at 79dc52ab1450> -> __attrs_133987186761872
                    __attrs_133987186761872 = _static_133987186712528

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option value="">')
                    __stream_133987186708560 = []
                    __append_133987186708560 = __stream_133987186708560.append
                    __append_133987186708560(u'Select template')
                    __msgid_133987186708560 = __re_whitespace(''.join(__stream_133987186708560)).strip()
                    if __msgid_133987186708560:
                        __append(translate(__msgid_133987186708560, mapping=None, default=__msgid_133987186708560, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</option>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186764112
                    __attrs_133987186764112 = _static_133987359720592
                    __backup_option_133987186754000 = get('option', __marker)

                    # <Value u'wstlist' (52:44)> -> __iterator
                    __token = 2358
                    try:
                        __zt_tmp = __attrs_133987186764112
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_133987276028048('path', u'wstlist', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    (__iterator, ____index_133987186764048, ) = getitem('repeat')(u'option', __iterator)
                    econtext['option'] = None
                    for __item in __iterator:
                        econtext['option'] = __item
                        __append(u'\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x79dc52abec90> name=None at 79dc52abec50> -> __attrs_133987186762576
                        __attrs_133987186762576 = _static_133987186764944

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186765776
                        __default_133987186765776 = _DEFAULT_MARKER

                        # <Substitution u'python:option' (54:42)> -> __attr_value
                        __token = 2438
                        try:
                            __zt_tmp = __attrs_133987186762576
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_133987276028048('python', u'option', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186763216
                        __default_133987186763216 = _DEFAULT_MARKER

                        # <Value u'python:wstlist.getValue(option)' (55:33)> -> __cache_133987186764688
                        __token = 2487
                        try:
                            __zt_tmp = __attrs_133987186762576
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133987186764688 = _static_133987276028048('python', u'wstlist.getValue(option)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:wstlist.getValue(option)' (55:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52abead0> -> __condition
                        __expression = __cache_133987186764688

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133987186764688
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>\r\n                ')
                        ____index_133987186764048 -= 1
                        if (____index_133987186764048 > 0):
                            __append('')
                    if (__backup_option_133987186754000 is __marker):
                        del econtext['option']
                    else:
                        econtext['option'] = __backup_option_133987186754000
                    __append(u'\r\n              </select>')
                    if (__backup_wstlist_133987186755216 is __marker):
                        del econtext['wstlist']
                    else:
                        econtext['wstlist'] = __backup_wstlist_133987186755216
                    __append(u'\r\n            </div>\r\n            <!-- Instrument -->\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52abe8d0> name=None at 79dc52abe0d0> -> __attrs_133987186762128
                    __attrs_133987186762128 = _static_133987186763984

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group input-group-append">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc526ec6d0> name=None at 79dc526ecd50> -> __attrs_133987186801040
                    __attrs_133987186801040 = _static_133987182757584
                    __backup_instrlist_133987186720208 = get('instrlist', __marker)

                    # <Value u'view/getInstruments' (65:44)> -> __value
                    __token = 2993
                    try:
                        __zt_tmp = __attrs_133987186801040
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133987276028048('path', u'view/getInstruments', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    econtext['instrlist'] = __value

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select name="instrument"                       class="instrument selectpicker form-control form-control-sm"                       data-style="dropdown-toggle btn-sm btn-light border rounded-0"                       data-live-search="true">\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79dc52ac7a50> name=None at 79dc52ac73d0> -> __attrs_133987186800784
                    __attrs_133987186800784 = _static_133987186801232

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option value="">')
                    __stream_133987186802576 = []
                    __append_133987186802576 = __stream_133987186802576.append
                    __append_133987186802576(u'Select instrument')
                    __msgid_133987186802576 = __re_whitespace(''.join(__stream_133987186802576)).strip()
                    if __msgid_133987186802576:
                        __append(translate(__msgid_133987186802576, mapping=None, default=__msgid_133987186802576, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</option>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186799696
                    __attrs_133987186799696 = _static_133987359720592
                    __backup_option_133987186763280 = get('option', __marker)

                    # <Value u'instrlist' (67:44)> -> __iterator
                    __token = 3139
                    try:
                        __zt_tmp = __attrs_133987186799696
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_133987276028048('path', u'instrlist', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    (__iterator, ____index_133987186801552, ) = getitem('repeat')(u'option', __iterator)
                    econtext['option'] = None
                    for __item in __iterator:
                        econtext['option'] = __item
                        __append(u'\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x79dc52abaad0> name=None at 79dc52abaa90> -> __attrs_133987186748560
                        __attrs_133987186748560 = _static_133987186748112

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186747856
                        __default_133987186747856 = _DEFAULT_MARKER

                        # <Substitution u'python:option' (69:42)> -> __attr_value
                        __token = 3221
                        try:
                            __zt_tmp = __attrs_133987186748560
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_133987276028048('python', u'option', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186745808
                        __default_133987186745808 = _DEFAULT_MARKER

                        # <Value u'python:instrlist.getValue(option)' (70:33)> -> __cache_133987186747152
                        __token = 3270
                        try:
                            __zt_tmp = __attrs_133987186748560
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133987186747152 = _static_133987276028048('python', u'instrlist.getValue(option)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:instrlist.getValue(option)' (70:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52aba810> -> __condition
                        __expression = __cache_133987186747152

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133987186747152
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>\r\n                ')
                        ____index_133987186801552 -= 1
                        if (____index_133987186801552 > 0):
                            __append('')
                    if (__backup_option_133987186763280 is __marker):
                        del econtext['option']
                    else:
                        econtext['option'] = __backup_option_133987186763280
                    __append(u'\r\n              </select>')
                    if (__backup_instrlist_133987186720208 is __marker):
                        del econtext['instrlist']
                    else:
                        econtext['instrlist'] = __backup_instrlist_133987186720208
                    __append(u'\r\n            </div>\r\n            <!-- Add button -->\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52ac7090> name=None at 79dc52ac71d0> -> __attrs_133987186748752
                    __attrs_133987186748752 = _static_133987186798736

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group input-group-append">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186746704
                    __attrs_133987186746704 = _static_133987359720592
                    __backup_add_item_133987186717904 = get('add_item', __marker)

                    # <Value u'python:view.context_actions.keys()' (76:48)> -> __iterator
                    __token = 3524
                    try:
                        __zt_tmp = __attrs_133987186746704
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_133987276028048('python', u'view.context_actions.keys()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    (__iterator, ____index_133987186746256, ) = getitem('repeat')(u'add_item', __iterator)
                    econtext['add_item'] = None
                    for __item in __iterator:
                        econtext['add_item'] = __item
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79dc52aa7090> name=None at 79dc52aba5d0> -> __attrs_133987186669776
                        __attrs_133987186669776 = _static_133987186667664

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="submit"                        class="btn btn-sm btn-primary"')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186668880
                        __default_133987186668880 = _DEFAULT_MARKER

                        # <Substitution u'add_item' (79:44)> -> __attr_name
                        __token = 3699
                        try:
                            __zt_tmp = __attrs_133987186669776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_133987276028048('path', u'add_item', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186670096
                        __default_133987186670096 = _DEFAULT_MARKER

                        # <Substitution u'add_item' (80:34)> -> __attr_value
                        __token = 3744
                        try:
                            __zt_tmp = __attrs_133987186669776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_133987276028048('path', u'add_item', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186669264
                        __default_133987186669264 = _DEFAULT_MARKER

                        # <Substitution u"python:view.context_actions[add_item]['url']" (81:32)> -> __attr_href
                        __token = 3788
                        try:
                            __zt_tmp = __attrs_133987186669776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_133987276028048('python', u"view.context_actions[add_item]['url']", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'/>\r\n              ')
                        ____index_133987186746256 -= 1
                        if (____index_133987186746256 > 0):
                            __append('')
                    if (__backup_add_item_133987186717904 is __marker):
                        del econtext['add_item']
                    else:
                        econtext['add_item'] = __backup_add_item_133987186717904
                    __append(u'\r\n            </div>\r\n          </div>\r\n\r\n          <!-- hidden fields -->\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc52abaed0> name=None at 79dc52aba250> -> __attrs_133987186669712
                    __attrs_133987186669712 = _static_133987186749136

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="submitted" value="1" />\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186624976
                    __attrs_133987186624976 = _static_133987359720592

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186622672
                    __default_133987186622672 = _DEFAULT_MARKER

                    # <Value u'context/@@authenticator/authenticator' (88:40)> -> __cache_133987186671056
                    __token = 4050
                    try:
                        __zt_tmp = __attrs_133987186624976
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987186671056 = _static_133987276028048('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'context/@@authenticator/authenticator' (88:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52aa7b90> -> __condition
                    __expression = __cache_133987186671056

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input/>')
                    else:
                        __content = __cache_133987186671056
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n\r\n        </form>\r\n      </div>')
                __append(u'\r\n    ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186685520
                __attrs_133987186685520 = _static_133987359720592
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52a9c210> name=None at 79dc52a9c250> -> __attrs_133987186624272
                __attrs_133987186624272 = _static_133987186622992

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="folderlisting-main-table">')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186623440
                __default_133987186623440 = _DEFAULT_MARKER

                # <Value u'view/contents_table' (96:34)> -> __cache_133987186623312
                __token = 4282
                try:
                    __zt_tmp = __attrs_133987186624272
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186623312 = _static_133987276028048('path', u'view/contents_table', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/contents_table' (96:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52a9c510> -> __condition
                __expression = __cache_133987186623312

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_133987186623312
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\r\n    ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (4:23)> -> __macro
            __token = 179
            try:
                __zt_tmp = __attrs_133987184240208
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133987276028048('path', u'here/main_template/macros/master', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __token = 179
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133987151384160 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133987151384160
            __i18n_domain = __previous_i18n_domain_133987184239440
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }