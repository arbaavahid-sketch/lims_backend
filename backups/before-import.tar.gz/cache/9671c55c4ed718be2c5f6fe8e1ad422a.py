# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/bika/lims/browser/analysisrequest/templates/ar_add2.pt'

__tokens = {352: (u'context/@@plone_portal_state/portal', 9, 36), 464: (u"python:portal.absolute_url() + '/senaite_widgets/datetimewidget.js'", 11, 34), 616: (u"python:portal.absolute_url() + '/senaite_widgets/rejectionwidget.js'", 13, 34), 851: (u'string:${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.analysisrequest.add.js', 17, 34), 1060: (u'string:${portal/absolute_url}/++plone++senaite.core.static/css/senaite.core.analysisrequest.add.css', 19, 33), 1349: (u'string:Enter {{fieldLabel}} fields', 25, 35), 1519: (u'python:range(view.ar_count)', 27, 67), 1580: (u'python: arnum + 1', 27, 128), 4521: (u'senaite_theme/icon_url/accredited', 102, 39), 11590: (u'senaite_theme/icon_url/sample', 309, 33), 11754: (u"python:checkPermission('senaite.core: Add AnalysisRequest', context)", 313, 29), 12021: (u'string:${context/absolute_url}/ar_add', 318, 39), 12154: (u'request/copy_from|nothing', 320, 58), 12461: (u'python:view.ar_count or 1', 327, 43), 12757: (u'senaite_theme/icon_url/plus', 333, 43), 12827: (u'python:1', 334, 38), 13165: (u'context/@@plone_portal_state/portal', 348, 28), 13228: (u' context/portal_membership/getAuthenticatedMembe', 349, 25), 13315: (u'l python:view.get_currency().symb', 350, 35), 13612: (u'portal/absolute_url', 357, 78), 13673: (u'context/@@authenticator/authenticator', 358, 37), 13799: (u'view/came_from', 360, 54), 13915: (u'view/ar_count', 362, 37), 14127: (u'python:view.get_copy_from()', 366, 47), 14050: (u'python:range(view.ar_count)', 365, 43), 14211: (u"python:'_source_uid-{}'.format(arnum)", 367, 53), 14299: (u' python:copy_from.get(arnum', 368, 48), 14377: (u'd python:source_obj.UID() if source_obj else No', 369, 47), 14498: (u'source_uid', 371, 34), 14551: (u'source_uid_key', 372, 40), 14608: (u' source_ui', 373, 40), 14816: (u'python:range(view.ar_count)', 378, 41), 14902: (u'string:nav-item nav-item-${arnum}', 379, 55), 14978: (u"python:'nav-link active' if arnum == 0 else 'nav-link'", 380, 39), 15093: (u' string:${arnum', 381, 58), 15155: (u't string:sample-column-${arnu', 382, 43), 15307: (u'python: arnum + 1', 385, 35), 15713: (u"python:user.has_role('LabManager') or user.has_role('Manager')", 397, 46), 16012: (u"python:context.absolute_url() + '/ar_add_manage'", 403, 36), 16357: (u"python:view.get_fields_with_visibility('edit')", 413, 39), 16443: (u'python:field.widget', 414, 36), 16503: (u' python:field.getName(', 415, 38), 16567: (u'l python:view.context.translate(widget.Label(here', 416, 38), 16656: (u'ed python:bool(field.requir', 417, 35), 16721: (u'ors pytho', 418, 32), 16766: (u"mode python:'", 419, 29), 16873: (u'python:fieldName', 421, 44), 16936: (u' python:fieldLabe', 422, 44), 17119: (u"python:required and 'text-primary' or ''", 426, 44), 17197: (u'python:fieldLabel', 427, 35), 17366: (u'required', 431, 41), 17622: (u'python:view.context.translate(widget.Description(here))', 435, 50), 17788: (u'string:${fieldName}_help', 437, 45), 17729: (u'description', 436, 49), 17976: (u'python:view.show_copy_button_for(field)', 441, 58), 18363: (u'python:fieldName', 448, 49), 18431: (u' python:fieldLabe', 449, 49), 18880: (u'python:view.show_paste_button_for(field)', 458, 38), 18972: (u'python:fieldName', 459, 49), 19040: (u' python:fieldLabe', 460, 49), 19240: (u'python:range(view.ar_count)', 466, 47), 19318: (u'python:view.get_fieldname(field, arnum)', 467, 47), 19397: (u' string: sample-column sample-column-${arnum', 468, 37), 19481: (u"s python:cls + ' d-none' if arnum > 0 else c", 469, 36), 19575: (u'python:cls', 470, 44), 19631: (u' arnu', 471, 43), 19686: (u'e newFieldNa', 472, 46), 19811: (u"python:view.get_input_widget(fieldName, arnum, mode='edit')", 474, 44), 19811: (u"python:view.get_input_widget(fieldName, arnum, mode='edit')", 474, 44), 20078: (u"python:view.get_fields_with_visibility('hidden')", 483, 39), 20169: (u'python:field.getName()', 484, 39), 20261: (u'fieldName', 485, 65), 20321: (u'python:range(view.ar_count)', 486, 47), 20399: (u'python:view.get_fieldname(field, arnum)', 487, 47), 20478: (u' python:view.fieldvalues.get(newFieldName', 488, 37), 20559: (u"l python:'' if not val else v", 489, 36), 20638: (u'python:arnum', 490, 44), 20661: (u' python:newFieldNam', 490, 67), 20776: (u'val/UID|val|nothing', 492, 49), 20845: (u' newFieldNam', 493, 47), 21064: (u'python:view.get_points_of_capture()', 501, 35), 21195: (u'python:view.get_services(poc)', 503, 54), 21282: (u' python:view.get_service_categories(', 504, 55), 21374: (u't python:view.ar_cou', 505, 52), 21448: (u'python:any(services.values())', 506, 48), 21521: (u'poc', 508, 38), 21569: (u' po', 509, 42), 21614: (u's string:${poc} service-listing-header field-services-head', 510, 38), 21804: (u"python:poc=='field'", 513, 41), 21980: (u"python:poc=='lab'", 517, 41), 22204: (u'python:1 + ar_count', 523, 44), 22865: (u'categories', 538, 51), 23013: (u'python:category.getId', 540, 54), 23093: (u' python:category.Titl', 541, 56), 22925: (u'python:services[category_title]', 539, 45), 23280: (u'python:category_id', 544, 52), 23342: (u' python:po', 545, 41), 23401: (u"y python:'fiel", 546, 45), 23461: (u"ss python:'{} category'.format(p", 547, 41), 23662: (u'category_title', 550, 41), 23911: (u'category_id', 556, 60), 24156: (u'python:ar_count', 560, 48), 24259: (u'python:services[category_title]', 563, 52), 24343: (u'python:service.UID', 564, 48), 24410: (u' python:service.getI', 565, 46), 24484: (u'd python:service.getKeywo', 566, 50), 24561: (u'le python:service.Ti', 567, 47), 24631: (u'python:service_id', 568, 43), 24696: (u" python:'{} {} service'.format(category_id, poc", 569, 45), 24789: (u'c python:p', 570, 42), 24850: (u'id python:service_', 571, 46), 24923: (u'ord python:service_key', 572, 49), 25001: (u'gory python:catego', 573, 49), 25071: (u"dname python:'Ana", 574, 44), 25298: (u'service_title', 578, 42), 25509: (u'python:view.show_copy_button_for()', 583, 64), 26086: (u'python:range(ar_count)', 594, 53), 26162: (u"python:'Analyses-{}'.format(arnum)", 595, 50), 26247: (u' python:view.fieldvalues.get(fieldname) or [', 596, 48), 26346: (u's python:map(view.get_service_uid_from, analyse', 597, 51), 26443: (u'ed python:service_uid in service_u', 598, 45), 26523: (u"cls python:'{}-column service-column'.format(service_", 599, 40), 26622: (u' cls string: ${cls} sample-column sample-column-${a', 600, 39), 26719: (u"  cls python:cls + ' d-none' if arnum > 0 el", 601, 38), 26827: (u"python:'Analyses-{}'.format(arnum)", 602, 54), 26911: (u' python:service_ui', 603, 47), 26981: (u's python:c', 604, 48), 27043: (u'um python:ar', 605, 47), 27174: (u'python:service_uid', 608, 51), 27247: (u' python:arnu', 609, 52), 27311: (u"d python:'{}-{}-lockbtn'.format(service_uid, arnu", 610, 48), 27415: (u"ss python:'service-lockbtn {}-lockbtn'.format(service_u", 611, 50), 27839: (u'python:service_uid', 618, 51), 27912: (u' python:arnu', 619, 52), 27976: (u"d python:'{}-{}-beyondholdingtime'.format(service_uid, arnu", 620, 48), 28090: (u"ss python:'service-beyondholdingtime {}-beyondholdingtime'.format(service_u", 621, 50), 28560: (u"python:'{}-{}-analysisservice'.format(service_uid, arnum)", 628, 50), 28672: (u" python:'analysisservice {}-analysisservice'.format(service_uid", 629, 52), 28906: (u"python:'{}:list'.format(fieldname)", 632, 56), 28999: (u' python:service_ui', 633, 56), 29076: (u"s python:'analysisservice-cb analysisservice-cb-{}'.format(arnu", 634, 55), 29195: (u"id python:'cb_{}_{}'.format(arnum, service_u", 635, 51), 29296: (u'alt python:service_t', 636, 51), 29377: (u"cked python:checked and 'checked' ", 637, 54), 29565: (u'python:service_uid', 641, 51), 29638: (u' python:arnu', 642, 52), 29702: (u"d python:'{}-infobtn'.format(service_ui", 643, 48), 29796: (u"ss python:'service-infobtn {}-infobtn'.format(service_u", 644, 50), 30035: (u"python:'{}-info'.format(service_uid)", 649, 50), 30126: (u" python:'{}-info service-info'.format(service_uid", 650, 52), 30322: (u"python:'{}-conditions'.format(service_uid)", 654, 50), 30419: (u" python:'{}-conditions service-conditions'.format(service_uid", 655, 52), 30908: (u'python:view.ShowPrices', 670, 37), 30965: (u'python:view.getMemberDiscountApplies()', 671, 31), 31168: (u'python:context.bika_setup.getMemberDiscount()', 674, 56), 31303: (u'currency_symbol', 677, 35), 31385: (u'python:range(view.ar_count)', 679, 41), 31458: (u'python:arnum', 680, 42), 31574: (u"python:'discount-{}'.format(arnum)", 682, 43), 31894: (u'currency_symbol', 691, 35), 31976: (u'python:range(view.ar_count)', 693, 41), 32049: (u'python:arnum', 694, 42), 32165: (u"python:'subtotal-{}'.format(arnum)", 696, 43), 32475: (u'currency_symbol', 705, 35), 32557: (u'python:range(view.ar_count)', 707, 41), 32630: (u'arnum', 708, 42), 32734: (u"python:'vat-{}'.format(arnum)", 710, 43), 33043: (u'currency_symbol', 719, 35), 33125: (u'python:range(view.ar_count)', 721, 41), 33198: (u'arnum', 722, 42), 33304: (u"python:'total-{}'.format(arnum)", 724, 43), 34546: (u'request/sample_uids|nothing', 756, 79), 179: (u'here/main_template/macros/master', 4, 23), 179: (u'here/main_template/macros/master', 4, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_127045737296272 = {u'class': u'fas fa-tasks', }
_static_127045737632528 = {u'class': u'service-profiles', }
_static_127045737763024 = {u'src': u'#', u'height': u'16', }
_static_127045737749264 = {u'name': u'ar_count', u'min': u'1', u'max': u'99', u'value': u'python:view.ar_count or 1', u'type': u'number', u'class': u'form-control form-control-sm', }
_static_127045737210640 = {u'style': u'height:auto;', u'checked': u"python:checked and 'checked' or ''", u'name': u"python:'{}:list'.format(fieldname)", u'value': u'python:service_uid', u'class': u"python:'analysisservice-cb analysisservice-cb-{}'.format(arnum)", u'alt': u'python:service_title', u'type': u'checkbox', u'id': u"python:'cb_{}_{}'.format(arnum, service_uid)", }
_static_127045736792720 = {u'class': u'price discount noborder', u'id': u"python:'discount-{}'.format(arnum)", }
_static_127045736872400 = {u'class': u'price vat noborder', u'id': u"python:'vat-{}'.format(arnum)", }
_static_127045737604944 = {u'class': u'service-info-key', }
_static_127045737574608 = {u'type': u'text/x-handlebars-template', u'id': u'service-info', }
_static_127045737617872 = {u'class': u'service-info-value', }
_static_127045737562384 = {u'title': u'Remove Template', }
_static_127045737339024 = {u'fieldLabel': u'python:fieldLabel', u'title': u'Enter individual values for this field per sample', u'data_toggle': u'tooltip', u'href': u'#', u'fieldName': u'python:fieldName', u'class': u'paste d-block', }
_static_127045737338128 = {u'class': u'fas fa-angle-double-right', }
_static_127045736967824 = {u'type': u'hidden', u'name': u'sample_uids', u'value': u'', }
_static_127045738059152 = {u'class': u'line-numbers', }
_static_127045737710096 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.required:records', u'value': u'{{required}}', }
_static_127045738046032 = {u'type': u'text/x-handlebars-template', u'id': u'paste-template', }
_static_127045737270544 = {u'class': u'discreet', }
_static_127045737320080 = {u'class': u'fieldRequired', u'title': u'Required', }
_static_127045737473872 = {u'type': u'submit', u'class': u'btn btn-success btn-sm', u'value': u'Save', u'name': u'save_button', }
_static_127045738049296 = {u'class': u'paste-container', }
_static_127045737660944 = {u'title': u'Confirm', }
_static_127045737309392 = {u'fieldLabel': u'python:fieldLabel', u'fieldName': u'python:fieldName', u'class': u'ar-table-row', }
_static_127045737547728 = {u'class': u'service-profile-dependents', }
_static_127045736871120 = {u'arnum': u'arnum', }
_static_127045737748048 = {u'class': u'input-group', }
_static_127045737619152 = {u'class': u'service-dependency', }
_static_127045737795408 = {u'class': u'nav-item', }
_static_127045737794640 = {u'class': u'nav-item', }
_static_127045738047696 = {u'title': u'string:Enter {{fieldLabel}} fields', }
_static_127045737765392 = {u'method': u'POST', u'id': u'analysisrequest_add_form', u'name': u'analysisrequest_add_form', }
_static_127045737362896 = u"python:view.get_input_widget(fieldName, arnum, mode='edit')"
_static_127045737674384 = {u'class': u'service-conditions-table table table-condensed table-bordered', }
_static_127045737572752 = {u'title': u'Remove Profile', }
_static_127045737603152 = {u'class': u'service-info-value', }
_static_127045737269456 = {u'class': u'pricelabel discount', }
_static_127045737547152 = {u'type': u'text/x-handlebars-template', u'id': u'template-remove-template', }
_static_127045737728464 = {u'type': u'{{type}}', u'name': u'ServiceConditions-{{../arnum}}.value:records', u'value': u'{{default}}', }
_static_127045737475920 = {u'class': u'fas fa-filter', }
_static_127045737673168 = {u'data-fieldname': u'ServiceConditions-{{arnum}}', }
_static_127045737574992 = {u'class': u'dialog-profile-services dialog-listing', }
_static_127045737285072 = {u'data-primary-sample-index': u'0', u'href': u'#', u'class': u'nav-link', u'data-target': u'show-all', }
_static_127045736818960 = {u'arnum': u'python:arnum', }
_static_127045737181328 = {u'id': u"python:'{}-{}-beyondholdingtime'.format(service_uid, arnum)", u'class': u"python:'service-beyondholdingtime {}-beyondholdingtime'.format(service_uid)", u'uid': u'python:service_uid', u'arnum': u'python:arnum', u'title': u'This service cannot be selected to prevent the analysis from being conducted beyond the analytical holding time.', }
_static_127045737522064 = {u'class': u'services-category-header', }
_static_127045737317264 = {u'class': u'formQuestion', }
_static_127045738058576 = {u'type': u'text/x-handlebars-template', u'id': u'service-dependent-template', }
_static_127045737025296 = {u'class': u"python:'{} {} service'.format(category_id, poc)", u'data-category': u'python:category_id', u'id': u'python:service_id', u'fieldname': u"python:'Analyses'", u'data-uid': u'python:service_uid', u'data-keyword': u'python:service_keyword', u'poc': u'python:poc', }
_static_127045737739600 = {u'src': u'#', u'class': u'd-inline-block align-middle', u'width': u'32', }
_static_127045736945296 = {u'type': u'submit', u'class': u'btn btn-outline-secondary btn-sm', u'value': u'Cancel', u'name': u'cancel_button', }
_static_127045737548624 = {u'class': u'service-template-dependents', }
_static_127045736918480 = {u'type': u'submit', u'class': u'btn btn-outline-success btn-sm', u'value': u'Save and Copy', u'name': u'save_and_copy_button', }
_static_127045737627920 = {u'class': u'service-dependency', }
_static_127045736891216 = {u'class': u'pricelabel total', }
_static_127045737648784 = {u'class': u'service-info-value', }
_static_127045737786192 = {u'type': u'hidden', u'name': u'source_uid_key', u'value': u'source_uid', }
_static_127045737713040 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.choices:records', u'value': u'{{choices}}', }
_static_127045737322576 = {u'class': u'formHelp discreet help-block small', u'id': u'string:${fieldName}_help', }
_static_127045737694864 = {u'class': u'formHelp discreet help-block small', u'id': u'ServiceConditions-{{arnum}}_help', }
_static_127045737594320 = {u'class': u'service-info-key', }
_static_127045737289168 = {u'href': u"python:context.absolute_url() + '/ar_add_manage'", u'title': u'Manage Form Fields', u'target': u'_blank', u'class': u'nav-link', u'data-target': u'manage-form-fields', }
_static_127045737378896 = {u'fieldName': u'python:newFieldName', u'arnum': u'python:arnum', }
_static_127045737718928 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.description:records', u'value': u'{{description}}', }
_static_127045737742672 = {u'class': u'd-inline-block align-middle ml-2', }
_static_127045737613072 = {u'class': u'service-info-value', }
_static_127045737586512 = {u'class': u'service-info-value', }
_static_127045737688016 = {u'class': u'', }
_static_127045737634704 = {u'class': u'service-info-key', }
_static_127045737744080 = {u'action': u'ar_add', u'method': u'GET', u'class': u'form-inline', }
_static_127045737474448 = {u'class': u'input-group-text', }
_static_127045737350736 = {u'class': u'fas fa-list-ol', }
_static_127045736915024 = {u'arnum': u'arnum', }
_static_127045737585424 = {u'class': u'service-info-key', }
_static_127045737645392 = {u'class': u'service-templates', }
_static_127045737291408 = {u'class': u'ar-table table table-sm table-bordered', }
_static_127045737616720 = {u'class': u'service-info-key', }
_static_127045736916304 = {u'class': u'price total noborder', u'id': u"python:'total-{}'.format(arnum)", }
_static_127045737711504 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.report:records', u'value': u'{{report}}', }
_static_127045737445264 = {u'class': u'input-group', }
_static_127045736947600 = {u'type': u'hidden', u'id': u'confirmed', u'value': u'0', u'name': u'confirmed', }
_static_127045737070992 = {u'class': u'service-header', }
_static_127045737537680 = {u'class': u'line', }
_static_127045738043600 = {u'media': u'all', u'href': u'', u'type': u'text/css', u'rel': u'stylesheet', }
_static_127045737708304 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.type:records', u'value': u'{{type}}', }
_static_127045886978576 = __C2ZContextWrapper
_static_127045737091152 = {u'class': u'text-center', }
_static_127045737423504 = {u'colspan': u'2', }
_static_127045970670736 = {}
_static_127045737697040 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.uid:records', u'value': u'{{../uid}}', }
_static_127045736994064 = {u'class': u'ar-footer', }
_static_127045737351632 = {u'fieldName': u'newFieldName', u'class': u'python:cls', u'arnum': u'arnum', }
_static_127045737784336 = {u'style': u'margin-bottom:-1px;', u'class': u'nav nav-tabs float-right', u'id': u'sample-tabs', }
_static_127045737245328 = {u'id': u"python:'{}-info'.format(service_uid)", u'class': u"python:'{}-info service-info'.format(service_uid)", }
_static_127045737614416 = {u'class': u'service-methods', }
_static_127045737599568 = {u'class': u'service-info-value', }
_static_127045737686672 = {u'class': u'formQuestion', }
_static_127045736965968 = {u'type': u'hidden', u'name': u'submit_action', u'value': u'save', }
_static_127045737631184 = {u'class': u'service-info-value', }
_static_127045737769168 = {u'type': u'hidden', u'name': u'portal_url', u'value': u'', }
_static_127045737141200 = {u'id': u"python:'{}-{}-lockbtn'.format(service_uid, arnum)", u'class': u"python:'service-lockbtn {}-lockbtn'.format(service_uid)", u'uid': u'python:service_uid', u'arnum': u'python:arnum', u'title': u'Service cannot be deselected. Please click the info button for further details', }
_static_127045738036432 = {u'src': u"python:portal.absolute_url() + '/senaite_widgets/rejectionwidget.js'", u'type': u'text/javascript', }
_static_127045737021968 = {u'data-category': u'category_id', u'class': u'btn btn-default btn-xs service-category-toggle', }
_static_127045737565840 = {u'class': u'dialog-profile-service', }
_static_127045737546448 = {u'class': u'dialog-dependents dialog-listing', }
_static_127045737184272 = {u'id': u"python:'{}-{}-analysisservice'.format(service_uid, arnum)", u'class': u"python:'analysisservice {}-analysisservice'.format(service_uid)", }
_static_127045737757200 = {u'type': u'submit', u'class': u'btn btn-outline-secondary btn-sm', }
_static_127045737746320 = {u'type': u'hidden', u'name': u'copy_from', u'value': u'request/copy_from|nothing', }
_static_127045737381456 = {u'type': u'hidden', u'name': u'newFieldName', u'value': u'val/UID|val|nothing', }
_static_127045737630096 = {u'class': u'service-info-key', }
_static_127045737693264 = {u'class': u'fieldRequired', u'title': u'Required', }
_static_127045737767632 = {u'type': u'hidden', u'name': u'submitted', u'value': u'1', }
_static_127045737576272 = {u'class': u'dialog-profile-service', }
_static_127045737565264 = {u'type': u'text/x-handlebars-template', u'id': u'profile-remove-template', }
_static_127045737974864 = u'master'
_static_127045737092688 = {u'data_toggle': u'tooltip', u'class': u'copy d-block', u'title': u'Copy the currently displayed column value to the other columns on the right', }
_static_127045737494352 = {u'category': u"python:'field'", u'class': u"python:'{} category'.format(poc)", u'data-category': u'python:category_id', u'poc': u'python:poc', u'title': u'Click to expand this category', }
_static_127045737094992 = {u'class': u'fas fa-angle-double-right', }
_static_127045737446416 = {u'placeholder': u'Filter analyses by name...', u'type': u'text', u'class': u'form-control services-filter', u'data-poc': u'poc', }
_static_127045737741520 = {u'class': u'd-inline-block align-middle', }
_static_127045738060176 = {u'class': u'paste-editor', }
_static_127045737311632 = {u'class': u'field-label', }
_static_127045737675664 = {u'data-subfield': u'{{title}}', }
_static_127045737275984 = {u'data-primary-sample-index': u'string:${arnum}', u'href': u'#', u'class': u"python:'nav-link active' if arnum == 0 else 'nav-link'", u'data-target': u'string:sample-column-${arnum}', }
_static_127045736795024 = {u'class': u'pricelabel subtotal', }
_static_127045737646096 = {u'type': u'text/x-handlebars-template', u'id': u'confirm-template', }
_static_127045737317904 = {u'class': u'pl-3 pr-3', }
_static_127045737473168 = {u'class': u'input-group-append', }
_static_127045737540240 = {u'title': u'Service locked', }
_static_127045737706768 = {u'type': u'hidden', u'name': u'ServiceConditions-{{../arnum}}.title:records', u'value': u'{{title}}', }
_static_127045737685264 = {u'class': u'service-conditions-label', }
_static_127045737363984 = {u'style': u'display:none', u'fieldName': u'fieldName', }
_static_127045737776016 = {u'type': u'hidden', u'name': u'came_from', u'value': u'view/came_from', }
_static_127045737602000 = {u'class': u'service-info-key', }
_static_127045737626576 = {u'class': u'service-info-value', }
_static_127045737606032 = {u'class': u'service-info-value', }
_static_127045737319056 = {u'class': u"python:required and 'text-primary' or ''", }
_static_127045737650128 = {u'class': u'service-specs', }
_static_127045737583184 = {u'class': u'service-info-table table table-condensed table-bordered', }
_static_127045737687568 = {u'class': u'service-conditions-value', }
_static_127045737726352 = {u'required': u'required', u'type': u'{{type}}', u'name': u'ServiceConditions-{{../arnum}}.value:records', u'value': u'{{default}}', }
_static_127045737755984 = {u'class': u'input-group-append', }
_static_127045737661968 = {u'type': u'text/x-handlebars-template', u'id': u'service-conditions', }
_static_127045737333200 = {u'class': u'text-center', }
_static_127045737564560 = {u'class': u'dialog-profile-services dialog-listing', }
_static_127045737591952 = {u'src': u'senaite_theme/icon_url/accredited', u'class': u'service-info-accredited-image', u'title': u'Accredited Service', }
_static_127045737072976 = {u'class': u'service-title small', }
_static_127045736774928 = {u'arnum': u'python:arnum', }
_static_127045737284688 = {u'class': u'nav-item', }
_static_127045886978192 = __compile_zt_expr
_static_127045737644112 = {u'class': u'service-info-value', }
_static_127045737116688 = {u'fieldname': u"python:'Analyses-{}'.format(arnum)", u'uid': u'python:service_uid', u'arnum': u'python:arnum', u'class': u'python:cls', }
_static_127045737777744 = {u'type': u'hidden', u'id': u'ar_count', u'value': u'view/ar_count', u'name': u'ar_count', }
_static_127045737625488 = {u'class': u'service-info-key', }
_static_127045737334736 = {u'fieldLabel': u'python:fieldLabel', u'title': u'Copy the value of the first sample to the others', u'data_toggle': u'tooltip', u'href': u'#', u'fieldName': u'python:fieldName', u'class': u'copy d-block', }
_static_127045737396624 = {u'class': u'string:${poc} service-listing-header field-services-header', u'poc': u'poc', u'data-poc': u'poc', }
_static_127045737242896 = {u'class': u"python:'service-infobtn {}-infobtn'.format(service_uid)", u'uid': u'python:service_uid', u'arnum': u'python:arnum', u'id': u"python:'{}-infobtn'.format(service_uid)", }
_static_127045737424848 = {u'class': u'poc-service-title', }
_static_127045736820304 = {u'class': u'price subtotal noborder', u'id': u"python:'subtotal-{}'.format(arnum)", }
_static_127045738042192 = {u'src': u'bika.lims.analysisrequest.add.js', u'type': u'text/javascript', }
_static_127045737720464 = {u'name': u'ServiceConditions-{{../arnum}}.value:records', }
_static_127045736843216 = {u'class': u'pricelabel vat', }
_static_127045737422992 = {u'colspan': u'python:1 + ar_count', }
_static_127045738035088 = {u'src': u"python:portal.absolute_url() + '/senaite_widgets/datetimewidget.js'", u'type': u'text/javascript', }
_static_127045737611984 = {u'class': u'service-info-key', }
_static_127045737647568 = {u'class': u'service-info-key', }
_static_127045737524048 = {u'class': u'services-category-title', }
_static_127045737267472 = {u'id': u"python:'{}-conditions'.format(service_uid)", u'class': u"python:'{}-conditions service-conditions'.format(service_uid)", }
_static_127045737023440 = {u'colspan': u'python:ar_count', }
_static_127045737738448 = {u'id': u'ar-header', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737975120
            __attrs_127045737975120 = _static_127045970670736
            __previous_i18n_domain_127045737975248 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_127045756215616 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c24150c50> name=None at 738c24150c90> -> __value
            __value = _static_127045737974864
            econtext['macroname'] = __value

            def __fill_senaite_legacy_resources(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739686288
                __attrs_127045739686288 = _static_127045970670736
                __backup_portal_127045737975632 = get('portal', __marker)

                # <Value u'context/@@plone_portal_state/portal' (9:36)> -> __value
                __token = 352
                try:
                    __zt_tmp = __attrs_127045739686288
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'context/@@plone_portal_state/portal', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['portal'] = __value
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c2415f790> name=None at 738c2415f750> -> __attrs_127045738036048
                __attrs_127045738036048 = _static_127045738035088

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738035728
                __default_127045738035728 = _DEFAULT_MARKER

                # <Substitution u"python:portal.absolute_url() + '/senaite_widgets/datetimewidget.js'" (11:34)> -> __attr_src
                __token = 464
                try:
                    __zt_tmp = __attrs_127045738036048
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_127045886978192('python', u"portal.absolute_url() + '/senaite_widgets/datetimewidget.js'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'></script>\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c2415fcd0> name=None at 738c2415fc50> -> __attrs_127045738041616
                __attrs_127045738041616 = _static_127045738036432

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738037136
                __default_127045738037136 = _DEFAULT_MARKER

                # <Substitution u"python:portal.absolute_url() + '/senaite_widgets/rejectionwidget.js'" (13:34)> -> __attr_src
                __token = 616
                try:
                    __zt_tmp = __attrs_127045738041616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_127045886978192('python', u"portal.absolute_url() + '/senaite_widgets/rejectionwidget.js'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'></script>\r\n      <!-- AR Add form -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24161350> name=None at 738c24161310> -> __attrs_127045738043344
                __attrs_127045738043344 = _static_127045738042192

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738043024
                __default_127045738043024 = _DEFAULT_MARKER

                # <Substitution u'string:${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.analysisrequest.add.js' (17:34)> -> __attr_src
                __token = 851
                try:
                    __zt_tmp = __attrs_127045738043344
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_127045886978192('string', u'${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.analysisrequest.add.js', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', u'bika.lims.analysisrequest.add.js', _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u'               src="%s"' % __attr_src))
                __append(u'></script>\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c241618d0> name=None at 738c24161990> -> __attrs_127045738045328
                __attrs_127045738045328 = _static_127045738043600

                # <link ... (0:0)
                # --------------------------------------------------------
                __append(u'<link rel="stylesheet" type="text/css" media="all"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738045072
                __default_127045738045072 = _DEFAULT_MARKER

                # <Substitution u'string:${portal/absolute_url}/++plone++senaite.core.static/css/senaite.core.analysisrequest.add.css' (19:33)> -> __attr_href
                __token = 1060
                try:
                    __zt_tmp = __attrs_127045738045328
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_127045886978192('string', u'${portal/absolute_url}/++plone++senaite.core.static/css/senaite.core.analysisrequest.add.css', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'/>\r\n\r\n      <!-- Handlebars JS Templates -->\r\n\r\n      <!-- Add row paste popup -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24162250> name=None at 738c24162210> -> __attrs_127045738046992
                __attrs_127045738046992 = _static_127045738046032

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="paste-template" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c241628d0> name=None at 738c24162890> -> __attrs_127045738048464
                __attrs_127045738048464 = _static_127045738047696

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738048144
                __default_127045738048144 = _DEFAULT_MARKER

                # <Translate msgid=None node=<Substitution u'string:Enter {{fieldLabel}} fields' (25:35)> at 738c24162a10> -> __attr_title

                # <Substitution u'string:Enter {{fieldLabel}} fields' (25:35)> -> __attr_title
                __token = 1349
                try:
                    __zt_tmp = __attrs_127045738048464
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_title = _static_127045886978192('string', u'Enter {{fieldLabel}} fields', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c24162f10> name=None at 738c24162ed0> -> __attrs_127045738058192
                __attrs_127045738058192 = _static_127045738049296

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="paste-container">\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c24165590> name=None at 738c24165550> -> __attrs_127045738059728
                __attrs_127045738059728 = _static_127045738059152

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="line-numbers">')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045738060560
                __attrs_127045738060560 = _static_127045970670736
                __backup_arnum_127045738058512 = get('arnum', __marker)

                # <Value u'python:range(view.ar_count)' (27:67)> -> __iterator
                __token = 1519
                try:
                    __zt_tmp = __attrs_127045738060560
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045738060880, ) = getitem('repeat')(u'arnum', __iterator)
                econtext['arnum'] = None
                for __item in __iterator:
                    econtext['arnum'] = __item

                    # <Static value=<_ast.Dict object at 0x738c240e6090> name=None at 738c24165fd0> -> __attrs_127045737538256
                    __attrs_127045737538256 = _static_127045737537680

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="line">')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045738061648
                    __default_127045738061648 = _DEFAULT_MARKER

                    # <Value u'python: arnum + 1' (27:128)> -> __cache_127045738061328
                    __token = 1580
                    try:
                        __zt_tmp = __attrs_127045737538256
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045738061328 = _static_127045886978192('python', u' arnum + 1', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python: arnum + 1' (27:128)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24165e90> -> __condition
                    __expression = __cache_127045738061328

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_127045738061328
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n              ')
                    ____index_127045738060880 -= 1
                    if (____index_127045738060880 > 0):
                        __append('')
                if (__backup_arnum_127045738058512 is __marker):
                    del econtext['arnum']
                else:
                    econtext['arnum'] = __backup_arnum_127045738058512
                __append(u'\r\n            </div>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c24165990> name=None at 738c24165a50> -> __attrs_127045737538768
                __attrs_127045737538768 = _static_127045738060176

                # <textarea ... (0:0)
                # --------------------------------------------------------
                __append(u'<textarea class="paste-editor"></textarea>\r\n          </div>\r\n        </div>\r\n      </script>\r\n\r\n      <!-- Dependent services popup -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24165350> name=None at 738c24162750> -> __attrs_127045737539600
                __attrs_127045737539600 = _static_127045738058576

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="service-dependent-template" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240e6a90> name=None at 738c240e6a10> -> __attrs_127045737541072
                __attrs_127045737541072 = _static_127045737540240

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737540752
                __default_127045737540752 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c240e6bd0> at 738c240e6c10> -> __attr_title
                __attr_title = u'Service locked'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n          {{#with service}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737546064
                __attrs_127045737546064 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737541584 = []
                __append_127045737541584 = __stream_127045737541584.append
                __append_127045737541584(u'{{title}} cannot be deselected, because it is included in:')
                __msgid_127045737541584 = __re_whitespace(''.join(__stream_127045737541584)).strip()
                if __msgid_127045737541584:
                    __append(translate(__msgid_127045737541584, mapping=None, default=__msgid_127045737541584, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n          {{/with}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c240e82d0> name=None at 738c240e8290> -> __attrs_127045737547088
                __attrs_127045737547088 = _static_127045737546448

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dialog-dependents dialog-listing">\r\n            {{#if profiles}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240e87d0> name=None at 738c240e8790> -> __attrs_127045737548368
                __attrs_127045737548368 = _static_127045737547728

                # <dl ... (0:0)
                # --------------------------------------------------------
                __append(u'<dl class="service-profile-dependents">\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737549264
                __attrs_127045737549264 = _static_127045970670736

                # <dt ... (0:0)
                # --------------------------------------------------------
                __append(u'<dt>')
                __stream_127045737548944 = []
                __append_127045737548944 = __stream_127045737548944.append
                __append_127045737548944(u'Analysis Profiles')
                __msgid_127045737548944 = __re_whitespace(''.join(__stream_127045737548944)).strip()
                if __msgid_127045737548944:
                    __append(translate(__msgid_127045737548944, mapping=None, default=__msgid_127045737548944, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</dt>\r\n                {{#each profiles}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737549904
                __attrs_127045737549904 = _static_127045970670736

                # <dd ... (0:0)
                # --------------------------------------------------------
                __append(u'<dd>{{title}}</dd>\r\n                {{/each}}\r\n              </dl>\r\n            {{/if}}\r\n            {{#if templates}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240e8b50> name=None at 738c240e8a90> -> __attrs_127045737550672
                __attrs_127045737550672 = _static_127045737548624

                # <dl ... (0:0)
                # --------------------------------------------------------
                __append(u'<dl class="service-template-dependents">\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737551568
                __attrs_127045737551568 = _static_127045970670736

                # <dt ... (0:0)
                # --------------------------------------------------------
                __append(u'<dt>')
                __stream_127045737551248 = []
                __append_127045737551248 = __stream_127045737551248.append
                __append_127045737551248(u'AR Templates')
                __msgid_127045737551248 = __re_whitespace(''.join(__stream_127045737551248)).strip()
                if __msgid_127045737551248:
                    __append(translate(__msgid_127045737551248, mapping=None, default=__msgid_127045737551248, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</dt>\r\n                {{#each templates}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737552208
                __attrs_127045737552208 = _static_127045970670736

                # <dd ... (0:0)
                # --------------------------------------------------------
                __append(u'<dd>{{title}}</dd>\r\n                {{/each}}\r\n              </dl>\r\n            {{/if}}\r\n          </div>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737552272
                __attrs_127045737552272 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737551952 = []
                __append_127045737551952 = __stream_127045737551952.append
                __append_127045737551952(u'Please deselect these dependents first.')
                __msgid_127045737551952 = __re_whitespace(''.join(__stream_127045737551952)).strip()
                if __msgid_127045737551952:
                    __append(translate(__msgid_127045737551952, mapping=None, default=__msgid_127045737551952, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n        </div>\r\n      </script>\r\n\r\n      <!-- Remove dependent services popup -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c240e8590> name=None at 738c240e8690> -> __attrs_127045737553488
                __attrs_127045737553488 = _static_127045737547152

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="template-remove-template" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240ec110> name=None at 738c240ec0d0> -> __attrs_127045737563216
                __attrs_127045737563216 = _static_127045737562384

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737562896
                __default_127045737562896 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c240ec250> at 738c240ec290> -> __attr_title
                __attr_title = u'Remove Template'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737564112
                __attrs_127045737564112 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737563792 = []
                __append_127045737563792 = __stream_127045737563792.append
                __append_127045737563792(u'Do you also want to remove the templates services?')
                __msgid_127045737563792 = __re_whitespace(''.join(__stream_127045737563792)).strip()
                if __msgid_127045737563792:
                    __append(translate(__msgid_127045737563792, mapping=None, default=__msgid_127045737563792, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c240ec990> name=None at 738c240ec950> -> __attrs_127045737565200
                __attrs_127045737565200 = _static_127045737564560

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dialog-profile-services dialog-listing">\r\n            {{#each services}}\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240ece90> name=None at 738c240ece50> -> __attrs_127045737570640
                __attrs_127045737570640 = _static_127045737565840

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dialog-profile-service">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737571472
                __attrs_127045737571472 = _static_127045970670736

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>{{title}}</span>\r\n            </div>\r\n            {{/each}}\r\n          </div>\r\n        </div>\r\n      </script>\r\n\r\n      <!-- Remove Profile popup -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c240ecc50> name=None at 738c240ec590> -> __attrs_127045737572112
                __attrs_127045737572112 = _static_127045737565264

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="profile-remove-template" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240ee990> name=None at 738c240ee910> -> __attrs_127045737573584
                __attrs_127045737573584 = _static_127045737572752

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737573264
                __default_127045737573264 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c240eead0> at 738c240eeb10> -> __attr_title
                __attr_title = u'Remove Profile'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737574544
                __attrs_127045737574544 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737574160 = []
                __append_127045737574160 = __stream_127045737574160.append
                __append_127045737574160(u'Do you also want to remove the profiles services?')
                __msgid_127045737574160 = __re_whitespace(''.join(__stream_127045737574160)).strip()
                if __msgid_127045737574160:
                    __append(translate(__msgid_127045737574160, mapping=None, default=__msgid_127045737574160, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c240ef250> name=None at 738c240ef210> -> __attrs_127045737575632
                __attrs_127045737575632 = _static_127045737574992

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dialog-profile-services dialog-listing">\r\n            {{#each services}}\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240ef750> name=None at 738c240ef710> -> __attrs_127045737576912
                __attrs_127045737576912 = _static_127045737576272

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dialog-profile-service">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737577744
                __attrs_127045737577744 = _static_127045970670736

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>{{title}}</span>\r\n            </div>\r\n            {{/each}}\r\n          </div>\r\n        </div>\r\n      </script>\r\n\r\n      <!-- Service Info Template -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c240ef0d0> name=None at 738c240ef190> -> __attrs_127045737578448
                __attrs_127045737578448 = _static_127045737574608

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="service-info" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240f1250> name=None at 738c240f1210> -> __attrs_127045737583824
                __attrs_127045737583824 = _static_127045737583184

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="service-info-table table table-condensed table-bordered">\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737584656
                __attrs_127045737584656 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f1b10> name=None at 738c240f1ad0> -> __attrs_127045737586064
                __attrs_127045737586064 = _static_127045737585424

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737585296 = []
                __append_127045737585296 = __stream_127045737585296.append
                __append_127045737585296(u'Analysis Service')
                __msgid_127045737585296 = __re_whitespace(''.join(__stream_127045737585296)).strip()
                if __msgid_127045737585296:
                    __append(translate(__msgid_127045737585296, mapping=None, default=__msgid_127045737585296, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f1f50> name=None at 738c240f1f10> -> __attrs_127045737591312
                __attrs_127045737591312 = _static_127045737586512

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              {{#if accredited}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240f3490> name=None at 738c240f3450> -> __attrs_127045737593424
                __attrs_127045737593424 = _static_127045737591952

                # <img ... (0:0)
                # --------------------------------------------------------
                __append(u'<img')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737592720
                __default_127045737592720 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c240f36d0> at 738c240f3710> -> __attr_title
                __attr_title = u'Accredited Service'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'                    class="service-info-accredited-image"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737593168
                __default_127045737593168 = _DEFAULT_MARKER

                # <Substitution u'senaite_theme/icon_url/accredited' (102:39)> -> __attr_src
                __token = 4521
                try:
                    __zt_tmp = __attrs_127045737593424
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_127045886978192('path', u'senaite_theme/icon_url/accredited', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'>\r\n              {{/if}}\r\n              {{title}}\r\n            </td>\r\n          </tr>\r\n          {{#if keyword}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737593488
                __attrs_127045737593488 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f3dd0> name=None at 738c240f3d90> -> __attrs_127045737599120
                __attrs_127045737599120 = _static_127045737594320

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737594192 = []
                __append_127045737594192 = __stream_127045737594192.append
                __append_127045737594192(u'Keyword')
                __msgid_127045737594192 = __re_whitespace(''.join(__stream_127045737594192)).strip()
                if __msgid_127045737594192:
                    __append(translate(__msgid_127045737594192, mapping=None, default=__msgid_127045737594192, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f5250> name=None at 738c240f5210> -> __attrs_127045737600208
                __attrs_127045737600208 = _static_127045737599568

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737601040
                __attrs_127045737601040 = _static_127045970670736

                # <code ... (0:0)
                # --------------------------------------------------------
                __append(u'<code>{{keyword}}</code>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if unit}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737601104
                __attrs_127045737601104 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f5bd0> name=None at 738c240f5b90> -> __attrs_127045737602640
                __attrs_127045737602640 = _static_127045737602000

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737601872 = []
                __append_127045737601872 = __stream_127045737601872.append
                __append_127045737601872(u'Unit')
                __msgid_127045737601872 = __re_whitespace(''.join(__stream_127045737601872)).strip()
                if __msgid_127045737601872:
                    __append(translate(__msgid_127045737601872, mapping=None, default=__msgid_127045737601872, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f6050> name=None at 738c240f5fd0> -> __attrs_127045737603792
                __attrs_127045737603792 = _static_127045737603152

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              {{unit}}\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737604176
                __attrs_127045737604176 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f6750> name=None at 738c240f6710> -> __attrs_127045737605584
                __attrs_127045737605584 = _static_127045737604944

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737604816 = []
                __append_127045737604816 = __stream_127045737604816.append
                __append_127045737604816(u'Price')
                __msgid_127045737604816 = __re_whitespace(''.join(__stream_127045737604816)).strip()
                if __msgid_127045737604816:
                    __append(translate(__msgid_127045737604816, mapping=None, default=__msgid_127045737604816, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f6b90> name=None at 738c240f6b50> -> __attrs_127045737606672
                __attrs_127045737606672 = _static_127045737606032

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              {{currency_symbol}} {{price}}\r\n            </td>\r\n          </tr>\r\n          {{#if methods}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737607056
                __attrs_127045737607056 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f82d0> name=None at 738c240f8290> -> __attrs_127045737612624
                __attrs_127045737612624 = _static_127045737611984

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737611856 = []
                __append_127045737611856 = __stream_127045737611856.append
                __append_127045737611856(u'Methods')
                __msgid_127045737611856 = __re_whitespace(''.join(__stream_127045737611856)).strip()
                if __msgid_127045737611856:
                    __append(translate(__msgid_127045737611856, mapping=None, default=__msgid_127045737611856, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f8710> name=None at 738c240f86d0> -> __attrs_127045737613712
                __attrs_127045737613712 = _static_127045737613072

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240f8c50> name=None at 738c240f8c10> -> __attrs_127045737615056
                __attrs_127045737615056 = _static_127045737614416

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-methods">\r\n                {{#each methods}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737615952
                __attrs_127045737615952 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if dependencies}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737615120
                __attrs_127045737615120 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f9550> name=None at 738c240f9510> -> __attrs_127045737617360
                __attrs_127045737617360 = _static_127045737616720

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737616592 = []
                __append_127045737616592 = __stream_127045737616592.append
                __append_127045737616592(u'Dependencies')
                __msgid_127045737616592 = __re_whitespace(''.join(__stream_127045737616592)).strip()
                if __msgid_127045737616592:
                    __append(translate(__msgid_127045737616592, mapping=None, default=__msgid_127045737616592, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240f99d0> name=None at 738c240f9990> -> __attrs_127045737618512
                __attrs_127045737618512 = _static_127045737617872

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240f9ed0> name=None at 738c240f9e90> -> __attrs_127045737623952
                __attrs_127045737623952 = _static_127045737619152

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-dependency">\r\n                {{#each dependencies}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737624784
                __attrs_127045737624784 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if dependendants}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737624208
                __attrs_127045737624208 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240fb790> name=None at 738c240fb750> -> __attrs_127045737626128
                __attrs_127045737626128 = _static_127045737625488

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737625360 = []
                __append_127045737625360 = __stream_127045737625360.append
                __append_127045737625360(u'Dependents')
                __msgid_127045737625360 = __re_whitespace(''.join(__stream_127045737625360)).strip()
                if __msgid_127045737625360:
                    __append(translate(__msgid_127045737625360, mapping=None, default=__msgid_127045737625360, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240fbbd0> name=None at 738c240fbb90> -> __attrs_127045737627216
                __attrs_127045737627216 = _static_127045737626576

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240fc110> name=None at 738c240fc0d0> -> __attrs_127045737628560
                __attrs_127045737628560 = _static_127045737627920

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-dependency">\r\n                {{#each dependendants}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737629392
                __attrs_127045737629392 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if profiles}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737627792
                __attrs_127045737627792 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240fc990> name=None at 738c240fc950> -> __attrs_127045737630736
                __attrs_127045737630736 = _static_127045737630096

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737629968 = []
                __append_127045737629968 = __stream_127045737629968.append
                __append_127045737629968(u'Analysis Profiles')
                __msgid_127045737629968 = __re_whitespace(''.join(__stream_127045737629968)).strip()
                if __msgid_127045737629968:
                    __append(translate(__msgid_127045737629968, mapping=None, default=__msgid_127045737629968, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240fcdd0> name=None at 738c240fcd90> -> __attrs_127045737631888
                __attrs_127045737631888 = _static_127045737631184

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c240fd310> name=None at 738c240fd2d0> -> __attrs_127045737633168
                __attrs_127045737633168 = _static_127045737632528

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-profiles">\r\n                {{#each profiles}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737634000
                __attrs_127045737634000 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if templates}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737632400
                __attrs_127045737632400 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240fdb90> name=None at 738c240fdb50> -> __attrs_127045737635344
                __attrs_127045737635344 = _static_127045737634704

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737634576 = []
                __append_127045737634576 = __stream_127045737634576.append
                __append_127045737634576(u'AR Templates')
                __msgid_127045737634576 = __re_whitespace(''.join(__stream_127045737634576)).strip()
                if __msgid_127045737634576:
                    __append(translate(__msgid_127045737634576, mapping=None, default=__msgid_127045737634576, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c24100050> name=None at 738c240fdfd0> -> __attrs_127045737644752
                __attrs_127045737644752 = _static_127045737644112

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24100550> name=None at 738c24100510> -> __attrs_127045737646032
                __attrs_127045737646032 = _static_127045737645392

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-templates">\r\n                {{#each templates}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737646864
                __attrs_127045737646864 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n          {{#if specifications}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737645264
                __attrs_127045737645264 = _static_127045970670736

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c24100dd0> name=None at 738c24100d90> -> __attrs_127045737648272
                __attrs_127045737648272 = _static_127045737647568

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-key">')
                __stream_127045737647440 = []
                __append_127045737647440 = __stream_127045737647440.append
                __append_127045737647440(u'Specification')
                __msgid_127045737647440 = __re_whitespace(''.join(__stream_127045737647440)).strip()
                if __msgid_127045737647440:
                    __append(translate(__msgid_127045737647440, mapping=None, default=__msgid_127045737647440, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c24101290> name=None at 738c24101250> -> __attrs_127045737649424
                __attrs_127045737649424 = _static_127045737648784

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-info-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c241017d0> name=None at 738c24101790> -> __attrs_127045737650768
                __attrs_127045737650768 = _static_127045737650128

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="service-specs">\r\n                {{#each specifications}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737651600
                __attrs_127045737651600 = _static_127045970670736

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>{{title}}</li>\r\n                {{/each}}\r\n              </ul>\r\n            </td>\r\n          </tr>\r\n          {{/if}}\r\n        </table>\r\n      </script>\r\n\r\n      <!-- Confirmation Template -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24100810> name=None at 738c240f65d0> -> __attrs_127045737652048
                __attrs_127045737652048 = _static_127045737646096

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="confirm-template" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24104210> name=None at 738c241041d0> -> __attrs_127045737661712
                __attrs_127045737661712 = _static_127045737660944

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737661392
                __default_127045737661392 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c24104310> at 738c24104350> -> __attr_title
                __attr_title = u'Confirm'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n          {{#if message}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737662544
                __attrs_127045737662544 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737662224 = []
                __append_127045737662224 = __stream_127045737662224.append
                __append_127045737662224(u'\r\n            {{message}}\r\n          ')
                __msgid_127045737662224 = __re_whitespace(''.join(__stream_127045737662224)).strip()
                if __msgid_127045737662224:
                    __append(translate(__msgid_127045737662224, mapping=None, default=__msgid_127045737662224, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n          {{/if}}\r\n          {{#if html_message}}\r\n          {{{html_message}}}\r\n          {{/if}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737663184
                __attrs_127045737663184 = _static_127045970670736

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_127045737662864 = []
                __append_127045737662864 = __stream_127045737662864.append
                __append_127045737662864(u'\r\n            Do you want to continue?\r\n          ')
                __msgid_127045737662864 = __re_whitespace(''.join(__stream_127045737662864)).strip()
                if __msgid_127045737662864:
                    __append(translate(__msgid_127045737662864, mapping=None, default=__msgid_127045737662864, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n        </div>\r\n      </script>\r\n\r\n      <!-- Service Conditions template -->\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24104610> name=None at 738c24104090> -> __attrs_127045737664272
                __attrs_127045737664272 = _static_127045737661968

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script id="service-conditions" type="text/x-handlebars-template">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c241071d0> name=None at 738c24107190> -> __attrs_127045737673808
                __attrs_127045737673808 = _static_127045737673168

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div data-fieldname="ServiceConditions-{{arnum}}">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24107690> name=None at 738c24107650> -> __attrs_127045737675024
                __attrs_127045737675024 = _static_127045737674384

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="service-conditions-table table table-condensed table-bordered">\r\n          {{#each conditions}}\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c24107b90> name=None at 738c24107b10> -> __attrs_127045737676304
                __attrs_127045737676304 = _static_127045737675664

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr data-subfield="{{title}}">\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c2410a110> name=None at 738c2410a0d0> -> __attrs_127045737685904
                __attrs_127045737685904 = _static_127045737685264

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-conditions-label">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c2410a690> name=None at 738c2410a650> -> __attrs_127045737687248
                __attrs_127045737687248 = _static_127045737686672

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="formQuestion">\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c2410abd0> name=None at 738c2410ab90> -> __attrs_127045737688592
                __attrs_127045737688592 = _static_127045737688016

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="">{{{title}}}</span>\r\n                {{#if required}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c2410c050> name=None at 738c2410af50> -> __attrs_127045737694480
                __attrs_127045737694480 = _static_127045737693264

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="fieldRequired"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737694160
                __default_127045737694160 = _DEFAULT_MARKER

                # <Translate msgid=u'title_required' node=<_ast.Str object at 0x738c2410c310> at 738c2410c350> -> __attr_title
                __attr_title = u'Required'
                __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'                       title="%s"' % __attr_title))
                __append(u'>&nbsp;</span>\r\n                {{/if}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c2410c690> name=None at 738c2410c610> -> __attrs_127045737695824
                __attrs_127045737695824 = _static_127045737694864

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="formHelp discreet help-block small"                       id="ServiceConditions-{{arnum}}_help">{{{description}}}</span>\r\n              </label>\r\n            </td>\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c2410aa10> name=None at 738c2410a910> -> __attrs_127045737696464
                __attrs_127045737696464 = _static_127045737687568

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="service-conditions-value">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c2410cf10> name=None at 738c2410cf50> -> __attrs_127045737706576
                __attrs_127045737706576 = _static_127045737697040

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type=\'hidden\'                      name="ServiceConditions-{{../arnum}}.uid:records"                      value="{{../uid}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c2410f510> name=None at 738c2410f590> -> __attrs_127045737708112
                __attrs_127045737708112 = _static_127045737706768

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.title:records"                      value="{{title}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c2410fb10> name=None at 738c2410fbd0> -> __attrs_127045737709712
                __attrs_127045737709712 = _static_127045737708304

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.type:records"                      value="{{type}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24110210> name=None at 738c241101d0> -> __attrs_127045737711312
                __attrs_127045737711312 = _static_127045737710096

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.required:records"                      value="{{required}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24110790> name=None at 738c24110810> -> __attrs_127045737712848
                __attrs_127045737712848 = _static_127045737711504

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.report:records"                      value="{{report}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24110d90> name=None at 738c24110e10> -> __attrs_127045737718544
                __attrs_127045737718544 = _static_127045737713040

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.choices:records"                      value="{{choices}}"/>\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24112490> name=None at 738c24112450> -> __attrs_127045737720144
                __attrs_127045737720144 = _static_127045737718928

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                      name="ServiceConditions-{{../arnum}}.description:records"                      value="{{description}}"/>\r\n              {{#if options}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24112a90> name=None at 738c24112a10> -> __attrs_127045737721104
                __attrs_127045737721104 = _static_127045737720464

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select name="ServiceConditions-{{../arnum}}.value:records">\r\n                {{#unless required}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737726096
                __attrs_127045737726096 = _static_127045970670736

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option></option>\r\n                {{/unless}}\r\n                {{#each options}}\r\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737726608
                __attrs_127045737726608 = _static_127045970670736

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option>{{this}}</option>\r\n                {{/each}}\r\n              </select>\r\n              {{else}}\r\n              {{#if required}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c24114190> name=None at 738c241142d0> -> __attrs_127045737728272
                __attrs_127045737728272 = _static_127045737726352

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="{{type}}"                      name="ServiceConditions-{{../arnum}}.value:records"                      required="required"                      value="{{default}}"/>\r\n              {{else}}\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c241149d0> name=None at 738c24114a50> -> __attrs_127045737729808
                __attrs_127045737729808 = _static_127045737728464

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="{{type}}"                      name="ServiceConditions-{{../arnum}}.value:records"                      value="{{default}}"/>\r\n              {{/if}}\r\n              {{/if}}\r\n            </td>\r\n          </tr>\r\n          {{/each}}\r\n        </table>\r\n        </div>\r\n      </script>\r\n\r\n    ')
                if (__backup_portal_127045737975632 is __marker):
                    del econtext['portal']
                else:
                    econtext['portal'] = __backup_portal_127045737975632
            _slots = econtext[u'__slot_senaite_legacy_resources'] = _deque((__fill_senaite_legacy_resources, ))

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737686160
                __attrs_127045737686160 = _static_127045970670736
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c241170d0> name=None at 738c24117050> -> __attrs_127045737739024
                __attrs_127045737739024 = _static_127045737738448

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 id="ar-header">\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24117550> name=None at 738c24117590> -> __attrs_127045737741072
                __attrs_127045737741072 = _static_127045737739600

                # <img ... (0:0)
                # --------------------------------------------------------
                __append(u'<img')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737740304
                __default_127045737740304 = _DEFAULT_MARKER

                # <Substitution u'senaite_theme/icon_url/sample' (309:33)> -> __attr_src
                __token = 11590
                try:
                    __zt_tmp = __attrs_127045737741072
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_127045886978192('path', u'senaite_theme/icon_url/sample', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'              class="d-inline-block align-middle"              width="32"/>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24117cd0> name=None at 738c24117c90> -> __attrs_127045737742160
                __attrs_127045737742160 = _static_127045737741520

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="d-inline-block align-middle">')
                __stream_127045737741392 = []
                __append_127045737741392 = __stream_127045737741392.append
                __append_127045737741392(u'Request new analyses')
                __msgid_127045737741392 = __re_whitespace(''.join(__stream_127045737741392)).strip()
                if __msgid_127045737741392:
                    __append(translate(__msgid_127045737741392, mapping=None, default=__msgid_127045737741392, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24118150> name=None at 738c24118110> -> __attrs_127045737743376
                __attrs_127045737743376 = _static_127045737742672

                # <Value u"python:checkPermission('senaite.core: Add AnalysisRequest', context)" (313:29)> -> __condition
                __token = 11754
                try:
                    __zt_tmp = __attrs_127045737743376
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u"checkPermission('senaite.core: Add AnalysisRequest', context)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span               class="d-inline-block align-middle ml-2">\r\n          ')

                    # <Static value=<_ast.Dict object at 0x738c241186d0> name=None at 738c24118750> -> __attrs_127045737745552
                    __attrs_127045737745552 = _static_127045737744080

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form method="GET"                 class="form-inline"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737745232
                    __default_127045737745232 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}/ar_add' (318:39)> -> __attr_action
                    __token = 12021
                    try:
                        __zt_tmp = __attrs_127045737745552
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_127045886978192('string', u'${context/absolute_url}/ar_add', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', u'ar_add', _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u'                 action="%s"' % __attr_action))
                    __append(u'>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c24118f90> name=None at 738c24118f50> -> __attrs_127045737747600
                    __attrs_127045737747600 = _static_127045737746320

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden"                    name="copy_from"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737747344
                    __default_127045737747344 = _DEFAULT_MARKER

                    # <Substitution u'request/copy_from|nothing' (320:58)> -> __attr_value
                    __token = 12154
                    try:
                        __zt_tmp = __attrs_127045737747600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_127045886978192('path', u'request/copy_from|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'/>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c24119650> name=None at 738c241195d0> -> __attrs_127045737748624
                    __attrs_127045737748624 = _static_127045737748048

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c24119b10> name=None at 738c24119bd0> -> __attrs_127045737755664
                    __attrs_127045737755664 = _static_127045737749264

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="number"                      name="ar_count"                      min="1"                      max="99"                      class="form-control form-control-sm"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737755408
                    __default_127045737755408 = _DEFAULT_MARKER

                    # <Substitution u'python:view.ar_count or 1' (327:43)> -> __attr_value
                    __token = 12461
                    try:
                        __zt_tmp = __attrs_127045737755664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_127045886978192('python', u'view.ar_count or 1', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'/>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c2411b550> name=None at 738c2411b4d0> -> __attrs_127045737756624
                    __attrs_127045737756624 = _static_127045737755984

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-append">\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c2411ba10> name=None at 738c2411ba50> -> __attrs_127045737758224
                    __attrs_127045737758224 = _static_127045737757200

                    # <button ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<button type="submit"                         class="btn btn-outline-secondary btn-sm">\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c2411d0d0> name=None at 738c2411d110> -> __attrs_127045737764048
                    __attrs_127045737764048 = _static_127045737763024

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737763600
                    __default_127045737763600 = _DEFAULT_MARKER

                    # <Substitution u'senaite_theme/icon_url/plus' (333:43)> -> __attr_src
                    __token = 12757
                    try:
                        __zt_tmp = __attrs_127045737764048
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_src = _static_127045886978192('path', u'senaite_theme/icon_url/plus', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_src = __quote(__attr_src, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_src is not None):
                        __append((u' src="%s"' % __attr_src))
                    __append(u'                        height="16"/>\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737764944
                    __attrs_127045737764944 = _static_127045970670736

                    # <Negate value=<Value u'python:1' (334:38)> at 738c2411d710> -> __cache_127045737764624

                    # <Value u'python:1' (334:38)> -> __cache_127045737764624
                    __token = 12827
                    try:
                        __zt_tmp = __attrs_127045737764944
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045737764624 = _static_127045886978192('python', u'1', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __cache_127045737764624 = not __cache_127045737764624
                    __condition = __cache_127045737764624
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                    __stream_127045737764240 = []
                    __append_127045737764240 = __stream_127045737764240.append
                    __append_127045737764240(u'Add')
                    __msgid_127045737764240 = __re_whitespace(''.join(__stream_127045737764240)).strip()
                    if __msgid_127045737764240:
                        __append(translate(__msgid_127045737764240, mapping=None, default=__msgid_127045737764240, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __condition = __cache_127045737764624
                    if __condition:
                        __append(u'</span>')
                    __append(u'\r\n                </button>\r\n              </span>\r\n            </span>\r\n          </form>\r\n        </span>')
                __append(u'\r\n      </h1>\r\n\r\n\r\n    ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_description(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737739088
                __attrs_127045737739088 = _static_127045970670736
                __append(u'\r\n    ')
            _slots = econtext[u'__slot_content_description'] = _deque((__fill_content_description, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737747856
                __attrs_127045737747856 = _static_127045970670736
                __backup_portal_127045738033616 = get('portal', __marker)

                # <Value u'context/@@plone_portal_state/portal' (348:28)> -> __value
                __token = 13165
                try:
                    __zt_tmp = __attrs_127045737747856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'context/@@plone_portal_state/portal', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['portal'] = __value
                __backup_user_127045738034512 = get('user', __marker)

                # <Value u'context/portal_membership/getAuthenticatedMember' (349:25)> -> __value
                __token = 13228
                try:
                    __zt_tmp = __attrs_127045737747856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'context/portal_membership/getAuthenticatedMember', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['user'] = __value
                __backup_currency_symbol_127045737974288 = get('currency_symbol', __marker)

                # <Value u'python:view.get_currency().symbol' (350:35)> -> __value
                __token = 13315
                try:
                    __zt_tmp = __attrs_127045737747856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'view.get_currency().symbol', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['currency_symbol'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c2411da10> name=None at 738c2411da50> -> __attrs_127045737766864
                __attrs_127045737766864 = _static_127045737765392

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form id="analysisrequest_add_form"             name="analysisrequest_add_form"             method="POST">\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c2411e2d0> name=None at 738c2411e310> -> __attrs_127045737768784
                __attrs_127045737768784 = _static_127045737767632

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="submitted" value="1"/>\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c2411e8d0> name=None at 738c2411e910> -> __attrs_127045737770448
                __attrs_127045737770448 = _static_127045737769168

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="portal_url"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737770192
                __default_127045737770192 = _DEFAULT_MARKER

                # <Substitution u'portal/absolute_url' (357:78)> -> __attr_value
                __token = 13612
                try:
                    __zt_tmp = __attrs_127045737770448
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('path', u'portal/absolute_url', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737775504
                __attrs_127045737775504 = _static_127045970670736

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737775376
                __default_127045737775376 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (358:37)> -> __cache_127045737770896
                __token = 13673
                try:
                    __zt_tmp = __attrs_127045737775504
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_127045737770896 = _static_127045886978192('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (358:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24120050> -> __condition
                __expression = __cache_127045737770896

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span/>')
                else:
                    __content = __cache_127045737770896
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24120390> name=None at 738c24120310> -> __attrs_127045737777296
                __attrs_127045737777296 = _static_127045737776016

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"                name="came_from"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737777040
                __default_127045737777040 = _DEFAULT_MARKER

                # <Substitution u'view/came_from' (360:54)> -> __attr_value
                __token = 13799
                try:
                    __zt_tmp = __attrs_127045737777296
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('path', u'view/came_from', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24120a50> name=None at 738c24120990> -> __attrs_127045737783504
                __attrs_127045737783504 = _static_127045737777744

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" id="ar_count" name="ar_count"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737779088
                __default_127045737779088 = _DEFAULT_MARKER

                # <Substitution u'view/ar_count' (362:37)> -> __attr_value
                __token = 13915
                try:
                    __zt_tmp = __attrs_127045737783504
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('path', u'view/ar_count', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n        <!-- Hidden fields for source UIDs (for partition copying) -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737784080
                __attrs_127045737784080 = _static_127045970670736
                __backup_copy_from_127045738060688 = get('copy_from', __marker)

                # <Value u'python:view.get_copy_from()' (366:47)> -> __value
                __token = 14127
                try:
                    __zt_tmp = __attrs_127045737784080
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'view.get_copy_from()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['copy_from'] = __value
                __backup_arnum_127045738060752 = get('arnum', __marker)

                # <Value u'python:range(view.ar_count)' (365:43)> -> __iterator
                __token = 14050
                try:
                    __zt_tmp = __attrs_127045737784080
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045737784400, ) = getitem('repeat')(u'arnum', __iterator)
                econtext['arnum'] = None
                for __item in __iterator:
                    econtext['arnum'] = __item
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737785104
                    __attrs_127045737785104 = _static_127045970670736
                    __backup_source_uid_key_127045738058896 = get('source_uid_key', __marker)

                    # <Value u"python:'_source_uid-{}'.format(arnum)" (367:53)> -> __value
                    __token = 14211
                    try:
                        __zt_tmp = __attrs_127045737785104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u"'_source_uid-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['source_uid_key'] = __value
                    __backup_source_obj_127045738034960 = get('source_obj', __marker)

                    # <Value u'python:copy_from.get(arnum)' (368:48)> -> __value
                    __token = 14299
                    try:
                        __zt_tmp = __attrs_127045737785104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'copy_from.get(arnum)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['source_obj'] = __value
                    __backup_source_uid_127045737616208 = get('source_uid', __marker)

                    # <Value u'python:source_obj.UID() if source_obj else None' (369:47)> -> __value
                    __token = 14377
                    try:
                        __zt_tmp = __attrs_127045737785104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'source_obj.UID() if source_obj else None', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['source_uid'] = __value
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c24122b50> name=None at 738c24122bd0> -> __attrs_127045737791952
                    __attrs_127045737791952 = _static_127045737786192

                    # <Value u'source_uid' (371:34)> -> __condition
                    __token = 14498
                    try:
                        __zt_tmp = __attrs_127045737791952
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('path', u'source_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737787280
                        __default_127045737787280 = _DEFAULT_MARKER

                        # <Substitution u'source_uid_key' (372:40)> -> __attr_name
                        __token = 14551
                        try:
                            __zt_tmp = __attrs_127045737791952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_127045886978192('path', u'source_uid_key', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737791696
                        __default_127045737791696 = _DEFAULT_MARKER

                        # <Substitution u'source_uid' (373:40)> -> __attr_value
                        __token = 14608
                        try:
                            __zt_tmp = __attrs_127045737791952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_127045886978192('path', u'source_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u'/>')
                    __append(u'\r\n          ')
                    if (__backup_source_uid_127045737616208 is __marker):
                        del econtext['source_uid']
                    else:
                        econtext['source_uid'] = __backup_source_uid_127045737616208
                    if (__backup_source_obj_127045738034960 is __marker):
                        del econtext['source_obj']
                    else:
                        econtext['source_obj'] = __backup_source_obj_127045738034960
                    if (__backup_source_uid_key_127045738058896 is __marker):
                        del econtext['source_uid_key']
                    else:
                        econtext['source_uid_key'] = __backup_source_uid_key_127045738058896
                    __append(u'\r\n        ')
                    ____index_127045737784400 -= 1
                    if (____index_127045737784400 > 0):
                        __append('')
                if (__backup_arnum_127045738060752 is __marker):
                    del econtext['arnum']
                else:
                    econtext['arnum'] = __backup_arnum_127045738060752
                if (__backup_copy_from_127045738060688 is __marker):
                    del econtext['copy_from']
                else:
                    econtext['copy_from'] = __backup_copy_from_127045738060688
                __append(u'\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24122410> name=None at 738c24122250> -> __attrs_127045737792976
                __attrs_127045737792976 = _static_127045737784336

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-tabs float-right" id="sample-tabs" style="margin-bottom:-1px;">\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737793744
                __attrs_127045737793744 = _static_127045970670736
                __backup_arnum_127045738047568 = get('arnum', __marker)

                # <Value u'python:range(view.ar_count)' (378:41)> -> __iterator
                __token = 14816
                try:
                    __zt_tmp = __attrs_127045737793744
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045737793936, ) = getitem('repeat')(u'arnum', __iterator)
                econtext['arnum'] = None
                for __item in __iterator:
                    econtext['arnum'] = __item
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c24124c50> name=None at 738c24124bd0> -> __attrs_127045737795344
                    __attrs_127045737795344 = _static_127045737794640

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737795024
                    __default_127045737795024 = _DEFAULT_MARKER

                    # <Substitution u'string:nav-item nav-item-${arnum}' (379:55)> -> __attr_class
                    __token = 14902
                    try:
                        __zt_tmp = __attrs_127045737795344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_127045886978192('string', u'nav-item nav-item-${arnum}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-item', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c240a6250> name=None at 738c240a6210> -> __attrs_127045737277968
                    __attrs_127045737277968 = _static_127045737275984

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a                  href="#"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737277072
                    __default_127045737277072 = _DEFAULT_MARKER

                    # <Substitution u"python:'nav-link active' if arnum == 0 else 'nav-link'" (380:39)> -> __attr_class
                    __token = 14978
                    try:
                        __zt_tmp = __attrs_127045737277968
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_127045886978192('python', u"'nav-link active' if arnum == 0 else 'nav-link'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737277392
                    __default_127045737277392 = _DEFAULT_MARKER

                    # <Substitution u'string:${arnum}' (381:58)> -> __attr_data_primary_sample_index
                    __token = 15093
                    try:
                        __zt_tmp = __attrs_127045737277968
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_primary_sample_index = _static_127045886978192('string', u'${arnum}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_data_primary_sample_index = __quote(__attr_data_primary_sample_index, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_primary_sample_index is not None):
                        __append((u' data-primary-sample-index="%s"' % __attr_data_primary_sample_index))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737277648
                    __default_127045737277648 = _DEFAULT_MARKER

                    # <Substitution u'string:sample-column-${arnum}' (382:43)> -> __attr_data_target
                    __token = 15155
                    try:
                        __zt_tmp = __attrs_127045737277968
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_target = _static_127045886978192('string', u'sample-column-${arnum}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_data_target = __quote(__attr_data_target, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_target is not None):
                        __append((u' data-target="%s"' % __attr_data_target))
                    __append(u'>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737278992
                    __attrs_127045737278992 = _static_127045970670736

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_127045737278672 = []
                    __append_127045737278672 = __stream_127045737278672.append
                    __append_127045737278672(u'Sample')
                    __msgid_127045737278672 = __re_whitespace(''.join(__stream_127045737278672)).strip()
                    if __msgid_127045737278672:
                        __append(translate(__msgid_127045737278672, mapping=None, default=__msgid_127045737278672, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737284240
                    __attrs_127045737284240 = _static_127045970670736

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737283856
                    __default_127045737283856 = _DEFAULT_MARKER

                    # <Value u'python: arnum + 1' (385:35)> -> __cache_127045737279312
                    __token = 15307
                    try:
                        __zt_tmp = __attrs_127045737284240
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045737279312 = _static_127045886978192('python', u' arnum + 1', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python: arnum + 1' (385:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c240a8050> -> __condition
                    __expression = __cache_127045737279312

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_127045737279312
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n              </a>\r\n            </li>\r\n          ')
                    ____index_127045737793936 -= 1
                    if (____index_127045737793936 > 0):
                        __append('')
                if (__backup_arnum_127045738047568 is __marker):
                    del econtext['arnum']
                else:
                    econtext['arnum'] = __backup_arnum_127045738047568
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c24124f50> name=None at 738c24124b50> -> __attrs_127045737284304
                __attrs_127045737284304 = _static_127045737795408

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\r\n            ')

                # <Static value=<_ast.Dict object at 0x738c240a85d0> name=None at 738c240a8590> -> __attrs_127045737286672
                __attrs_127045737286672 = _static_127045737285072

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="nav-link"                data-target="show-all"                data-primary-sample-index="0"                href="#">\r\n              ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737287568
                __attrs_127045737287568 = _static_127045970670736

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_127045737287248 = []
                __append_127045737287248 = __stream_127045737287248.append
                __append_127045737287248(u'Show all')
                __msgid_127045737287248 = __re_whitespace(''.join(__stream_127045737287248)).strip()
                if __msgid_127045737287248:
                    __append(translate(__msgid_127045737287248, mapping=None, default=__msgid_127045737287248, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\r\n            </a>\r\n          </li>\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c240a8450> name=None at 738c240a8c50> -> __attrs_127045737288336
                __attrs_127045737288336 = _static_127045737284688

                # <Value u"python:user.has_role('LabManager') or user.has_role('Manager')" (397:46)> -> __condition
                __token = 15713
                try:
                    __zt_tmp = __attrs_127045737288336
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u"user.has_role('LabManager') or user.has_role('Manager')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c240a95d0> name=None at 738c240a9590> -> __attrs_127045737291344
                    __attrs_127045737291344 = _static_127045737289168

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a class="nav-link"                data-target="manage-form-fields"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737290576
                    __default_127045737290576 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x738c240a9a90> at 738c240a9ad0> -> __attr_title
                    __attr_title = u'Manage Form Fields'
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u'                title="%s"' % __attr_title))
                    __append(u'                target="_blank"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737291024
                    __default_127045737291024 = _DEFAULT_MARKER

                    # <Substitution u"python:context.absolute_url() + '/ar_add_manage'" (403:36)> -> __attr_href
                    __token = 16012
                    try:
                        __zt_tmp = __attrs_127045737291344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_127045886978192('python', u"context.absolute_url() + '/ar_add_manage'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c240ab190> name=None at 738c240ab150> -> __attrs_127045737296848
                    __attrs_127045737296848 = _static_127045737296272

                    # <i ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<i class="fas fa-tasks"></i>\r\n            </a>\r\n          </li>')
                __append(u'\r\n        </ul>\r\n\r\n        <!-- ADD Form -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240a9e90> name=None at 738c240a9510> -> __attrs_127045737297424
                __attrs_127045737297424 = _static_127045737291408

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="ar-table table table-sm table-bordered">\r\n\r\n          <!-- All edit fields with fields with add=visible -->\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737298384
                __attrs_127045737298384 = _static_127045970670736
                __backup_field_127045737688848 = get('field', __marker)

                # <Value u"python:view.get_fields_with_visibility('edit')" (413:39)> -> __iterator
                __token = 16357
                try:
                    __zt_tmp = __attrs_127045737298384
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u"view.get_fields_with_visibility('edit')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045737298576, ) = getitem('repeat')(u'field', __iterator)
                econtext['field'] = None
                for __item in __iterator:
                    econtext['field'] = __item
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737299408
                    __attrs_127045737299408 = _static_127045970670736
                    __backup_widget_127045737792080 = get('widget', __marker)

                    # <Value u'python:field.widget' (414:36)> -> __value
                    __token = 16443
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'field.widget', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['widget'] = __value
                    __backup_fieldName_127045738061264 = get('fieldName', __marker)

                    # <Value u'python:field.getName()' (415:38)> -> __value
                    __token = 16503
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'field.getName()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['fieldName'] = __value
                    __backup_fieldLabel_127045738060112 = get('fieldLabel', __marker)

                    # <Value u'python:view.context.translate(widget.Label(here))' (416:38)> -> __value
                    __token = 16567
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'view.context.translate(widget.Label(here))', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['fieldLabel'] = __value
                    __backup_required_127045737275856 = get('required', __marker)

                    # <Value u'python:bool(field.required)' (417:35)> -> __value
                    __token = 16656
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'bool(field.required)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['required'] = __value
                    __backup_errors_127045737278224 = get('errors', __marker)

                    # <Value u'python:{}' (418:32)> -> __value
                    __token = 16721
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'{}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['errors'] = __value
                    __backup_mode_127045737278608 = get('mode', __marker)

                    # <Value u"python:'edit'" (419:29)> -> __value
                    __token = 16766
                    try:
                        __zt_tmp = __attrs_127045737299408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u"'edit'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['mode'] = __value
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c240ae4d0> name=None at 738c240ae490> -> __attrs_127045737310800
                    __attrs_127045737310800 = _static_127045737309392

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr class="ar-table-row"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737310224
                    __default_127045737310224 = _DEFAULT_MARKER

                    # <Substitution u'python:fieldName' (421:44)> -> __attr_fieldName
                    __token = 16873
                    try:
                        __zt_tmp = __attrs_127045737310800
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_fieldName = _static_127045886978192('python', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_fieldName is not None):
                        __append((u' fieldName="%s"' % __attr_fieldName))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737310480
                    __default_127045737310480 = _DEFAULT_MARKER

                    # <Substitution u'python:fieldLabel' (422:44)> -> __attr_fieldLabel
                    __token = 16936
                    try:
                        __zt_tmp = __attrs_127045737310800
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_fieldLabel = _static_127045886978192('python', u'fieldLabel', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_fieldLabel = __quote(__attr_fieldLabel, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_fieldLabel is not None):
                        __append((u' fieldLabel="%s"' % __attr_fieldLabel))
                    __append(u'>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c240aed90> name=None at 738c240aed10> -> __attrs_127045737312208
                    __attrs_127045737312208 = _static_127045737311632

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td class="field-label">\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c240b0390> name=None at 738c240b0350> -> __attrs_127045737317840
                    __attrs_127045737317840 = _static_127045737317264

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="formQuestion">\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c240b0a90> name=None at 738c240b0a50> -> __attrs_127045737319760
                    __attrs_127045737319760 = _static_127045737319056

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737319440
                    __default_127045737319440 = _DEFAULT_MARKER

                    # <Substitution u"python:required and 'text-primary' or ''" (426:44)> -> __attr_class
                    __token = 17119
                    try:
                        __zt_tmp = __attrs_127045737319760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_127045886978192('python', u"required and 'text-primary' or ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737318864
                    __default_127045737318864 = _DEFAULT_MARKER

                    # <Value u'python:fieldLabel' (427:35)> -> __cache_127045737318544
                    __token = 17197
                    try:
                        __zt_tmp = __attrs_127045737319760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045737318544 = _static_127045886978192('python', u'fieldLabel', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:fieldLabel' (427:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c240b0910> -> __condition
                    __expression = __cache_127045737318544

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n                      Label\r\n                    ')
                    else:
                        __content = __cache_127045737318544
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c240b0e90> name=None at 738c240b0f10> -> __attrs_127045737321552
                    __attrs_127045737321552 = _static_127045737320080

                    # <Value u'required' (431:41)> -> __condition
                    __token = 17366
                    try:
                        __zt_tmp = __attrs_127045737321552
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('path', u'required', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="fieldRequired"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737321232
                        __default_127045737321232 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x738c240b1250> at 738c240b1290> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u'                           title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c240b1850> name=None at 738c240b1810> -> __attrs_127045737323600
                    __attrs_127045737323600 = _static_127045737322576
                    __backup_description_127045737318096 = get('description', __marker)

                    # <Value u'python:view.context.translate(widget.Description(here))' (435:50)> -> __value
                    __token = 17622
                    try:
                        __zt_tmp = __attrs_127045737323600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'view.context.translate(widget.Description(here))', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp discreet help-block small"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737323280
                    __default_127045737323280 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_help' (437:45)> -> __attr_id
                    __token = 17788
                    try:
                        __zt_tmp = __attrs_127045737323600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('string', u'${fieldName}_help', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737322384
                    __default_127045737322384 = _DEFAULT_MARKER

                    # <Value u'description' (436:49)> -> __cache_127045737322000
                    __token = 17729
                    try:
                        __zt_tmp = __attrs_127045737323600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045737322000 = _static_127045886978192('path', u'description', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description' (436:49)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c240b16d0> -> __condition
                    __expression = __cache_127045737322000

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Help')
                    else:
                        __content = __cache_127045737322000
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                    if (__backup_description_127045737318096 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_127045737318096
                    __append(u'\r\n                  </label>\r\n                </td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c240b0610> name=None at 738c240b0190> -> __attrs_127045737324240
                    __attrs_127045737324240 = _static_127045737317904

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td class="pl-3 pr-3">\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c240b41d0> name=None at 738c240b4150> -> __attrs_127045737333776
                    __attrs_127045737333776 = _static_127045737333200

                    # <Value u'python:view.show_copy_button_for(field)' (441:58)> -> __condition
                    __token = 17976
                    try:
                        __zt_tmp = __attrs_127045737333776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('python', u'view.show_copy_button_for(field)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-center">\r\n                    <!-- Copy Button -->\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c240b47d0> name=None at 738c240b4750> -> __attrs_127045737337360
                        __attrs_127045737337360 = _static_127045737334736

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a class="copy d-block"                        href="#"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737336272
                        __default_127045737336272 = _DEFAULT_MARKER

                        # <Translate msgid=None node=<_ast.Str object at 0x738c240b4d10> at 738c240b4d50> -> __attr_title
                        __attr_title = u'Copy the value of the first sample to the others'
                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u'                        title="%s"' % __attr_title))
                        __append(u'                        data_toggle="tooltip"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737336720
                        __default_127045737336720 = _DEFAULT_MARKER

                        # <Substitution u'python:fieldName' (448:49)> -> __attr_fieldName
                        __token = 18363
                        try:
                            __zt_tmp = __attrs_127045737337360
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_fieldName = _static_127045886978192('python', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_fieldName is not None):
                            __append((u' fieldName="%s"' % __attr_fieldName))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737337040
                        __default_127045737337040 = _DEFAULT_MARKER

                        # <Substitution u'python:fieldLabel' (449:49)> -> __attr_fieldLabel
                        __token = 18431
                        try:
                            __zt_tmp = __attrs_127045737337360
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_fieldLabel = _static_127045886978192('python', u'fieldLabel', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_fieldLabel = __quote(__attr_fieldLabel, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_fieldLabel is not None):
                            __append((u' fieldLabel="%s"' % __attr_fieldLabel))
                        __append(u'>\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x738c240b5510> name=None at 738c240b54d0> -> __attrs_127045737338768
                        __attrs_127045737338768 = _static_127045737338128

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-angle-double-right"></i>\r\n                    </a>\r\n                    <!-- Paste Button -->\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c240b5890> name=None at 738c240b5390> -> __attrs_127045737349840
                        __attrs_127045737349840 = _static_127045737339024

                        # <Value u'python:view.show_paste_button_for(field)' (458:38)> -> __condition
                        __token = 18880
                        try:
                            __zt_tmp = __attrs_127045737349840
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_127045886978192('python', u'view.show_paste_button_for(field)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if __condition:

                            # <a ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<a class="paste d-block"                        href="#"')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737340560
                            __default_127045737340560 = _DEFAULT_MARKER

                            # <Translate msgid=None node=<_ast.Str object at 0x738c240b5dd0> at 738c240b5e10> -> __attr_title
                            __attr_title = u'Enter individual values for this field per sample'
                            __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u'                        title="%s"' % __attr_title))
                            __append(u'                        data_toggle="tooltip"')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737349264
                            __default_127045737349264 = _DEFAULT_MARKER

                            # <Substitution u'python:fieldName' (459:49)> -> __attr_fieldName
                            __token = 18972
                            try:
                                __zt_tmp = __attrs_127045737349840
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_fieldName = _static_127045886978192('python', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_fieldName is not None):
                                __append((u' fieldName="%s"' % __attr_fieldName))

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737349520
                            __default_127045737349520 = _DEFAULT_MARKER

                            # <Substitution u'python:fieldLabel' (460:49)> -> __attr_fieldLabel
                            __token = 19040
                            try:
                                __zt_tmp = __attrs_127045737349840
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_fieldLabel = _static_127045886978192('python', u'fieldLabel', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            __attr_fieldLabel = __quote(__attr_fieldLabel, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_fieldLabel is not None):
                                __append((u' fieldLabel="%s"' % __attr_fieldLabel))
                            __append(u'>\r\n                      ')

                            # <Static value=<_ast.Dict object at 0x738c240b8650> name=None at 738c240b85d0> -> __attrs_127045737351376
                            __attrs_127045737351376 = _static_127045737350736

                            # <i ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<i class="fas fa-list-ol"></i>\r\n                    </a>')
                        __append(u'\r\n                  </div>')
                    __append(u'\r\n                </td>\r\n\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737337680
                    __attrs_127045737337680 = _static_127045970670736
                    __backup_arnum_127045737299600 = get('arnum', __marker)

                    # <Value u'python:range(view.ar_count)' (466:47)> -> __iterator
                    __token = 19240
                    try:
                        __zt_tmp = __attrs_127045737337680
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045737350224, ) = getitem('repeat')(u'arnum', __iterator)
                    econtext['arnum'] = None
                    for __item in __iterator:
                        econtext['arnum'] = __item
                        __append(u'\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c240b89d0> name=None at 738c240b8a90> -> __attrs_127045737361680
                        __attrs_127045737361680 = _static_127045737351632
                        __backup_newFieldName_127045737311440 = get('newFieldName', __marker)

                        # <Value u'python:view.get_fieldname(field, arnum)' (467:47)> -> __value
                        __token = 19318
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u'view.get_fieldname(field, arnum)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['newFieldName'] = __value
                        __backup_cls_127045737311056 = get('cls', __marker)

                        # <Value u'string: sample-column sample-column-${arnum}' (468:37)> -> __value
                        __token = 19397
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('string', u' sample-column sample-column-${arnum}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['cls'] = __value
                        __backup_cls_127045737320016 = get('cls', __marker)

                        # <Value u"python:cls + ' d-none' if arnum > 0 else cls" (469:36)> -> __value
                        __token = 19481
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u"cls + ' d-none' if arnum > 0 else cls", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['cls'] = __value

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737352528
                        __default_127045737352528 = _DEFAULT_MARKER

                        # <Substitution u'python:cls' (470:44)> -> __attr_class
                        __token = 19575
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_127045886978192('python', u'cls', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737352784
                        __default_127045737352784 = _DEFAULT_MARKER

                        # <Substitution u'arnum' (471:43)> -> __attr_arnum
                        __token = 19631
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_arnum = _static_127045886978192('path', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_arnum is not None):
                            __append((u' arnum="%s"' % __attr_arnum))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737353104
                        __default_127045737353104 = _DEFAULT_MARKER

                        # <Substitution u'newFieldName' (472:46)> -> __attr_fieldName
                        __token = 19686
                        try:
                            __zt_tmp = __attrs_127045737361680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_fieldName = _static_127045886978192('path', u'newFieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_fieldName is not None):
                            __append((u' fieldName="%s"' % __attr_fieldName))
                        __append(u'>\r\n                    <!-- The input field is rendered here -->\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737363152
                        __attrs_127045737363152 = _static_127045970670736
                        __backup_macroname_127045759872048 = get('macroname', __marker)

                        # <Static value=<_ast.Str object at 0x738c240bb5d0> name=None at 738c240bb610> -> __value
                        __value = _static_127045737362896
                        econtext['macroname'] = __value

                        # <Value u"python:view.get_input_widget(fieldName, arnum, mode='edit')" (474:44)> -> __macro
                        __token = 19811
                        try:
                            __zt_tmp = __attrs_127045737363152
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __macro = _static_127045886978192('python', u"view.get_input_widget(fieldName, arnum, mode='edit')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __token = 19811
                        __m = __macro.include
                        __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                        econtext.update(rcontext)
                        if (__backup_macroname_127045759872048 is __marker):
                            del econtext['macroname']
                        else:
                            econtext['macroname'] = __backup_macroname_127045759872048
                        __append(u'\r\n                  </td>')
                        if (__backup_cls_127045737320016 is __marker):
                            del econtext['cls']
                        else:
                            econtext['cls'] = __backup_cls_127045737320016
                        if (__backup_cls_127045737311056 is __marker):
                            del econtext['cls']
                        else:
                            econtext['cls'] = __backup_cls_127045737311056
                        if (__backup_newFieldName_127045737311440 is __marker):
                            del econtext['newFieldName']
                        else:
                            econtext['newFieldName'] = __backup_newFieldName_127045737311440
                        __append(u'\r\n                ')
                        ____index_127045737350224 -= 1
                        if (____index_127045737350224 > 0):
                            __append('')
                    if (__backup_arnum_127045737299600 is __marker):
                        del econtext['arnum']
                    else:
                        econtext['arnum'] = __backup_arnum_127045737299600
                    __append(u'\r\n\r\n              </tr>\r\n            ')
                    if (__backup_mode_127045737278608 is __marker):
                        del econtext['mode']
                    else:
                        econtext['mode'] = __backup_mode_127045737278608
                    if (__backup_errors_127045737278224 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_127045737278224
                    if (__backup_required_127045737275856 is __marker):
                        del econtext['required']
                    else:
                        econtext['required'] = __backup_required_127045737275856
                    if (__backup_fieldLabel_127045738060112 is __marker):
                        del econtext['fieldLabel']
                    else:
                        econtext['fieldLabel'] = __backup_fieldLabel_127045738060112
                    if (__backup_fieldName_127045738061264 is __marker):
                        del econtext['fieldName']
                    else:
                        econtext['fieldName'] = __backup_fieldName_127045738061264
                    if (__backup_widget_127045737792080 is __marker):
                        del econtext['widget']
                    else:
                        econtext['widget'] = __backup_widget_127045737792080
                    __append(u'\r\n          ')
                    ____index_127045737298576 -= 1
                    if (____index_127045737298576 > 0):
                        __append('')
                if (__backup_field_127045737688848 is __marker):
                    del econtext['field']
                else:
                    econtext['field'] = __backup_field_127045737688848
                __append(u'\r\n\r\n          <!-- Hidden Fields -->\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737309136
                __attrs_127045737309136 = _static_127045970670736
                __backup_field_127045737687824 = get('field', __marker)

                # <Value u"python:view.get_fields_with_visibility('hidden')" (483:39)> -> __iterator
                __token = 20078
                try:
                    __zt_tmp = __attrs_127045737309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u"view.get_fields_with_visibility('hidden')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045737316688, ) = getitem('repeat')(u'field', __iterator)
                econtext['field'] = None
                for __item in __iterator:
                    econtext['field'] = __item
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737362192
                    __attrs_127045737362192 = _static_127045970670736
                    __backup_fieldName_127045737299344 = get('fieldName', __marker)

                    # <Value u'python:field.getName()' (484:39)> -> __value
                    __token = 20169
                    try:
                        __zt_tmp = __attrs_127045737362192
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'field.getName()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['fieldName'] = __value
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c240bba10> name=None at 738c240bb990> -> __attrs_127045737364944
                    __attrs_127045737364944 = _static_127045737363984

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr style="display:none"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737364624
                    __default_127045737364624 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (485:65)> -> __attr_fieldName
                    __token = 20261
                    try:
                        __zt_tmp = __attrs_127045737364944
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_fieldName = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_fieldName is not None):
                        __append((u' fieldName="%s"' % __attr_fieldName))
                    __append(u'>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737378064
                    __attrs_127045737378064 = _static_127045970670736
                    __backup_arnum_127045737318480 = get('arnum', __marker)

                    # <Value u'python:range(view.ar_count)' (486:47)> -> __iterator
                    __token = 20321
                    try:
                        __zt_tmp = __attrs_127045737378064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045737378256, ) = getitem('repeat')(u'arnum', __iterator)
                    econtext['arnum'] = None
                    for __item in __iterator:
                        econtext['arnum'] = __item
                        __append(u'\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c240bf450> name=None at 738c240bf410> -> __attrs_127045737380176
                        __attrs_127045737380176 = _static_127045737378896
                        __backup_newFieldName_127045737316624 = get('newFieldName', __marker)

                        # <Value u'python:view.get_fieldname(field, arnum)' (487:47)> -> __value
                        __token = 20399
                        try:
                            __zt_tmp = __attrs_127045737380176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u'view.get_fieldname(field, arnum)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['newFieldName'] = __value
                        __backup_val_127045737350544 = get('val', __marker)

                        # <Value u'python:view.fieldvalues.get(newFieldName)' (488:37)> -> __value
                        __token = 20478
                        try:
                            __zt_tmp = __attrs_127045737380176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u'view.fieldvalues.get(newFieldName)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['val'] = __value
                        __backup_val_127045737378640 = get('val', __marker)

                        # <Value u"python:'' if not val else val" (489:36)> -> __value
                        __token = 20559
                        try:
                            __zt_tmp = __attrs_127045737380176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u"'' if not val else val", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['val'] = __value

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737379536
                        __default_127045737379536 = _DEFAULT_MARKER

                        # <Substitution u'python:arnum' (490:44)> -> __attr_arnum
                        __token = 20638
                        try:
                            __zt_tmp = __attrs_127045737380176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_arnum is not None):
                            __append((u' arnum="%s"' % __attr_arnum))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737379792
                        __default_127045737379792 = _DEFAULT_MARKER

                        # <Substitution u'python:newFieldName' (490:67)> -> __attr_fieldName
                        __token = 20661
                        try:
                            __zt_tmp = __attrs_127045737380176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_fieldName = _static_127045886978192('python', u'newFieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_fieldName = __quote(__attr_fieldName, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_fieldName is not None):
                            __append((u' fieldName="%s"' % __attr_fieldName))
                        __append(u'>\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c240bfe50> name=None at 738c240bfed0> -> __attrs_127045737395408
                        __attrs_127045737395408 = _static_127045737381456

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737394832
                        __default_127045737394832 = _DEFAULT_MARKER

                        # <Substitution u'val/UID|val|nothing' (492:49)> -> __attr_value
                        __token = 20776
                        try:
                            __zt_tmp = __attrs_127045737395408
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_127045886978192('path', u'val/UID|val|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737395152
                        __default_127045737395152 = _DEFAULT_MARKER

                        # <Substitution u'newFieldName' (493:47)> -> __attr_name
                        __token = 20845
                        try:
                            __zt_tmp = __attrs_127045737395408
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_127045886978192('path', u'newFieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))
                        __append(u'/>\r\n                  </td>')
                        if (__backup_val_127045737378640 is __marker):
                            del econtext['val']
                        else:
                            econtext['val'] = __backup_val_127045737378640
                        if (__backup_val_127045737350544 is __marker):
                            del econtext['val']
                        else:
                            econtext['val'] = __backup_val_127045737350544
                        if (__backup_newFieldName_127045737316624 is __marker):
                            del econtext['newFieldName']
                        else:
                            econtext['newFieldName'] = __backup_newFieldName_127045737316624
                        __append(u'\r\n                ')
                        ____index_127045737378256 -= 1
                        if (____index_127045737378256 > 0):
                            __append('')
                    if (__backup_arnum_127045737318480 is __marker):
                        del econtext['arnum']
                    else:
                        econtext['arnum'] = __backup_arnum_127045737318480
                    __append(u'\r\n              </tr>\r\n            ')
                    if (__backup_fieldName_127045737299344 is __marker):
                        del econtext['fieldName']
                    else:
                        econtext['fieldName'] = __backup_fieldName_127045737299344
                    __append(u'\r\n          ')
                    ____index_127045737316688 -= 1
                    if (____index_127045737316688 > 0):
                        __append('')
                if (__backup_field_127045737687824 is __marker):
                    del econtext['field']
                else:
                    econtext['field'] = __backup_field_127045737687824
                __append(u'\r\n\r\n          <!-- POCs (Field/Lab) -->\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737363536
                __attrs_127045737363536 = _static_127045970670736
                __backup_poc_127045737765200 = get('poc', __marker)

                # <Value u'python:view.get_points_of_capture()' (501:35)> -> __iterator
                __token = 21064
                try:
                    __zt_tmp = __attrs_127045737363536
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_127045886978192('python', u'view.get_points_of_capture()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                (__iterator, ____index_127045737365264, ) = getitem('repeat')(u'poc', __iterator)
                econtext['poc'] = None
                for __item in __iterator:
                    econtext['poc'] = __item
                    __append(u'\r\n            <!-- Services in POC -->\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737381648
                    __attrs_127045737381648 = _static_127045970670736
                    __backup_services_127045737279248 = get('services', __marker)

                    # <Value u'python:view.get_services(poc)' (503:54)> -> __value
                    __token = 21195
                    try:
                        __zt_tmp = __attrs_127045737381648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'view.get_services(poc)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['services'] = __value
                    __backup_categories_127045737309200 = get('categories', __marker)

                    # <Value u'python:view.get_service_categories()' (504:55)> -> __value
                    __token = 21282
                    try:
                        __zt_tmp = __attrs_127045737381648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'view.get_service_categories()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['categories'] = __value
                    __backup_ar_count_127045737337616 = get('ar_count', __marker)

                    # <Value u'python:view.ar_count' (505:52)> -> __value
                    __token = 21374
                    try:
                        __zt_tmp = __attrs_127045737381648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_127045886978192('python', u'view.ar_count', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    econtext['ar_count'] = __value

                    # <Value u'python:any(services.values())' (506:48)> -> __condition
                    __token = 21448
                    try:
                        __zt_tmp = __attrs_127045737381648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('python', u'any(services.values())', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n\r\n              ')

                        # <Static value=<_ast.Dict object at 0x738c240c3990> name=None at 738c240c3950> -> __attrs_127045737398096
                        __attrs_127045737398096 = _static_127045737396624

                        # <tr ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<tr')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737397264
                        __default_127045737397264 = _DEFAULT_MARKER

                        # <Substitution u'poc' (508:38)> -> __attr_poc
                        __token = 21521
                        try:
                            __zt_tmp = __attrs_127045737398096
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_poc = _static_127045886978192('path', u'poc', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_poc = __quote(__attr_poc, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_poc is not None):
                            __append((u' poc="%s"' % __attr_poc))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737397520
                        __default_127045737397520 = _DEFAULT_MARKER

                        # <Substitution u'poc' (509:42)> -> __attr_data_poc
                        __token = 21569
                        try:
                            __zt_tmp = __attrs_127045737398096
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_poc = _static_127045886978192('path', u'poc', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_data_poc = __quote(__attr_data_poc, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_poc is not None):
                            __append((u' data-poc="%s"' % __attr_data_poc))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737397776
                        __default_127045737397776 = _DEFAULT_MARKER

                        # <Substitution u'string:${poc} service-listing-header field-services-header' (510:38)> -> __attr_class
                        __token = 21614
                        try:
                            __zt_tmp = __attrs_127045737398096
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_127045886978192('string', u'${poc} service-listing-header field-services-header', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))
                        __append(u'>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c240ca290> name=None at 738c240ca210> -> __attrs_127045737424080
                        __attrs_127045737424080 = _static_127045737423504

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td colspan="2">\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c240ca7d0> name=None at 738c240ca790> -> __attrs_127045737425488
                        __attrs_127045737425488 = _static_127045737424848

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="poc-service-title">\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737426512
                        __attrs_127045737426512 = _static_127045970670736

                        # <Value u"python:poc=='field'" (513:41)> -> __condition
                        __token = 21804
                        try:
                            __zt_tmp = __attrs_127045737426512
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_127045886978192('python', u"poc=='field'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_127045737426192 = []
                            __append_127045737426192 = __stream_127045737426192.append
                            __append_127045737426192(u'\r\n                      Field Analyses\r\n                    ')
                            __msgid_127045737426192 = __re_whitespace(''.join(__stream_127045737426192)).strip()
                            if __msgid_127045737426192:
                                __append(translate(__msgid_127045737426192, mapping=None, default=__msgid_127045737426192, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>')
                        __append(u'\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737443856
                        __attrs_127045737443856 = _static_127045970670736

                        # <Value u"python:poc=='lab'" (517:41)> -> __condition
                        __token = 21980
                        try:
                            __zt_tmp = __attrs_127045737443856
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_127045886978192('python', u"poc=='lab'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_127045737443472 = []
                            __append_127045737443472 = __stream_127045737443472.append
                            __append_127045737443472(u'\r\n                      Lab Analyses\r\n                    ')
                            __msgid_127045737443472 = __re_whitespace(''.join(__stream_127045737443472)).strip()
                            if __msgid_127045737443472:
                                __append(translate(__msgid_127045737443472, mapping=None, default=__msgid_127045737443472, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>')
                        __append(u'\r\n                  </div>\r\n                </td>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c240ca090> name=None at 738c240ca710> -> __attrs_127045737444560
                        __attrs_127045737444560 = _static_127045737422992

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737444240
                        __default_127045737444240 = _DEFAULT_MARKER

                        # <Substitution u'python:1 + ar_count' (523:44)> -> __attr_colspan
                        __token = 22204
                        try:
                            __zt_tmp = __attrs_127045737444560
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_colspan = _static_127045886978192('python', u'1 + ar_count', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_colspan = __quote(__attr_colspan, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_colspan is not None):
                            __append((u' colspan="%s"' % __attr_colspan))
                        __append(u'>\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c240cf790> name=None at 738c240cf710> -> __attrs_127045737445840
                        __attrs_127045737445840 = _static_127045737445264

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="input-group">\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c240cfc10> name=None at 738c240cfc50> -> __attrs_127045737472848
                        __attrs_127045737472848 = _static_127045737446416

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" class="form-control services-filter"                            data-poc="poc"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737472592
                        __default_127045737472592 = _DEFAULT_MARKER

                        # <Translate msgid=None node=<_ast.Str object at 0x738c240d6190> at 738c240d61d0> -> __attr_placeholder
                        __attr_placeholder = u'Filter analyses by name...'
                        __attr_placeholder = translate(__attr_placeholder, default=__attr_placeholder, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_placeholder is not None):
                            __append((u'                            placeholder="%s"' % __attr_placeholder))
                        __append(u'/>\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x738c240d6490> name=None at 738c240d6410> -> __attrs_127045737473808
                        __attrs_127045737473808 = _static_127045737473168

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="input-group-append">\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x738c240d6990> name=None at 738c240d6950> -> __attrs_127045737475088
                        __attrs_127045737475088 = _static_127045737474448

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="input-group-text">\r\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c240d6f50> name=None at 738c240d6f10> -> __attrs_127045737493008
                        __attrs_127045737493008 = _static_127045737475920

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-filter"></i>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n\r\n              ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737444880
                        __attrs_127045737444880 = _static_127045970670736
                        __backup_category_127045737380112 = get('category', __marker)

                        # <Value u'categories' (538:51)> -> __iterator
                        __token = 22865
                        try:
                            __zt_tmp = __attrs_127045737444880
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_127045886978192('path', u'categories', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        (__iterator, ____index_127045737446096, ) = getitem('repeat')(u'category', __iterator)
                        econtext['category'] = None
                        for __item in __iterator:
                            econtext['category'] = __item
                            __append(u'\r\n                ')

                            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737475472
                            __attrs_127045737475472 = _static_127045970670736
                            __backup_category_id_127045737423312 = get('category_id', __marker)

                            # <Value u'python:category.getId' (540:54)> -> __value
                            __token = 23013
                            try:
                                __zt_tmp = __attrs_127045737475472
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_127045886978192('python', u'category.getId', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            econtext['category_id'] = __value
                            __backup_category_title_127045737321936 = get('category_title', __marker)

                            # <Value u'python:category.Title' (541:56)> -> __value
                            __token = 23093
                            try:
                                __zt_tmp = __attrs_127045737475472
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_127045886978192('python', u'category.Title', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            econtext['category_title'] = __value

                            # <Value u'python:services[category_title]' (539:45)> -> __condition
                            __token = 22925
                            try:
                                __zt_tmp = __attrs_127045737475472
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_127045886978192('python', u'services[category_title]', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\r\n                  ')

                                # <Static value=<_ast.Dict object at 0x738c240db750> name=None at 738c240db650> -> __attrs_127045737521424
                                __attrs_127045737521424 = _static_127045737494352

                                # <tr ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<tr')

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737495376
                                __default_127045737495376 = _DEFAULT_MARKER

                                # <Translate msgid=None node=<_ast.Str object at 0x738c240dba90> at 738c240dbad0> -> __attr_title
                                __attr_title = u'Click to expand this category'
                                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737495632
                                __default_127045737495632 = _DEFAULT_MARKER

                                # <Substitution u'python:category_id' (544:52)> -> __attr_data_category
                                __token = 23280
                                try:
                                    __zt_tmp = __attrs_127045737521424
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_data_category = _static_127045886978192('python', u'category_id', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_data_category = __quote(__attr_data_category, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_data_category is not None):
                                    __append((u' data-category="%s"' % __attr_data_category))

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737495888
                                __default_127045737495888 = _DEFAULT_MARKER

                                # <Substitution u'python:poc' (545:41)> -> __attr_poc
                                __token = 23342
                                try:
                                    __zt_tmp = __attrs_127045737521424
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_poc = _static_127045886978192('python', u'poc', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_poc = __quote(__attr_poc, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_poc is not None):
                                    __append((u' poc="%s"' % __attr_poc))

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737496208
                                __default_127045737496208 = _DEFAULT_MARKER

                                # <Substitution u"python:'field'" (546:45)> -> __attr_category
                                __token = 23401
                                try:
                                    __zt_tmp = __attrs_127045737521424
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_category = _static_127045886978192('python', u"'field'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_category = __quote(__attr_category, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_category is not None):
                                    __append((u' category="%s"' % __attr_category))

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737496464
                                __default_127045737496464 = _DEFAULT_MARKER

                                # <Substitution u"python:'{} category'.format(poc)" (547:41)> -> __attr_class
                                __token = 23461
                                try:
                                    __zt_tmp = __attrs_127045737521424
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_127045886978192('python', u"'{} category'.format(poc)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>\r\n                    ')

                                # <Static value=<_ast.Dict object at 0x738c240e2390> name=None at 738c240e2350> -> __attrs_127045737522704
                                __attrs_127045737522704 = _static_127045737522064

                                # <td ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<td class="services-category-header">\r\n                      ')

                                # <Static value=<_ast.Dict object at 0x738c240e2b50> name=None at 738c240e2b10> -> __attrs_127045737524688
                                __attrs_127045737524688 = _static_127045737524048

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span class="services-category-title">')

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737523856
                                __default_127045737523856 = _DEFAULT_MARKER

                                # <Value u'category_title' (550:41)> -> __cache_127045737523472
                                __token = 23662
                                try:
                                    __zt_tmp = __attrs_127045737524688
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_127045737523472 = _static_127045886978192('path', u'category_title', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                                # <BinOp left=<Value u'category_title' (550:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c240e29d0> -> __condition
                                __expression = __cache_127045737523472

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\r\n                        Category Title\r\n                      ')
                                else:
                                    __content = __cache_127045737523472
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>\r\n                    </td>\r\n                    ')

                                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737525072
                                __attrs_127045737525072 = _static_127045970670736

                                # <td ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<td>\r\n                      ')

                                # <Static value=<_ast.Dict object at 0x738c24068210> name=None at 738c24068250> -> __attrs_127045737023120
                                __attrs_127045737023120 = _static_127045737021968

                                # <button ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<button                               class="btn btn-default btn-xs service-category-toggle"')

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737022800
                                __default_127045737022800 = _DEFAULT_MARKER

                                # <Substitution u'category_id' (556:60)> -> __attr_data_category
                                __token = 23911
                                try:
                                    __zt_tmp = __attrs_127045737023120
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_data_category = _static_127045886978192('path', u'category_id', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_data_category = __quote(__attr_data_category, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_data_category is not None):
                                    __append((u' data-category="%s"' % __attr_data_category))
                                __append(u'>+</button>\r\n                    </td>\r\n                    <!-- span over all sample columns -->\r\n                    ')

                                # <Static value=<_ast.Dict object at 0x738c240687d0> name=None at 738c240680d0> -> __attrs_127045737024272
                                __attrs_127045737024272 = _static_127045737023440

                                # <td ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<td')

                                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737023952
                                __default_127045737023952 = _DEFAULT_MARKER

                                # <Substitution u'python:ar_count' (560:48)> -> __attr_colspan
                                __token = 24156
                                try:
                                    __zt_tmp = __attrs_127045737024272
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_colspan = _static_127045886978192('python', u'ar_count', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                __attr_colspan = __quote(__attr_colspan, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_colspan is not None):
                                    __append((u' colspan="%s"' % __attr_colspan))
                                __append(u'></td>\r\n                  </tr>\r\n\r\n                  ')

                                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737023504
                                __attrs_127045737023504 = _static_127045970670736
                                __backup_service_127045737424720 = get('service', __marker)

                                # <Value u'python:services[category_title]' (563:52)> -> __iterator
                                __token = 24259
                                try:
                                    __zt_tmp = __attrs_127045737023504
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __iterator = _static_127045886978192('python', u'services[category_title]', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                (__iterator, ____index_127045737024528, ) = getitem('repeat')(u'service', __iterator)
                                econtext['service'] = None
                                for __item in __iterator:
                                    econtext['service'] = __item
                                    __append(u'\r\n                    ')

                                    # <Static value=<_ast.Dict object at 0x738c24068f10> name=None at 738c24068e50> -> __attrs_127045737053008
                                    __attrs_127045737053008 = _static_127045737025296
                                    __backup_service_uid_127045737425744 = get('service_uid', __marker)

                                    # <Value u'python:service.UID' (564:48)> -> __value
                                    __token = 24343
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __value = _static_127045886978192('python', u'service.UID', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    econtext['service_uid'] = __value
                                    __backup_service_id_127045737475728 = get('service_id', __marker)

                                    # <Value u'python:service.getId' (565:46)> -> __value
                                    __token = 24410
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __value = _static_127045886978192('python', u'service.getId', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    econtext['service_id'] = __value
                                    __backup_service_keyword_127045737522960 = get('service_keyword', __marker)

                                    # <Value u'python:service.getKeyword' (566:50)> -> __value
                                    __token = 24484
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __value = _static_127045886978192('python', u'service.getKeyword', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    econtext['service_keyword'] = __value
                                    __backup_service_title_127045737523408 = get('service_title', __marker)

                                    # <Value u'python:service.Title' (567:47)> -> __value
                                    __token = 24561
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __value = _static_127045886978192('python', u'service.Title', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    econtext['service_title'] = __value

                                    # <tr ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<tr')

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737051088
                                    __default_127045737051088 = _DEFAULT_MARKER

                                    # <Substitution u'python:service_id' (568:43)> -> __attr_id
                                    __token = 24631
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_127045886978192('python', u'service_id', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737051344
                                    __default_127045737051344 = _DEFAULT_MARKER

                                    # <Substitution u"python:'{} {} service'.format(category_id, poc)" (569:45)> -> __attr_class
                                    __token = 24696
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_class = _static_127045886978192('python', u"'{} {} service'.format(category_id, poc)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_class is not None):
                                        __append((u' class="%s"' % __attr_class))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737051600
                                    __default_127045737051600 = _DEFAULT_MARKER

                                    # <Substitution u'python:poc' (570:42)> -> __attr_poc
                                    __token = 24789
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_poc = _static_127045886978192('python', u'poc', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_poc = __quote(__attr_poc, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_poc is not None):
                                        __append((u' poc="%s"' % __attr_poc))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737051856
                                    __default_127045737051856 = _DEFAULT_MARKER

                                    # <Substitution u'python:service_uid' (571:46)> -> __attr_data_uid
                                    __token = 24850
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_data_uid = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_data_uid = __quote(__attr_data_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_data_uid is not None):
                                        __append((u' data-uid="%s"' % __attr_data_uid))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737052112
                                    __default_127045737052112 = _DEFAULT_MARKER

                                    # <Substitution u'python:service_keyword' (572:49)> -> __attr_data_keyword
                                    __token = 24923
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_data_keyword = _static_127045886978192('python', u'service_keyword', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_data_keyword = __quote(__attr_data_keyword, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_data_keyword is not None):
                                        __append((u' data-keyword="%s"' % __attr_data_keyword))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737052368
                                    __default_127045737052368 = _DEFAULT_MARKER

                                    # <Substitution u'python:category_id' (573:49)> -> __attr_data_category
                                    __token = 25001
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_data_category = _static_127045886978192('python', u'category_id', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_data_category = __quote(__attr_data_category, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_data_category is not None):
                                        __append((u' data-category="%s"' % __attr_data_category))

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737052624
                                    __default_127045737052624 = _DEFAULT_MARKER

                                    # <Substitution u"python:'Analyses'" (574:44)> -> __attr_fieldname
                                    __token = 25071
                                    try:
                                        __zt_tmp = __attrs_127045737053008
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_fieldname = _static_127045886978192('python', u"'Analyses'", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    __attr_fieldname = __quote(__attr_fieldname, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_fieldname is not None):
                                        __append((u' fieldname="%s"' % __attr_fieldname))
                                    __append(u'>\r\n                      ')

                                    # <Static value=<_ast.Dict object at 0x738c24074190> name=None at 738c24074110> -> __attrs_127045737071632
                                    __attrs_127045737071632 = _static_127045737070992

                                    # <td ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<td class="service-header">\r\n                        ')

                                    # <Static value=<_ast.Dict object at 0x738c24074950> name=None at 738c24074910> -> __attrs_127045737073616
                                    __attrs_127045737073616 = _static_127045737072976

                                    # <div ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<div class="service-title small">')

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737072784
                                    __default_127045737072784 = _DEFAULT_MARKER

                                    # <Value u'service_title' (578:42)> -> __cache_127045737072400
                                    __token = 25298
                                    try:
                                        __zt_tmp = __attrs_127045737073616
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __cache_127045737072400 = _static_127045886978192('path', u'service_title', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                                    # <BinOp left=<Value u'service_title' (578:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c240747d0> -> __condition
                                    __expression = __cache_127045737072400

                                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                                    __value = _DEFAULT_MARKER
                                    __condition = (__expression is __value)
                                    if __condition:
                                        __append(u'\r\n                          Service Title\r\n                        ')
                                    else:
                                        __content = __cache_127045737072400
                                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        __content = __quote(__content, None, '\xad', None, None)
                                        if (__content is not None):
                                            __append(__content)
                                    __append(u'</div>\r\n                      </td>\r\n                      ')

                                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737074000
                                    __attrs_127045737074000 = _static_127045970670736

                                    # <td ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<td>\r\n                        ')

                                    # <Static value=<_ast.Dict object at 0x738c24079050> name=None at 738c24074f90> -> __attrs_127045737091728
                                    __attrs_127045737091728 = _static_127045737091152

                                    # <Value u'python:view.show_copy_button_for()' (583:64)> -> __condition
                                    __token = 25509
                                    try:
                                        __zt_tmp = __attrs_127045737091728
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __condition = _static_127045886978192('python', u'view.show_copy_button_for()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    if __condition:

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div class="text-center">\r\n                          <!-- Copy Button -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c24079650> name=None at 738c240796d0> -> __attrs_127045737094288
                                        __attrs_127045737094288 = _static_127045737092688

                                        # <a ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<a class="copy d-block"')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737093776
                                        __default_127045737093776 = _DEFAULT_MARKER

                                        # <Translate msgid=None node=<_ast.Str object at 0x738c240799d0> at 738c24079a10> -> __attr_title
                                        __attr_title = u'Copy the currently displayed column value to the other columns on the right'
                                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        if (__attr_title is not None):
                                            __append((u'                              title="%s"' % __attr_title))
                                        __append(u'                              data_toggle="tooltip">\r\n                            ')

                                        # <Static value=<_ast.Dict object at 0x738c24079f50> name=None at 738c24079f10> -> __attrs_127045737116176
                                        __attrs_127045737116176 = _static_127045737094992

                                        # <i ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<i class="fas fa-angle-double-right"></i>\r\n                          </a>\r\n                        </div>')
                                    __append(u'\r\n                      </td>\r\n\r\n                      ')

                                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737092432
                                    __attrs_127045737092432 = _static_127045970670736
                                    __backup_arnum_127045737053264 = get('arnum', __marker)

                                    # <Value u'python:range(ar_count)' (594:53)> -> __iterator
                                    __token = 26086
                                    try:
                                        __zt_tmp = __attrs_127045737092432
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __iterator = _static_127045886978192('python', u'range(ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                    (__iterator, ____index_127045737094352, ) = getitem('repeat')(u'arnum', __iterator)
                                    econtext['arnum'] = None
                                    for __item in __iterator:
                                        econtext['arnum'] = __item
                                        __append(u'\r\n                        ')

                                        # <Static value=<_ast.Dict object at 0x738c2407f410> name=None at 738c2407f3d0> -> __attrs_127045737118736
                                        __attrs_127045737118736 = _static_127045737116688
                                        __backup_fieldname_127045737070800 = get('fieldname', __marker)

                                        # <Value u"python:'Analyses-{}'.format(arnum)" (595:50)> -> __value
                                        __token = 26162
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u"'Analyses-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['fieldname'] = __value
                                        __backup_analyses_127045737092112 = get('analyses', __marker)

                                        # <Value u'python:view.fieldvalues.get(fieldname) or []' (596:48)> -> __value
                                        __token = 26247
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u'view.fieldvalues.get(fieldname) or []', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['analyses'] = __value
                                        __backup_service_uids_127045737071888 = get('service_uids', __marker)

                                        # <Value u'python:map(view.get_service_uid_from, analyses)' (597:51)> -> __value
                                        __token = 26346
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u'map(view.get_service_uid_from, analyses)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['service_uids'] = __value
                                        __backup_checked_127045737092624 = get('checked', __marker)

                                        # <Value u'python:service_uid in service_uids' (598:45)> -> __value
                                        __token = 26443
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u'service_uid in service_uids', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['checked'] = __value
                                        __backup_cls_127045737073872 = get('cls', __marker)

                                        # <Value u"python:'{}-column service-column'.format(service_uid)" (599:40)> -> __value
                                        __token = 26523
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u"'{}-column service-column'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['cls'] = __value
                                        __backup_cls_127045737094544 = get('cls', __marker)

                                        # <Value u'string: ${cls} sample-column sample-column-${arnum}' (600:39)> -> __value
                                        __token = 26622
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('string', u' ${cls} sample-column sample-column-${arnum}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['cls'] = __value
                                        __backup_cls_127045737094864 = get('cls', __marker)

                                        # <Value u"python:cls + ' d-none' if arnum > 0 else cls" (601:38)> -> __value
                                        __token = 26719
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_127045886978192('python', u"cls + ' d-none' if arnum > 0 else cls", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        econtext['cls'] = __value

                                        # <td ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<td')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737117520
                                        __default_127045737117520 = _DEFAULT_MARKER

                                        # <Substitution u"python:'Analyses-{}'.format(arnum)" (602:54)> -> __attr_fieldname
                                        __token = 26827
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_fieldname = _static_127045886978192('python', u"'Analyses-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_fieldname = __quote(__attr_fieldname, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_fieldname is not None):
                                            __append((u' fieldname="%s"' % __attr_fieldname))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737117776
                                        __default_127045737117776 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_uid' (603:47)> -> __attr_uid
                                        __token = 26911
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_uid = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_uid = __quote(__attr_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_uid is not None):
                                            __append((u' uid="%s"' % __attr_uid))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737118032
                                        __default_127045737118032 = _DEFAULT_MARKER

                                        # <Substitution u'python:cls' (604:48)> -> __attr_class
                                        __token = 26981
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u'cls', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737118352
                                        __default_127045737118352 = _DEFAULT_MARKER

                                        # <Substitution u'python:arnum' (605:47)> -> __attr_arnum
                                        __token = 27043
                                        try:
                                            __zt_tmp = __attrs_127045737118736
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_arnum is not None):
                                            __append((u' arnum="%s"' % __attr_arnum))
                                        __append(u'>\r\n\r\n                          <!-- Service locked button -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c240853d0> name=None at 738c24085410> -> __attrs_127045737143824
                                        __attrs_127045737143824 = _static_127045737141200

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737142416
                                        __default_127045737142416 = _DEFAULT_MARKER

                                        # <Translate msgid=None node=<_ast.Str object at 0x738c240857d0> at 738c24085810> -> __attr_title
                                        __attr_title = u'Service cannot be deselected. Please click the info button for further details'
                                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        if (__attr_title is not None):
                                            __append((u'                                title="%s"' % __attr_title))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737142672
                                        __default_127045737142672 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_uid' (608:51)> -> __attr_uid
                                        __token = 27174
                                        try:
                                            __zt_tmp = __attrs_127045737143824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_uid = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_uid = __quote(__attr_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_uid is not None):
                                            __append((u' uid="%s"' % __attr_uid))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737142992
                                        __default_127045737142992 = _DEFAULT_MARKER

                                        # <Substitution u'python:arnum' (609:52)> -> __attr_arnum
                                        __token = 27247
                                        try:
                                            __zt_tmp = __attrs_127045737143824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_arnum is not None):
                                            __append((u' arnum="%s"' % __attr_arnum))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737143248
                                        __default_127045737143248 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-{}-lockbtn'.format(service_uid, arnum)" (610:48)> -> __attr_id
                                        __token = 27311
                                        try:
                                            __zt_tmp = __attrs_127045737143824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-{}-lockbtn'.format(service_uid, arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737143504
                                        __default_127045737143504 = _DEFAULT_MARKER

                                        # <Substitution u"python:'service-lockbtn {}-lockbtn'.format(service_uid)" (611:50)> -> __attr_class
                                        __token = 27415
                                        try:
                                            __zt_tmp = __attrs_127045737143824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'service-lockbtn {}-lockbtn'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                            &#128274;\r\n                          </div>\r\n\r\n                          <!-- Beyond holding time box -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c2408f090> name=None at 738c24085f90> -> __attrs_127045737183824
                                        __attrs_127045737183824 = _static_127045737181328

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737182416
                                        __default_127045737182416 = _DEFAULT_MARKER

                                        # <Translate msgid=None node=<_ast.Str object at 0x738c2408f410> at 738c2408f450> -> __attr_title
                                        __attr_title = u'This service cannot be selected to prevent the analysis from being conducted beyond the analytical holding time.'
                                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        if (__attr_title is not None):
                                            __append((u'                                title="%s"' % __attr_title))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737182672
                                        __default_127045737182672 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_uid' (618:51)> -> __attr_uid
                                        __token = 27839
                                        try:
                                            __zt_tmp = __attrs_127045737183824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_uid = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_uid = __quote(__attr_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_uid is not None):
                                            __append((u' uid="%s"' % __attr_uid))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737182992
                                        __default_127045737182992 = _DEFAULT_MARKER

                                        # <Substitution u'python:arnum' (619:52)> -> __attr_arnum
                                        __token = 27912
                                        try:
                                            __zt_tmp = __attrs_127045737183824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_arnum is not None):
                                            __append((u' arnum="%s"' % __attr_arnum))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737183248
                                        __default_127045737183248 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-{}-beyondholdingtime'.format(service_uid, arnum)" (620:48)> -> __attr_id
                                        __token = 27976
                                        try:
                                            __zt_tmp = __attrs_127045737183824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-{}-beyondholdingtime'.format(service_uid, arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737183504
                                        __default_127045737183504 = _DEFAULT_MARKER

                                        # <Substitution u"python:'service-beyondholdingtime {}-beyondholdingtime'.format(service_uid)" (621:50)> -> __attr_class
                                        __token = 28090
                                        try:
                                            __zt_tmp = __attrs_127045737183824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'service-beyondholdingtime {}-beyondholdingtime'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                            &#128683;\r\n                          </div>\r\n\r\n                          <!-- Service checkbox -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c2408fc10> name=None at 738c2408fb90> -> __attrs_127045737210000
                                        __attrs_127045737210000 = _static_127045737184272

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737184784
                                        __default_127045737184784 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-{}-analysisservice'.format(service_uid, arnum)" (628:50)> -> __attr_id
                                        __token = 28560
                                        try:
                                            __zt_tmp = __attrs_127045737210000
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-{}-analysisservice'.format(service_uid, arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737185040
                                        __default_127045737185040 = _DEFAULT_MARKER

                                        # <Substitution u"python:'analysisservice {}-analysisservice'.format(service_uid)" (629:52)> -> __attr_class
                                        __token = 28672
                                        try:
                                            __zt_tmp = __attrs_127045737210000
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'analysisservice {}-analysisservice'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                            ')

                                        # <Static value=<_ast.Dict object at 0x738c24096310> name=None at 738c240962d0> -> __attrs_127045737213840
                                        __attrs_127045737213840 = _static_127045737210640

                                        # <input ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<input type="checkbox"                                    style="height:auto;"')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737212368
                                        __default_127045737212368 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}:list'.format(fieldname)" (632:56)> -> __attr_name
                                        __token = 28906
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_name = _static_127045886978192('python', u"'{}:list'.format(fieldname)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_name is not None):
                                            __append((u' name="%s"' % __attr_name))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737212624
                                        __default_127045737212624 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_uid' (633:56)> -> __attr_value
                                        __token = 28999
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_value = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_value is not None):
                                            __append((u' value="%s"' % __attr_value))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737212880
                                        __default_127045737212880 = _DEFAULT_MARKER

                                        # <Substitution u"python:'analysisservice-cb analysisservice-cb-{}'.format(arnum)" (634:55)> -> __attr_class
                                        __token = 29076
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'analysisservice-cb analysisservice-cb-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737213136
                                        __default_127045737213136 = _DEFAULT_MARKER

                                        # <Substitution u"python:'cb_{}_{}'.format(arnum, service_uid)" (635:51)> -> __attr_id
                                        __token = 29195
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'cb_{}_{}'.format(arnum, service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737213392
                                        __default_127045737213392 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_title' (636:51)> -> __attr_alt
                                        __token = 29296
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_alt = _static_127045886978192('python', u'service_title', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_alt = __quote(__attr_alt, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_alt is not None):
                                            __append((u' alt="%s"' % __attr_alt))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737213584
                                        __default_127045737213584 = _DEFAULT_MARKER

                                        # <Boolean u"python:checked and 'checked' or ''" (637:54)> -> __attr_checked
                                        __token = 29377
                                        try:
                                            __zt_tmp = __attrs_127045737213840
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_checked = _static_127045886978192('python', u"checked and 'checked' or ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        if (__attr_checked is _DEFAULT_MARKER):
                                            __attr_checked = None
                                        else:
                                            if __attr_checked:
                                                __attr_checked = u'checked'
                                            else:
                                                __attr_checked = None
                                        if (__attr_checked is not None):
                                            __append((u' checked="%s"' % __attr_checked))
                                        __append(u'/>\r\n                          </div>\r\n\r\n                          <!-- Service info button -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c2409e110> name=None at 738c2409e0d0> -> __attrs_127045737244880
                                        __attrs_127045737244880 = _static_127045737242896

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737243728
                                        __default_127045737243728 = _DEFAULT_MARKER

                                        # <Substitution u'python:service_uid' (641:51)> -> __attr_uid
                                        __token = 29565
                                        try:
                                            __zt_tmp = __attrs_127045737244880
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_uid = _static_127045886978192('python', u'service_uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_uid = __quote(__attr_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_uid is not None):
                                            __append((u' uid="%s"' % __attr_uid))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737244048
                                        __default_127045737244048 = _DEFAULT_MARKER

                                        # <Substitution u'python:arnum' (642:52)> -> __attr_arnum
                                        __token = 29638
                                        try:
                                            __zt_tmp = __attrs_127045737244880
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_arnum is not None):
                                            __append((u' arnum="%s"' % __attr_arnum))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737244304
                                        __default_127045737244304 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-infobtn'.format(service_uid)" (643:48)> -> __attr_id
                                        __token = 29702
                                        try:
                                            __zt_tmp = __attrs_127045737244880
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-infobtn'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737244560
                                        __default_127045737244560 = _DEFAULT_MARKER

                                        # <Substitution u"python:'service-infobtn {}-infobtn'.format(service_uid)" (644:50)> -> __attr_class
                                        __token = 29796
                                        try:
                                            __zt_tmp = __attrs_127045737244880
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'service-infobtn {}-infobtn'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                            &#9432;\r\n                          </div>\r\n\r\n                          <!-- Service Info Box -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c2409ea90> name=None at 738c2409ea10> -> __attrs_127045737246416
                                        __attrs_127045737246416 = _static_127045737245328

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737245840
                                        __default_127045737245840 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-info'.format(service_uid)" (649:50)> -> __attr_id
                                        __token = 30035
                                        try:
                                            __zt_tmp = __attrs_127045737246416
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-info'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737246096
                                        __default_127045737246096 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-info service-info'.format(service_uid)" (650:52)> -> __attr_class
                                        __token = 30126
                                        try:
                                            __zt_tmp = __attrs_127045737246416
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'{}-info service-info'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                          </div>\r\n\r\n                          <!-- Service conditions -->\r\n                          ')

                                        # <Static value=<_ast.Dict object at 0x738c240a4110> name=None at 738c240a4090> -> __attrs_127045737268560
                                        __attrs_127045737268560 = _static_127045737267472

                                        # <div ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<div')

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737267984
                                        __default_127045737267984 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-conditions'.format(service_uid)" (654:50)> -> __attr_id
                                        __token = 30322
                                        try:
                                            __zt_tmp = __attrs_127045737268560
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_id = _static_127045886978192('python', u"'{}-conditions'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_id is not None):
                                            __append((u' id="%s"' % __attr_id))

                                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737268240
                                        __default_127045737268240 = _DEFAULT_MARKER

                                        # <Substitution u"python:'{}-conditions service-conditions'.format(service_uid)" (655:52)> -> __attr_class
                                        __token = 30419
                                        try:
                                            __zt_tmp = __attrs_127045737268560
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_127045886978192('python', u"'{}-conditions service-conditions'.format(service_uid)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'>\r\n                          </div>\r\n\r\n                        </td>')
                                        if (__backup_cls_127045737094864 is __marker):
                                            del econtext['cls']
                                        else:
                                            econtext['cls'] = __backup_cls_127045737094864
                                        if (__backup_cls_127045737094544 is __marker):
                                            del econtext['cls']
                                        else:
                                            econtext['cls'] = __backup_cls_127045737094544
                                        if (__backup_cls_127045737073872 is __marker):
                                            del econtext['cls']
                                        else:
                                            econtext['cls'] = __backup_cls_127045737073872
                                        if (__backup_checked_127045737092624 is __marker):
                                            del econtext['checked']
                                        else:
                                            econtext['checked'] = __backup_checked_127045737092624
                                        if (__backup_service_uids_127045737071888 is __marker):
                                            del econtext['service_uids']
                                        else:
                                            econtext['service_uids'] = __backup_service_uids_127045737071888
                                        if (__backup_analyses_127045737092112 is __marker):
                                            del econtext['analyses']
                                        else:
                                            econtext['analyses'] = __backup_analyses_127045737092112
                                        if (__backup_fieldname_127045737070800 is __marker):
                                            del econtext['fieldname']
                                        else:
                                            econtext['fieldname'] = __backup_fieldname_127045737070800
                                        __append(u'\r\n                      ')
                                        ____index_127045737094352 -= 1
                                        if (____index_127045737094352 > 0):
                                            __append('')
                                    if (__backup_arnum_127045737053264 is __marker):
                                        del econtext['arnum']
                                    else:
                                        econtext['arnum'] = __backup_arnum_127045737053264
                                    __append(u'\r\n                    </tr>')
                                    if (__backup_service_title_127045737523408 is __marker):
                                        del econtext['service_title']
                                    else:
                                        econtext['service_title'] = __backup_service_title_127045737523408
                                    if (__backup_service_keyword_127045737522960 is __marker):
                                        del econtext['service_keyword']
                                    else:
                                        econtext['service_keyword'] = __backup_service_keyword_127045737522960
                                    if (__backup_service_id_127045737475728 is __marker):
                                        del econtext['service_id']
                                    else:
                                        econtext['service_id'] = __backup_service_id_127045737475728
                                    if (__backup_service_uid_127045737425744 is __marker):
                                        del econtext['service_uid']
                                    else:
                                        econtext['service_uid'] = __backup_service_uid_127045737425744
                                    __append(u'\r\n                  ')
                                    ____index_127045737024528 -= 1
                                    if (____index_127045737024528 > 0):
                                        __append('')
                                if (__backup_service_127045737424720 is __marker):
                                    del econtext['service']
                                else:
                                    econtext['service'] = __backup_service_127045737424720
                                __append(u'\r\n                ')
                            if (__backup_category_title_127045737321936 is __marker):
                                del econtext['category_title']
                            else:
                                econtext['category_title'] = __backup_category_title_127045737321936
                            if (__backup_category_id_127045737423312 is __marker):
                                del econtext['category_id']
                            else:
                                econtext['category_id'] = __backup_category_id_127045737423312
                            __append(u'\r\n              ')
                            ____index_127045737446096 -= 1
                            if (____index_127045737446096 > 0):
                                __append('')
                        if (__backup_category_127045737380112 is __marker):
                            del econtext['category']
                        else:
                            econtext['category'] = __backup_category_127045737380112
                        __append(u'\r\n            ')
                    if (__backup_ar_count_127045737337616 is __marker):
                        del econtext['ar_count']
                    else:
                        econtext['ar_count'] = __backup_ar_count_127045737337616
                    if (__backup_categories_127045737309200 is __marker):
                        del econtext['categories']
                    else:
                        econtext['categories'] = __backup_categories_127045737309200
                    if (__backup_services_127045737279248 is __marker):
                        del econtext['services']
                    else:
                        econtext['services'] = __backup_services_127045737279248
                    __append(u'\r\n            <!-- /Services in POC -->\r\n          ')
                    ____index_127045737365264 -= 1
                    if (____index_127045737365264 > 0):
                        __append('')
                if (__backup_poc_127045737765200 is __marker):
                    del econtext['poc']
                else:
                    econtext['poc'] = __backup_poc_127045737765200
                __append(u'\r\n          <!-- /POCs -->\r\n\r\n          <!-- Prices -->\r\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737475152
                __attrs_127045737475152 = _static_127045970670736

                # <Value u'python:view.ShowPrices' (670:37)> -> __condition
                __token = 30908
                try:
                    __zt_tmp = __attrs_127045737475152
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u'view.ShowPrices', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737074064
                    __attrs_127045737074064 = _static_127045970670736

                    # <Value u'python:view.getMemberDiscountApplies()' (671:31)> -> __condition
                    __token = 30965
                    try:
                        __zt_tmp = __attrs_127045737074064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('python', u'view.getMemberDiscountApplies()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <tr ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<tr>\r\n              ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737268624
                        __attrs_127045737268624 = _static_127045970670736

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c240a48d0> name=None at 738c240a4890> -> __attrs_127045737270096
                        __attrs_127045737270096 = _static_127045737269456

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="pricelabel discount">')
                        __stream_127045737269328 = []
                        __append_127045737269328 = __stream_127045737269328.append
                        __append_127045737269328(u'Discount')
                        __msgid_127045737269328 = __re_whitespace(''.join(__stream_127045737269328)).strip()
                        if __msgid_127045737269328:
                            __append(translate(__msgid_127045737269328, mapping=None, default=__msgid_127045737269328, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c240a4d10> name=None at 738c240a4cd0> -> __attrs_127045737271120
                        __attrs_127045737271120 = _static_127045737270544

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="discreet">(')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736772624
                        __attrs_127045736772624 = _static_127045970670736

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736772304
                        __default_127045736772304 = _DEFAULT_MARKER

                        # <Value u'python:context.bika_setup.getMemberDiscount()' (674:56)> -> __cache_127045736771984
                        __token = 31168
                        try:
                            __zt_tmp = __attrs_127045736772624
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045736771984 = _static_127045886978192('python', u'context.bika_setup.getMemberDiscount()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:context.bika_setup.getMemberDiscount()' (674:56)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c2402b210> -> __condition
                        __expression = __cache_127045736771984

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_127045736771984
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'%)</span>\r\n              </td>\r\n              ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736771792
                        __attrs_127045736771792 = _static_127045970670736

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736773840
                        __attrs_127045736773840 = _static_127045970670736

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736773712
                        __default_127045736773712 = _DEFAULT_MARKER

                        # <Value u'currency_symbol' (677:35)> -> __cache_127045736773328
                        __token = 31303
                        try:
                            __zt_tmp = __attrs_127045736773840
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045736773328 = _static_127045886978192('path', u'currency_symbol', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'currency_symbol' (677:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c2402b790> -> __condition
                        __expression = __cache_127045736773328

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span/>')
                        else:
                            __content = __cache_127045736773328
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n              </td>\r\n              ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736774032
                        __attrs_127045736774032 = _static_127045970670736
                        __backup_arnum_127045737308816 = get('arnum', __marker)

                        # <Value u'python:range(view.ar_count)' (679:41)> -> __iterator
                        __token = 31385
                        try:
                            __zt_tmp = __attrs_127045736774032
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        (__iterator, ____index_127045736774224, ) = getitem('repeat')(u'arnum', __iterator)
                        econtext['arnum'] = None
                        for __item in __iterator:
                            econtext['arnum'] = __item
                            __append(u'\r\n                ')

                            # <Static value=<_ast.Dict object at 0x738c2402bd10> name=None at 738c2402bc90> -> __attrs_127045736775632
                            __attrs_127045736775632 = _static_127045736774928

                            # <td ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<td')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736775312
                            __default_127045736775312 = _DEFAULT_MARKER

                            # <Substitution u'python:arnum' (680:42)> -> __attr_arnum
                            __token = 31458
                            try:
                                __zt_tmp = __attrs_127045736775632
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_arnum is not None):
                                __append((u' arnum="%s"' % __attr_arnum))
                            __append(u'>\r\n                  ')

                            # <Static value=<_ast.Dict object at 0x738c24030290> name=None at 738c24030250> -> __attrs_127045736793744
                            __attrs_127045736793744 = _static_127045736792720

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="price discount noborder"')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736793424
                            __default_127045736793424 = _DEFAULT_MARKER

                            # <Substitution u"python:'discount-{}'.format(arnum)" (682:43)> -> __attr_id
                            __token = 31574
                            try:
                                __zt_tmp = __attrs_127045736793744
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_127045886978192('python', u"'discount-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))
                            __append(u'>0.00</span>\r\n                </td>\r\n              ')
                            ____index_127045736774224 -= 1
                            if (____index_127045736774224 > 0):
                                __append('')
                        if (__backup_arnum_127045737308816 is __marker):
                            del econtext['arnum']
                        else:
                            econtext['arnum'] = __backup_arnum_127045737308816
                        __append(u'\r\n            </tr>')
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736774864
                    __attrs_127045736774864 = _static_127045970670736

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736794320
                    __attrs_127045736794320 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c24030b90> name=None at 738c24030b50> -> __attrs_127045736795664
                    __attrs_127045736795664 = _static_127045736795024

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="pricelabel subtotal">')
                    __stream_127045736794896 = []
                    __append_127045736794896 = __stream_127045736794896.append
                    __append_127045736794896(u'Subtotal')
                    __msgid_127045736794896 = __re_whitespace(''.join(__stream_127045736794896)).strip()
                    if __msgid_127045736794896:
                        __append(translate(__msgid_127045736794896, mapping=None, default=__msgid_127045736794896, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736795984
                    __attrs_127045736795984 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736817872
                    __attrs_127045736817872 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736817744
                    __default_127045736817744 = _DEFAULT_MARKER

                    # <Value u'currency_symbol' (691:35)> -> __cache_127045736817360
                    __token = 31894
                    try:
                        __zt_tmp = __attrs_127045736817872
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045736817360 = _static_127045886978192('path', u'currency_symbol', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'currency_symbol' (691:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24036390> -> __condition
                    __expression = __cache_127045736817360

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_127045736817360
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736818064
                    __attrs_127045736818064 = _static_127045970670736
                    __backup_arnum_127045737381008 = get('arnum', __marker)

                    # <Value u'python:range(view.ar_count)' (693:41)> -> __iterator
                    __token = 31976
                    try:
                        __zt_tmp = __attrs_127045736818064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045736818256, ) = getitem('repeat')(u'arnum', __iterator)
                    econtext['arnum'] = None
                    for __item in __iterator:
                        econtext['arnum'] = __item
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c24036910> name=None at 738c24036890> -> __attrs_127045736819664
                        __attrs_127045736819664 = _static_127045736818960

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736819344
                        __default_127045736819344 = _DEFAULT_MARKER

                        # <Substitution u'python:arnum' (694:42)> -> __attr_arnum
                        __token = 32049
                        try:
                            __zt_tmp = __attrs_127045736819664
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_arnum = _static_127045886978192('python', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_arnum is not None):
                            __append((u' arnum="%s"' % __attr_arnum))
                        __append(u'>\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c24036e50> name=None at 738c24036e10> -> __attrs_127045736841872
                        __attrs_127045736841872 = _static_127045736820304

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="price subtotal noborder"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736841552
                        __default_127045736841552 = _DEFAULT_MARKER

                        # <Substitution u"python:'subtotal-{}'.format(arnum)" (696:43)> -> __attr_id
                        __token = 32165
                        try:
                            __zt_tmp = __attrs_127045736841872
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('python', u"'subtotal-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>0.00</span>\r\n                </td>\r\n              ')
                        ____index_127045736818256 -= 1
                        if (____index_127045736818256 > 0):
                            __append('')
                    if (__backup_arnum_127045737381008 is __marker):
                        del econtext['arnum']
                    else:
                        econtext['arnum'] = __backup_arnum_127045737381008
                    __append(u'\r\n            </tr>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736818576
                    __attrs_127045736818576 = _static_127045970670736

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736842448
                    __attrs_127045736842448 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c2403c7d0> name=None at 738c2403c750> -> __attrs_127045736843856
                    __attrs_127045736843856 = _static_127045736843216

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="pricelabel vat">')
                    __stream_127045736843024 = []
                    __append_127045736843024 = __stream_127045736843024.append
                    __append_127045736843024(u'VAT')
                    __msgid_127045736843024 = __re_whitespace(''.join(__stream_127045736843024)).strip()
                    if __msgid_127045736843024:
                        __append(translate(__msgid_127045736843024, mapping=None, default=__msgid_127045736843024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736844176
                    __attrs_127045736844176 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736870160
                    __attrs_127045736870160 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736870032
                    __default_127045736870032 = _DEFAULT_MARKER

                    # <Value u'currency_symbol' (705:35)> -> __cache_127045736845008
                    __token = 32475
                    try:
                        __zt_tmp = __attrs_127045736870160
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045736845008 = _static_127045886978192('path', u'currency_symbol', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'currency_symbol' (705:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c2403cf90> -> __condition
                    __expression = __cache_127045736845008

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_127045736845008
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736870352
                    __attrs_127045736870352 = _static_127045970670736
                    __backup_arnum_127045737426128 = get('arnum', __marker)

                    # <Value u'python:range(view.ar_count)' (707:41)> -> __iterator
                    __token = 32557
                    try:
                        __zt_tmp = __attrs_127045736870352
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045736870544, ) = getitem('repeat')(u'arnum', __iterator)
                    econtext['arnum'] = None
                    for __item in __iterator:
                        econtext['arnum'] = __item
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c240434d0> name=None at 738c24043490> -> __attrs_127045736871760
                        __attrs_127045736871760 = _static_127045736871120

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736871440
                        __default_127045736871440 = _DEFAULT_MARKER

                        # <Substitution u'arnum' (708:42)> -> __attr_arnum
                        __token = 32630
                        try:
                            __zt_tmp = __attrs_127045736871760
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_arnum = _static_127045886978192('path', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_arnum is not None):
                            __append((u' arnum="%s"' % __attr_arnum))
                        __append(u'>\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c240439d0> name=None at 738c24043990> -> __attrs_127045736873424
                        __attrs_127045736873424 = _static_127045736872400

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="price vat noborder"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736873104
                        __default_127045736873104 = _DEFAULT_MARKER

                        # <Substitution u"python:'vat-{}'.format(arnum)" (710:43)> -> __attr_id
                        __token = 32734
                        try:
                            __zt_tmp = __attrs_127045736873424
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('python', u"'vat-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>0.00</span>\r\n                </td>\r\n              ')
                        ____index_127045736870544 -= 1
                        if (____index_127045736870544 > 0):
                            __append('')
                    if (__backup_arnum_127045737426128 is __marker):
                        del econtext['arnum']
                    else:
                        econtext['arnum'] = __backup_arnum_127045737426128
                    __append(u'\r\n            </tr>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736870864
                    __attrs_127045736870864 = _static_127045970670736

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736890512
                    __attrs_127045736890512 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c24048350> name=None at 738c24048310> -> __attrs_127045736891856
                    __attrs_127045736891856 = _static_127045736891216

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="pricelabel total">')
                    __stream_127045736891088 = []
                    __append_127045736891088 = __stream_127045736891088.append
                    __append_127045736891088(u'Total')
                    __msgid_127045736891088 = __re_whitespace(''.join(__stream_127045736891088)).strip()
                    if __msgid_127045736891088:
                        __append(translate(__msgid_127045736891088, mapping=None, default=__msgid_127045736891088, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736892176
                    __attrs_127045736892176 = _static_127045970670736

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736893520
                    __attrs_127045736893520 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736893392
                    __default_127045736893392 = _DEFAULT_MARKER

                    # <Value u'currency_symbol' (719:35)> -> __cache_127045736893008
                    __token = 33043
                    try:
                        __zt_tmp = __attrs_127045736893520
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045736893008 = _static_127045886978192('path', u'currency_symbol', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'currency_symbol' (719:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24048b10> -> __condition
                    __expression = __cache_127045736893008

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_127045736893008
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              </td>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736893712
                    __attrs_127045736893712 = _static_127045970670736
                    __backup_arnum_127045737475344 = get('arnum', __marker)

                    # <Value u'python:range(view.ar_count)' (721:41)> -> __iterator
                    __token = 33125
                    try:
                        __zt_tmp = __attrs_127045736893712
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('python', u'range(view.ar_count)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045736893904, ) = getitem('repeat')(u'arnum', __iterator)
                    econtext['arnum'] = None
                    for __item in __iterator:
                        econtext['arnum'] = __item
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x738c2404e050> name=None at 738c24048fd0> -> __attrs_127045736915664
                        __attrs_127045736915664 = _static_127045736915024

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736915344
                        __default_127045736915344 = _DEFAULT_MARKER

                        # <Substitution u'arnum' (722:42)> -> __attr_arnum
                        __token = 33198
                        try:
                            __zt_tmp = __attrs_127045736915664
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_arnum = _static_127045886978192('path', u'arnum', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_arnum = __quote(__attr_arnum, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_arnum is not None):
                            __append((u' arnum="%s"' % __attr_arnum))
                        __append(u'>\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x738c2404e550> name=None at 738c2404e510> -> __attrs_127045736917328
                        __attrs_127045736917328 = _static_127045736916304

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="price total noborder"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736917008
                        __default_127045736917008 = _DEFAULT_MARKER

                        # <Substitution u"python:'total-{}'.format(arnum)" (724:43)> -> __attr_id
                        __token = 33304
                        try:
                            __zt_tmp = __attrs_127045736917328
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('python', u"'total-{}'.format(arnum)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>0.00</span>\r\n                </td>\r\n              ')
                        ____index_127045736893904 -= 1
                        if (____index_127045736893904 > 0):
                            __append('')
                    if (__backup_arnum_127045737475344 is __marker):
                        del econtext['arnum']
                    else:
                        econtext['arnum'] = __backup_arnum_127045737475344
                    __append(u'\r\n            </tr>\r\n          ')
                __append(u'\r\n\r\n        </table>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c240d6750> name=None at 738c240d6890> -> __attrs_127045736918160
                __attrs_127045736918160 = _static_127045737473872

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input class="btn btn-success btn-sm"                type="submit"                name="save_button"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736917904
                __default_127045736917904 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c2404ead0> at 738c2404eb10> -> __attr_value
                __attr_value = u'Save'
                __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_value is not None):
                    __append((u'                value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c2404edd0> name=None at 738c2404ee50> -> __attrs_127045736944976
                __attrs_127045736944976 = _static_127045736918480

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input class="btn btn-outline-success btn-sm"                type="submit"                name="save_and_copy_button"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736944720
                __default_127045736944720 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c24055390> at 738c240553d0> -> __attr_value
                __attr_value = u'Save and Copy'
                __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_value is not None):
                    __append((u'                value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24055690> name=None at 738c240556d0> -> __attrs_127045736947152
                __attrs_127045736947152 = _static_127045736945296

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input class="btn btn-outline-secondary btn-sm"                type="submit"                name="cancel_button"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736946896
                __default_127045736946896 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x738c24055c10> at 738c24055c50> -> __attr_value
                __attr_value = u'Cancel'
                __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_value is not None):
                    __append((u'                value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c24055f90> name=None at 738c24055fd0> -> __attrs_127045736965520
                __attrs_127045736965520 = _static_127045736947600

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" id="confirmed" name="confirmed" value="0"/>\r\n\r\n        <!-- The input[type=submit] fields are not included in the request when submitting via JS.\r\n             Therefore, we set the action explicitly in the ajax event handler -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c2405a750> name=None at 738c2405a7d0> -> __attrs_127045736967312
                __attrs_127045736967312 = _static_127045736965968

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="submit_action" value="save"/>\r\n        <!-- List of previous created sample UIDs from copy&save cycles -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x738c2405ae90> name=None at 738c2405aed0> -> __attrs_127045736993744
                __attrs_127045736993744 = _static_127045736967824

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="sample_uids"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736993488
                __default_127045736993488 = _DEFAULT_MARKER

                # <Substitution u'request/sample_uids|nothing' (756:79)> -> __attr_value
                __token = 34546
                try:
                    __zt_tmp = __attrs_127045736993744
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('path', u'request/sample_uids|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n      </form>\r\n      <!-- /ADD Form -->\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x738c24061510> name=None at 738c24061490> -> __attrs_127045736994640
                __attrs_127045736994640 = _static_127045736994064

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="ar-footer"></div>\r\n\r\n    </div>')
                if (__backup_currency_symbol_127045737974288 is __marker):
                    del econtext['currency_symbol']
                else:
                    econtext['currency_symbol'] = __backup_currency_symbol_127045737974288
                if (__backup_user_127045738034512 is __marker):
                    del econtext['user']
                else:
                    econtext['user'] = __backup_user_127045738034512
                if (__backup_portal_127045738033616 is __marker):
                    del econtext['portal']
                else:
                    econtext['portal'] = __backup_portal_127045738033616
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (4:23)> -> __macro
            __token = 179
            try:
                __zt_tmp = __attrs_127045737975120
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'here/main_template/macros/master', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 179
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756215616 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756215616
            __i18n_domain = __previous_i18n_domain_127045737975248
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }