# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/address_display.pt'

__tokens = {200: (u'python:view.value', 7, 33), 256: (u'python:view.get_formatted_address(address)', 8, 35)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402356200592 = {}
_static_140402272508432 = __C2ZContextWrapper
_static_140402272508048 = __compile_zt_expr
_static_140402101072720 = {u'class': u'senaite-addresswidget-view', }
_static_140402101072976 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e95c3450> name=None at 7fb1e95c3a50> -> __attrs_140402101075728
            __attrs_140402101075728 = _static_140402101072976
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e95c3350> name=None at 7fb1e95c3490> -> __attrs_140402101074576
            __attrs_140402101074576 = _static_140402101072720

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="senaite-addresswidget-view">\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101477136
            __attrs_140402101477136 = _static_140402356200592
            __backup_address_140402101198992 = get('address', __marker)

            # <Value u'python:view.value' (7:33)> -> __iterator
            __token = 200
            try:
                __zt_tmp = __attrs_140402101477136
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_140402272508048('python', u'view.value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            (__iterator, ____index_140402101473744, ) = getitem('repeat')(u'address', __iterator)
            econtext['address'] = None
            for __item in __iterator:
                econtext['address'] = __item

                # <address ... (0:0)
                # --------------------------------------------------------
                __append(u'<address>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101476880
                __attrs_140402101476880 = _static_140402356200592

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101477072
                __default_140402101477072 = _DEFAULT_MARKER

                # <Value u'python:view.get_formatted_address(address)' (8:35)> -> __cache_140402101474640
                __token = 256
                try:
                    __zt_tmp = __attrs_140402101476880
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402101474640 = _static_140402272508048('python', u'view.get_formatted_address(address)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_formatted_address(address)' (8:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9625e50> -> __condition
                __expression = __cache_140402101474640

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span/>')
                else:
                    __content = __cache_140402101474640
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n    </address>')
                ____index_140402101473744 -= 1
                if (____index_140402101473744 > 0):
                    __append('\n    ')
            if (__backup_address_140402101198992 is __marker):
                del econtext['address']
            else:
                econtext['address'] = __backup_address_140402101198992
            __append(u'\r\n\r\n  </div>\r\n\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }