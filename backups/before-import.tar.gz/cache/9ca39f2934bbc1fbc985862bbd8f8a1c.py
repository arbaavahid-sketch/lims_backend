# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/toolbar.pt'

__tokens = {107: (u'view/context_state', 3, 31), 157: (u' view/portal_stat', 4, 29), 209: (u's python:view.get_global_sections', 5, 31), 279: (u'or python:view.get_language_selecto', 6, 32), 346: (u'bar python:view.get_personal_b', 7, 26), 505: (u'portal_state/portal_url', 11, 56), 561: (u'python:view.get_toolbar_logo()', 12, 29), 597: (u' python:view.get_toolbar_styles(', 12, 65), 1166: (u'view/base_render', 26, 34), 1338: (u'personal_bar/user_name', 33, 42), 1400: (u'global_sections/render', 34, 36), 1546: (u'language_selector/template', 39, 36), 1670: (u'personal_bar/user_name', 43, 42), 1862: (u'string:${portal_state/portal_url}/spotlight', 47, 32), 2048: (u'view/is_manager', 53, 42), 2128: (u'view/get_lims_setup_url', 55, 32), 2362: (u'personal_bar/user_name', 63, 51), 2650: (u'personal_bar/homelink_url', 71, 32), 2708: (u'personal_bar/user_name', 72, 29), 2879: (u'view/context_state/current_page_url', 76, 28), 2983: (u'personal_bar/user_actions', 78, 33), 3072: (u"python:action['href'] == url", 80, 36), 3134: (u'action', 81, 31), 3147: (u" python:selected and 'active nav-link' or 'nav-link", 81, 44), 3239: (u"python:action['id'] == 'personaltools-site-setup'", 82, 36), 3412: (u"python:action['id'] == 'personaltools-my-organization'", 85, 45), 3595: (u"python:action['id'] == 'personaltools-logout'", 88, 39), 3772: (u"python:action['id'] == 'personaltools-user-profile'", 91, 44), 3955: (u'action/title', 94, 43), 4172: (u'not:personal_bar/user_name', 103, 42), 4258: (u'personal_bar/user_actions', 104, 56), 4229: (u'python:1', 104, 27), 4329: (u'action/href', 105, 42), 4347: (u' string:nav-lin', 105, 60), 4408: (u'action/title', 106, 41), 4520: (u"python:action['id'] == 'personaltools-logout'", 109, 37)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_133838698615056 = {u'class': u'nav-item dropdown', }
_static_133838716845392 = {u'class': u'fas fa-sign-out-alt', }
_static_133838681234256 = {u'href': u'string:${portal_state/portal_url}/spotlight', u'class': u'nav-link', u'title': u'Press Ctrl+Space to trigger the Spotlight search', }
_static_133838698618512 = {u'class': u'fas fa-cog', }
_static_133838685965840 = set([u'class', ])
_static_133838681239376 = {u'class': u'nav-item', }
_static_133838716840272 = {u'id': u'senaite-toolbar', u'class': u'navbar static-top navbar-expand-md', }
_static_133838681237520 = {u'class': u'fas fa-search', }
_static_133838681271504 = {u'class': u'nav-item', }
_static_133838681204816 = {u'class': u'collapse navbar-collapse', u'id': u'toolbarContent', }
_static_133838698696464 = {u'class': u'icon-logout', }
_static_133838700740816 = {u'class': u'fas fa-user-cog', }
_static_133838716845456 = {u'class': u'fas fa-building', }
_static_133838700749072 = {u'href': u'#', u'class': u'navbar-brand', }
_static_133838698644304 = {u'class': u'nav-item', }
_static_133838681203216 = {u'class': u'fas fa-bars', }
_static_133838716843984 = {u'class': u'fas fa-wrench', }
_static_133838700751376 = {u'src': u'python:view.get_toolbar_logo()', u'style': u'python:view.get_toolbar_styles()', }
_static_133838700678480 = {u'aria-haspopup': u'true', u'aria-expanded': u'false', u'id': u'navbarUserDropdown', u'href': u'#', u'role': u'button', u'data-toggle': u'dropdown', u'class': u'nav-link dropdown-toggle', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838681233360 = {u'class': u'nav-item', }
_static_133838698617488 = {u'href': u'view/get_lims_setup_url', u'class': u'nav-link', }
_static_133838681214352 = {u'class': u'nav-item', }
_static_133838794967184 = __compile_zt_expr
_static_133838681270096 = {u'class': u'navbar-nav ml-auto', }
_static_133838698639120 = {u'aria-label': u'Toggle navigation', u'aria-controls': u'toolbarContent', u'data-target': u'#toolbarContent', u'aria-expanded': u'false', u'data-toggle': u'collapse', u'type': u'button', u'class': u'navbar-toggler btn btn-outline-light', }
_static_133838698685392 = {u'class': u'dropdown-menu dropdown-menu-right', }
_static_133838698685072 = {u'class': u'nav-item', }
_static_133838698698448 = {u'href': u'', u'class': u'string:nav-link', }
_static_133838698643920 = {u'href': u'', u'class': u"python:selected and 'active nav-link' or 'nav-link'", }
_static_133838681206032 = {u'class': u'nav navbar-nav mr-auto content-views', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9c12ca950> name=None at 79b9c12ca4d0> -> __attrs_133838716839568
            __attrs_133838716839568 = _static_133838716840272
            __backup_context_state_133838716891856 = get('context_state', __marker)

            # <Value u'view/context_state' (3:31)> -> __value
            __token = 107
            try:
                __zt_tmp = __attrs_133838716839568
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'view/context_state', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_portal_state_133838716847312 = get('portal_state', __marker)

            # <Value u'view/portal_state' (4:29)> -> __value
            __token = 157
            try:
                __zt_tmp = __attrs_133838716839568
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'view/portal_state', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_global_sections_133838716892048 = get('global_sections', __marker)

            # <Value u'python:view.get_global_sections()' (5:31)> -> __value
            __token = 209
            try:
                __zt_tmp = __attrs_133838716839568
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'view.get_global_sections()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['global_sections'] = __value
            __backup_language_selector_133838716892880 = get('language_selector', __marker)

            # <Value u'python:view.get_language_selector()' (6:32)> -> __value
            __token = 279
            try:
                __zt_tmp = __attrs_133838716839568
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'view.get_language_selector()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['language_selector'] = __value
            __backup_personal_bar_133838716893840 = get('personal_bar', __marker)

            # <Value u'python:view.get_personal_bar()' (7:26)> -> __value
            __token = 346
            try:
                __zt_tmp = __attrs_133838716839568
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'view.get_personal_bar()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['personal_bar'] = __value
            __previous_i18n_domain_133838716838160 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <nav ... (0:0)
            # --------------------------------------------------------
            __append(u'<nav id="senaite-toolbar"      class="navbar static-top navbar-expand-md">\r\n\r\n  <!-- Navbar Brand Icon -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9c0372110> name=None at 79b9c0372190> -> __attrs_133838700751888
            __attrs_133838700751888 = _static_133838700749072

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="navbar-brand"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700750288
            __default_133838700750288 = _DEFAULT_MARKER

            # <Substitution u'portal_state/portal_url' (11:56)> -> __attr_href
            __token = 505
            try:
                __zt_tmp = __attrs_133838700751888
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_133838794967184('path', u'portal_state/portal_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9c0372a10> name=None at 79b9c0372fd0> -> __attrs_133838700752400
            __attrs_133838700752400 = _static_133838700751376

            # <img ... (0:0)
            # --------------------------------------------------------
            __append(u'<img')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700750352
            __default_133838700750352 = _DEFAULT_MARKER

            # <Substitution u'python:view.get_toolbar_logo()' (12:29)> -> __attr_src
            __token = 561
            try:
                __zt_tmp = __attrs_133838700752400
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_133838794967184('python', u'view.get_toolbar_logo()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700749136
            __default_133838700749136 = _DEFAULT_MARKER

            # <Substitution u'python:view.get_toolbar_styles()' (12:65)> -> __attr_style
            __token = 597
            try:
                __zt_tmp = __attrs_133838700752400
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_133838794967184('python', u'view.get_toolbar_styles()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))
            __append(u' />\r\n  </a>\r\n\r\n  <!-- Navbar Toggle Button -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9c016ef10> name=None at 79b9c016e9d0> -> __attrs_133838698636624
            __attrs_133838698636624 = _static_133838698639120

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button class="navbar-toggler btn btn-outline-light" type="button" data-toggle="collapse" data-target="#toolbarContent" aria-controls="toolbarContent" aria-expanded="false" aria-label="Toggle navigation">\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9bf0ce210> name=None at 79b9c016e290> -> __attrs_133838681204944
            __attrs_133838681204944 = _static_133838681203216

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-bars"></i>\r\n  </button>\r\n\r\n  <!-- Navbar Menu Items -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9bf0ce850> name=None at 79b9bf0ce890> -> __attrs_133838681202896
            __attrs_133838681202896 = _static_133838681204816

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="collapse navbar-collapse" id="toolbarContent">\r\n\r\n    <!-- left -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9bf0ced10> name=None at 79b9bf0ceb10> -> __attrs_133838681204688
            __attrs_133838681204688 = _static_133838681206032

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="nav navbar-nav mr-auto content-views">\r\n      <!-- contentviews -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681268624
            __attrs_133838681268624 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681268304
            __default_133838681268304 = _DEFAULT_MARKER

            # <Value u'view/base_render' (26:34)> -> __cache_133838681272208
            __token = 1166
            try:
                __zt_tmp = __attrs_133838681268624
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838681272208 = _static_133838794967184('path', u'view/base_render', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/base_render' (26:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf0de450> -> __condition
            __expression = __cache_133838681272208

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_133838681272208
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n    </ul>\r\n\r\n    <!-- right -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9bf0de750> name=None at 79b9bf0de3d0> -> __attrs_133838681272016
            __attrs_133838681272016 = _static_133838681270096

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="navbar-nav ml-auto">\r\n\r\n      <!-- Global Sections -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9bf0decd0> name=None at 79b9bf0de650> -> __attrs_133838681212304
            __attrs_133838681212304 = _static_133838681271504

            # <Value u'personal_bar/user_name' (33:42)> -> __condition
            __token = 1338
            try:
                __zt_tmp = __attrs_133838681212304
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'personal_bar/user_name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681214032
                __attrs_133838681214032 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681214608
                __default_133838681214608 = _DEFAULT_MARKER

                # <Value u'global_sections/render' (34:36)> -> __cache_133838681213904
                __token = 1400
                try:
                    __zt_tmp = __attrs_133838681214032
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838681213904 = _static_133838794967184('path', u'global_sections/render', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'global_sections/render' (34:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf0d0f10> -> __condition
                __expression = __cache_133838681213904

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div></div>')
                else:
                    __content = __cache_133838681213904
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n      </li>')
            __append(u'\r\n\r\n      <!-- Language Selector -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9bf0d0d90> name=None at 79b9bf0d0fd0> -> __attrs_133838681211984
            __attrs_133838681211984 = _static_133838681214352

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="nav-item">\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681235024
            __attrs_133838681235024 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681231952
            __default_133838681231952 = _DEFAULT_MARKER

            # <Value u'language_selector/template' (39:36)> -> __cache_133838681232976
            __token = 1546
            try:
                __zt_tmp = __attrs_133838681235024
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838681232976 = _static_133838794967184('path', u'language_selector/template', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'language_selector/template' (39:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf0d5b10> -> __condition
            __expression = __cache_133838681232976

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_133838681232976
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n      </li>\r\n\r\n      <!-- Search trigger -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9bf0d57d0> name=None at 79b9bf0d5110> -> __attrs_133838681233296
            __attrs_133838681233296 = _static_133838681233360

            # <Value u'personal_bar/user_name' (43:42)> -> __condition
            __token = 1670
            try:
                __zt_tmp = __attrs_133838681233296
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'personal_bar/user_name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9bf0d5b50> name=None at 79b9bf0d5050> -> __attrs_133838681237136
                __attrs_133838681237136 = _static_133838681234256

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="nav-link"')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681238928
                __default_133838681238928 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x79b9bf0d6750> at 79b9bf0d6e50> -> __attr_title
                __attr_title = u'Press Ctrl+Space to trigger the Spotlight search'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'            title="%s"' % __attr_title))

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681238800
                __default_133838681238800 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_state/portal_url}/spotlight' (47:32)> -> __attr_href
                __token = 1862
                try:
                    __zt_tmp = __attrs_133838681237136
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133838794967184('string', u'${portal_state/portal_url}/spotlight', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9bf0d6810> name=None at 79b9bf0d6850> -> __attrs_133838681239312
                __attrs_133838681239312 = _static_133838681237520

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-search"></i>\r\n        </a>\r\n      </li>')
            __append(u'\r\n\r\n      <!-- LIMS Setup -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9bf0d6f50> name=None at 79b9bf0d6ed0> -> __attrs_133838681235728
            __attrs_133838681235728 = _static_133838681239376

            # <Value u'view/is_manager' (53:42)> -> __condition
            __token = 2048
            try:
                __zt_tmp = __attrs_133838681235728
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'view/is_manager', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9c0169a90> name=None at 79b9c0169f10> -> __attrs_133838698615248
                __attrs_133838698615248 = _static_133838698617488

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="nav-link"')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698615632
                __default_133838698615632 = _DEFAULT_MARKER

                # <Substitution u'view/get_lims_setup_url' (55:32)> -> __attr_href
                __token = 2128
                try:
                    __zt_tmp = __attrs_133838698615248
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133838794967184('path', u'view/get_lims_setup_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698616720
                __attrs_133838698616720 = _static_133838878659728
                __append(u'\r\n            ')

                # <Static value=<_ast.Dict object at 0x79b9c0169e90> name=None at 79b9c0169ad0> -> __attrs_133838698616208
                __attrs_133838698616208 = _static_133838698618512

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-cog"></i>\r\n          \r\n        </a>\r\n      </li>')
            __append(u'\r\n\r\n      <!-- Personal Bar Menu -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0169110> name=None at 79b9c0169610> -> __attrs_133838698615376
            __attrs_133838698615376 = _static_133838698615056

            # <Value u'personal_bar/user_name' (63:51)> -> __condition
            __token = 2362
            try:
                __zt_tmp = __attrs_133838698615376
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'personal_bar/user_name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item dropdown">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9c0360d50> name=None at 79b9c03606d0> -> __attrs_133838698684816
                __attrs_133838698684816 = _static_133838700678480

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700678544
                __default_133838700678544 = _DEFAULT_MARKER

                # <Substitution u'personal_bar/homelink_url' (71:32)> -> __attr_href
                __token = 2650
                try:
                    __zt_tmp = __attrs_133838698684816
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133838794967184('path', u'personal_bar/homelink_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'            class="nav-link dropdown-toggle"            id="navbarUserDropdown"            role="button"            data-toggle="dropdown"            aria-haspopup="true"            aria-expanded="false">\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698686352
                __attrs_133838698686352 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698686800
                __default_133838698686800 = _DEFAULT_MARKER

                # <Value u'personal_bar/user_name' (72:29)> -> __cache_133838698688464
                __token = 2708
                try:
                    __zt_tmp = __attrs_133838698686352
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838698688464 = _static_133838794967184('path', u'personal_bar/user_name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'personal_bar/user_name' (72:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c017a650> -> __condition
                __expression = __cache_133838698688464

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_133838698688464
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n        </a>\r\n        <!-- Personal Bar Dropdown Items -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9c017a3d0> name=None at 79b9c017a5d0> -> __attrs_133838698685776
                __attrs_133838698685776 = _static_133838698685392
                __backup_url_133838681211536 = get('url', __marker)

                # <Value u'view/context_state/current_page_url' (76:28)> -> __value
                __token = 2879
                try:
                    __zt_tmp = __attrs_133838698685776
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'view/context_state/current_page_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['url'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="dropdown-menu dropdown-menu-right">\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9c017a290> name=None at 79b9c017a6d0> -> __attrs_133838698688208
                __attrs_133838698688208 = _static_133838698685072
                __backup_action_133838681270672 = get('action', __marker)

                # <Value u'personal_bar/user_actions' (78:33)> -> __iterator
                __token = 2983
                try:
                    __zt_tmp = __attrs_133838698688208
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'personal_bar/user_actions', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838698643792, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79b9c01701d0> name=None at 79b9c0170a90> -> __attrs_133838698647056
                    __attrs_133838698647056 = _static_133838698643920
                    __backup_selected_133838698617744 = get('selected', __marker)

                    # <Value u"python:action['href'] == url" (80:36)> -> __value
                    __token = 3072
                    try:
                        __zt_tmp = __attrs_133838698647056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u"action['href'] == url", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['selected'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Value u'action' (81:31)> -> __cache_133838698646736
                    __token = 3134
                    try:
                        __zt_tmp = __attrs_133838698647056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838698646736 = _static_133838794967184('path', u'action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if (u'href' not in __chain(__cache_133838698646736)):
                        __append(u' href=""')
                    __attr_133838698646352 = __cache_133838698646736
                    for (name, value, ) in __attr_133838698646352.items():
                        if ((name not in _static_133838685965840) and (value is not None)):
                            __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698645840
                    __default_133838698645840 = _DEFAULT_MARKER

                    # <Substitution u"python:selected and 'active nav-link' or 'nav-link'" (81:44)> -> __attr_class
                    __token = 3147
                    try:
                        __zt_tmp = __attrs_133838698647056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('python', u"selected and 'active nav-link' or 'nav-link'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698645136
                    __attrs_133838698645136 = _static_133838878659728

                    # <Value u"python:action['id'] == 'personaltools-site-setup'" (82:36)> -> __condition
                    __token = 3239
                    try:
                        __zt_tmp = __attrs_133838698645136
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"action['id'] == 'personaltools-site-setup'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c12cb7d0> name=None at 79b9c12cba50> -> __attrs_133838716844752
                        __attrs_133838716844752 = _static_133838716843984

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-wrench"></i>\r\n              ')
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698647504
                    __attrs_133838698647504 = _static_133838878659728

                    # <Value u"python:action['id'] == 'personaltools-my-organization'" (85:45)> -> __condition
                    __token = 3412
                    try:
                        __zt_tmp = __attrs_133838698647504
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"action['id'] == 'personaltools-my-organization'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c12cbd90> name=None at 79b9c12cba90> -> __attrs_133838716843024
                        __attrs_133838716843024 = _static_133838716845456

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-building"></i>\r\n              ')
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716842640
                    __attrs_133838716842640 = _static_133838878659728

                    # <Value u"python:action['id'] == 'personaltools-logout'" (88:39)> -> __condition
                    __token = 3595
                    try:
                        __zt_tmp = __attrs_133838716842640
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"action['id'] == 'personaltools-logout'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c12cbd50> name=None at 79b9c12cb2d0> -> __attrs_133838700741200
                        __attrs_133838700741200 = _static_133838716845392

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-sign-out-alt"></i>\r\n              ')
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698645072
                    __attrs_133838698645072 = _static_133838878659728

                    # <Value u"python:action['id'] == 'personaltools-user-profile'" (91:44)> -> __condition
                    __token = 3772
                    try:
                        __zt_tmp = __attrs_133838698645072
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"action['id'] == 'personaltools-user-profile'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c03700d0> name=None at 79b9c03705d0> -> __attrs_133838700744464
                        __attrs_133838700744464 = _static_133838700740816

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-user-cog"></i>\r\n              ')
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700744656
                    __attrs_133838700744656 = _static_133838878659728

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700743120
                    __default_133838700743120 = _DEFAULT_MARKER

                    # <Value u'action/title' (94:43)> -> __cache_133838700743376
                    __token = 3955
                    try:
                        __zt_tmp = __attrs_133838700744656
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700743376 = _static_133838794967184('path', u'action/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/title' (94:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c03702d0> -> __condition
                    __expression = __cache_133838700743376

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n                action title\r\n              ')
                    else:
                        __content = __cache_133838700743376
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n            </a>')
                    if (__backup_selected_133838698617744 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_133838698617744
                    __append(u'\r\n          </li>')
                    ____index_133838698643792 -= 1
                    if (____index_133838698643792 > 0):
                        __append('\n          ')
                if (__backup_action_133838681270672 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_133838681270672
                __append(u'\r\n        </ul>')
                if (__backup_url_133838681211536 is __marker):
                    del econtext['url']
                else:
                    econtext['url'] = __backup_url_133838681211536
                __append(u'\r\n      </li>')
            __append(u'\r\n\r\n      <!-- Login/Register -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0170350> name=None at 79b9c01708d0> -> __attrs_133838700744272
            __attrs_133838700744272 = _static_133838698644304

            # <Value u'not:personal_bar/user_name' (103:42)> -> __condition
            __token = 4172
            try:
                __zt_tmp = __attrs_133838700744272
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('not', u'personal_bar/user_name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700743248
                __attrs_133838700743248 = _static_133838878659728
                __backup_action_133838716840016 = get('action', __marker)

                # <Value u'personal_bar/user_actions' (104:56)> -> __iterator
                __token = 4258
                try:
                    __zt_tmp = __attrs_133838700743248
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'personal_bar/user_actions', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838698700752, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item

                    # <Negate value=<Value u'python:1' (104:27)> at 79b9c0370d50> -> __cache_133838700744016

                    # <Value u'python:1' (104:27)> -> __cache_133838700744016
                    __token = 4229
                    try:
                        __zt_tmp = __attrs_133838700743248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700744016 = _static_133838794967184('python', u'1', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __cache_133838700744016 = not __cache_133838700744016
                    __condition = __cache_133838700744016
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>')
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79b9c017d6d0> name=None at 79b9c017d4d0> -> __attrs_133838698699856
                    __attrs_133838698699856 = _static_133838698698448

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698699216
                    __default_133838698699216 = _DEFAULT_MARKER

                    # <Substitution u'action/href' (105:42)> -> __attr_href
                    __token = 4329
                    try:
                        __zt_tmp = __attrs_133838698699856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133838794967184('path', u'action/href', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698699600
                    __default_133838698699600 = _DEFAULT_MARKER

                    # <Substitution u'string:nav-link' (105:60)> -> __attr_class
                    __token = 4347
                    try:
                        __zt_tmp = __attrs_133838698699856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('string', u'nav-link', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698698000
                    __attrs_133838698698000 = _static_133838878659728

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698698192
                    __default_133838698698192 = _DEFAULT_MARKER

                    # <Value u'action/title' (106:41)> -> __cache_133838698698320
                    __token = 4408
                    try:
                        __zt_tmp = __attrs_133838698698000
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838698698320 = _static_133838794967184('path', u'action/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/title' (106:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c017d410> -> __condition
                    __expression = __cache_133838698698320

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n              action title\r\n            ')
                    else:
                        __content = __cache_133838698698320
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698697232
                    __attrs_133838698697232 = _static_133838878659728

                    # <Value u"python:action['id'] == 'personaltools-logout'" (109:37)> -> __condition
                    __token = 4520
                    try:
                        __zt_tmp = __attrs_133838698697232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"action['id'] == 'personaltools-logout'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n              ')

                        # <Static value=<_ast.Dict object at 0x79b9c017cf10> name=None at 79b9c017c610> -> __attrs_133838698695376
                        __attrs_133838698695376 = _static_133838698696464

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="icon-logout"></span>\r\n            ')
                    __append(u'\r\n          </a>\r\n        ')
                    __condition = __cache_133838700744016
                    if __condition:
                        __append(u'</div>')
                    ____index_133838698700752 -= 1
                    if (____index_133838698700752 > 0):
                        __append('\n        ')
                if (__backup_action_133838716840016 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_133838716840016
                __append(u'\r\n      </li>')
            __append(u'\r\n\r\n    </ul>\r\n  </div>\r\n</nav>')
            __i18n_domain = __previous_i18n_domain_133838716838160
            if (__backup_personal_bar_133838716893840 is __marker):
                del econtext['personal_bar']
            else:
                econtext['personal_bar'] = __backup_personal_bar_133838716893840
            if (__backup_language_selector_133838716892880 is __marker):
                del econtext['language_selector']
            else:
                econtext['language_selector'] = __backup_language_selector_133838716892880
            if (__backup_global_sections_133838716892048 is __marker):
                del econtext['global_sections']
            else:
                econtext['global_sections'] = __backup_global_sections_133838716892048
            if (__backup_portal_state_133838716847312 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_133838716847312
            if (__backup_context_state_133838716891856 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_133838716891856
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }