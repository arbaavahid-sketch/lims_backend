# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/listingactions.pt'

__tokens = {93: (u'python:view.get_context_actions()', 2, 26), 202: (u'action/url', 4, 28), 243: (u" python:'mx-2 btn btn-sm btn-light %s' % action.get('css_class', ''", 5, 28), 343: (u'action/icon|nothing', 6, 28), 391: (u'icon', 7, 26), 453: (u'icon', 9, 31), 487: (u'action/title', 10, 25)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525735071184 = {u'class': u'd-inline-block align-middle', }
_static_124525979686032 = {}
_static_124525732178512 = {u'class': u'listing-actions-viewlet d-inline-block align-middle', }
_static_124525731902864 = {u'href': u'action/url', u'class': u"python:'mx-2 btn btn-sm btn-light %s' % action.get('css_class', '')", }
_static_124525896002064 = __C2ZContextWrapper
_static_124525521583056 = {u'src': u'icon', u'height': u'16', }
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714168082a50> name=None at 714168082150> -> __attrs_124525734948240
            __attrs_124525734948240 = _static_124525732178512

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="listing-actions-viewlet d-inline-block align-middle">\r\n  ')

            # <Static value=<_ast.Dict object at 0x714168344dd0> name=None at 714168344d90> -> __attrs_124525731874448
            __attrs_124525731874448 = _static_124525735071184
            __backup_action_124525732134096 = get('action', __marker)

            # <Value u'python:view.get_context_actions()' (2:26)> -> __iterator
            __token = 93
            try:
                __zt_tmp = __attrs_124525731874448
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_124525896001680('python', u'view.get_context_actions()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            (__iterator, ____index_124525731903504, ) = getitem('repeat')(u'action', __iterator)
            econtext['action'] = None
            for __item in __iterator:
                econtext['action'] = __item

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div        class="d-inline-block align-middle">\r\n    ')

                # <Static value=<_ast.Dict object at 0x71416803f590> name=None at 71416803fc10> -> __attrs_124525731902800
                __attrs_124525731902800 = _static_124525731902864

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731903696
                __default_124525731903696 = _DEFAULT_MARKER

                # <Substitution u'action/url' (4:28)> -> __attr_href
                __token = 202
                try:
                    __zt_tmp = __attrs_124525731902800
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_124525896001680('path', u'action/url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731902480
                __default_124525731902480 = _DEFAULT_MARKER

                # <Substitution u"python:'mx-2 btn btn-sm btn-light %s' % action.get('css_class', '')" (5:28)> -> __attr_class
                __token = 243
                try:
                    __zt_tmp = __attrs_124525731902800
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_124525896001680('python', u"'mx-2 btn btn-sm btn-light %s' % action.get('css_class', '')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b7abbd0> name=None at 71415b7ab590> -> __attrs_124525733312208
                __attrs_124525733312208 = _static_124525521583056
                __backup_icon_124525732133136 = get('icon', __marker)

                # <Value u'action/icon|nothing' (6:28)> -> __value
                __token = 343
                try:
                    __zt_tmp = __attrs_124525733312208
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'action/icon|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['icon'] = __value

                # <Value u'icon' (7:26)> -> __condition
                __token = 391
                try:
                    __zt_tmp = __attrs_124525733312208
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img            height="16"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525735170256
                    __default_124525735170256 = _DEFAULT_MARKER

                    # <Substitution u'icon' (9:31)> -> __attr_src
                    __token = 453
                    try:
                        __zt_tmp = __attrs_124525733312208
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_src = _static_124525896001680('path', u'icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_src is not None):
                        __append((u' src="%s"' % __attr_src))
                    __append(u'/>')
                if (__backup_icon_124525732133136 is __marker):
                    del econtext['icon']
                else:
                    econtext['icon'] = __backup_icon_124525732133136
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525806958800
                __attrs_124525806958800 = _static_124525979686032

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734580368
                __default_124525734580368 = _DEFAULT_MARKER

                # <Value u'action/title' (10:25)> -> __cache_124525521512592
                __token = 487
                try:
                    __zt_tmp = __attrs_124525806958800
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521512592 = _static_124525896001680('path', u'action/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'action/title' (10:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b79a690> -> __condition
                __expression = __cache_124525521512592

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_124525521512592
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n    </a>\r\n  </div>')
                ____index_124525731903504 -= 1
                if (____index_124525731903504 > 0):
                    __append('\n  ')
            if (__backup_action_124525732134096 is __marker):
                del econtext['action']
            else:
                econtext['action'] = __backup_action_124525732134096
            __append(u'\r\n</div>\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }