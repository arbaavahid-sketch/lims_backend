# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/path_bar.pt'

__tokens = {85: (u'view/breadcrumbs', 3, 30), 127: (u' view/is_rt', 4, 24), 167: (u"python:is_rtl and 'rtl' or 'ltr'", 5, 26), 345: (u'view/navigation_root_url', 9, 61), 424: (u'breadcrumbs', 12, 33), 474: (u'repeat/crumb/end', 13, 36), 523: (u' crumb/absolute_ur', 14, 31), 576: (u'e crumb/Tit', 15, 32), 626: (u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'", 16, 34), 723: (u' string:breadcrumbs-${repeat/crumb/number', 17, 30), 818: (u'not: url', 19, 27), 862: (u'url', 20, 34), 901: (u" python:is_last and 'text-secondary", 21, 34), 965: (u'title', 22, 26)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756868937104 = {u'class': u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'", u'id': u'string:breadcrumbs-${repeat/crumb/number}', }
_static_135757150040336 = {u'id': u'breadcrumbs-home', u'class': u'breadcrumb-item', }
_static_135757244280656 = __compile_zt_expr
_static_135757075532304 = {u'class': u'breadcrumb', u'dir': u"python:is_rtl and 'rtl' or 'ltr'", }
_static_135756868936848 = {u'href': u'#', }
_static_135757327983760 = {}
_static_135757075275728 = {u'href': u'#', u'class': u"python:is_last and 'text-secondary'", }
_static_135756868874192 = {u'aria-label': u'breadcrumb', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bf1efd0> name=None at 7b785bf1e410> -> __attrs_135757075532624
            __attrs_135757075532624 = _static_135756868874192

            # <nav ... (0:0)
            # --------------------------------------------------------
            __append(u'<nav aria-label="breadcrumb">\n  ')

            # <Static value=<_ast.Dict object at 0x7b7868434a10> name=None at 7b7868434750> -> __attrs_135757150041616
            __attrs_135757150041616 = _static_135757075532304
            __backup_breadcrumbs_135756868873424 = get('breadcrumbs', __marker)

            # <Value u'view/breadcrumbs' (3:30)> -> __value
            __token = 85
            try:
                __zt_tmp = __attrs_135757150041616
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/breadcrumbs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['breadcrumbs'] = __value
            __backup_is_rtl_135756868870800 = get('is_rtl', __marker)

            # <Value u'view/is_rtl' (4:24)> -> __value
            __token = 127
            try:
                __zt_tmp = __attrs_135757150041616
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/is_rtl', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['is_rtl'] = __value
            __previous_i18n_domain_135757150042768 = __i18n_domain
            __i18n_domain = u'plone'

            # <ol ... (0:0)
            # --------------------------------------------------------
            __append(u'<ol class="breadcrumb"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150042384
            __default_135757150042384 = _DEFAULT_MARKER

            # <Substitution u"python:is_rtl and 'rtl' or 'ltr'" (5:26)> -> __attr_dir
            __token = 167
            try:
                __zt_tmp = __attrs_135757150041616
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_135757244280656('python', u"is_rtl and 'rtl' or 'ltr'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_dir is not None):
                __append((u' dir="%s"' % __attr_dir))
            __append(u'>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cb43110> name=None at 7b786cb43c10> -> __attrs_135757073487888
            __attrs_135757073487888 = _static_135757150040336

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li id="breadcrumbs-home" class="breadcrumb-item">\n      ')

            # <Static value=<_ast.Dict object at 0x7b785bf2e490> name=None at 7b785bf2eb10> -> __attrs_135756868936464
            __attrs_135756868936464 = _static_135756868936848

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868939408
            __default_135756868939408 = _DEFAULT_MARKER

            # <Substitution u'view/navigation_root_url' (9:61)> -> __attr_href
            __token = 345
            try:
                __zt_tmp = __attrs_135756868936464
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('path', u'view/navigation_root_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_135756868936080 = []
            __append_135756868936080 = __stream_135756868936080.append
            __append_135756868936080(u'Home')
            __msgid_135756868936080 = __re_whitespace(''.join(__stream_135756868936080)).strip()
            if u'Home':
                __append(translate(u'Home', mapping=None, default=__msgid_135756868936080, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\n    </li>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868937616
            __attrs_135756868937616 = _static_135757327983760
            __backup_crumb_135757150040976 = get('crumb', __marker)

            # <Value u'breadcrumbs' (12:33)> -> __iterator
            __token = 424
            try:
                __zt_tmp = __attrs_135756868937616
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_135757244280656('path', u'breadcrumbs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            (__iterator, ____index_135757075239504, ) = getitem('repeat')(u'crumb', __iterator)
            econtext['crumb'] = None
            for __item in __iterator:
                econtext['crumb'] = __item
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073701712
                __attrs_135757073701712 = _static_135757327983760
                __backup_is_last_135757150040464 = get('is_last', __marker)

                # <Value u'repeat/crumb/end' (13:36)> -> __value
                __token = 474
                try:
                    __zt_tmp = __attrs_135757073701712
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'repeat/crumb/end', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['is_last'] = __value
                __backup_url_135757150042832 = get('url', __marker)

                # <Value u'crumb/absolute_url' (14:31)> -> __value
                __token = 523
                try:
                    __zt_tmp = __attrs_135757073701712
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'crumb/absolute_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['url'] = __value
                __backup_title_135756868939664 = get('title', __marker)

                # <Value u'crumb/Title' (15:32)> -> __value
                __token = 576
                try:
                    __zt_tmp = __attrs_135757073701712
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'crumb/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['title'] = __value
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b785bf2e590> name=None at 7b785bf2e210> -> __attrs_135757075273232
                __attrs_135757075273232 = _static_135756868937104

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868938192
                __default_135756868938192 = _DEFAULT_MARKER

                # <Substitution u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'" (16:34)> -> __attr_class
                __token = 626
                try:
                    __zt_tmp = __attrs_135757075273232
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_135757244280656('python', u" is_last and 'active breadcrumb-item' or 'breadcrumb-item'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075274256
                __default_135757075274256 = _DEFAULT_MARKER

                # <Substitution u'string:breadcrumbs-${repeat/crumb/number}' (17:30)> -> __attr_id
                __token = 723
                try:
                    __zt_tmp = __attrs_135757075273232
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'breadcrumbs-${repeat/crumb/number}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\n          ')

                # <Static value=<_ast.Dict object at 0x7b78683f5fd0> name=None at 7b78683f5b90> -> __attrs_135757074248400
                __attrs_135757074248400 = _static_135757075275728

                # <Negate value=<Value u'not: url' (19:27)> at 7b7868098f90> -> __cache_135757071749008

                # <Value u'not: url' (19:27)> -> __cache_135757071749008
                __token = 818
                try:
                    __zt_tmp = __attrs_135757074248400
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757071749008 = _static_135757244280656('not', u' url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __cache_135757071749008 = not __cache_135757071749008
                __condition = __cache_135757071749008
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072303120
                    __default_135757072303120 = _DEFAULT_MARKER

                    # <Substitution u'url' (20:34)> -> __attr_href
                    __token = 862
                    try:
                        __zt_tmp = __attrs_135757074248400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('path', u'url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072305168
                    __default_135757072305168 = _DEFAULT_MARKER

                    # <Substitution u"python:is_last and 'text-secondary'" (21:34)> -> __attr_class
                    __token = 901
                    try:
                        __zt_tmp = __attrs_135757074248400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('python', u"is_last and 'text-secondary'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075272976
                __default_135757075272976 = _DEFAULT_MARKER

                # <Value u'title' (22:26)> -> __cache_135757075274832
                __token = 965
                try:
                    __zt_tmp = __attrs_135757074248400
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075274832 = _static_135757244280656('path', u'title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'title' (22:26)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683f5990> -> __condition
                __expression = __cache_135757075274832

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n            crumb\n          ')
                else:
                    __content = __cache_135757075274832
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __condition = __cache_135757071749008
                if __condition:
                    __append(u'</a>')
                __append(u'\n        </li>\n      ')
                if (__backup_title_135756868939664 is __marker):
                    del econtext['title']
                else:
                    econtext['title'] = __backup_title_135756868939664
                if (__backup_url_135757150042832 is __marker):
                    del econtext['url']
                else:
                    econtext['url'] = __backup_url_135757150042832
                if (__backup_is_last_135757150040464 is __marker):
                    del econtext['is_last']
                else:
                    econtext['is_last'] = __backup_is_last_135757150040464
                __append(u'\n    ')
                ____index_135757075239504 -= 1
                if (____index_135757075239504 > 0):
                    __append('')
            if (__backup_crumb_135757150040976 is __marker):
                del econtext['crumb']
            else:
                econtext['crumb'] = __backup_crumb_135757150040976
            __append(u'\n\n  </ol>')
            __i18n_domain = __previous_i18n_domain_135757150042768
            if (__backup_is_rtl_135756868870800 is __marker):
                del econtext['is_rtl']
            else:
                econtext['is_rtl'] = __backup_is_rtl_135756868870800
            if (__backup_breadcrumbs_135756868873424 is __marker):
                del econtext['breadcrumbs']
            else:
                econtext['breadcrumbs'] = __backup_breadcrumbs_135756868873424
            __append(u'\n</nav>\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }