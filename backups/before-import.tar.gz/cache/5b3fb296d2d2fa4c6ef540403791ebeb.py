# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFPlone-5.2.15-py2.7.egg/Products/CMFPlone/browser/templates/main_template.pt'

__tokens = {3333: (u'provider:plone.abovecontenttitle', 83, 73), 3465: (u'context/@@title', 85, 41), 3585: (u'provider:plone.belowcontenttitle', 87, 73), 3729: (u'context/@@description', 90, 40), 3879: (u'provider:plone.abovecontentbody', 94, 70), 4013: (u'nothing', 96, 64), 4165: (u'provider:plone.belowcontentbody', 100, 70), 71: (u'string:&lt;!DOCTYPE ht', 2, 36), 344: (u"python:context.restrictedTraverse('@@plone_portal_state')", 8, 31), 426: (u" python:context.restrictedTraverse('@@plone_context_state'", 9, 23), 506: (u"w python:context.restrictedTraverse('@@plone", 10, 19), 574: (u"ut python:context.restrictedTraverse('@@plone_layou", 11, 20), 641: (u'ang python:portal_state.langua', 12, 11), 687: (u'view nocall:view | nocall: plone', 13, 10), 736: (u'dummy python: plone_layout.mark_view', 14, 10), 794: (u'al_url python:portal_state.porta', 15, 14), 853: (u"mission python:context.restrictedTraverse('portal_membership').checkPe", 16, 18), 950: (u"operties python:context.restrictedTraverse('portal_properties').site_p", 17, 17), 1049: (u"lude_head python:request.get('ajax_include_hea", 18, 18), 1116: (u' ajax_load p', 19, 9), 1195: (u'lang', 21, 27), 1244: (u'provider:plone.httpheaders', 23, 40), 1312: (u'provider:plone.htmlhead', 25, 36), 1367: (u'nothing', 27, 26), 1653: (u'provider:plone.scripts', 34, 32), 1778: (u'provider:plone.htmlhead.links', 37, 33), 1915: (u'portal_state/is_rtl', 42, 26), 1958: (u" python:plone_layout.have_portlets('plone.leftcolumn', view", 43, 22), 2041: (u"r python:plone_layout.have_portlets('plone.rightcolumn', vie", 44, 21), 2133: (u'ss python:plone_layout.bodyClass(template, vi', 45, 28), 2309: (u'  python:plone_view.patterns_settings', 48, 22), 2214: (u'body_class', 46, 30), 2253: (u" python:isRTL and 'rtl' or 'ltr", 47, 27), 2419: (u'provider:plone.toolbar', 51, 32), 2530: (u'provider:plone.portaltop', 54, 34), 2633: (u'provider:plone.mainnavigation', 57, 59), 2783: (u'provider:plone.globalstatusmessage', 62, 42), 2960: (u'provider:plone.abovecontent', 67, 59), 4621: (u'provider:plone.belowcontent', 115, 63), 4794: (u'sl', 123, 26), 4892: (u'provider:plone.leftcolumn', 125, 38), 5067: (u'sr', 131, 26), 5165: (u'provider:plone.rightcolumn', 133, 38), 5328: (u'provider:plone.portalfooter', 138, 34)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757134642896 = {u'id': u'viewlet-below-content-title', }
_static_135757138340944 = {u'id': u'visual-portal-wrapper', u'dir': u"python:isRTL and 'rtl' or 'ltr'", u'class': u'body_class', }
_static_135757134639504 = {u'id': u'viewlet-above-content-title', }
_static_135757159720976 = {u'id': u'portal-column-one', }
_static_135757365992336 = set([])
_static_135757154869072 = {u'id': u'portal-footer-wrapper', }
_static_135757365996688 = {u'id': u'content-core', }
_static_135757327983760 = {}
_static_135757365995728 = {u'id': u'viewlet-above-content-body', }
_static_135757244280656 = __compile_zt_expr
_static_135757134667152 = {u'id': u'viewlet-below-content', }
_static_135757134637072 = {u'id': u'portal-mainnavigation', }
_static_135757134665168 = {u'id': u'viewlet-below-content-body', }
_static_135757134638544 = {u'id': u'portal-top', }
_static_135757226747600 = {u'lang': u'lang', u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757134629136 = {u'id': u'portal-column-content', }
_static_135757159722576 = {u'id': u'content', }
_static_135757134635216 = {u'id': u'global_statusmessage', }
_static_135757232036944 = {u'content': u'Plone - http://plone.com', u'name': u'generator', }
_static_135757134627472 = {u'id': u'viewlet-above-content', }
_static_135757237164688 = {u'id': u'portal-column-two', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_content(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_content_description = econtext[u'__slot_content_description'].pop()
        except:
            __slot_content_description = None

        try:
            __slot_main = econtext[u'__slot_main'].pop()
        except:
            __slot_main = None

        try:
            __slot_body = econtext[u'__slot_body'].pop()
        except:
            __slot_body = None

        try:
            __slot_content_core = econtext[u'__slot_content_core'].pop()
        except:
            __slot_content_core = None

        try:
            __slot_content_title = econtext[u'__slot_content_title'].pop()
        except:
            __slot_content_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159719184
            __attrs_135757159719184 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n\n\n        ')
            if (__slot_body is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159719504
                __attrs_135757159719504 = _static_135757327983760
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b786d47ee50> name=None at 7b786d47efd0> -> __attrs_135757226696976
                __attrs_135757226696976 = _static_135757159722576

                # <article ... (0:0)
                # --------------------------------------------------------
                __append(u'<article id="content">\n\n          ')
                if (__slot_main is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226697296
                    __attrs_135757226697296 = _static_135757327983760
                    __append(u'\n\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226698960
                    __attrs_135757226698960 = _static_135757327983760

                    # <header ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<header>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b786bc93190> name=None at 7b786bc93090> -> __attrs_135757134640912
                    __attrs_135757134640912 = _static_135757134639504

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-title">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134639888
                    __default_135757134639888 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontenttitle' (83:73)> -> __cache_135757226700560
                    __token = 3333
                    try:
                        __zt_tmp = __attrs_135757134640912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757226700560 = _static_135757244280656('provider', u'plone.abovecontenttitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontenttitle' (83:73)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787145e9d0> -> __condition
                    __expression = __cache_135757226700560

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757226700560
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n            ')
                    if (__slot_content_title is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134641040
                        __attrs_135757134641040 = _static_135757327983760
                        __append(u'\n              ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134642256
                        __attrs_135757134642256 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134640336
                        __default_135757134640336 = _DEFAULT_MARKER

                        # <Value u'context/@@title' (85:41)> -> __cache_135757134640528
                        __token = 3465
                        try:
                            __zt_tmp = __attrs_135757134642256
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757134640528 = _static_135757244280656('path', u'context/@@title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@title' (85:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc93410> -> __condition
                        __expression = __cache_135757134640528

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <h1 ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<h1 />')
                        else:
                            __content = __cache_135757134640528
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n            ')
                    else:
                        __slot_content_title(__stream, econtext.copy(), rcontext)
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7b786bc93ed0> name=None at 7b786bc93e10> -> __attrs_135757365994512
                    __attrs_135757365994512 = _static_135757134642896

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-title">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134640464
                    __default_135757134640464 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontenttitle' (87:73)> -> __cache_135757134640720
                    __token = 3585
                    try:
                        __zt_tmp = __attrs_135757365994512
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757134640720 = _static_135757244280656('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontenttitle' (87:73)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc93610> -> __condition
                    __expression = __cache_135757134640720

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757134640720
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n\n            ')
                    if (__slot_content_description is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365994320
                        __attrs_135757365994320 = _static_135757327983760
                        __append(u'\n              ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365997456
                        __attrs_135757365997456 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757365994576
                        __default_135757365994576 = _DEFAULT_MARKER

                        # <Value u'context/@@description' (90:40)> -> __cache_135757365997520
                        __token = 3729
                        try:
                            __zt_tmp = __attrs_135757365997456
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757365997520 = _static_135757244280656('path', u'context/@@description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@description' (90:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7879936a10> -> __condition
                        __expression = __cache_135757365997520

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <p ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<p />')
                        else:
                            __content = __cache_135757365997520
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n            ')
                    else:
                        __slot_content_description(__stream, econtext.copy(), rcontext)
                    __append(u'\n          </header>\n\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78799368d0> name=None at 7b7879936050> -> __attrs_135757365997136
                    __attrs_135757365997136 = _static_135757365995728

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-body">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757365994832
                    __default_135757365994832 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontentbody' (94:70)> -> __cache_135757365994768
                    __token = 3879
                    try:
                        __zt_tmp = __attrs_135757365997136
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757365994768 = _static_135757244280656('provider', u'plone.abovecontentbody', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontentbody' (94:70)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7879936610> -> __condition
                    __expression = __cache_135757365994768

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757365994768
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n          ')

                    # <Static value=<_ast.Dict object at 0x7b7879936c90> name=None at 7b7879936ed0> -> __attrs_135757365995152
                    __attrs_135757365995152 = _static_135757365996688

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\n            ')
                    if (__slot_content_core is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134665552
                        __attrs_135757134665552 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134667088
                        __default_135757134667088 = _DEFAULT_MARKER

                        # <Value u'nothing' (96:64)> -> __cache_135757134666512
                        __token = 4013
                        try:
                            __zt_tmp = __attrs_135757134665552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757134666512 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'nothing' (96:64)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc99810> -> __condition
                        __expression = __cache_135757134666512

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n              Page body text\n            ')
                        else:
                            __content = __cache_135757134666512
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                    else:
                        __slot_content_core(__stream, econtext.copy(), rcontext)
                    __append(u'\n          </div>\n          ')

                    # <Static value=<_ast.Dict object at 0x7b786bc995d0> name=None at 7b786bc990d0> -> __attrs_135757134666192
                    __attrs_135757134666192 = _static_135757134665168

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-body">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134666384
                    __default_135757134666384 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontentbody' (100:70)> -> __cache_135757134666832
                    __token = 4165
                    try:
                        __zt_tmp = __attrs_135757134666192
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757134666832 = _static_135757244280656('provider', u'plone.belowcontentbody', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontentbody' (100:70)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc99e50> -> __condition
                    __expression = __cache_135757134666832

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757134666832
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n\n          ')
                else:
                    __slot_main(__stream, econtext.copy(), rcontext)
                __append(u'\n        </article>\n\n        ')
            else:
                __slot_body(__stream, econtext.copy(), rcontext)
            __append(u'\n\n<!--                 <metal:sub define-slot="sub" tal:content="nothing">\n                   This slot is here for backwards compatibility only.\n                   Don\'t use it in your custom templates.\n                </metal:sub> -->\n      </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_master(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_column_one_slot = econtext[u'__slot_column_one_slot'].pop()
        except:
            __slot_column_one_slot = None

        try:
            __slot_head_slot = econtext[u'__slot_head_slot'].pop()
        except:
            __slot_head_slot = None

        try:
            __slot_column_two_slot = econtext[u'__slot_column_two_slot'].pop()
        except:
            __slot_column_two_slot = None

        try:
            __slot_style_slot = econtext[u'__slot_style_slot'].pop()
        except:
            __slot_style_slot = None

        try:
            __slot_javascript_head_slot = econtext[u'__slot_javascript_head_slot'].pop()
        except:
            __slot_javascript_head_slot = None

        try:
            __slot_global_statusmessage = econtext[u'__slot_global_statusmessage'].pop()
        except:
            __slot_global_statusmessage = None

        try:
            __slot_top_slot = econtext[u'__slot_top_slot'].pop()
        except:
            __slot_top_slot = None

        try:
            __slot_portlets_one_slot = econtext[u'__slot_portlets_one_slot'].pop()
        except:
            __slot_portlets_one_slot = None

        try:
            __slot_portlets_two_slot = econtext[u'__slot_portlets_two_slot'].pop()
        except:
            __slot_portlets_two_slot = None

        try:
            __slot_content = econtext[u'__slot_content'].pop()
        except:
            __slot_content = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226748368
            __attrs_135757226748368 = _static_135757327983760
            __append(u'\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226748560
            __attrs_135757226748560 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226749904
            __default_135757226749904 = _DEFAULT_MARKER

            # <Value u'string:<!DOCTYPE html>' (2:36)> -> __cache_135757226749136
            __token = 71
            try:
                __zt_tmp = __attrs_135757226748560
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226749136 = _static_135757244280656('string', u'<!DOCTYPE html>', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'string:<!DOCTYPE html>' (2:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787146a950> -> __condition
            __expression = __cache_135757226749136

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757226749136
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n')

            # <Static value=<_ast.Dict object at 0x7b787146a6d0> name=None at 7b787146ad10> -> __attrs_135757231985168
            __attrs_135757231985168 = _static_135757226747600
            __backup_portal_state_135757232021328 = get('portal_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_portal_state')" (8:31)> -> __value
            __token = 344
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_portal_state')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_context_state_135757237165072 = get('context_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_context_state')" (9:23)> -> __value
            __token = 426
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_context_state')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_plone_view_135757159719824 = get('plone_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone')" (10:19)> -> __value
            __token = 506
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['plone_view'] = __value
            __backup_plone_layout_135757237117776 = get('plone_layout', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_layout')" (11:20)> -> __value
            __token = 574
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_layout')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['plone_layout'] = __value
            __backup_lang_135757154849488 = get('lang', __marker)

            # <Value u'python:portal_state.language()' (12:11)> -> __value
            __token = 641
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'portal_state.language()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['lang'] = __value
            __backup_view_135757132573520 = get('view', __marker)

            # <Value u'nocall:view | nocall: plone_view' (13:10)> -> __value
            __token = 687
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'view | nocall: plone_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['view'] = __value
            __backup_dummy_135757237117840 = get('dummy', __marker)

            # <Value u'python: plone_layout.mark_view(view)' (14:10)> -> __value
            __token = 736
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u' plone_layout.mark_view(view)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_portal_url_135757123417552 = get('portal_url', __marker)

            # <Value u'python:portal_state.portal_url()' (15:14)> -> __value
            __token = 794
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'portal_state.portal_url()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_checkPermission_135757154865360 = get('checkPermission', __marker)

            # <Value u"python:context.restrictedTraverse('portal_membership').checkPermission" (16:18)> -> __value
            __token = 853
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('portal_membership').checkPermission", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['checkPermission'] = __value
            __backup_site_properties_135757237096848 = get('site_properties', __marker)

            # <Value u"python:context.restrictedTraverse('portal_properties').site_properties" (17:17)> -> __value
            __token = 950
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('portal_properties').site_properties", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['site_properties'] = __value
            __backup_ajax_include_head_135757232020432 = get('ajax_include_head', __marker)

            # <Value u"python:request.get('ajax_include_head', False)" (18:18)> -> __value
            __token = 1049
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"request.get('ajax_include_head', False)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['ajax_include_head'] = __value
            __backup_ajax_load_135757305499408 = get('ajax_load', __marker)

            # <Value u'python:False' (19:9)> -> __value
            __token = 1116
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'False', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['ajax_load'] = __value
            __previous_i18n_domain_135757226824720 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757231987472
            __default_135757231987472 = _DEFAULT_MARKER

            # <Substitution u'lang' (21:27)> -> __attr_lang
            __token = 1195
            try:
                __zt_tmp = __attrs_135757231985168
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_135757244280656('path', u'lang', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u'>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226827408
            __attrs_135757226827408 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226825232
            __default_135757226825232 = _DEFAULT_MARKER

            # <Value u'provider:plone.httpheaders' (23:40)> -> __cache_135757226826448
            __token = 1244
            try:
                __zt_tmp = __attrs_135757226827408
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226826448 = _static_135757244280656('provider', u'plone.httpheaders', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.httpheaders' (23:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787147dd50> -> __condition
            __expression = __cache_135757226826448

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757226826448
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226824848
            __attrs_135757226824848 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226825744
            __attrs_135757226825744 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226826768
            __default_135757226826768 = _DEFAULT_MARKER

            # <Value u'provider:plone.htmlhead' (25:36)> -> __cache_135757226826000
            __token = 1312
            try:
                __zt_tmp = __attrs_135757226825744
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226826000 = _static_135757244280656('provider', u'plone.htmlhead', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.htmlhead' (25:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787147d990> -> __condition
            __expression = __cache_135757226826000

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757226826000
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138292048
            __attrs_135757138292048 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757138290192
            __default_135757138290192 = _DEFAULT_MARKER

            # <Value u'nothing' (27:26)> -> __cache_135757138291152
            __token = 1367
            try:
                __zt_tmp = __attrs_135757138292048
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757138291152 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'nothing' (27:26)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786c00ee50> -> __condition
            __expression = __cache_135757138291152

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n        Various slots where you can insert elements in the header from a template.\n    ')
            else:
                __content = __cache_135757138291152
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    ')
            if (__slot_top_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138292624
                __attrs_135757138292624 = _static_135757327983760
            else:
                __slot_top_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n    ')
            if (__slot_head_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138289616
                __attrs_135757138289616 = _static_135757327983760
            else:
                __slot_head_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n    ')
            if (__slot_style_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232034896
                __attrs_135757232034896 = _static_135757327983760
            else:
                __slot_style_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232035728
            __attrs_135757232035728 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232035344
            __default_135757232035344 = _DEFAULT_MARKER

            # <Value u'provider:plone.scripts' (34:32)> -> __cache_135757232036176
            __token = 1653
            try:
                __zt_tmp = __attrs_135757232035728
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757232036176 = _static_135757244280656('provider', u'plone.scripts', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.scripts' (34:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871975a90> -> __condition
            __expression = __cache_135757232036176

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757232036176
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    ')
            if (__slot_javascript_head_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232035088
                __attrs_135757232035088 = _static_135757327983760
            else:
                __slot_javascript_head_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232037328
            __attrs_135757232037328 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232036240
            __default_135757232036240 = _DEFAULT_MARKER

            # <Value u'provider:plone.htmlhead.links' (37:33)> -> __cache_135757232037584
            __token = 1778
            try:
                __zt_tmp = __attrs_135757232037328
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757232037584 = _static_135757244280656('provider', u'plone.htmlhead.links', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.htmlhead.links' (37:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78719756d0> -> __condition
            __expression = __cache_135757232037584

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <link ... (0:0)
                # --------------------------------------------------------
                __append(u'<link />')
            else:
                __content = __cache_135757232037584
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7b7871975c50> name=None at 7b7871975c90> -> __attrs_135757138341200
            __attrs_135757138341200 = _static_135757232036944

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="generator" content="Plone - http://plone.com" />\n\n  </head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786c01ac50> name=None at 7b786c00e490> -> __attrs_135757226789904
            __attrs_135757226789904 = _static_135757138340944
            __backup_isRTL_135757237097424 = get('isRTL', __marker)

            # <Value u'portal_state/is_rtl' (42:26)> -> __value
            __token = 1915
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'portal_state/is_rtl', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isRTL'] = __value
            __backup_sl_135757154839824 = get('sl', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.leftcolumn', view)" (43:22)> -> __value
            __token = 1958
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"plone_layout.have_portlets('plone.leftcolumn', view)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['sl'] = __value
            __backup_sr_135757132717200 = get('sr', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.rightcolumn', view)" (44:21)> -> __value
            __token = 2041
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"plone_layout.have_portlets('plone.rightcolumn', view)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['sr'] = __value
            __backup_body_class_135757237097808 = get('body_class', __marker)

            # <Value u'python:plone_layout.bodyClass(template, view)' (45:28)> -> __value
            __token = 2133
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'plone_layout.bodyClass(template, view)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['body_class'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body')

            # <Value u'python:plone_view.patterns_settings()' (48:22)> -> __cache_135757226786960
            __token = 2309
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226786960 = _static_135757244280656('python', u'plone_view.patterns_settings()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if (u'id' not in __chain(__cache_135757226786960)):
                __append(u' id="visual-portal-wrapper"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226788816
            __default_135757226788816 = _DEFAULT_MARKER

            # <Substitution u'body_class' (46:30)> -> __attr_class
            __token = 2214
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'body_class', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_135757226786960))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226790672
            __default_135757226790672 = _DEFAULT_MARKER

            # <Substitution u"python:isRTL and 'rtl' or 'ltr'" (47:27)> -> __attr_dir
            __token = 2253
            try:
                __zt_tmp = __attrs_135757226789904
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_135757244280656('python', u"isRTL and 'rtl' or 'ltr'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_dir is not None) and (u'dir' not in __chain(__cache_135757226786960))):
                __append((u' dir="%s"' % __attr_dir))
            __attr_135757226790864 = __cache_135757226786960
            for (name, value, ) in __attr_135757226790864.items():
                if ((name not in _static_135757365992336) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134637520
            __attrs_135757134637520 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134637904
            __default_135757134637904 = _DEFAULT_MARKER

            # <Value u'provider:plone.toolbar' (51:32)> -> __cache_135757226788368
            __token = 2419
            try:
                __zt_tmp = __attrs_135757134637520
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226788368 = _static_135757244280656('provider', u'plone.toolbar', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.toolbar' (51:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78714745d0> -> __condition
            __expression = __cache_135757226788368

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757226788368
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bc92dd0> name=None at 7b786bc92d50> -> __attrs_135757134638864
            __attrs_135757134638864 = _static_135757134638544
            __previous_i18n_domain_135757134638672 = __i18n_domain
            __i18n_domain = u'plone'

            # <header ... (0:0)
            # --------------------------------------------------------
            __append(u'<header id="portal-top">\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134635920
            __attrs_135757134635920 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134636240
            __default_135757134636240 = _DEFAULT_MARKER

            # <Value u'provider:plone.portaltop' (54:34)> -> __cache_135757134638928
            __token = 2530
            try:
                __zt_tmp = __attrs_135757134635920
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757134638928 = _static_135757244280656('provider', u'plone.portaltop', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portaltop' (54:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc92510> -> __condition
            __expression = __cache_135757134638928

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757134638928
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    </header>')
            __i18n_domain = __previous_i18n_domain_135757134638672
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bc92810> name=None at 7b786bc92a10> -> __attrs_135757134636496
            __attrs_135757134636496 = _static_135757134637072

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="portal-mainnavigation">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134636688
            __default_135757134636688 = _DEFAULT_MARKER

            # <Value u'provider:plone.mainnavigation' (57:59)> -> __cache_135757134637200
            __token = 2633
            try:
                __zt_tmp = __attrs_135757134636496
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757134637200 = _static_135757244280656('provider', u'plone.mainnavigation', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.mainnavigation' (57:59)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc92a50> -> __condition
            __expression = __cache_135757134637200

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n      The main navigation\n    ')
            else:
                __content = __cache_135757134637200
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bc920d0> name=None at 7b786bc92050> -> __attrs_135757134628560
            __attrs_135757134628560 = _static_135757134635216

            # <aside ... (0:0)
            # --------------------------------------------------------
            __append(u'<aside id="global_statusmessage">\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134629776
            __attrs_135757134629776 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134629840
            __default_135757134629840 = _DEFAULT_MARKER

            # <Value u'provider:plone.globalstatusmessage' (62:42)> -> __cache_135757134629008
            __token = 2783
            try:
                __zt_tmp = __attrs_135757134629776
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757134629008 = _static_135757244280656('provider', u'plone.globalstatusmessage', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.globalstatusmessage' (62:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc90750> -> __condition
            __expression = __cache_135757134629008

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757134629008
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n      ')
            if (__slot_global_statusmessage is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134630224
                __attrs_135757134630224 = _static_135757327983760

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n      </div>')
            else:
                __slot_global_statusmessage(__stream, econtext.copy(), rcontext)
            __append(u'\n    </aside>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bc90290> name=None at 7b786bc90c90> -> __attrs_135757134627664
            __attrs_135757134627664 = _static_135757134627472

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-above-content">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134629968
            __default_135757134629968 = _DEFAULT_MARKER

            # <Value u'provider:plone.abovecontent' (67:59)> -> __cache_135757134627344
            __token = 2960
            try:
                __zt_tmp = __attrs_135757134627664
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757134627344 = _static_135757244280656('provider', u'plone.abovecontent', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.abovecontent' (67:59)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc90e10> -> __condition
            __expression = __cache_135757134627344

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757134627344
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bc90910> name=None at 7b786bc90a90> -> __attrs_135757159721680
            __attrs_135757159721680 = _static_135757134629136

            # <article ... (0:0)
            # --------------------------------------------------------
            __append(u'<article id="portal-column-content">\n\n      ')
            if (__slot_content is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159721232
                __attrs_135757159721232 = _static_135757327983760
                __append(u'\n\n      ')
                __token = None
                render_content(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n\n      ')
            else:
                __slot_content(__stream, econtext.copy(), rcontext)
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159720464
            __attrs_135757159720464 = _static_135757327983760

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer>\n        ')

            # <Static value=<_ast.Dict object at 0x7b786bc99d90> name=None at 7b786bc99ed0> -> __attrs_135757134664720
            __attrs_135757134664720 = _static_135757134667152

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-below-content">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134665872
            __default_135757134665872 = _DEFAULT_MARKER

            # <Value u'provider:plone.belowcontent' (115:63)> -> __cache_135757226699856
            __token = 4621
            try:
                __zt_tmp = __attrs_135757134664720
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757226699856 = _static_135757244280656('provider', u'plone.belowcontent', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.belowcontent' (115:63)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787145ec90> -> __condition
            __expression = __cache_135757226699856

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757226699856
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n      </footer>\n    </article>\n\n\n\n    ')
            if (__slot_column_one_slot is None):

                # <Static value=<_ast.Dict object at 0x7b786d47e810> name=None at 7b786d47e550> -> __attrs_135757237165840
                __attrs_135757237165840 = _static_135757159720976

                # <Value u'sl' (123:26)> -> __condition
                __token = 4794
                try:
                    __zt_tmp = __attrs_135757237165840
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'sl', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-one">\n      ')
                    if (__slot_portlets_one_slot is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237162960
                        __attrs_135757237162960 = _static_135757327983760
                        __append(u'\n        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154865680
                        __attrs_135757154865680 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154866832
                        __default_135757154866832 = _DEFAULT_MARKER

                        # <Value u'provider:plone.leftcolumn' (125:38)> -> __cache_135757237164432
                        __token = 4892
                        try:
                            __zt_tmp = __attrs_135757154865680
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757237164432 = _static_135757244280656('provider', u'plone.leftcolumn', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.leftcolumn' (125:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cfdd390> -> __condition
                        __expression = __cache_135757237164432

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757237164432
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n      ')
                    else:
                        __slot_portlets_one_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\n    </aside>')
            else:
                __slot_column_one_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    ')
            if (__slot_column_two_slot is None):

                # <Static value=<_ast.Dict object at 0x7b7871e59a90> name=None at 7b7871e59190> -> __attrs_135757154865936
                __attrs_135757154865936 = _static_135757237164688

                # <Value u'sr' (131:26)> -> __condition
                __token = 5067
                try:
                    __zt_tmp = __attrs_135757154865936
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'sr', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-two">\n      ')
                    if (__slot_portlets_two_slot is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154869136
                        __attrs_135757154869136 = _static_135757327983760
                        __append(u'\n        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154867536
                        __attrs_135757154867536 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154865616
                        __default_135757154865616 = _DEFAULT_MARKER

                        # <Value u'provider:plone.rightcolumn' (133:38)> -> __cache_135757154868048
                        __token = 5165
                        try:
                            __zt_tmp = __attrs_135757154867536
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757154868048 = _static_135757244280656('provider', u'plone.rightcolumn', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.rightcolumn' (133:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cfdd3d0> -> __condition
                        __expression = __cache_135757154868048

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757154868048
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n      ')
                    else:
                        __slot_portlets_two_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\n    </aside>')
            else:
                __slot_column_two_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cfddf50> name=None at 7b786cfdd8d0> -> __attrs_135757154865296
            __attrs_135757154865296 = _static_135757154869072
            __previous_i18n_domain_135757154868368 = __i18n_domain
            __i18n_domain = u'plone'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer id="portal-footer-wrapper">\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134668304
            __attrs_135757134668304 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134669776
            __default_135757134669776 = _DEFAULT_MARKER

            # <Value u'provider:plone.portalfooter' (138:34)> -> __cache_135757134669520
            __token = 5328
            try:
                __zt_tmp = __attrs_135757134668304
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757134669520 = _static_135757244280656('provider', u'plone.portalfooter', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portalfooter' (138:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc9a0d0> -> __condition
            __expression = __cache_135757134669520

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757134669520
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    </footer>')
            __i18n_domain = __previous_i18n_domain_135757154868368
            __append(u'\n\n  </body>')
            if (__backup_body_class_135757237097808 is __marker):
                del econtext['body_class']
            else:
                econtext['body_class'] = __backup_body_class_135757237097808
            if (__backup_sr_135757132717200 is __marker):
                del econtext['sr']
            else:
                econtext['sr'] = __backup_sr_135757132717200
            if (__backup_sl_135757154839824 is __marker):
                del econtext['sl']
            else:
                econtext['sl'] = __backup_sl_135757154839824
            if (__backup_isRTL_135757237097424 is __marker):
                del econtext['isRTL']
            else:
                econtext['isRTL'] = __backup_isRTL_135757237097424
            __append(u'\n</html>')
            __i18n_domain = __previous_i18n_domain_135757226824720
            if (__backup_ajax_load_135757305499408 is __marker):
                del econtext['ajax_load']
            else:
                econtext['ajax_load'] = __backup_ajax_load_135757305499408
            if (__backup_ajax_include_head_135757232020432 is __marker):
                del econtext['ajax_include_head']
            else:
                econtext['ajax_include_head'] = __backup_ajax_include_head_135757232020432
            if (__backup_site_properties_135757237096848 is __marker):
                del econtext['site_properties']
            else:
                econtext['site_properties'] = __backup_site_properties_135757237096848
            if (__backup_checkPermission_135757154865360 is __marker):
                del econtext['checkPermission']
            else:
                econtext['checkPermission'] = __backup_checkPermission_135757154865360
            if (__backup_portal_url_135757123417552 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_135757123417552
            if (__backup_dummy_135757237117840 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_135757237117840
            if (__backup_view_135757132573520 is __marker):
                del econtext['view']
            else:
                econtext['view'] = __backup_view_135757132573520
            if (__backup_lang_135757154849488 is __marker):
                del econtext['lang']
            else:
                econtext['lang'] = __backup_lang_135757154849488
            if (__backup_plone_layout_135757237117776 is __marker):
                del econtext['plone_layout']
            else:
                econtext['plone_layout'] = __backup_plone_layout_135757237117776
            if (__backup_plone_view_135757159719824 is __marker):
                del econtext['plone_view']
            else:
                econtext['plone_view'] = __backup_plone_view_135757159719824
            if (__backup_context_state_135757237165072 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_135757237165072
            if (__backup_portal_state_135757232021328 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_135757232021328
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_master(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_content': render_content, u'render_master': render_master, 'render': render, }