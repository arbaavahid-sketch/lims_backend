# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/documentactions.pt'

__tokens = {102: (u'view/actions', 4, 33), 195: (u'nocall: context/@@plone/normalizeString', 6, 36), 267: (u'view/actions', 7, 30), 310: (u"python:'document-action-' + normalizeString(daction['id'])", 8, 29), 452: (u'daction/url', 11, 33), 499: (u' daction/link_target|nothin', 12, 34), 561: (u'e daction/descripti', 13, 32), 615: (u'daction/icon', 14, 30), 665: (u"python:daction.get('icon')", 15, 36), 728: (u" python:daction.get('title'", 16, 35), 794: (u"e python:daction.get('title", 17, 36), 856: (u'not:daction/icon', 18, 29), 901: (u"python:daction.get('id')", 19, 27)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757073102736 = {u'id': u"python:'document-action-' + normalizeString(daction['id'])", }
_static_135757150475856 = {u'title': u'daction/description', u'href': u'', u'class': u'nav-link', u'target': u'daction/link_target|nothing', }
_static_135757073104400 = {u'class': u'nav nav-pills float-right', }
_static_135757244280656 = __compile_zt_expr
_static_135757073129744 = {u'src': u"python:daction.get('icon')", u'alt': u"python:daction.get('title')", u'title': u"python:daction.get('title')", }
_static_135757327983760 = {}
_static_135757075150992 = {u'id': u'senaite-document-actions', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78683d7890> name=None at 7b78683d7c50> -> __attrs_135757075151120
            __attrs_135757075151120 = _static_135757075150992
            __previous_i18n_domain_135757075151376 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="senaite-document-actions">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073101328
            __attrs_135757073101328 = _static_135757327983760

            # <Value u'view/actions' (4:33)> -> __condition
            __token = 102
            try:
                __zt_tmp = __attrs_135757073101328
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'view/actions', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78681e3e10> name=None at 7b78681e3710> -> __attrs_135757073104080
                __attrs_135757073104080 = _static_135757073104400
                __backup_normalizeString_135757075534224 = get('normalizeString', __marker)

                # <Value u'nocall: context/@@plone/normalizeString' (6:36)> -> __value
                __token = 195
                try:
                    __zt_tmp = __attrs_135757073104080
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('nocall', u' context/@@plone/normalizeString', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['normalizeString'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-pills float-right">\n      ')

                # <Static value=<_ast.Dict object at 0x7b78681e3790> name=None at 7b78681e37d0> -> __attrs_135757073104656
                __attrs_135757073104656 = _static_135757073102736
                __backup_daction_135757075356048 = get('daction', __marker)

                # <Value u'view/actions' (7:30)> -> __iterator
                __token = 267
                try:
                    __zt_tmp = __attrs_135757073104656
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'view/actions', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757150476880, ) = getitem('repeat')(u'daction', __iterator)
                econtext['daction'] = None
                for __item in __iterator:
                    econtext['daction'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073103632
                    __default_135757073103632 = _DEFAULT_MARKER

                    # <Substitution u"python:'document-action-' + normalizeString(daction['id'])" (8:29)> -> __attr_id
                    __token = 310
                    try:
                        __zt_tmp = __attrs_135757073104656
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('python', u"'document-action-' + normalizeString(daction['id'])", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n        ')

                    # <Static value=<_ast.Dict object at 0x7b786cbad650> name=None at 7b786cbadb90> -> __attrs_135757166677776
                    __attrs_135757166677776 = _static_135757150475856

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166284368
                    __default_135757166284368 = _DEFAULT_MARKER

                    # <Substitution u'daction/url' (11:33)> -> __attr_href
                    __token = 452
                    try:
                        __zt_tmp = __attrs_135757166677776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('path', u'daction/url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u' class="nav-link"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166282128
                    __default_135757166282128 = _DEFAULT_MARKER

                    # <Substitution u'daction/link_target|nothing' (12:34)> -> __attr_target
                    __token = 499
                    try:
                        __zt_tmp = __attrs_135757166677776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_target = _static_135757244280656('path', u'daction/link_target|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_target = __quote(__attr_target, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_target is not None):
                        __append((u' target="%s"' % __attr_target))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166284304
                    __default_135757166284304 = _DEFAULT_MARKER

                    # <Substitution u'daction/description' (13:32)> -> __attr_title
                    __token = 561
                    try:
                        __zt_tmp = __attrs_135757166677776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_135757244280656('path', u'daction/description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78681ea110> name=None at 7b78681ea4d0> -> __attrs_135757075356112
                    __attrs_135757075356112 = _static_135757073129744

                    # <Value u'daction/icon' (14:30)> -> __condition
                    __token = 615
                    try:
                        __zt_tmp = __attrs_135757075356112
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'daction/icon', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073131728
                        __default_135757073131728 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('icon')" (15:36)> -> __attr_src
                        __token = 665
                        try:
                            __zt_tmp = __attrs_135757075356112
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_135757244280656('python', u"daction.get('icon')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073129936
                        __default_135757073129936 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('title')" (16:35)> -> __attr_alt
                        __token = 728
                        try:
                            __zt_tmp = __attrs_135757075356112
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_alt = _static_135757244280656('python', u"daction.get('title')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_alt = __quote(__attr_alt, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_alt is not None):
                            __append((u' alt="%s"' % __attr_alt))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075354576
                        __default_135757075354576 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('title')" (17:36)> -> __attr_title
                        __token = 794
                        try:
                            __zt_tmp = __attrs_135757075356112
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('python', u"daction.get('title')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'/>')
                    __append(u'\n        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075357136
                    __attrs_135757075357136 = _static_135757327983760

                    # <Value u'not:daction/icon' (18:29)> -> __condition
                    __token = 856
                    try:
                        __zt_tmp = __attrs_135757075357136
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('not', u'daction/icon', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073130320
                        __default_135757073130320 = _DEFAULT_MARKER

                        # <Value u"python:daction.get('id')" (19:27)> -> __cache_135757075355152
                        __token = 901
                        try:
                            __zt_tmp = __attrs_135757075357136
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757075355152 = _static_135757244280656('python', u"daction.get('id')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u"python:daction.get('id')" (19:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78684092d0> -> __condition
                        __expression = __cache_135757075355152

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757075355152
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>')
                    __append(u'\n        </a>\n      </li>')
                    ____index_135757150476880 -= 1
                    if (____index_135757150476880 > 0):
                        __append('\n      ')
                if (__backup_daction_135757075356048 is __marker):
                    del econtext['daction']
                else:
                    econtext['daction'] = __backup_daction_135757075356048
                __append(u'\n    </ul>')
                if (__backup_normalizeString_135757075534224 is __marker):
                    del econtext['normalizeString']
                else:
                    econtext['normalizeString'] = __backup_normalizeString_135757075534224
                __append(u'\n  ')
            __append(u'\n</div>')
            __i18n_domain = __previous_i18n_domain_135757075151376
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }