# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/multiuploadwidget.pt'

__tokens = {1348: (u'python:field.getEditAccessor(here)() or []', 33, 32), 1431: (u' python:here.session_restore_value(fieldName, value', 34, 39), 1522: (u'e python:request.get(fieldName, session_valu', 35, 37), 1599: (u'ue python:cached_value or va', 36, 29), 1663: (u'red field/required|not', 37, 31), 1721: (u"ired python: required and 'required' or", 38, 30), 1796: (u'or_id python:errors.get(fiel', 39, 29), 1863: (u'domain field/widget/i18n_domain|context/i18n_domain|strin', 40, 31), 1968: (u'not: widget/render_own_label | nothing', 42, 36), 2084: (u'python:fieldName', 44, 37), 2134: (u'python:widget.Label(here)', 45, 31), 2268: (u'field/required', 48, 33), 2468: (u'python:widget.Description(here)', 52, 42), 2592: (u'string:${fieldName}_help', 54, 37), 2542: (u'description', 53, 41), 2822: (u'python:field.widget.get_input_widget_attributes(context, field, value)', 62, 38), 2933: (u' python:field.widget.get_existing_files_data(context, field, value', 63, 39), 3399: (u'    python:widget_a', 68, 25), 3035: (u'python:fieldName', 64, 32), 3087: (u" python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klas", 65, 34), 3268: (u"d python:required and '1' or '", 66, 41), 3348: (u'es python:existing_fi', 67, 46), 3641: (u'python:fieldName', 73, 36), 3695: (u" python:'\\r\\n'.join(field.widget.get_value(context, field, value)", 74, 36), 3832: (u'required', 77, 50), 3897: (u'error_id', 78, 48), 443: (u'python:accessor()', 12, 29), 489: (u' python:widget.get_value(context, field, value', 13, 27), 616: (u'refs', 15, 30), 688: (u'python:widget.render_reference(context, field, ref)', 16, 42), 776: (u'python:rendered', 17, 34), 904: (u'rendered', 19, 45), 971: (u'python:not rendered', 21, 34), 1057: (u'string:broken reference ${ref}', 22, 44), 1124: (u'ref', 23, 35), 231: (u'here/main_template/macros/master', 5, 23), 231: (u'here/main_template/macros/master', 5, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756869543760 = {u'type': u'hidden', u'name': u'python:fieldName', u'value': u"python:'\\r\\n'.join(field.widget.get_value(context, field, value))", }
_static_135757075013200 = {u'class': u'text-danger', }
_static_135757074404112 = {u'class': u'formQuestion', u'for': u'python:fieldName', }
_static_135757073441744 = {u'class': u'd-inline-block', }
_static_135756869325136 = {u'class': u'p-1 mb-1 mr-1 bg-light border rounded', }
_static_135757244280656 = __compile_zt_expr
_static_135757075181264 = {u'class': u'fieldErrorBox', }
_static_135757075859536 = u'master'
_static_135756869545168 = {u'class': u'fieldErrorBox', }
_static_135757109739152 = set([])
_static_135757075195280 = {u'class': u'list-unstyled d-table-row', }
_static_135757109777552 = {u'title': u'string:broken reference ${ref}', }
_static_135757327983760 = {}
_static_135757109936208 = {u'data-existing_files': u'python:existing_files', u'data-required': u"python:required and '1' or '0'", u'id': u'python:fieldName', u'class': u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass", }
_static_135757109764880 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757109939472 = {u'class': u'required', u'title': u'Required', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137293776
            __attrs_135757137293776 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869325072
            __attrs_135756869325072 = _static_135757327983760
            __backup_value_135757150216592 = get('value', __marker)

            # <Value u'python:field.getEditAccessor(here)() or []' (33:32)> -> __value
            __token = 1348
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.getEditAccessor(here)() or []', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_session_value_135757073221776 = get('session_value', __marker)

            # <Value u'python:here.session_restore_value(fieldName, value)' (34:39)> -> __value
            __token = 1431
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'here.session_restore_value(fieldName, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['session_value'] = __value
            __backup_cached_value_135757074601168 = get('cached_value', __marker)

            # <Value u'python:request.get(fieldName, session_value)' (35:37)> -> __value
            __token = 1522
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'request.get(fieldName, session_value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['cached_value'] = __value
            __backup_value_135757075180304 = get('value', __marker)

            # <Value u'python:cached_value or value' (36:29)> -> __value
            __token = 1599
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'cached_value or value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_required_135757152988112 = get('required', __marker)

            # <Value u'field/required|nothing' (37:31)> -> __value
            __token = 1663
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/required|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['required'] = __value
            __backup_required_135757075250064 = get('required', __marker)

            # <Value u"python: required and 'required' or None" (38:30)> -> __value
            __token = 1721
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u" required and 'required' or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['required'] = __value
            __backup_error_id_135757075248656 = get('error_id', __marker)

            # <Value u'python:errors.get(fieldName)' (39:29)> -> __value
            __token = 1796
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'errors.get(fieldName)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['error_id'] = __value
            __backup_i18n_domain_135757109878544 = get('i18n_domain', __marker)

            # <Value u'field/widget/i18n_domain|context/i18n_domain|string:plone' (40:31)> -> __value
            __token = 1863
            try:
                __zt_tmp = __attrs_135756869325072
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/widget/i18n_domain|context/i18n_domain|string:plone', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['i18n_domain'] = __value
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109778960
            __attrs_135757109778960 = _static_135757327983760

            # <Value u'not: widget/render_own_label | nothing' (42:36)> -> __condition
            __token = 1968
            try:
                __zt_tmp = __attrs_135757109778960
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u' widget/render_own_label | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b7868321310> name=None at 7b78683216d0> -> __attrs_135757109937104
                __attrs_135757109937104 = _static_135757074404112

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="formQuestion"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109937296
                __default_135757109937296 = _DEFAULT_MARKER

                # <Substitution u'python:fieldName' (44:37)> -> __attr_for
                __token = 2084
                try:
                    __zt_tmp = __attrs_135757109937104
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109938064
                __attrs_135757109938064 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109937872
                __default_135757109937872 = _DEFAULT_MARKER

                # <Value u'python:widget.Label(here)' (45:31)> -> __cache_135757109938384
                __token = 2134
                try:
                    __zt_tmp = __attrs_135757109938064
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757109938384 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:widget.Label(here)' (45:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a504510> -> __condition
                __expression = __cache_135757109938384

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_135757109938384
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b786a504d10> name=None at 7b786a504ed0> -> __attrs_135757109765840
                __attrs_135757109765840 = _static_135757109939472

                # <Value u'field/required' (48:33)> -> __condition
                __token = 2268
                try:
                    __zt_tmp = __attrs_135757109765840
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'field/required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="required"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109936272
                    __default_135757109936272 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7b786a504d90> at 7b786a504e10> -> __attr_title
                    __attr_title = u'Required'
                    __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>&nbsp;</span>')
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b786a4da310> name=None at 7b786a4da350> -> __attrs_135757109766352
                __attrs_135757109766352 = _static_135757109764880
                __backup_description_135756868148368 = get('description', __marker)

                # <Value u'python:widget.Description(here)' (52:42)> -> __value
                __token = 2468
                try:
                    __zt_tmp = __attrs_135757109766352
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.Description(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['description'] = __value

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="formHelp"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109766928
                __default_135757109766928 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_help' (54:37)> -> __attr_id
                __token = 2592
                try:
                    __zt_tmp = __attrs_135757109766352
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}_help', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109765072
                __default_135757109765072 = _DEFAULT_MARKER

                # <Value u'description' (53:41)> -> __cache_135757109766608
                __token = 2542
                try:
                    __zt_tmp = __attrs_135757109766352
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757109766608 = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'description' (53:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a4da0d0> -> __condition
                __expression = __cache_135757109766608

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n              Help\n            ')
                else:
                    __content = __cache_135757109766608
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>')
                if (__backup_description_135756868148368 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_135756868148368
                __append(u'\n          </label>\n        ')
            __append(u'\n\n        <!-- Multi-Upload Widget Container -->\n        ')

            # <Static value=<_ast.Dict object at 0x7b786a504050> name=None at 7b786a504bd0> -> __attrs_135756869545488
            __attrs_135756869545488 = _static_135757109936208
            __backup_widget_attrs_135757074666448 = get('widget_attrs', __marker)

            # <Value u'python:field.widget.get_input_widget_attributes(context, field, value)' (62:38)> -> __value
            __token = 2822
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.widget.get_input_widget_attributes(context, field, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['widget_attrs'] = __value
            __backup_existing_files_135757166194384 = get('existing_files', __marker)

            # <Value u'python:field.widget.get_existing_files_data(context, field, value)' (63:39)> -> __value
            __token = 2933
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.widget.get_existing_files_data(context, field, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['existing_files'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Value u'python:widget_attrs' (68:25)> -> __cache_135756869545744
            __token = 3399
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135756869545744 = _static_135757244280656('python', u'widget_attrs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109767504
            __default_135757109767504 = _DEFAULT_MARKER

            # <Substitution u'python:fieldName' (64:32)> -> __attr_id
            __token = 3035
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_id is not None) and (u'id' not in __chain(__cache_135756869545744))):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109766480
            __default_135757109766480 = _DEFAULT_MARKER

            # <Substitution u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass" (65:34)> -> __attr_class
            __token = 3087
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('python', u" test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_135756869545744))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869543248
            __default_135756869543248 = _DEFAULT_MARKER

            # <Substitution u"python:required and '1' or '0'" (66:41)> -> __attr_data_required
            __token = 3268
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_required = _static_135757244280656('python', u"required and '1' or '0'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_data_required = __quote(__attr_data_required, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_data_required is not None) and (u'data-required' not in __chain(__cache_135756869545744))):
                __append((u' data-required="%s"' % __attr_data_required))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869544016
            __default_135756869544016 = _DEFAULT_MARKER

            # <Substitution u'python:existing_files' (67:46)> -> __attr_data_existing_files
            __token = 3348
            try:
                __zt_tmp = __attrs_135756869545488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_existing_files = _static_135757244280656('python', u'existing_files', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_data_existing_files = __quote(__attr_data_existing_files, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_data_existing_files is not None) and (u'data-existing_files' not in __chain(__cache_135756869545744))):
                __append((u' data-existing_files="%s"' % __attr_data_existing_files))
            __attr_135756869543184 = __cache_135756869545744
            for (name, value, ) in __attr_135756869543184.items():
                if ((name not in _static_135757109739152) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\n          <!-- ReactJS multiupload widget will be rendered here -->\n\n        <!-- Hidden input field to store the current UIDs (for display only) -->\n        ')

            # <Static value=<_ast.Dict object at 0x7b785bfc2750> name=None at 7b785bfc26d0> -> __attrs_135756869543888
            __attrs_135756869543888 = _static_135756869543760

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869542352
            __default_135756869542352 = _DEFAULT_MARKER

            # <Substitution u'python:fieldName' (73:36)> -> __attr_name
            __token = 3641
            try:
                __zt_tmp = __attrs_135756869543888
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869542864
            __default_135756869542864 = _DEFAULT_MARKER

            # <Substitution u"python:'\\r\\n'.join(field.widget.get_value(context, field, value))" (74:36)> -> __attr_value
            __token = 3695
            try:
                __zt_tmp = __attrs_135756869543888
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('python', u"'\\r\\n'.join(field.widget.get_value(context, field, value))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n        </div>')
            if (__backup_existing_files_135757166194384 is __marker):
                del econtext['existing_files']
            else:
                econtext['existing_files'] = __backup_existing_files_135757166194384
            if (__backup_widget_attrs_135757074666448 is __marker):
                del econtext['widget_attrs']
            else:
                econtext['widget_attrs'] = __backup_widget_attrs_135757074666448
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b785bfc2cd0> name=None at 7b785bfc2790> -> __attrs_135757075178128
            __attrs_135757075178128 = _static_135756869545168

            # <Value u'required' (77:50)> -> __condition
            __token = 3832
            try:
                __zt_tmp = __attrs_135757075178128
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="fieldErrorBox"></div>')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78683deed0> name=None at 7b78683de050> -> __attrs_135757075180624
            __attrs_135757075180624 = _static_135757075181264

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="fieldErrorBox">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075177872
            __default_135757075177872 = _DEFAULT_MARKER

            # <Value u'error_id' (78:48)> -> __cache_135757075178768
            __token = 3897
            try:
                __zt_tmp = __attrs_135757075180624
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075178768 = _static_135757244280656('path', u'error_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'error_id' (78:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683de990> -> __condition
            __expression = __cache_135757075178768

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757075178768
                __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n\n      ')
            if (__backup_i18n_domain_135757109878544 is __marker):
                del econtext['i18n_domain']
            else:
                econtext['i18n_domain'] = __backup_i18n_domain_135757109878544
            if (__backup_error_id_135757075248656 is __marker):
                del econtext['error_id']
            else:
                econtext['error_id'] = __backup_error_id_135757075248656
            if (__backup_required_135757075250064 is __marker):
                del econtext['required']
            else:
                econtext['required'] = __backup_required_135757075250064
            if (__backup_required_135757152988112 is __marker):
                del econtext['required']
            else:
                econtext['required'] = __backup_required_135757152988112
            if (__backup_value_135757075180304 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757075180304
            if (__backup_cached_value_135757074601168 is __marker):
                del econtext['cached_value']
            else:
                econtext['cached_value'] = __backup_cached_value_135757074601168
            if (__backup_session_value_135757073221776 is __marker):
                del econtext['session_value']
            else:
                econtext['session_value'] = __backup_session_value_135757073221776
            if (__backup_value_135757150216592 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757150216592
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148727120
            __attrs_135757148727120 = _static_135757327983760
            __append(u'\n      ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149863568
                __attrs_135757149863568 = _static_135757327983760
                __backup_value_135756868130704 = get('value', __marker)

                # <Value u'python:accessor()' (12:29)> -> __value
                __token = 443
                try:
                    __zt_tmp = __attrs_135757149863568
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['value'] = __value
                __backup_refs_135756869620816 = get('refs', __marker)

                # <Value u'python:widget.get_value(context, field, value)' (13:27)> -> __value
                __token = 489
                try:
                    __zt_tmp = __attrs_135757149863568
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.get_value(context, field, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['refs'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n        ')

                # <Static value=<_ast.Dict object at 0x7b78683e2590> name=None at 7b787172b150> -> __attrs_135757075197264
                __attrs_135757075197264 = _static_135757075195280

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="list-unstyled d-table-row">\n          ')

                # <Static value=<_ast.Dict object at 0x7b78682363d0> name=None at 7b7868236650> -> __attrs_135756869328464
                __attrs_135756869328464 = _static_135757073441744
                __backup_ref_135757150217552 = get('ref', __marker)

                # <Value u'refs' (15:30)> -> __iterator
                __token = 616
                try:
                    __zt_tmp = __attrs_135756869328464
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'refs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756869328144, ) = getitem('repeat')(u'ref', __iterator)
                econtext['ref'] = None
                for __item in __iterator:
                    econtext['ref'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="d-inline-block">\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869325520
                    __attrs_135756869325520 = _static_135757327983760
                    __backup_rendered_135757109737488 = get('rendered', __marker)

                    # <Value u'python:widget.render_reference(context, field, ref)' (16:42)> -> __value
                    __token = 688
                    try:
                        __zt_tmp = __attrs_135756869325520
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'widget.render_reference(context, field, ref)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['rendered'] = __value
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b785bf8d150> name=None at 7b785bf8d550> -> __attrs_135756869325008
                    __attrs_135756869325008 = _static_135756869325136

                    # <Value u'python:rendered' (17:34)> -> __condition
                    __token = 776
                    try:
                        __zt_tmp = __attrs_135756869325008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="p-1 mb-1 mr-1 bg-light border rounded">\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075011280
                        __attrs_135757075011280 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075012112
                        __default_135757075012112 = _DEFAULT_MARKER

                        # <Value u'rendered' (19:45)> -> __cache_135757075934672
                        __token = 904
                        try:
                            __zt_tmp = __attrs_135757075011280
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757075934672 = _static_135757244280656('path', u'rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'rendered' (19:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683b50d0> -> __condition
                        __expression = __cache_135757075934672

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span/>')
                        else:
                            __content = __cache_135757075934672
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n              </div>')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78683b5e50> name=None at 7b785bf8d350> -> __attrs_135757109780368
                    __attrs_135757109780368 = _static_135757075013200

                    # <Value u'python:not rendered' (21:34)> -> __condition
                    __token = 971
                    try:
                        __zt_tmp = __attrs_135757109780368
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'not rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-danger">\n                ')

                        # <Static value=<_ast.Dict object at 0x7b786a4dd490> name=None at 7b786a4dd8d0> -> __attrs_135757109777936
                        __attrs_135757109777936 = _static_135757109777552

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109779792
                        __default_135757109779792 = _DEFAULT_MARKER

                        # <Substitution u'string:broken reference ${ref}' (22:44)> -> __attr_title
                        __token = 1057
                        try:
                            __zt_tmp = __attrs_135757109777936
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('string', u'broken reference ${ref}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109779344
                        __default_135757109779344 = _DEFAULT_MARKER

                        # <Value u'ref' (23:35)> -> __cache_135757109778704
                        __token = 1124
                        try:
                            __zt_tmp = __attrs_135757109777936
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757109778704 = _static_135757244280656('path', u'ref', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'ref' (23:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a4dd990> -> __condition
                        __expression = __cache_135757109778704

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757109778704
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n              </div>')
                    __append(u'\n            ')
                    if (__backup_rendered_135757109737488 is __marker):
                        del econtext['rendered']
                    else:
                        econtext['rendered'] = __backup_rendered_135757109737488
                    __append(u'\n          </li>')
                    ____index_135756869328144 -= 1
                    if (____index_135756869328144 > 0):
                        __append('\n          ')
                if (__backup_ref_135757150217552 is __marker):
                    del econtext['ref']
                else:
                    econtext['ref'] = __backup_ref_135757150217552
                __append(u'\n        </ul>\n      </div>')
                if (__backup_refs_135756869620816 is __marker):
                    del econtext['refs']
                else:
                    econtext['refs'] = __backup_refs_135756869620816
                if (__backup_value_135756868130704 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_135756868130704
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075859920
            __attrs_135757075859920 = _static_135757327983760
            __previous_i18n_domain_135757075859088 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_135757118713440 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868484850> name=None at 7b7868484b50> -> __value
            __value = _static_135757075859536
            econtext['macroname'] = __value

            # <Value u'here/main_template/macros/master' (5:23)> -> __macro
            __token = 231
            try:
                __zt_tmp = __attrs_135757075859920
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 231
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118713440 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118713440
            __i18n_domain = __previous_i18n_domain_135757075859088
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_view': render_view, 'render': render, }