# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/listingtitle.pt'

__tokens = {146: (u'view/icon', 4, 32), 250: (u'view/title', 8, 19)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525979686032 = {}
_static_124525731903312 = {u'class': u'listing-title-viewlet d-inline-block', }
_static_124525521768016 = {u'class': u'd-inline-block align-middle', }
_static_124525732178768 = {u'class': u'd-inline-block align-middle', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71416803f750> name=None at 71416803f110> -> __attrs_124525521543312
            __attrs_124525521543312 = _static_124525731903312

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="listing-title-viewlet d-inline-block">\r\n  <!-- icon -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x71415b7d8e50> name=None at 714168328490> -> __attrs_124525732518992
            __attrs_124525732518992 = _static_124525521768016

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="d-inline-block align-middle">\r\n    ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732176144
            __attrs_124525732176144 = _static_124525979686032

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732178832
            __default_124525732178832 = _DEFAULT_MARKER

            # <Value u'view/icon' (4:32)> -> __cache_124525733138128
            __token = 146
            try:
                __zt_tmp = __attrs_124525732176144
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_124525733138128 = _static_124525896001680('path', u'view/icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/icon' (4:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680825d0> -> __condition
            __expression = __cache_124525733138128

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <img ... (0:0)
                # --------------------------------------------------------
                __append(u'<img/>')
            else:
                __content = __cache_124525733138128
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n  </div>\r\n  <!-- title -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x714168082b50> name=None at 714168082490> -> __attrs_124525806958800
            __attrs_124525806958800 = _static_124525732178768

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1 class="d-inline-block align-middle">')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732176464
            __default_124525732176464 = _DEFAULT_MARKER

            # <Value u'view/title' (8:19)> -> __cache_124525732176080
            __token = 250
            try:
                __zt_tmp = __attrs_124525806958800
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_124525732176080 = _static_124525896001680('path', u'view/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/title' (8:19)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168082a50> -> __condition
            __expression = __cache_124525732176080

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\r\n  ')
            else:
                __content = __cache_124525732176080
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</h1>\r\n</div>\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }