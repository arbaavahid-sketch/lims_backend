# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/colophon.pt'

__tokens = {}

from sys import exc_info as _exc_info

_static_124525979686032 = {}
_static_124525521771152 = {u'class': u'container-fluid', }
_static_124525521770128 = {u'class': u'row', }
_static_124525521719824 = {u'class': u'text-center text-muted', }
_static_124525521772432 = {u'class': u'col-md-12', }
_static_124525521755280 = {u'id': u'senaite-colophon', }
_static_124525521723024 = {u'class': u'list-inline', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7d5c90> name=None at 71415b7d5c50> -> __attrs_124525521752272
            __attrs_124525521752272 = _static_124525521755280
            __previous_i18n_domain_124525521755472 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="senaite-colophon">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x71415b7d9a90> name=None at 71415b7d5f90> -> __attrs_124525521769296
            __attrs_124525521769296 = _static_124525521771152

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\r\n    ')

            # <Static value=<_ast.Dict object at 0x71415b7d9690> name=None at 71415b7d9650> -> __attrs_124525521770192
            __attrs_124525521770192 = _static_124525521770128

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n      ')

            # <Static value=<_ast.Dict object at 0x71415b7d9f90> name=None at 71415b7d9a50> -> __attrs_124525521770256
            __attrs_124525521770256 = _static_124525521772432

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\r\n\r\n        ')

            # <Static value=<_ast.Dict object at 0x71415b7cd210> name=None at 71415b7cd150> -> __attrs_124525521721104
            __attrs_124525521721104 = _static_124525521719824

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="text-center text-muted">\r\n          ')

            # <Static value=<_ast.Dict object at 0x71415b7cde90> name=None at 71415b7cdbd0> -> __attrs_124525521722640
            __attrs_124525521722640 = _static_124525521723024

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-inline">\r\n            ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521721232
            __attrs_124525521721232 = _static_124525979686032

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>\r\n              \u0622\u0632\u0645\u0627\u06cc\u0634\u06af\u0627\u0647 \u062a\u0646\u062f\u06cc\u0633 \u2014 Tandis Laboratory\r\n            </li>\r\n          </ul>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</div>')
            __i18n_domain = __previous_i18n_domain_124525521755472
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }