# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.Archetypes-1.16.6-py2.7.egg/Products/Archetypes/skins/archetypes/widgets/file.pt'

__tokens = {5436: (u'accessor', 117, 28), 5473: (u' unit/get_size | python:unit and len(unit) or ', 118, 27), 5612: (u'string:${fieldName}_file', 121, 36), 5671: (u' string:${fieldName}_fil', 122, 33), 5773: (u"python:test(accessor() and size!=0, 'true', 'false')", 124, 32), 5856: (u"string:document.getElementById('${fieldName}_file').disabled=$isDisabled;", 125, 29), 6468: (u'context/widgets/file/macros/edit', 142, 28), 6468: (u'context/widgets/file/macros/edit', 142, 28), 2463: (u'python:0', 54, 64), 2504: (u'context/widgets/file/macros/file_view', 55, 30), 2504: (u'context/widgets/file/macros/file_view', 55, 30), 2635: (u'accessor', 57, 28), 2672: (u' unit/get_size | python:unit and len(unit) or ', 58, 27), 2572: (u'accessor', 56, 26), 2763: (u'size', 59, 40), 3025: (u"python:test(size!=0, 'checked', None)", 64, 43), 3103: (u' string:${fieldName}_delet', 65, 39), 3168: (u'd string:${fieldName}_nochan', 66, 36), 3240: (u"ck string:document.getElementById('${fieldName}_file').disabled=t", 67, 40), 3380: (u'string:${fieldName}_nochange', 69, 40), 3621: (u'python: not field.required', 75, 40), 3808: (u'string:${fieldName}_delete', 79, 44), 3877: (u' string:${fieldName}_delet', 80, 41), 3951: (u"k string:document.getElementById('${fieldName}_file').disabled=tr", 81, 45), 4116: (u'string:${fieldName}_delete', 84, 44), 4741: (u"ck string:document.getElementById('${fieldName}_file').disabled=fa", 97, 42), 4522: (u"python:test(size==0, 'checked', None)", 94, 45), 4602: (u' string:${fieldName}_delet', 95, 41), 4669: (u'd string:${fieldName}_uplo', 96, 38), 4878: (u'string:${fieldName}_upload', 100, 38), 5140: (u'context/widgets/file/macros/file_upload', 106, 35), 5140: (u'context/widgets/file/macros/file_upload', 106, 35), 5236: (u'not: accessor', 109, 26), 5284: (u'context/widgets/file/macros/file_upload', 110, 32), 5284: (u'context/widgets/file/macros/file_upload', 110, 32), 6295: (u'context/widgets/file/macros/file_edit', 136, 32), 6295: (u'context/widgets/file/macros/file_edit', 136, 32), 6168: (u'field_macro | context/widgets/field/macros/edit', 134, 28), 6168: (u'field_macro | context/widgets/field/macros/edit', 134, 28), 427: (u'accessor', 15, 31), 471: (u' showLink|python:', 16, 34), 524: (u'unit/get_size | python:unit and len(unit) or 0', 17, 32), 603: (u' unit/getBestIcon | nothin', 18, 31), 666: (u'e unit/filename | nothi', 19, 34), 733: (u'ze nocall:context/@@plone/toLocalizedS', 20, 40), 791: (u'ize python:toLocalizedSize(s', 21, 15), 860: (u"size python: (size > 1000 and '%s (%s bytes)' % (display_size, size)) or display", 22, 35), 978: (u'python:size &gt', 23, 30), 1037: (u'python:context.lookupMime(field.getContentType(here))', 24, 38), 1124: (u'showLink', 25, 31), 1181: (u'string:${context/absolute_url}/at_download/$fieldName', 26, 46), 1273: (u'icon', 27, 36), 1334: (u'string:${context/portal_url}/$icon', 28, 41), 1410: (u' string:${doc_type} ico', 29, 40), 1481: (u'filename | fieldName', 30, 43), 1625: (u'doc_type', 34, 37), 1710: (u'display_size', 35, 37), 1812: (u'not:showLink', 38, 31), 1861: (u'icon', 39, 34), 1920: (u'string:${context/portal_url}/$icon', 40, 39), 1994: (u' string:${doc_type} ico', 41, 38), 2063: (u'filename | fieldName', 42, 41), 2162: (u'doc_type', 44, 37), 2254: (u'display_size', 45, 37), 6038: (u'context/widgets/file/macros/file_view', 130, 28), 6038: (u'context/widgets/file/macros/file_view', 130, 28)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_127045642091088 = {u'for': u'', }
_static_127045886978576 = __C2ZContextWrapper
_static_127045642584464 = {u'src': u'', u'alt': u'', }
_static_127045642000592 = {u'style': u'padding-left:1.5em;padding-top:0.5em;', }
_static_127045970670736 = {}
_static_127045640635280 = u'edit'
_static_127045640775376 = {u'checked': u"python:test(size==0, 'checked', None)", u'name': u'string:${fieldName}_delete', u'value': u'', u'id': u'string:${fieldName}_upload', u'onclick': u'', u'type': u'radio', u'class': u'noborder', }
_static_127045640774160 = {u'name': u'string:${fieldName}_delete', u'value': u'delete', u'class': u'noborder', u'onclick': u"string:document.getElementById('${fieldName}_file').disabled=true", u'type': u'radio', u'id': u'string:${fieldName}_delete', }
_static_127045640220752 = u'file_upload'
_static_127045640221648 = {u'id': u'string:${fieldName}_file', u'type': u'file', u'name': u'string:${fieldName}_file', u'size': u'30', }
_static_127045640635728 = u'file_edit'
_static_127045640637264 = u'file_view'
_static_127045642149584 = {u'src': u'', u'alt': u'', }
_static_127045739725776 = {u'href': u'', }
_static_127045886978192 = __compile_zt_expr
_static_127045641722704 = {u'style': u'padding-top:1em;', }
_static_127045640570000 = {u'for': u'', }
_static_127045640637776 = u'edit'
_static_127045640570576 = u'file_upload'
_static_127045642603728 = {u'for': u'', }
_static_127045643100112 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_127045739076944 = u'file_view'
_static_127045642585808 = {u'class': u'discreet', }
_static_127045641721040 = {u'class': u'discreet', }
_static_127045641999376 = {u'checked': u"python:test(size!=0, 'checked', None)", u'name': u'string:${fieldName}_delete', u'value': u'nochange', u'class': u'noborder', u'onclick': u"string:document.getElementById('${fieldName}_file').disabled=true", u'type': u'radio', u'id': u'string:${fieldName}_nochange', }
_static_127045640224016 = {u'type': u'text/javascript', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_file_upload(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640571984
            __attrs_127045640571984 = _static_127045970670736
            __backup_unit_127045643097552 = get('unit', __marker)

            # <Value u'accessor' (117:28)> -> __value
            __token = 5436
            try:
                __zt_tmp = __attrs_127045640571984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['unit'] = __value
            __backup_size_127045739281488 = get('size', __marker)

            # <Value u'unit/get_size | python:unit and len(unit) or 0' (118:27)> -> __value
            __token = 5473
            try:
                __zt_tmp = __attrs_127045640571984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'unit/get_size | python:unit and len(unit) or 0', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['size'] = __value
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x738c1e4173d0> name=None at 738c1e417d90> -> __attrs_127045640224464
            __attrs_127045640224464 = _static_127045640221648

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="file" size="30"')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640223184
            __default_127045640223184 = _DEFAULT_MARKER

            # <Substitution u'string:${fieldName}_file' (121:36)> -> __attr_name
            __token = 5612
            try:
                __zt_tmp = __attrs_127045640224464
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_127045886978192('string', u'${fieldName}_file', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640222096
            __default_127045640222096 = _DEFAULT_MARKER

            # <Substitution u'string:${fieldName}_file' (122:33)> -> __attr_id
            __token = 5671
            try:
                __zt_tmp = __attrs_127045640224464
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_127045886978192('string', u'${fieldName}_file', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u' />\n        ')

            # <Static value=<_ast.Dict object at 0x738c1e417d10> name=None at 738c1e417810> -> __attrs_127045640635856
            __attrs_127045640635856 = _static_127045640224016
            __backup_isDisabled_127045739076624 = get('isDisabled', __marker)

            # <Value u"python:test(accessor() and size!=0, 'true', 'false')" (124:32)> -> __value
            __token = 5773
            try:
                __zt_tmp = __attrs_127045640635856
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('python', u"test(accessor() and size!=0, 'true', 'false')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['isDisabled'] = __value

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript">')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640223248
            __default_127045640223248 = _DEFAULT_MARKER

            # <Value u"string:document.getElementById('${fieldName}_file').disabled=$isDisabled;" (125:29)> -> __cache_127045640223760
            __token = 5856
            try:
                __zt_tmp = __attrs_127045640635856
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_127045640223760 = _static_127045886978192('string', u"document.getElementById('${fieldName}_file').disabled=$isDisabled;", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

            # <BinOp left=<Value u"string:document.getElementById('${fieldName}_file').disabled=$isDisabled;" (125:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e417790> -> __condition
            __expression = __cache_127045640223760

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n        ')
            else:
                __content = __cache_127045640223760
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</script>')
            if (__backup_isDisabled_127045739076624 is __marker):
                del econtext['isDisabled']
            else:
                econtext['isDisabled'] = __backup_isDisabled_127045739076624
            __append(u'\n    ')
            if (__backup_size_127045739281488 is __marker):
                del econtext['size']
            else:
                econtext['size'] = __backup_size_127045739281488
            if (__backup_unit_127045643097552 is __marker):
                del econtext['unit']
            else:
                econtext['unit'] = __backup_unit_127045643097552
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640634896
            __attrs_127045640634896 = _static_127045970670736
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640826704
            __attrs_127045640826704 = _static_127045970670736
            __backup_macroname_127045756944864 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e47cd50> name=None at 738c1e47ccd0> -> __value
            __value = _static_127045640637776
            econtext['macroname'] = __value

            # <Value u'context/widgets/file/macros/edit' (142:28)> -> __macro
            __token = 6468
            try:
                __zt_tmp = __attrs_127045640826704
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'context/widgets/file/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 6468
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756944864 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756944864
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_file_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643455888
            __attrs_127045643455888 = _static_127045970670736
            __backup_showLink_127045739281808 = get('showLink', __marker)

            # <Value u'python:0' (54:64)> -> __value
            __token = 2463
            try:
                __zt_tmp = __attrs_127045643455888
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('python', u'0', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['showLink'] = __value
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641721424
            __attrs_127045641721424 = _static_127045970670736
            __backup_macroname_127045757626720 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c2425dd50> name=None at 738c24399150> -> __value
            __value = _static_127045739076944
            econtext['macroname'] = __value

            # <Value u'context/widgets/file/macros/file_view' (55:30)> -> __macro
            __token = 2504
            try:
                __zt_tmp = __attrs_127045641721424
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'context/widgets/file/macros/file_view', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 2504
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045757626720 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045757626720
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c1e585b50> name=None at 738c1e585c10> -> __attrs_127045642002064
            __attrs_127045642002064 = _static_127045641722704
            __backup_unit_127045643452496 = get('unit', __marker)

            # <Value u'accessor' (57:28)> -> __value
            __token = 2635
            try:
                __zt_tmp = __attrs_127045642002064
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['unit'] = __value
            __backup_size_127045643456272 = get('size', __marker)

            # <Value u'unit/get_size | python:unit and len(unit) or 0' (58:27)> -> __value
            __token = 2672
            try:
                __zt_tmp = __attrs_127045642002064
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'unit/get_size | python:unit and len(unit) or 0', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['size'] = __value

            # <Value u'accessor' (56:26)> -> __condition
            __token = 2572
            try:
                __zt_tmp = __attrs_127045642002064
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_127045886978192('path', u'accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-top:1em;">\n        ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641999440
                __attrs_127045641999440 = _static_127045970670736

                # <Value u'size' (59:40)> -> __condition
                __token = 2763
                try:
                    __zt_tmp = __attrs_127045641999440
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('path', u'size', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n            <!-- these complex buttons have no reson to be here if there is not a file already uploaded -->\n            ')

                    # <Static value=<_ast.Dict object at 0x738c1e5c9410> name=None at 738c1e5c9b10> -> __attrs_127045642092176
                    __attrs_127045642092176 = _static_127045641999376

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="noborder" type="radio" value="nochange"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642091280
                    __default_127045642091280 = _DEFAULT_MARKER

                    # <Boolean u"python:test(size!=0, 'checked', None)" (64:43)> -> __attr_checked
                    __token = 3025
                    try:
                        __zt_tmp = __attrs_127045642092176
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_checked = _static_127045886978192('python', u"test(size!=0, 'checked', None)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if (__attr_checked is _DEFAULT_MARKER):
                        __attr_checked = None
                    else:
                        if __attr_checked:
                            __attr_checked = u'checked'
                        else:
                            __attr_checked = None
                    if (__attr_checked is not None):
                        __append((u' checked="%s"' % __attr_checked))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642089232
                    __default_127045642089232 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_delete' (65:39)> -> __attr_name
                    __token = 3103
                    try:
                        __zt_tmp = __attrs_127045642092176
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_127045886978192('string', u'${fieldName}_delete', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642089936
                    __default_127045642089936 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_nochange' (66:36)> -> __attr_id
                    __token = 3168
                    try:
                        __zt_tmp = __attrs_127045642092176
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('string', u'${fieldName}_nochange', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642091024
                    __default_127045642091024 = _DEFAULT_MARKER

                    # <Substitution u"string:document.getElementById('${fieldName}_file').disabled=true" (67:40)> -> __attr_onclick
                    __token = 3240
                    try:
                        __zt_tmp = __attrs_127045642092176
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_onclick = _static_127045886978192('string', u"document.getElementById('${fieldName}_file').disabled=true", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_onclick is not None):
                        __append((u' onclick="%s"' % __attr_onclick))
                    __append(u'/>\n             ')

                    # <Static value=<_ast.Dict object at 0x738c1e5dfa50> name=None at 738c1e5df410> -> __attrs_127045642092112
                    __attrs_127045642092112 = _static_127045642091088

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642091536
                    __default_127045642091536 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_nochange' (69:40)> -> __attr_for
                    __token = 3380
                    try:
                        __zt_tmp = __attrs_127045642092112
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_127045886978192('string', u'${fieldName}_nochange', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_127045642089424 = []
                    __append_127045642089424 = __stream_127045642089424.append
                    __append_127045642089424(u'\n                    Keep existing file\n             ')
                    __msgid_127045642089424 = __re_whitespace(''.join(__stream_127045642089424)).strip()
                    if u'nochange_file':
                        __append(translate(u'nochange_file', mapping=None, default=__msgid_127045642089424, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n             ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640775824
                    __attrs_127045640775824 = _static_127045970670736

                    # <br ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<br />\n             ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640776208
                    __attrs_127045640776208 = _static_127045970670736

                    # <Value u'python: not field.required' (75:40)> -> __condition
                    __token = 3621
                    try:
                        __zt_tmp = __attrs_127045640776208
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('python', u' not field.required', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x738c1e49e210> name=None at 738c1e49e350> -> __attrs_127045640773776
                        __attrs_127045640773776 = _static_127045640774160

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input class="noborder" type="radio" value="delete"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640777488
                        __default_127045640777488 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_delete' (79:44)> -> __attr_name
                        __token = 3808
                        try:
                            __zt_tmp = __attrs_127045640773776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_127045886978192('string', u'${fieldName}_delete', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640776272
                        __default_127045640776272 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_delete' (80:41)> -> __attr_id
                        __token = 3877
                        try:
                            __zt_tmp = __attrs_127045640773776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('string', u'${fieldName}_delete', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640777296
                        __default_127045640777296 = _DEFAULT_MARKER

                        # <Substitution u"string:document.getElementById('${fieldName}_file').disabled=true" (81:45)> -> __attr_onclick
                        __token = 3951
                        try:
                            __zt_tmp = __attrs_127045640773776
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_onclick = _static_127045886978192('string', u"document.getElementById('${fieldName}_file').disabled=true", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_onclick is not None):
                            __append((u' onclick="%s"' % __attr_onclick))
                        __append(u' />\n                 ')

                        # <Static value=<_ast.Dict object at 0x738c1e65ccd0> name=None at 738c1e65cd90> -> __attrs_127045642602512
                        __attrs_127045642602512 = _static_127045642603728

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642601552
                        __default_127045642601552 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_delete' (84:44)> -> __attr_for
                        __token = 4116
                        try:
                            __zt_tmp = __attrs_127045642602512
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_127045886978192('string', u'${fieldName}_delete', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>')
                        __stream_127045640774416 = []
                        __append_127045640774416 = __stream_127045640774416.append
                        __append_127045640774416(u'\n                        Delete current file\n                 ')
                        __msgid_127045640774416 = __re_whitespace(''.join(__stream_127045640774416)).strip()
                        if u'delete_file':
                            __append(translate(u'delete_file', mapping=None, default=__msgid_127045640774416, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</label>')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642602000
                        __attrs_127045642602000 = _static_127045970670736

                        # <br ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<br />\n             ')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x738c1e49e6d0> name=None at 738c1e49eed0> -> __attrs_127045640571600
                    __attrs_127045640571600 = _static_127045640775376

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="noborder" type="radio" value=""')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642603472
                    __default_127045642603472 = _DEFAULT_MARKER

                    # <Substitution u"string:document.getElementById('${fieldName}_file').disabled=false" (97:42)> -> __attr_onclick
                    __token = 4741
                    try:
                        __zt_tmp = __attrs_127045640571600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_onclick = _static_127045886978192('string', u"document.getElementById('${fieldName}_file').disabled=false", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_onclick = __quote(__attr_onclick, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_onclick is not None):
                        __append((u' onclick="%s"' % __attr_onclick))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642604432
                    __default_127045642604432 = _DEFAULT_MARKER

                    # <Boolean u"python:test(size==0, 'checked', None)" (94:45)> -> __attr_checked
                    __token = 4522
                    try:
                        __zt_tmp = __attrs_127045640571600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_checked = _static_127045886978192('python', u"test(size==0, 'checked', None)", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if (__attr_checked is _DEFAULT_MARKER):
                        __attr_checked = None
                    else:
                        if __attr_checked:
                            __attr_checked = u'checked'
                        else:
                            __attr_checked = None
                    if (__attr_checked is not None):
                        __append((u' checked="%s"' % __attr_checked))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642601360
                    __default_127045642601360 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_delete' (95:41)> -> __attr_name
                    __token = 4602
                    try:
                        __zt_tmp = __attrs_127045640571600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_127045886978192('string', u'${fieldName}_delete', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640570064
                    __default_127045640570064 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_upload' (96:38)> -> __attr_id
                    __token = 4669
                    try:
                        __zt_tmp = __attrs_127045640571600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('string', u'${fieldName}_upload', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'/>\n\n           ')

                    # <Static value=<_ast.Dict object at 0x738c1e46c490> name=None at 738c1e46cd50> -> __attrs_127045640570960
                    __attrs_127045640570960 = _static_127045640570000

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640572176
                    __default_127045640572176 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_upload' (100:38)> -> __attr_for
                    __token = 4878
                    try:
                        __zt_tmp = __attrs_127045640570960
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_127045886978192('string', u'${fieldName}_upload', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_127045640571408 = []
                    __append_127045640571408 = __stream_127045640571408.append
                    __append_127045640571408(u'\n                  Replace with new file:\n           ')
                    __msgid_127045640571408 = __re_whitespace(''.join(__stream_127045640571408)).strip()
                    if u'upload_file':
                        __append(translate(u'upload_file', mapping=None, default=__msgid_127045640571408, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n       ')
                __append(u'\n       ')

                # <Static value=<_ast.Dict object at 0x738c1e5c98d0> name=None at 738c1e5c9610> -> __attrs_127045640569424
                __attrs_127045640569424 = _static_127045642000592

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-left:1.5em;padding-top:0.5em;">\n           ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640571728
                __attrs_127045640571728 = _static_127045970670736
                __backup_macroname_127045760569664 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x738c1e46c6d0> name=None at 738c1e46c690> -> __value
                __value = _static_127045640570576
                econtext['macroname'] = __value

                # <Value u'context/widgets/file/macros/file_upload' (106:35)> -> __macro
                __token = 5140
                try:
                    __zt_tmp = __attrs_127045640571728
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_127045886978192('path', u'context/widgets/file/macros/file_upload', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __token = 5140
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_127045760569664 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_127045760569664
                __append(u'\n       </div>\n      </div>')
            if (__backup_size_127045643456272 is __marker):
                del econtext['size']
            else:
                econtext['size'] = __backup_size_127045643456272
            if (__backup_unit_127045643452496 is __marker):
                del econtext['unit']
            else:
                econtext['unit'] = __backup_unit_127045643452496
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640571472
            __attrs_127045640571472 = _static_127045970670736

            # <Value u'not: accessor' (109:26)> -> __condition
            __token = 5236
            try:
                __zt_tmp = __attrs_127045640571472
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_127045886978192('not', u' accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n        ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640222416
                __attrs_127045640222416 = _static_127045970670736
                __backup_macroname_127045760569824 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x738c1e417050> name=None at 738c1e4170d0> -> __value
                __value = _static_127045640220752
                econtext['macroname'] = __value

                # <Value u'context/widgets/file/macros/file_upload' (110:32)> -> __macro
                __token = 5284
                try:
                    __zt_tmp = __attrs_127045640222416
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_127045886978192('path', u'context/widgets/file/macros/file_upload', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __token = 5284
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_127045760569824 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_127045760569824
                __append(u'\n      </div>')
            __append(u'\n\n    ')
            if (__backup_showLink_127045739281808 is __marker):
                del econtext['showLink']
            else:
                econtext['showLink'] = __backup_showLink_127045739281808
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640635408
            __attrs_127045640635408 = _static_127045970670736
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640636368
            __attrs_127045640636368 = _static_127045970670736
            __backup_macroname_127045756946224 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e47c390> name=None at 738c1e47c310> -> __value
            __value = _static_127045640635280
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640636432
                __attrs_127045640636432 = _static_127045970670736
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640825680
                __attrs_127045640825680 = _static_127045970670736
                __backup_macroname_127045756944464 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x738c1e47c550> name=None at 738c1e47c290> -> __value
                __value = _static_127045640635728
                econtext['macroname'] = __value

                # <Value u'context/widgets/file/macros/file_edit' (136:32)> -> __macro
                __token = 6295
                try:
                    __zt_tmp = __attrs_127045640825680
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_127045886978192('path', u'context/widgets/file/macros/file_edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __token = 6295
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_127045756944464 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_127045756944464
                __append(u'\n        ')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | context/widgets/field/macros/edit' (134:28)> -> __macro
            __token = 6168
            try:
                __zt_tmp = __attrs_127045640636368
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'field_macro | context/widgets/field/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 6168
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756946224 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756946224
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_file_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_widget_label = econtext[u'__slot_widget_label'].pop()
        except:
            __slot_widget_label = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739279376
            __attrs_127045739279376 = _static_127045970670736

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span>\n      ')
            if (__slot_widget_label is None):

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643455952
                __attrs_127045643455952 = _static_127045970670736
            else:
                __slot_widget_label(__stream, econtext.copy(), rcontext)
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643456400
            __attrs_127045643456400 = _static_127045970670736
            __backup_unit_127045643455568 = get('unit', __marker)

            # <Value u'accessor' (15:31)> -> __value
            __token = 427
            try:
                __zt_tmp = __attrs_127045643456400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['unit'] = __value
            __backup_showLink_127045643096592 = get('showLink', __marker)

            # <Value u'showLink|python:1' (16:34)> -> __value
            __token = 471
            try:
                __zt_tmp = __attrs_127045643456400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'showLink|python:1', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['showLink'] = __value
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643454288
            __attrs_127045643454288 = _static_127045970670736
            __backup_size_127045643456464 = get('size', __marker)

            # <Value u'unit/get_size | python:unit and len(unit) or 0' (17:32)> -> __value
            __token = 524
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'unit/get_size | python:unit and len(unit) or 0', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['size'] = __value
            __backup_icon_127045739279056 = get('icon', __marker)

            # <Value u'unit/getBestIcon | nothing' (18:31)> -> __value
            __token = 603
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'unit/getBestIcon | nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['icon'] = __value
            __backup_filename_127045643454800 = get('filename', __marker)

            # <Value u'unit/filename | nothing' (19:34)> -> __value
            __token = 666
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'unit/filename | nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['filename'] = __value
            __backup_toLocalizedSize_127045643454672 = get('toLocalizedSize', __marker)

            # <Value u'nocall:context/@@plone/toLocalizedSize' (20:40)> -> __value
            __token = 733
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('nocall', u'context/@@plone/toLocalizedSize', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['toLocalizedSize'] = __value
            __backup_display_size_127045643454864 = get('display_size', __marker)

            # <Value u'python:toLocalizedSize(size)' (21:15)> -> __value
            __token = 791
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('python', u'toLocalizedSize(size)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['display_size'] = __value
            __backup_display_size_127045643456080 = get('display_size', __marker)

            # <Value u"python: (size > 1000 and '%s (%s bytes)' % (display_size, size)) or display_size" (22:35)> -> __value
            __token = 860
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('python', u" (size > 1000 and '%s (%s bytes)' % (display_size, size)) or display_size", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['display_size'] = __value

            # <Value u'python:size > 0' (23:30)> -> __condition
            __token = 978
            try:
                __zt_tmp = __attrs_127045643454288
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_127045886978192('python', u'size > 0', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            if __condition:
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739076816
                __attrs_127045739076816 = _static_127045970670736
                __backup_doc_type_127045643453968 = get('doc_type', __marker)

                # <Value u'python:context.lookupMime(field.getContentType(here))' (24:38)> -> __value
                __token = 1037
                try:
                    __zt_tmp = __attrs_127045739076816
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'context.lookupMime(field.getContentType(here))', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['doc_type'] = __value
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045740369744
                __attrs_127045740369744 = _static_127045970670736

                # <Value u'showLink' (25:31)> -> __condition
                __token = 1124
                try:
                    __zt_tmp = __attrs_127045740369744
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('path', u'showLink', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x738c242fc3d0> name=None at 738c242fccd0> -> __attrs_127045642586512
                    __attrs_127045642586512 = _static_127045739725776

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642586000
                    __default_127045642586000 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}/at_download/$fieldName' (26:46)> -> __attr_href
                    __token = 1181
                    try:
                        __zt_tmp = __attrs_127045642586512
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_127045886978192('string', u'${context/absolute_url}/at_download/$fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'>\n                ')

                    # <Static value=<_ast.Dict object at 0x738c1e658190> name=None at 738c1e658ad0> -> __attrs_127045642586448
                    __attrs_127045642586448 = _static_127045642584464

                    # <Value u'icon' (27:36)> -> __condition
                    __token = 1273
                    try:
                        __zt_tmp = __attrs_127045642586448
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('path', u'icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642587216
                        __default_127045642587216 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/portal_url}/$icon' (28:41)> -> __attr_src
                        __token = 1334
                        try:
                            __zt_tmp = __attrs_127045642586448
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_127045886978192('string', u'${context/portal_url}/$icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642585488
                        __default_127045642585488 = _DEFAULT_MARKER

                        # <Substitution u'string:${doc_type} icon' (29:40)> -> __attr_alt
                        __token = 1410
                        try:
                            __zt_tmp = __attrs_127045642586448
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_alt = _static_127045886978192('string', u'${doc_type} icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_alt is not None):
                            __append((u' alt="%s"' % __attr_alt))
                        __append(u'/>')
                    __append(u'\n                ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642586704
                    __attrs_127045642586704 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642587088
                    __default_127045642587088 = _DEFAULT_MARKER

                    # <Value u'filename | fieldName' (30:43)> -> __cache_127045642585552
                    __token = 1481
                    try:
                        __zt_tmp = __attrs_127045642586704
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045642585552 = _static_127045886978192('path', u'filename | fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'filename | fieldName' (30:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e658510> -> __condition
                    __expression = __cache_127045642585552

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_127045642585552
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n              </a>\n              ')

                    # <Static value=<_ast.Dict object at 0x738c1e6586d0> name=None at 738c1e658b90> -> __attrs_127045741533840
                    __attrs_127045741533840 = _static_127045642585808

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="discreet">\n                  &mdash;\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642145936
                    __attrs_127045642145936 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642147344
                    __default_127045642147344 = _DEFAULT_MARKER

                    # <Value u'doc_type' (34:37)> -> __cache_127045642147280
                    __token = 1625
                    try:
                        __zt_tmp = __attrs_127045642145936
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045642147280 = _static_127045886978192('path', u'doc_type', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'doc_type' (34:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e5ed350> -> __condition
                    __expression = __cache_127045642147280

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>ContentType</span>')
                    else:
                        __content = __cache_127045642147280
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u',\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642149456
                    __attrs_127045642149456 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642149072
                    __default_127045642149072 = _DEFAULT_MARKER

                    # <Value u'display_size' (35:37)> -> __cache_127045642149392
                    __token = 1710
                    try:
                        __zt_tmp = __attrs_127045642149456
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045642149392 = _static_127045886978192('path', u'display_size', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'display_size' (35:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e5edbd0> -> __condition
                    __expression = __cache_127045642149392

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'?')
                    else:
                        __content = __cache_127045642149392
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n              </span>\n          ')
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642147408
                __attrs_127045642147408 = _static_127045970670736

                # <Value u'not:showLink' (38:31)> -> __condition
                __token = 1812
                try:
                    __zt_tmp = __attrs_127045642147408
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('not', u'showLink', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>\n              ')

                    # <Static value=<_ast.Dict object at 0x738c1e5eded0> name=None at 738c1e5edd10> -> __attrs_127045641719888
                    __attrs_127045641719888 = _static_127045642149584

                    # <Value u'icon' (39:34)> -> __condition
                    __token = 1861
                    try:
                        __zt_tmp = __attrs_127045641719888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('path', u'icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642148432
                        __default_127045642148432 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/portal_url}/$icon' (40:39)> -> __attr_src
                        __token = 1920
                        try:
                            __zt_tmp = __attrs_127045641719888
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_127045886978192('string', u'${context/portal_url}/$icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642147664
                        __default_127045642147664 = _DEFAULT_MARKER

                        # <Substitution u'string:${doc_type} icon' (41:38)> -> __attr_alt
                        __token = 1994
                        try:
                            __zt_tmp = __attrs_127045641719888
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_alt = _static_127045886978192('string', u'${doc_type} icon', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_alt is not None):
                            __append((u' alt="%s"' % __attr_alt))
                        __append(u'/>')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641721168
                    __attrs_127045641721168 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045641723280
                    __default_127045641723280 = _DEFAULT_MARKER

                    # <Value u'filename | fieldName' (42:41)> -> __cache_127045641721872
                    __token = 2063
                    try:
                        __zt_tmp = __attrs_127045641721168
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045641721872 = _static_127045886978192('path', u'filename | fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'filename | fieldName' (42:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e585dd0> -> __condition
                    __expression = __cache_127045641721872

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_127045641721872
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x738c1e5854d0> name=None at 738c1e585690> -> __attrs_127045641722832
                    __attrs_127045641722832 = _static_127045641721040

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="discreet">\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641721744
                    __attrs_127045641721744 = _static_127045970670736

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045641723536
                    __default_127045641723536 = _DEFAULT_MARKER

                    # <Value u'doc_type' (44:37)> -> __cache_127045641722256
                    __token = 2162
                    try:
                        __zt_tmp = __attrs_127045641721744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045641722256 = _static_127045886978192('path', u'doc_type', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'doc_type' (44:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e5855d0> -> __condition
                    __expression = __cache_127045641722256

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'ContentType')
                    else:
                        __content = __cache_127045641722256
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span> &mdash;\n                  ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642001744
                    __attrs_127045642001744 = _static_127045970670736

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642001552
                    __default_127045642001552 = _DEFAULT_MARKER

                    # <Value u'display_size' (45:37)> -> __cache_127045641721232
                    __token = 2254
                    try:
                        __zt_tmp = __attrs_127045642001744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045641721232 = _static_127045886978192('path', u'display_size', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                    # <BinOp left=<Value u'display_size' (45:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e5c91d0> -> __condition
                    __expression = __cache_127045641721232

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'?')
                    else:
                        __content = __cache_127045641721232
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n              </span>\n          </span>')
                __append(u'\n          ')
                if (__backup_doc_type_127045643453968 is __marker):
                    del econtext['doc_type']
                else:
                    econtext['doc_type'] = __backup_doc_type_127045643453968
                __append(u'\n\n        ')
            if (__backup_display_size_127045643456080 is __marker):
                del econtext['display_size']
            else:
                econtext['display_size'] = __backup_display_size_127045643456080
            if (__backup_display_size_127045643454864 is __marker):
                del econtext['display_size']
            else:
                econtext['display_size'] = __backup_display_size_127045643454864
            if (__backup_toLocalizedSize_127045643454672 is __marker):
                del econtext['toLocalizedSize']
            else:
                econtext['toLocalizedSize'] = __backup_toLocalizedSize_127045643454672
            if (__backup_filename_127045643454800 is __marker):
                del econtext['filename']
            else:
                econtext['filename'] = __backup_filename_127045643454800
            if (__backup_icon_127045739279056 is __marker):
                del econtext['icon']
            else:
                econtext['icon'] = __backup_icon_127045739279056
            if (__backup_size_127045643456464 is __marker):
                del econtext['size']
            else:
                econtext['size'] = __backup_size_127045643456464
            __append(u'\n      ')
            if (__backup_showLink_127045643096592 is __marker):
                del econtext['showLink']
            else:
                econtext['showLink'] = __backup_showLink_127045643096592
            if (__backup_unit_127045643455568 is __marker):
                del econtext['unit']
            else:
                econtext['unit'] = __backup_unit_127045643455568
            __append(u'\n    </span>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640224592
            __attrs_127045640224592 = _static_127045970670736
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640636496
            __attrs_127045640636496 = _static_127045970670736
            __backup_macroname_127045760571024 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e47cb50> name=None at 738c1e47c250> -> __value
            __value = _static_127045640637264
            econtext['macroname'] = __value

            # <Value u'context/widgets/file/macros/file_view' (130:28)> -> __macro
            __token = 6038
            try:
                __zt_tmp = __attrs_127045640636496
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'context/widgets/file/macros/file_view', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 6038
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045760571024 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045760571024
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c1e6d5fd0> name=None at 738c1e6d5710> -> __attrs_127045643099088
            __attrs_127045643099088 = _static_127045643100112
            __previous_i18n_domain_127045643098960 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n\n  ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739281296
            __attrs_127045739281296 = _static_127045970670736

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739281936
            __attrs_127045739281936 = _static_127045970670736

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739281616
            __attrs_127045739281616 = _static_127045970670736

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- File Widgets -->\n\n    ')
            __token = None
            render_file_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_file_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n\n    ')
            __token = None
            render_file_upload(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_127045643098960
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_file_upload': render_file_upload, u'render_search': render_search, u'render_file_edit': render_file_edit, u'render_edit': render_edit, u'render_file_view': render_file_view, u'render_view': render_view, 'render': render, }