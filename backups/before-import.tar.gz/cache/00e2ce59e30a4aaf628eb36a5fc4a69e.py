# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.Archetypes-1.16.6-py2.7.egg/Products/Archetypes/skins/archetypes/widgets/integer.pt'

__tokens = {1369: (u'fieldName', 32, 34), 1424: (u'e val', 34, 17), 1448: (u'ze widget/s', 35, 15), 1395: (u' fieldNam', 33, 15), 1485: (u'der widget/placeholder|not', 36, 21), 1535: (u'ngth widget/maxlength|no', 37, 18), 1107: (u'field_macro | context/widgets/field/macros/edit', 25, 34), 1107: (u'field_macro | context/widgets/field/macros/edit', 25, 34), 1689: (u'context/widgets/integer/macros/edit', 43, 28), 1689: (u'context/widgets/integer/macros/edit', 43, 28), 601: (u"python:getKssClasses(fieldName,\n                         templateId='widgets/integer', macro='integer-field-view')", 14, 35), 745: (u' context/UID|nothin', 16, 28), 803: (u'kss_class', 17, 35), 845: (u' string:parent-fieldname-$fieldName-$ui', 18, 31), 964: (u'accessor', 20, 31), 386: (u'context/@@kss_field_decorator_view', 11, 39), 459: (u' nocall:kssClassesView/getKssClassesInlineEditabl', 12, 37)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756866266896 = u'edit'
_static_135757244280656 = __compile_zt_expr
_static_135756866266128 = {u'name': u'', u'placeholder': u'widget/placeholder|nothing', u'value': u'', u'class': u'blurrable firstToFocus', u'maxlength': u'widget/maxlength|nothing', u'type': u'text', u'id': u'fieldName', u'size': u'30', }
_static_135757109777616 = {u'class': u'kss_class', u'id': u'string:parent-fieldname-$fieldName-$uid', }
_static_135756865672528 = u'edit'
_static_135757327983760 = {}
_static_135756866086224 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866087696
            __attrs_135756866087696 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866267088
            __attrs_135756866267088 = _static_135757327983760
            __backup_macroname_135757114940624 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bca2710> name=None at 7b785bca21d0> -> __value
            __value = _static_135756866266896
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b785bca2410> name=None at 7b785bca2d50> -> __attrs_135756865671952
                __attrs_135756865671952 = _static_135756866266128

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input class="blurrable firstToFocus" type="text"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865674320
                __default_135756865674320 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (32:34)> -> __attr_name
                __token = 1369
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865673808
                __default_135756865673808 = _DEFAULT_MARKER

                # <Substitution u'value' (34:17)> -> __attr_value
                __token = 1424
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865674512
                __default_135756865674512 = _DEFAULT_MARKER

                # <Substitution u'widget/size' (35:15)> -> __attr_size
                __token = 1448
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_size = _static_135757244280656('path', u'widget/size', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_size = __quote(__attr_size, '"', '&quot;', u'30', _DEFAULT_MARKER)
                if (__attr_size is not None):
                    __append((u' size="%s"' % __attr_size))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865673744
                __default_135756865673744 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (33:15)> -> __attr_id
                __token = 1395
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865675024
                __default_135756865675024 = _DEFAULT_MARKER

                # <Substitution u'widget/placeholder|nothing' (36:21)> -> __attr_placeholder
                __token = 1485
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_placeholder = _static_135757244280656('path', u'widget/placeholder|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_placeholder = __quote(__attr_placeholder, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_placeholder is not None):
                    __append((u' placeholder="%s"' % __attr_placeholder))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865671376
                __default_135756865671376 = _DEFAULT_MARKER

                # <Substitution u'widget/maxlength|nothing' (37:18)> -> __attr_maxlength
                __token = 1535
                try:
                    __zt_tmp = __attrs_135756865671952
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_maxlength = _static_135757244280656('path', u'widget/maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_maxlength is not None):
                    __append((u' maxlength="%s"' % __attr_maxlength))
                __append(u' />')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | context/widgets/field/macros/edit' (25:34)> -> __macro
            __token = 1107
            try:
                __zt_tmp = __attrs_135756866267088
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'field_macro | context/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 1107
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757114940624 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757114940624
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866268880
            __attrs_135756866268880 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865672656
            __attrs_135756865672656 = _static_135757327983760
            __backup_macroname_135757114938464 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bc11550> name=None at 7b785bc11510> -> __value
            __value = _static_135756865672528
            econtext['macroname'] = __value

            # <Value u'context/widgets/integer/macros/edit' (43:28)> -> __macro
            __token = 1689
            try:
                __zt_tmp = __attrs_135756865672656
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/integer/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 1689
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757114938464 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757114938464
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_integer_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786a4dd4d0> name=None at 7b786a4dd310> -> __attrs_135757109777872
            __attrs_135757109777872 = _static_135757109777616
            __backup_kss_class_135756866018064 = get('kss_class', __marker)

            # <Value u"python:getKssClasses(fieldName,\n                         templateId='widgets/integer', macro='integer-field-view')" (14:35)> -> __value
            __token = 601
            try:
                __zt_tmp = __attrs_135757109777872
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"getKssClasses(fieldName,\n                         templateId='widgets/integer', macro='integer-field-view')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kss_class'] = __value
            __backup_uid_135757072742224 = get('uid', __marker)

            # <Value u'context/UID|nothing' (16:28)> -> __value
            __token = 745
            try:
                __zt_tmp = __attrs_135757109777872
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/UID|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['uid'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109776976
            __default_135757109776976 = _DEFAULT_MARKER

            # <Substitution u'kss_class' (17:35)> -> __attr_class
            __token = 803
            try:
                __zt_tmp = __attrs_135757109777872
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'kss_class', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109779600
            __default_135757109779600 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName-$uid' (18:31)> -> __attr_id
            __token = 845
            try:
                __zt_tmp = __attrs_135757109777872
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('string', u'parent-fieldname-$fieldName-$uid', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n            ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866266512
                __attrs_135756866266512 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866266960
                __default_135756866266960 = _DEFAULT_MARKER

                # <Value u'accessor' (20:31)> -> __cache_135756866268112
                __token = 964
                try:
                    __zt_tmp = __attrs_135756866266512
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135756866268112 = _static_135757244280656('path', u'accessor', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'accessor' (20:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bca2910> -> __condition
                __expression = __cache_135756866268112

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>string</span>')
                else:
                    __content = __cache_135756866268112
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n        </div>')
            if (__backup_uid_135757072742224 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_135757072742224
            if (__backup_kss_class_135756866018064 is __marker):
                del econtext['kss_class']
            else:
                econtext['kss_class'] = __backup_kss_class_135756866018064
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109779024
            __attrs_135757109779024 = _static_135757327983760
            __backup_kssClassesView_135756869379792 = get('kssClassesView', __marker)

            # <Value u'context/@@kss_field_decorator_view' (11:39)> -> __value
            __token = 386
            try:
                __zt_tmp = __attrs_135757109779024
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kssClassesView'] = __value
            __backup_getKssClasses_135757075859344 = get('getKssClasses', __marker)

            # <Value u'nocall:kssClassesView/getKssClassesInlineEditable' (12:37)> -> __value
            __token = 459
            try:
                __zt_tmp = __attrs_135757109779024
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'kssClassesView/getKssClassesInlineEditable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['getKssClasses'] = __value
            __append(u'\n        ')
            __token = None
            render_integer_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
            if (__backup_getKssClasses_135757075859344 is __marker):
                del econtext['getKssClasses']
            else:
                econtext['getKssClasses'] = __backup_getKssClasses_135757075859344
            if (__backup_kssClassesView_135756869379792 is __marker):
                del econtext['kssClassesView']
            else:
                econtext['kssClassesView'] = __backup_kssClassesView_135756869379792
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bc76550> name=None at 7b785bc76ed0> -> __attrs_135757074799120
            __attrs_135757074799120 = _static_135756866086224
            __previous_i18n_domain_135757074797200 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074800080
            __attrs_135757074800080 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074798864
            __attrs_135757074798864 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074797904
            __attrs_135757074797904 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Integer Widgets -->\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_135757074797200
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_integer_field_view': render_integer_field_view, u'render_view': render_view, 'render': render, }