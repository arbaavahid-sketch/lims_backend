# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/tinymce_wysiwyg_support.pt'

__tokens = {1373: (u'inputname', 41, 33), 1414: (u' inputnam', 42, 30), 1328: (u'inputvalue', 40, 25), 1541: (u"python:request.get('text_format', getattr(here,'text_format','structured-text'))", 48, 29), 2076: (u"python:test(text_format=='structured-text', 1, None)", 62, 35), 2410: (u"python:test(text_format=='html', 1, None)", 71, 35), 2703: (u"python:test(text_format=='plain', 1, None)", 80, 35)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402103028624 = {u'for': u'cb_html', }
_static_140402102862800 = {u'for': u'cb_plain', }
_static_140402099284496 = {u'class': u'formHelp', }
_static_140402356200592 = {}
_static_140402100348880 = {u'checked': u"python:test(text_format=='plain', 1, None)", u'name': u'text_format', u'value': u'plain', u'class': u'noborder', u'type': u'radio', u'id': u'cb_plain', }
_static_140402272508048 = __compile_zt_expr
_static_140402099284752 = {u'for': u'text_format', }
_static_140402101392016 = {u'checked': u"python:test(text_format=='structured-text', 1, None)", u'name': u'text_format', u'value': u'structured-text', u'class': u'noborder', u'type': u'radio', u'id': u'cb_structuredtext', }
_static_140402099285520 = {u'class': u'field', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402099470544 = {u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_140402099112400 = {u'id': u'inputname', u'rows': u'25', u'name': u'description', u'class': u'richTextWidget', }
_static_140402100228688 = {u'for': u'cb_structuredtext', }
_static_140402101483856 = {u'checked': u"python:test(text_format=='html', 1, None)", u'name': u'text_format', u'value': u'html', u'class': u'noborder', u'type': u'radio', u'id': u'cb_html', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_wysiwygEditorBox(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402180838544
            __attrs_140402180838544 = _static_140402356200592

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e93e49d0> name=None at 7fb1e93e4890> -> __attrs_140402099284688
            __attrs_140402099284688 = _static_140402099112400

            # <textarea ... (0:0)
            # --------------------------------------------------------
            __append(u'<textarea')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101757968
            __default_140402101757968 = _DEFAULT_MARKER

            # <Substitution u'inputname' (41:33)> -> __attr_name
            __token = 1373
            try:
                __zt_tmp = __attrs_140402099284688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'inputname', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'description', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))
            __append(u' rows="25" class="richTextWidget"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099285392
            __default_140402099285392 = _DEFAULT_MARKER

            # <Substitution u'inputname' (42:30)> -> __attr_id
            __token = 1414
            try:
                __zt_tmp = __attrs_140402099284688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'inputname', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101722640
            __default_140402101722640 = _DEFAULT_MARKER

            # <Value u'inputvalue' (40:25)> -> __cache_140402102065424
            __token = 1328
            try:
                __zt_tmp = __attrs_140402099284688
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402102065424 = _static_140402272508048('path', u'inputvalue', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

            # <BinOp left=<Value u'inputvalue' (40:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9661850> -> __condition
            __expression = __cache_140402102065424

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_140402102065424
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</textarea>\n</div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_textFormatSelector(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e940ee10> name=None at 7fb1e95cf0d0> -> __attrs_140402099285456
            __attrs_140402099285456 = _static_140402099285520
            __backup_text_format_140402098645520 = get('text_format', __marker)

            # <Value u"python:request.get('text_format', getattr(here,'text_format','structured-text'))" (48:29)> -> __value
            __token = 1541
            try:
                __zt_tmp = __attrs_140402099285456
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"request.get('text_format', getattr(here,'text_format','structured-text'))", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['text_format'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="field">\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e940eb10> name=None at 7fb1e940e950> -> __attrs_140402099285200
            __attrs_140402099285200 = _static_140402099284752

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="text_format">')
            __stream_140402099282704 = []
            __append_140402099282704 = __stream_140402099282704.append
            __append_140402099282704(u'Format')
            __msgid_140402099282704 = __re_whitespace(''.join(__stream_140402099282704)).strip()
            if u'label_format':
                __append(translate(u'label_format', mapping=None, default=__msgid_140402099282704, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e940ea10> name=None at 7fb1e940eed0> -> __attrs_140402101394256
            __attrs_140402101394256 = _static_140402099284496

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="formHelp">')
            __stream_140402099284112 = []
            __append_140402099284112 = __stream_140402099284112.append
            __append_140402099284112(u'\n    If you are unsure of which format to use, just select Plain\n    Text and type the document as you usually do.\n    ')
            __msgid_140402099284112 = __re_whitespace(''.join(__stream_140402099284112)).strip()
            if u'help_format_wysiwyg':
                __append(translate(u'help_format_wysiwyg', mapping=None, default=__msgid_140402099284112, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e9611290> name=None at 7fb1e9611050> -> __attrs_140402100228240
            __attrs_140402100228240 = _static_140402101392016

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input class="noborder" type="radio" name="text_format" value="structured-text" id="cb_structuredtext"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100229200
            __default_140402100229200 = _DEFAULT_MARKER

            # <Boolean u"python:test(text_format=='structured-text', 1, None)" (62:35)> -> __attr_checked
            __token = 2076
            try:
                __zt_tmp = __attrs_140402100228240
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_checked = _static_140402272508048('python', u"test(text_format=='structured-text', 1, None)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if (__attr_checked is _DEFAULT_MARKER):
                __attr_checked = None
            else:
                if __attr_checked:
                    __attr_checked = u'checked'
                else:
                    __attr_checked = None
            if (__attr_checked is not None):
                __append((u' checked="%s"' % __attr_checked))
            __append(u' />\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e94f5250> name=None at 7fb1e94f5fd0> -> __attrs_140402102739152
            __attrs_140402102739152 = _static_140402100228688

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="cb_structuredtext">')
            __stream_140402100229520 = []
            __append_140402100229520 = __stream_140402100229520.append
            __append_140402100229520(u'Structured Text')
            __msgid_140402100229520 = __re_whitespace(''.join(__stream_140402100229520)).strip()
            if u'structured_text':
                __append(translate(u'structured_text', mapping=None, default=__msgid_140402100229520, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label> ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101817104
            __attrs_140402101817104 = _static_140402356200592

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e9627950> name=None at 7fb1e9627b90> -> __attrs_140402102710608
            __attrs_140402102710608 = _static_140402101483856

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input class="noborder" type="radio" name="text_format" value="html" id="cb_html"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402181861840
            __default_140402181861840 = _DEFAULT_MARKER

            # <Boolean u"python:test(text_format=='html', 1, None)" (71:35)> -> __attr_checked
            __token = 2410
            try:
                __zt_tmp = __attrs_140402102710608
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_checked = _static_140402272508048('python', u"test(text_format=='html', 1, None)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if (__attr_checked is _DEFAULT_MARKER):
                __attr_checked = None
            else:
                if __attr_checked:
                    __attr_checked = u'checked'
                else:
                    __attr_checked = None
            if (__attr_checked is not None):
                __append((u' checked="%s"' % __attr_checked))
            __append(u' />\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e97a0b90> name=None at 7fb1e97a0dd0> -> __attrs_140402100021072
            __attrs_140402100021072 = _static_140402103028624

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="cb_html">')
            __stream_140402101043984 = []
            __append_140402101043984 = __stream_140402101043984.append
            __append_140402101043984(u'HTML')
            __msgid_140402101043984 = __re_whitespace(''.join(__stream_140402101043984)).strip()
            if u'html':
                __append(translate(u'html', mapping=None, default=__msgid_140402101043984, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label> ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100348752
            __attrs_140402100348752 = _static_140402356200592

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e95127d0> name=None at 7fb1e9512190> -> __attrs_140402163254928
            __attrs_140402163254928 = _static_140402100348880

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input class="noborder" type="radio" name="text_format" value="plain" id="cb_plain"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402103245136
            __default_140402103245136 = _DEFAULT_MARKER

            # <Boolean u"python:test(text_format=='plain', 1, None)" (80:35)> -> __attr_checked
            __token = 2703
            try:
                __zt_tmp = __attrs_140402163254928
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_checked = _static_140402272508048('python', u"test(text_format=='plain', 1, None)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if (__attr_checked is _DEFAULT_MARKER):
                __attr_checked = None
            else:
                if __attr_checked:
                    __attr_checked = u'checked'
                else:
                    __attr_checked = None
            if (__attr_checked is not None):
                __append((u' checked="%s"' % __attr_checked))
            __append(u' />\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e97783d0> name=None at 7fb1e9778110> -> __attrs_140402101411600
            __attrs_140402101411600 = _static_140402102862800

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="cb_plain">')
            __stream_140402102862736 = []
            __append_140402102862736 = __stream_140402102862736.append
            __append_140402102862736(u'Plain Text')
            __msgid_140402102862736 = __re_whitespace(''.join(__stream_140402102862736)).strip()
            if u'plain_text':
                __append(translate(u'plain_text', mapping=None, default=__msgid_140402102862736, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n\n</div>')
            if (__backup_text_format_140402098645520 is __marker):
                del econtext['text_format']
            else:
                econtext['text_format'] = __backup_text_format_140402098645520
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!-- SENAITE TinyMCE editor support\n\n     - Customized class to richTextWidget for tinyMCE initialization\n       see senaite.core.js in webpack/app folder\n\n     - NOTE: This macro is used by plone.app.textfield.widget_input.pt\n\n\n      IMPORTANT:\n\n      This template is **only** rendered for RichTextFieldWidgets coming from `plone.app.textfield.widget`, e.g:\n\n          from plone.app.textfield.widget import RichTextFieldWidget\n\n          class IInterpretationTemplateSchema(model.Schema):\n              directives.widget("foo", RichTextFieldWidget)\n              foo = RichTextField(\n                  title=_(u\'Text\'),\n                  description=u\'\',\n                  required=False,\n              )\n\n     This means it is **not** rendered if the IRichTextBehavior is used!\n\n     In this case, the widget HTML is generated dynamically by this code (mpte the self.el):\n\n     plone.app.widgets.base.BaseWidget\n\n-->\n')

            # <Static value=<_ast.Dict object at 0x7fb1e943c0d0> name=None at 7fb1e943c5d0> -> __attrs_140402099473488
            __attrs_140402099473488 = _static_140402099470544
            __previous_i18n_domain_140402101530128 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">\n\n')
            __token = None
            render_wysiwygEditorBox(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n\n')
            __token = None
            render_textFormatSelector(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n\n</html>')
            __i18n_domain = __previous_i18n_domain_140402101530128
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_wysiwygEditorBox': render_wysiwygEditorBox, u'render_textFormatSelector': render_textFormatSelector, 'render': render, }