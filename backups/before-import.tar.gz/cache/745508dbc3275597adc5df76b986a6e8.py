# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFEditions-3.3.5-py2.7.egg/Products/CMFEditions/browser/edit.pt'

__tokens = {176: (u'nocall:here/portal_repository|nothing', 4, 27), 252: (u' python:pr is not None and pr.isVersionable(context) or Non', 5, 37), 356: (u"n python:pr is not None and pr.supportsPolicy(context, 'at_edit_autoversion') or No", 6, 42), 506: (u'python:isVersionable and not supportsAutoVersion', 8, 27), 1646: (u'python: isVersionable and not supportsAutoVersion', 41, 24), 2341: (u'python: isVersionable', 59, 24), 2890: (u'request/form/cmfeditions_version_comment | nothing', 73, 37)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757075218896 = {u'class': u'field editionComment', u'id': u'cmfeditions_version_comment_block', }
_static_135757074837200 = {u'for': u'cmfeditions_save_new_version', }
_static_135757149929680 = {u'class': u'field editionSaveVersion', }
_static_135757074833488 = {u'type': u'checkbox', u'name': u'cmfeditions_save_new_version', u'id': u'cmfeditions_save_new_version', }
_static_135756869622608 = {u'type': u'text/javascript', }
_static_135757244280656 = __compile_zt_expr
_static_135757075219728 = {u'for': u'cmfeditions_version_comment', }
_static_135757075846736 = {u'class': u'formHelp', u'id': u'cmfeditions_version_comment_help', }
_static_135757075846032 = {u'size': u'40', u'type': u'text', u'name': u'cmfeditions_version_comment', u'value': u'request/form/cmfeditions_version_comment | nothing', u'id': u'cmfeditions_version_comment', }
_static_135757075408528 = {u'class': u'formHelp', u'id': u'cmfeditions_save_new_version_help', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869620112
            __attrs_135756869620112 = _static_135757327983760
            __backup_pr_135757109778832 = get('pr', __marker)

            # <Value u'nocall:here/portal_repository|nothing' (4:27)> -> __value
            __token = 176
            try:
                __zt_tmp = __attrs_135756869620112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'here/portal_repository|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['pr'] = __value
            __backup_isVersionable_135757151775824 = get('isVersionable', __marker)

            # <Value u'python:pr is not None and pr.isVersionable(context) or None' (5:37)> -> __value
            __token = 252
            try:
                __zt_tmp = __attrs_135756869620112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'pr is not None and pr.isVersionable(context) or None', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isVersionable'] = __value
            __backup_supportsAutoVersion_135757072801360 = get('supportsAutoVersion', __marker)

            # <Value u"python:pr is not None and pr.supportsPolicy(context, 'at_edit_autoversion') or None" (6:42)> -> __value
            __token = 356
            try:
                __zt_tmp = __attrs_135756869620112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"pr is not None and pr.supportsPolicy(context, 'at_edit_autoversion') or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['supportsAutoVersion'] = __value
            __previous_i18n_domain_135756869623120 = __i18n_domain
            __i18n_domain = u'plone'
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7b785bfd5b50> name=None at 7b785bfd5850> -> __attrs_135756869623632
            __attrs_135756869623632 = _static_135756869622608

            # <Value u'python:isVersionable and not supportsAutoVersion' (8:27)> -> __condition
            __token = 506
            try:
                __zt_tmp = __attrs_135756869623632
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u'isVersionable and not supportsAutoVersion', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript">\n    <!--\n    function switchComment(ev) {\n        var save_version = document.getElementById(\'cmfeditions_save_new_version\');\n        var comment = document.getElementById(\'cmfeditions_version_comment_block\');\n        if (save_version && comment) {\n            if (save_version.checked) {\n                comment.style.display = \'block\';\n            } else {\n                comment.style.display = \'none\';\n            }\n        }\n    }\n\n    function setupSaveNewVersion(ev) {\n        var save_version = document.getElementById(\'cmfeditions_save_new_version\');\n        var comment = document.getElementById(\'cmfeditions_version_comment_block\');\n\n        if (save_version && comment) {\n            if (save_version.checked) {\n                comment.style.display = \'block\';\n            } else {\n                comment.style.display = \'none\';\n            }\n        }\n        jQuery(save_version).bind("click", switchComment);\n    }\n    jQuery(setupSaveNewVersion);\n    -->\n    </script>')
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cb280d0> name=None at 7b786cb28f90> -> __attrs_135757149931920
            __attrs_135757149931920 = _static_135757149929680

            # <Value u'python: isVersionable and not supportsAutoVersion' (41:24)> -> __condition
            __token = 1646
            try:
                __zt_tmp = __attrs_135757149931920
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u' isVersionable and not supportsAutoVersion', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757074836176 = __i18n_domain
                __i18n_domain = u'cmfeditions'

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="field editionSaveVersion">\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b786838a050> name=None at 7b786838aa50> -> __attrs_135757074834384
                __attrs_135757074834384 = _static_135757074833488

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="checkbox" name="cmfeditions_save_new_version" id="cmfeditions_save_new_version" />\n        ')

                # <Static value=<_ast.Dict object at 0x7b786838aed0> name=None at 7b786838a4d0> -> __attrs_135757075408208
                __attrs_135757075408208 = _static_135757074837200

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label for="cmfeditions_save_new_version">')
                __stream_135757074834448 = []
                __append_135757074834448 = __stream_135757074834448.append
                __append_135757074834448(u'Save as new version')
                __msgid_135757074834448 = __re_whitespace(''.join(__stream_135757074834448)).strip()
                if u'label_save_new_version':
                    __append(translate(u'label_save_new_version', mapping=None, default=__msgid_135757074834448, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n\n         ')

                # <Static value=<_ast.Dict object at 0x7b7868416690> name=None at 7b7868416150> -> __attrs_135757075221136
                __attrs_135757075221136 = _static_135757075408528

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="formHelp" id="cmfeditions_save_new_version_help">')
                __stream_135757075407888 = []
                __append_135757075407888 = __stream_135757075407888.append
                __append_135757075407888(u'\n              Select to make a version of the current content.\n         ')
                __msgid_135757075407888 = __re_whitespace(''.join(__stream_135757075407888)).strip()
                if u'help_save_new_version':
                    __append(translate(u'help_save_new_version', mapping=None, default=__msgid_135757075407888, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</div>\n    </div>')
                __i18n_domain = __previous_i18n_domain_135757074836176
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78683e81d0> name=None at 7b786838a810> -> __attrs_135757075220560
            __attrs_135757075220560 = _static_135757075218896

            # <Value u'python: isVersionable' (59:24)> -> __condition
            __token = 2341
            try:
                __zt_tmp = __attrs_135757075220560
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u' isVersionable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757075220432 = __i18n_domain
                __i18n_domain = u'cmfeditions'

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="field editionComment" id="cmfeditions_version_comment_block">\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78683e8510> name=None at 7b78683e8950> -> __attrs_135757075848272
                __attrs_135757075848272 = _static_135757075219728

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label for="cmfeditions_version_comment">')
                __stream_135757075221200 = []
                __append_135757075221200 = __stream_135757075221200.append
                __append_135757075221200(u'Change note')
                __msgid_135757075221200 = __re_whitespace(''.join(__stream_135757075221200)).strip()
                if u'label_version_comment':
                    __append(translate(u'label_version_comment', mapping=None, default=__msgid_135757075221200, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n        ')

                # <Static value=<_ast.Dict object at 0x7b7868481650> name=None at 7b7868481d10> -> __attrs_135757075846608
                __attrs_135757075846608 = _static_135757075846736

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="formHelp" id="cmfeditions_version_comment_help">')
                __stream_135757075848400 = []
                __append_135757075848400 = __stream_135757075848400.append
                __append_135757075848400(u'\n            Enter a comment that describes the changes you made.\n        ')
                __msgid_135757075848400 = __re_whitespace(''.join(__stream_135757075848400)).strip()
                if u'help_version_comment':
                    __append(translate(u'help_version_comment', mapping=None, default=__msgid_135757075848400, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</div>\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b7868481390> name=None at 7b7868481810> -> __attrs_135757071596560
                __attrs_135757071596560 = _static_135757075846032

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="text" name="cmfeditions_version_comment" id="cmfeditions_version_comment" size="40"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071595344
                __default_135757071595344 = _DEFAULT_MARKER

                # <Substitution u'request/form/cmfeditions_version_comment | nothing' (73:37)> -> __attr_value
                __token = 2890
                try:
                    __zt_tmp = __attrs_135757071596560
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_135757244280656('path', u'request/form/cmfeditions_version_comment | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\n    </div>')
                __i18n_domain = __previous_i18n_domain_135757075220432
            __append(u'\n')
            __i18n_domain = __previous_i18n_domain_135756869623120
            if (__backup_supportsAutoVersion_135757072801360 is __marker):
                del econtext['supportsAutoVersion']
            else:
                econtext['supportsAutoVersion'] = __backup_supportsAutoVersion_135757072801360
            if (__backup_isVersionable_135757151775824 is __marker):
                del econtext['isVersionable']
            else:
                econtext['isVersionable'] = __backup_isVersionable_135757151775824
            if (__backup_pr_135757109778832 is __marker):
                del econtext['pr']
            else:
                econtext['pr'] = __backup_pr_135757109778832
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }