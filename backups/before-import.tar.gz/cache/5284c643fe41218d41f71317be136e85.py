# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/contentmenu/templates/contentmenu.pt'

__tokens = {70: (u'view/menu', 3, 15), 38: (u'view/available', 2, 13), 146: (u'menu', 6, 30), 404: (u"python:menuItem.get('action', '').endswith(\r\n                            'content_status_history')", 12, 23), 603: (u'menuItem/extra/id', 16, 15), 643: (u' context/UI', 17, 20), 685: (u"e python:view.translate_workflow_msg(\r\n                menuItem['extra'].get('stateTitle', ''", 18, 27), 809: (u'ss menuItem/extra/class | noth', 20, 26), 868: (u'url string:${context/absolute_url}/@@workflow_menu_', 21, 23), 1137: (u'string:${menuItem/extra/class} tb-state', 25, 36), 1206: (u'menuItem/extra/stateTitle', 26, 27), 1621: (u'menuItem/submenu', 36, 28), 1672: (u' not:menuItem/extra/hideChildren | not:submenu | nothin', 37, 32), 1760: (u'r menuItem/extra/', 38, 29), 1325: (u"python:not menuItem.get('action', '').endswith(\r\n                            'content_status_history')", 31, 23), 1532: (u" python:has_dropdown and 'nav-item dropdown' or 'nav-item", 35, 29), 1483: (u'menuItem/extra/id', 34, 27), 2123: (u'menuItem/action', 46, 32), 2173: (u' menuItem/extra/class | nothin', 47, 32), 2238: (u's python:state_class and state_class or ', 48, 31), 1887: (u'not:has_dropdown', 42, 24), 2306: (u'not:has_action', 49, 23), 1936: (u'string:#${menuItem/extra/id}', 43, 30), 1997: (u' menuItem/descriptio', 44, 30), 2050: (u's string:label-${state_class} nav-li', 45, 29), 2399: (u'string:${menuItem/extra/class} tb-state', 52, 32), 2559: (u'menuItem/extra/stateTitle | nothing', 54, 25), 2473: (u"python:has_action and css_class or css_class + ' nav-link'", 53, 32), 2620: (u'menuItem/extra/stateTitle', 55, 23), 2827: (u'not:menuItem/extra/hideChildren | not:submenu | nothing', 63, 26), 3150: (u'not:menuItem/extra/stateTitle | nothing', 69, 29), 3219: (u'menuItem/title', 70, 27), 3501: (u'menuItem/extra/stateTitle | nothing', 78, 29), 3430: (u'string:${menuItem/extra/class} tb-state', 77, 36), 3566: (u'menuItem/extra/stateTitle', 79, 27), 3871: (u'submenu', 86, 41), 3739: (u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', 85, 39), 4302: (u'subMenuItem/action', 94, 45), 4018: (u'subMenuItem/action', 90, 35), 4074: (u' subMenuItem/descriptio', 91, 35), 4132: (u'd subMenuItem/extra/id | nothi', 92, 31), 4200: (u'ss string:${subMenuItem/extra/class|nothing} nav-l', 93, 33), 4385: (u'subMenuItem/title', 96, 35), 4696: (u'not:subMenuItem/action', 104, 29), 4562: (u'subMenuItem/extra/id | nothing', 102, 33), 4630: (u' subMenuItem/extra/class | nothin', 103, 35), 4817: (u'subMenuItem/title', 107, 39)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133838686049488 = {u'class': u'nav-item', u'id': u'menuItem/extra/id', }
_static_133838698893968 = {u'class': u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', }
_static_133838698893584 = {u'class': u'dropdown-menu', }
_static_133838686050768 = {u'class': u'dropdown-menu', }
_static_133838685974736 = {u'class': u'nav-item dropdown', u'aria-hidden': u'true', }
_static_133838686154256 = {u'id': u'subMenuItem/extra/id | nothing', u'class': u'subMenuItem/extra/class | nothing', }
_static_133838698729872 = {u'href': u'#', u'class': u'string:label-${state_class} nav-link', u'title': u'menuItem/description', }
_static_133838698706128 = {u'id': u'menuItem/extra/id', u'data-state-class': u'menuItem/extra/class | nothing', u'data-state-title': u"python:view.translate_workflow_msg(\r\n                menuItem['extra'].get('stateTitle', ''))", u'data-fetch-url': u'string:${context/absolute_url}/@@workflow_menu_data', u'data-uid': u'context/UID', u'class': u'nav-item dropdown senaite-workflow-menu', }
_static_133838698741904 = {u'class': u'', }
_static_133838681239504 = {u'aria-haspopup': u'true', u'aria-expanded': u'false', u'id': u'navbarDropdown', u'href': u'#', u'role': u'button', u'data-toggle': u'dropdown', u'class': u'nav-link dropdown-toggle', }
_static_133838685978384 = {u'class': u"python:has_action and css_class or css_class + ' nav-link'", }
_static_133838698744848 = {u'class': u'', }
_static_133838700749712 = {u'href': u'#', u'role': u'button', u'class': u'nav-link dropdown-toggle workflow-menu-toggle', u'aria-expanded': u'false', u'aria-haspopup': u'true', }
_static_133838794967184 = __compile_zt_expr
_static_133838686049296 = {u'class': u'string:${menuItem/extra/class} tb-state', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838686044368 = {u'class': u'string:${subMenuItem/extra/class|nothing} nav-link', u'href': u'#', u'id': u'subMenuItem/extra/id | nothing', u'aria-expanded': u'false', u'title': u'subMenuItem/description', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698708752
            __attrs_133838698708752 = _static_133838878659728
            __backup_menu_133838698696848 = get('menu', __marker)

            # <Value u'view/menu' (3:15)> -> __value
            __token = 70
            try:
                __zt_tmp = __attrs_133838698708752
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'view/menu', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['menu'] = __value

            # <Value u'view/available' (2:13)> -> __condition
            __token = 38
            try:
                __zt_tmp = __attrs_133838698708752
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'view/available', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_133838698705168 = __i18n_domain
                __i18n_domain = u'senaite.core'
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698707792
                __attrs_133838698707792 = _static_133838878659728
                __backup_menuItem_133838698893392 = get('menuItem', __marker)

                # <Value u'menu' (6:30)> -> __iterator
                __token = 146
                try:
                    __zt_tmp = __attrs_133838698707792
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'menu', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838698705872, ) = getitem('repeat')(u'menuItem', __iterator)
                econtext['menuItem'] = None
                for __item in __iterator:
                    econtext['menuItem'] = __item
                    __append(u'\r\n\r\n    <!-- Workflow menu: React mount point. The current state pill is\r\n         rendered server-side so the menu is visible immediately;\r\n         transitions are fetched on first open via\r\n         @@workflow_menu_data. -->\r\n    ')

                    # <Static value=<_ast.Dict object at 0x79b9c017f4d0> name=None at 79b9c017f710> -> __attrs_133838700749904
                    __attrs_133838700749904 = _static_133838698706128

                    # <Value u"python:menuItem.get('action', '').endswith(\r\n                            'content_status_history')" (12:23)> -> __condition
                    __token = 404
                    try:
                        __zt_tmp = __attrs_133838700749904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"menuItem.get('action', '').endswith(\r\n                            'content_status_history')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li         class="nav-item dropdown senaite-workflow-menu"')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698705104
                        __default_133838698705104 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/id' (16:15)> -> __attr_id
                        __token = 603
                        try:
                            __zt_tmp = __attrs_133838700749904
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_133838794967184('path', u'menuItem/extra/id', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700752464
                        __default_133838700752464 = _DEFAULT_MARKER

                        # <Substitution u'context/UID' (17:20)> -> __attr_data_uid
                        __token = 643
                        try:
                            __zt_tmp = __attrs_133838700749904
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_uid = _static_133838794967184('path', u'context/UID', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_data_uid = __quote(__attr_data_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_uid is not None):
                            __append((u' data-uid="%s"' % __attr_data_uid))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700750736
                        __default_133838700750736 = _DEFAULT_MARKER

                        # <Substitution u"python:view.translate_workflow_msg(\r\n                menuItem['extra'].get('stateTitle', ''))" (18:27)> -> __attr_data_state_title
                        __token = 685
                        try:
                            __zt_tmp = __attrs_133838700749904
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_state_title = _static_133838794967184('python', u"view.translate_workflow_msg(\r\n                menuItem['extra'].get('stateTitle', ''))", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_data_state_title = __quote(__attr_data_state_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_state_title is not None):
                            __append((u' data-state-title="%s"' % __attr_data_state_title))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700749200
                        __default_133838700749200 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/class | nothing' (20:26)> -> __attr_data_state_class
                        __token = 809
                        try:
                            __zt_tmp = __attrs_133838700749904
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_state_class = _static_133838794967184('path', u'menuItem/extra/class | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_data_state_class = __quote(__attr_data_state_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_state_class is not None):
                            __append((u' data-state-class="%s"' % __attr_data_state_class))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700751952
                        __default_133838700751952 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/@@workflow_menu_data' (21:23)> -> __attr_data_fetch_url
                        __token = 868
                        try:
                            __zt_tmp = __attrs_133838700749904
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_fetch_url = _static_133838794967184('string', u'${context/absolute_url}/@@workflow_menu_data', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_data_fetch_url = __quote(__attr_data_fetch_url, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_fetch_url is not None):
                            __append((u' data-fetch-url="%s"' % __attr_data_fetch_url))
                        __append(u'>\r\n      ')

                        # <Static value=<_ast.Dict object at 0x79b9c0372390> name=None at 79b9c0372d90> -> __attrs_133838686049168
                        __attrs_133838686049168 = _static_133838700749712

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a class="nav-link dropdown-toggle workflow-menu-toggle" href="#"          role="button" aria-haspopup="true" aria-expanded="false">\r\n        ')

                        # <Static value=<_ast.Dict object at 0x79b9bf56d410> name=None at 79b9bf56dd50> -> __attrs_133838686050832
                        __attrs_133838686050832 = _static_133838686049296

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686049616
                        __default_133838686049616 = _DEFAULT_MARKER

                        # <Substitution u'string:${menuItem/extra/class} tb-state' (25:36)> -> __attr_class
                        __token = 1137
                        try:
                            __zt_tmp = __attrs_133838686050832
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_133838794967184('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686051472
                        __default_133838686051472 = _DEFAULT_MARKER

                        # <Value u'menuItem/extra/stateTitle' (26:27)> -> __cache_133838686050192
                        __token = 1206
                        try:
                            __zt_tmp = __attrs_133838686050832
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838686050192 = _static_133838794967184('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'menuItem/extra/stateTitle' (26:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf56d910> -> __condition
                        __expression = __cache_133838686050192

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133838686050192
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n      </a>\r\n      ')

                        # <Static value=<_ast.Dict object at 0x79b9bf56d9d0> name=None at 79b9bf56de90> -> __attrs_133838686051792
                        __attrs_133838686051792 = _static_133838686050768

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="dropdown-menu"></div>\r\n    </li>')
                    __append(u'\r\n\r\n    ')

                    # <Static value=<_ast.Dict object at 0x79b9bf56d4d0> name=None at 79b9bf56d650> -> __attrs_133838716894928
                    __attrs_133838716894928 = _static_133838686049488
                    __backup_submenu_133838685910864 = get('submenu', __marker)

                    # <Value u'menuItem/submenu' (36:28)> -> __value
                    __token = 1621
                    try:
                        __zt_tmp = __attrs_133838716894928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'menuItem/submenu', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['submenu'] = __value
                    __backup_has_dropdown_133838681237136 = get('has_dropdown', __marker)

                    # <Value u'not:menuItem/extra/hideChildren | not:submenu | nothing' (37:32)> -> __value
                    __token = 1672
                    try:
                        __zt_tmp = __attrs_133838716894928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('not', u'menuItem/extra/hideChildren | not:submenu | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['has_dropdown'] = __value
                    __backup_identifier_133838716838416 = get('identifier', __marker)

                    # <Value u'menuItem/extra/id' (38:29)> -> __value
                    __token = 1760
                    try:
                        __zt_tmp = __attrs_133838716894928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'menuItem/extra/id', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['identifier'] = __value

                    # <Value u"python:not menuItem.get('action', '').endswith(\r\n                            'content_status_history')" (31:23)> -> __condition
                    __token = 1325
                    try:
                        __zt_tmp = __attrs_133838716894928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u"not menuItem.get('action', '').endswith(\r\n                            'content_status_history')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716895056
                        __default_133838716895056 = _DEFAULT_MARKER

                        # <Substitution u"python:has_dropdown and 'nav-item dropdown' or 'nav-item'" (35:29)> -> __attr_class
                        __token = 1532
                        try:
                            __zt_tmp = __attrs_133838716894928
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_133838794967184('python', u"has_dropdown and 'nav-item dropdown' or 'nav-item'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-item', _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u'         class="%s"' % __attr_class))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716891920
                        __default_133838716891920 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/id' (34:27)> -> __attr_id
                        __token = 1483
                        try:
                            __zt_tmp = __attrs_133838716894928
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_133838794967184('path', u'menuItem/extra/id', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>\r\n      <!-- Menu Item -->\r\n      ')

                        # <Static value=<_ast.Dict object at 0x79b9c0185190> name=None at 79b9c0185250> -> __attrs_133838698729808
                        __attrs_133838698729808 = _static_133838698729872
                        __backup_has_action_133838698897360 = get('has_action', __marker)

                        # <Value u'menuItem/action' (46:32)> -> __value
                        __token = 2123
                        try:
                            __zt_tmp = __attrs_133838698729808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_133838794967184('path', u'menuItem/action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        econtext['has_action'] = __value
                        __backup_state_class_133838705509776 = get('state_class', __marker)

                        # <Value u'menuItem/extra/class | nothing' (47:32)> -> __value
                        __token = 2173
                        try:
                            __zt_tmp = __attrs_133838698729808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_133838794967184('path', u'menuItem/extra/class | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        econtext['state_class'] = __value
                        __backup_state_class_133838716839888 = get('state_class', __marker)

                        # <Value u"python:state_class and state_class or ''" (48:31)> -> __value
                        __token = 2238
                        try:
                            __zt_tmp = __attrs_133838698729808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_133838794967184('python', u"state_class and state_class or ''", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        econtext['state_class'] = __value

                        # <Value u'not:has_dropdown' (42:24)> -> __condition
                        __token = 1887
                        try:
                            __zt_tmp = __attrs_133838698729808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_133838794967184('not', u'has_dropdown', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        if __condition:

                            # <Negate value=<Value u'not:has_action' (49:23)> at 79b9c0185690> -> __cache_133838698731152

                            # <Value u'not:has_action' (49:23)> -> __cache_133838698731152
                            __token = 2306
                            try:
                                __zt_tmp = __attrs_133838698729808
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_133838698731152 = _static_133838794967184('not', u'has_action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            __cache_133838698731152 = not __cache_133838698731152
                            __condition = __cache_133838698731152
                            if __condition:

                                # <a ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<a')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698730384
                                __default_133838698730384 = _DEFAULT_MARKER

                                # <Substitution u'string:#${menuItem/extra/id}' (43:30)> -> __attr_href
                                __token = 1936
                                try:
                                    __zt_tmp = __attrs_133838698729808
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_href = _static_133838794967184('string', u'#${menuItem/extra/id}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_href is not None):
                                    __append((u' href="%s"' % __attr_href))

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698731536
                                __default_133838698731536 = _DEFAULT_MARKER

                                # <Translate msgid=None node=<Substitution u'menuItem/description' (44:30)> at 79b9c0185cd0> -> __attr_title

                                # <Substitution u'menuItem/description' (44:30)> -> __attr_title
                                __token = 1997
                                try:
                                    __zt_tmp = __attrs_133838698729808
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_133838794967184('path', u'menuItem/description', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698731472
                                __default_133838698731472 = _DEFAULT_MARKER

                                # <Substitution u'string:label-${state_class} nav-link' (45:29)> -> __attr_class
                                __token = 2050
                                try:
                                    __zt_tmp = __attrs_133838698729808
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_133838794967184('string', u'label-${state_class} nav-link', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')
                            __append(u'\r\n        ')

                            # <Static value=<_ast.Dict object at 0x79b9bf55bf10> name=None at 79b9bf55b150> -> __attrs_133838685978256
                            __attrs_133838685978256 = _static_133838685978384
                            __backup_css_class_133838681231632 = get('css_class', __marker)

                            # <Value u'string:${menuItem/extra/class} tb-state' (52:32)> -> __value
                            __token = 2399
                            try:
                                __zt_tmp = __attrs_133838685978256
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_133838794967184('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            econtext['css_class'] = __value

                            # <Value u'menuItem/extra/stateTitle | nothing' (54:25)> -> __condition
                            __token = 2559
                            try:
                                __zt_tmp = __attrs_133838685978256
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_133838794967184('path', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838685978576
                                __default_133838685978576 = _DEFAULT_MARKER

                                # <Substitution u"python:has_action and css_class or css_class + ' nav-link'" (53:32)> -> __attr_class
                                __token = 2473
                                try:
                                    __zt_tmp = __attrs_133838685978256
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_133838794967184('python', u"has_action and css_class or css_class + ' nav-link'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698688336
                                __default_133838698688336 = _DEFAULT_MARKER

                                # <Value u'menuItem/extra/stateTitle' (55:23)> -> __cache_133838698730576
                                __token = 2620
                                try:
                                    __zt_tmp = __attrs_133838685978256
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_133838698730576 = _static_133838794967184('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/extra/stateTitle' (55:23)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c017af90> -> __condition
                                __expression = __cache_133838698730576

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\r\n          State title\r\n        ')
                                else:
                                    __content = __cache_133838698730576
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            if (__backup_css_class_133838681231632 is __marker):
                                del econtext['css_class']
                            else:
                                econtext['css_class'] = __backup_css_class_133838681231632
                            __append(u'\r\n      ')
                            __condition = __cache_133838698731152
                            if __condition:
                                __append(u'</a>')
                        if (__backup_state_class_133838716839888 is __marker):
                            del econtext['state_class']
                        else:
                            econtext['state_class'] = __backup_state_class_133838716839888
                        if (__backup_state_class_133838705509776 is __marker):
                            del econtext['state_class']
                        else:
                            econtext['state_class'] = __backup_state_class_133838705509776
                        if (__backup_has_action_133838698897360 is __marker):
                            del econtext['has_action']
                        else:
                            econtext['has_action'] = __backup_has_action_133838698897360
                        __append(u'\r\n\r\n      <!-- dropdown menu -->\r\n      ')

                        # <Static value=<_ast.Dict object at 0x79b9bf55b0d0> name=None at 79b9bf55b090> -> __attrs_133838685974992
                        __attrs_133838685974992 = _static_133838685974736

                        # <Value u'not:menuItem/extra/hideChildren | not:submenu | nothing' (63:26)> -> __condition
                        __token = 2827
                        try:
                            __zt_tmp = __attrs_133838685974992
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_133838794967184('not', u'menuItem/extra/hideChildren | not:submenu | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="nav-item dropdown"            aria-hidden="true">\r\n\r\n          ')

                            # <Static value=<_ast.Dict object at 0x79b9bf0d6fd0> name=None at 79b9bf0d6cd0> -> __attrs_133838681238224
                            __attrs_133838681238224 = _static_133838681239504

                            # <a ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\r\n            ')

                            # <Static value=<_ast.Dict object at 0x79b9c0188c10> name=None at 79b9c0188d90> -> __attrs_133838698744592
                            __attrs_133838698744592 = _static_133838698744848

                            # <Value u'not:menuItem/extra/stateTitle | nothing' (69:29)> -> __condition
                            __token = 3150
                            try:
                                __zt_tmp = __attrs_133838698744592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_133838794967184('not', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span               class="">')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698742800
                                __default_133838698742800 = _DEFAULT_MARKER

                                # <Value u'menuItem/title' (70:27)> -> __cache_133838698742352
                                __token = 3219
                                try:
                                    __zt_tmp = __attrs_133838698744592
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_133838698742352 = _static_133838794967184('path', u'menuItem/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/title' (70:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0188bd0> -> __condition
                                __expression = __cache_133838698742352

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\r\n              Menu Title\r\n            ')
                                else:
                                    __content = __cache_133838698742352
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>')
                            __append(u'\r\n            <!-- State Title -->\r\n            ')

                            # <Static value=<_ast.Dict object at 0x79b9c0188090> name=None at 79b9c0188c50> -> __attrs_133838698896080
                            __attrs_133838698896080 = _static_133838698741904

                            # <Value u'menuItem/extra/stateTitle | nothing' (78:29)> -> __condition
                            __token = 3501
                            try:
                                __zt_tmp = __attrs_133838698896080
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_133838794967184('path', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698895312
                                __default_133838698895312 = _DEFAULT_MARKER

                                # <Substitution u'string:${menuItem/extra/class} tb-state' (77:36)> -> __attr_class
                                __token = 3430
                                try:
                                    __zt_tmp = __attrs_133838698896080
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_133838794967184('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u'               class="%s"' % __attr_class))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698743504
                                __default_133838698743504 = _DEFAULT_MARKER

                                # <Value u'menuItem/extra/stateTitle' (79:27)> -> __cache_133838698745296
                                __token = 3566
                                try:
                                    __zt_tmp = __attrs_133838698896080
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_133838698745296 = _static_133838794967184('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/extra/stateTitle' (79:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0188150> -> __condition
                                __expression = __cache_133838698745296

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\r\n              State title\r\n            ')
                                else:
                                    __content = __cache_133838698745296
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>')
                            __append(u'\r\n          </a>\r\n\r\n          ')

                            # <Static value=<_ast.Dict object at 0x79b9c01ad110> name=None at 79b9c01ad5d0> -> __attrs_133838698896656
                            __attrs_133838698896656 = _static_133838698893584

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="dropdown-menu">\r\n            ')

                            # <Static value=<_ast.Dict object at 0x79b9c01ad290> name=None at 79b9c01ada90> -> __attrs_133838716837520
                            __attrs_133838716837520 = _static_133838698893968
                            __backup_subMenuItem_133838700750672 = get('subMenuItem', __marker)

                            # <Value u'submenu' (86:41)> -> __iterator
                            __token = 3871
                            try:
                                __zt_tmp = __attrs_133838716837520
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __iterator = _static_133838794967184('path', u'submenu', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                            (__iterator, ____index_133838686045904, ) = getitem('repeat')(u'subMenuItem', __iterator)
                            econtext['subMenuItem'] = None
                            for __item in __iterator:
                                econtext['subMenuItem'] = __item

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div')

                                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716834320
                                __default_133838716834320 = _DEFAULT_MARKER

                                # <Substitution u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item' (85:39)> -> __attr_class
                                __token = 3739
                                try:
                                    __zt_tmp = __attrs_133838716837520
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_133838794967184('string', u'${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>\r\n            ')

                                # <Static value=<_ast.Dict object at 0x79b9bf56c0d0> name=None at 79b9bf56cb50> -> __attrs_133838686046800
                                __attrs_133838686046800 = _static_133838686044368

                                # <Value u'subMenuItem/action' (94:45)> -> __condition
                                __token = 4302
                                try:
                                    __zt_tmp = __attrs_133838686046800
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_133838794967184('path', u'subMenuItem/action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                if __condition:

                                    # <a ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<a')

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686048144
                                    __default_133838686048144 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/action' (90:35)> -> __attr_href
                                    __token = 4018
                                    try:
                                        __zt_tmp = __attrs_133838686046800
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_href = _static_133838794967184('path', u'subMenuItem/action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                    if (__attr_href is not None):
                                        __append((u' href="%s"' % __attr_href))
                                    __append(u'               aria-expanded="false"')

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686046096
                                    __default_133838686046096 = _DEFAULT_MARKER

                                    # <Translate msgid=None node=<Substitution u'subMenuItem/description' (91:35)> at 79b9bf56ca10> -> __attr_title

                                    # <Substitution u'subMenuItem/description' (91:35)> -> __attr_title
                                    __token = 4074
                                    try:
                                        __zt_tmp = __attrs_133838686046800
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_title = _static_133838794967184('path', u'subMenuItem/description', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    if (__attr_title is not None):
                                        __append((u' title="%s"' % __attr_title))

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686046864
                                    __default_133838686046864 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/id | nothing' (92:31)> -> __attr_id
                                    __token = 4132
                                    try:
                                        __zt_tmp = __attrs_133838686046800
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_133838794967184('path', u'subMenuItem/extra/id | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686047184
                                    __default_133838686047184 = _DEFAULT_MARKER

                                    # <Substitution u'string:${subMenuItem/extra/class|nothing} nav-link' (93:33)> -> __attr_class
                                    __token = 4200
                                    try:
                                        __zt_tmp = __attrs_133838686046800
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_class = _static_133838794967184('string', u'${subMenuItem/extra/class|nothing} nav-link', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_class is not None):
                                        __append((u' class="%s"' % __attr_class))
                                    __append(u'>\r\n              ')

                                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686151184
                                    __attrs_133838686151184 = _static_133838878659728

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686154704
                                    __default_133838686154704 = _DEFAULT_MARKER

                                    # <Value u'subMenuItem/title' (96:35)> -> __cache_133838686154384
                                    __token = 4385
                                    try:
                                        __zt_tmp = __attrs_133838686151184
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __cache_133838686154384 = _static_133838794967184('path', u'subMenuItem/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                                    # <BinOp left=<Value u'subMenuItem/title' (96:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf586950> -> __condition
                                    __expression = __cache_133838686154384

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                                    __value = _DEFAULT_MARKER
                                    __condition = (__expression is __value)
                                    if __condition:
                                        __append(u'\r\n                Title\r\n              ')
                                    else:
                                        __content = __cache_133838686154384
                                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        __content = __convert(__content)
                                        if (__content is not None):
                                            __append(__content)
                                    __append(u'\r\n            </a>')
                                __append(u'\r\n            ')

                                # <Static value=<_ast.Dict object at 0x79b9bf586e10> name=None at 79b9bf586490> -> __attrs_133838686152848
                                __attrs_133838686152848 = _static_133838686154256

                                # <Value u'not:subMenuItem/action' (104:29)> -> __condition
                                __token = 4696
                                try:
                                    __zt_tmp = __attrs_133838686152848
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_133838794967184('not', u'subMenuItem/action', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                if __condition:

                                    # <span ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<span')

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686153936
                                    __default_133838686153936 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/id | nothing' (102:33)> -> __attr_id
                                    __token = 4562
                                    try:
                                        __zt_tmp = __attrs_133838686152848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_133838794967184('path', u'subMenuItem/extra/id | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686150864
                                    __default_133838686150864 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/class | nothing' (103:35)> -> __attr_class
                                    __token = 4630
                                    try:
                                        __zt_tmp = __attrs_133838686152848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_class = _static_133838794967184('path', u'subMenuItem/extra/class | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_class is not None):
                                        __append((u' class="%s"' % __attr_class))
                                    __append(u'>\r\n              ')

                                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698710096
                                    __attrs_133838698710096 = _static_133838878659728

                                    # <span ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<span>')

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698709648
                                    __default_133838698709648 = _DEFAULT_MARKER

                                    # <Value u'subMenuItem/title' (107:39)> -> __cache_133838698711760
                                    __token = 4817
                                    try:
                                        __zt_tmp = __attrs_133838698710096
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __cache_133838698711760 = _static_133838794967184('path', u'subMenuItem/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                                    # <BinOp left=<Value u'subMenuItem/title' (107:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0180dd0> -> __condition
                                    __expression = __cache_133838698711760

                                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                                    __value = _DEFAULT_MARKER
                                    __condition = (__expression is __value)
                                    if __condition:
                                        __append(u'\r\n                Title\r\n              ')
                                    else:
                                        __content = __cache_133838698711760
                                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        __content = __convert(__content)
                                        if (__content is not None):
                                            __append(__content)
                                    __append(u'</span>\r\n            </span>')
                                __append(u'\r\n          </div>')
                                ____index_133838686045904 -= 1
                                if (____index_133838686045904 > 0):
                                    __append('\n            ')
                            if (__backup_subMenuItem_133838700750672 is __marker):
                                del econtext['subMenuItem']
                            else:
                                econtext['subMenuItem'] = __backup_subMenuItem_133838700750672
                            __append(u'\r\n        </div>\r\n      </div>')
                        __append(u'\r\n\r\n    </li>')
                    if (__backup_identifier_133838716838416 is __marker):
                        del econtext['identifier']
                    else:
                        econtext['identifier'] = __backup_identifier_133838716838416
                    if (__backup_has_dropdown_133838681237136 is __marker):
                        del econtext['has_dropdown']
                    else:
                        econtext['has_dropdown'] = __backup_has_dropdown_133838681237136
                    if (__backup_submenu_133838685910864 is __marker):
                        del econtext['submenu']
                    else:
                        econtext['submenu'] = __backup_submenu_133838685910864
                    __append(u'\r\n  ')
                    ____index_133838698705872 -= 1
                    if (____index_133838698705872 > 0):
                        __append('')
                if (__backup_menuItem_133838698893392 is __marker):
                    del econtext['menuItem']
                else:
                    econtext['menuItem'] = __backup_menuItem_133838698893392
                __append(u'\r\n')
                __i18n_domain = __previous_i18n_domain_133838698705168
            if (__backup_menu_133838698696848 is __marker):
                del econtext['menu']
            else:
                econtext['menu'] = __backup_menu_133838698696848
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }