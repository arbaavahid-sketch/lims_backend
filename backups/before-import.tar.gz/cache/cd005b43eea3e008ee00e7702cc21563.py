# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/datagrid/datagrid_input.pt'

__tokens = {2005: (u'widget/render', 35, 40), 397: (u'view/extra', 9, 36), 411: (u' view/id_prefi', 9, 50), 486: (u'view/columns', 12, 34), 565: (u'string:header cell-${repeat/column/number}', 14, 35), 638: (u" python: cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or ''", 15, 29), 764: (u'cssclass', 16, 36), 806: (u'column/label', 17, 31), 901: (u'column/required', 19, 33), 1058: (u'column/description', 20, 50), 1091: (u'column/description', 20, 83), 1209: (u'view/allow_insert', 23, 42), 1276: (u'view/allow_delete', 24, 42), 1343: (u'view/allow_reorder', 25, 42), 1411: (u'view/allow_reorder', 26, 42), 1534: (u'view/name_prefix', 29, 72), 1566: (u' view/id_prefi', 29, 104), 1616: (u'view/widgets', 30, 32), 1876: (u'python:view._includeRow(widget.name)', 33, 27), 1665: (u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", 31, 34), 1812: (u" python:widget.name.split('.')[-1", 32, 38), 2155: (u'view/counterMarker', 41, 46), 2266: (u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js', 43, 60), 2441: (u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css', 44, 86)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948309386704 = {u'class': u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", u'data-index': u"python:widget.name.split('.')[-1]", }
_static_136948418207568 = __compile_zt_expr
_static_136948501914768 = {}
_static_136948327993744 = {u'type': u'hidden', }
_static_136948327993936 = {u'class': u'header', }
_static_136948309527120 = {u'class': u'header', }
_static_136948323753232 = {u'src': u'', u'type': u'text/javascript', }
_static_136948328156944 = {u'class': u'header', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948328062672 = {u'data-id_prefix': u'view/id_prefix', u'class': u'datagridwidget-body', u'data-name_prefix': u'view/name_prefix', }
_static_136948328154832 = {u'class': u'header', }
_static_136948327988432 = {u'class': u'required', u'title': u'Required', }
_static_136948308596624 = {u'media': u'screen', u'href': u'', u'type': u'text/css', u'rel': u'stylesheet', }
_static_136948327985680 = {u'class': u'formHelp', }
_static_136948283606928 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_136948309524560 = {u'class': u'header', }
_static_136948325704080 = {u'data-mode': u'row', u'data-extra': u'view/extra', u'class': u'table table-hover table-responsive table-sm table-borderless datagridwidget-table-view', u'id': u'view/id_prefix', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_row(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323752464
            __attrs_136948323752464 = _static_136948501914768
            __append(u'\n            ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323753616
            __attrs_136948323753616 = _static_136948501914768

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323752976
            __default_136948323752976 = _DEFAULT_MARKER

            # <Value u'widget/render' (35:40)> -> __cache_136948323750288
            __token = 2005
            try:
                __zt_tmp = __attrs_136948323753616
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_136948323750288 = _static_136948418207568('path', u'widget/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

            # <BinOp left=<Value u'widget/render' (35:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc4309b90> -> __condition
            __expression = __cache_136948323750288

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_136948323750288
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n          ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc1cc0790> name=None at 7c8dc1cc0850> -> __attrs_136948328042000
            __attrs_136948328042000 = _static_136948283606928
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc44e6190> name=None at 7c8dc359dc50> -> __attrs_136948328062224
            __attrs_136948328062224 = _static_136948325704080

            # <table ... (0:0)
            # --------------------------------------------------------
            __append(u'<table class="table table-hover table-responsive table-sm table-borderless datagridwidget-table-view" data-mode="row"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328062736
            __default_136948328062736 = _DEFAULT_MARKER

            # <Substitution u'view/extra' (9:36)> -> __attr_data_extra
            __token = 397
            try:
                __zt_tmp = __attrs_136948328062224
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_extra = _static_136948418207568('path', u'view/extra', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_data_extra = __quote(__attr_data_extra, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_extra is not None):
                __append((u' data-extra="%s"' % __attr_data_extra))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328060304
            __default_136948328060304 = _DEFAULT_MARKER

            # <Substitution u'view/id_prefix' (9:50)> -> __attr_id
            __token = 411
            try:
                __zt_tmp = __attrs_136948328062224
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('path', u'view/id_prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328059152
            __attrs_136948328059152 = _static_136948501914768

            # <thead ... (0:0)
            # --------------------------------------------------------
            __append(u'<thead>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328062096
            __attrs_136948328062096 = _static_136948501914768

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328153808
            __attrs_136948328153808 = _static_136948501914768
            __backup_column_136948309523856 = get('column', __marker)

            # <Value u'view/columns' (12:34)> -> __iterator
            __token = 486
            try:
                __zt_tmp = __attrs_136948328153808
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/columns', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948328153488, ) = getitem('repeat')(u'column', __iterator)
            econtext['column'] = None
            for __item in __iterator:
                econtext['column'] = __item
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dc473c6d0> name=None at 7c8dc473cc10> -> __attrs_136948328153296
                __attrs_136948328153296 = _static_136948328154832
                __backup_cssclass_136948328046480 = get('cssclass', __marker)

                # <Value u'string:header cell-${repeat/column/number}' (14:35)> -> __value
                __token = 565
                try:
                    __zt_tmp = __attrs_136948328153296
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('string', u'header cell-${repeat/column/number}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['cssclass'] = __value
                __backup_cssclass_136948325800784 = get('cssclass', __marker)

                # <Value u"python: cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or '')" (15:29)> -> __value
                __token = 638
                try:
                    __zt_tmp = __attrs_136948328153296
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u" cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or '')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['cssclass'] = __value

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328156560
                __default_136948328156560 = _DEFAULT_MARKER

                # <Substitution u'cssclass' (16:36)> -> __attr_class
                __token = 764
                try:
                    __zt_tmp = __attrs_136948328153296
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_136948418207568('path', u'cssclass', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', u'header', _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948327986768
                __attrs_136948327986768 = _static_136948501914768

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328155856
                __default_136948328155856 = _DEFAULT_MARKER

                # <Value u'column/label' (17:31)> -> __cache_136948328155664
                __token = 806
                try:
                    __zt_tmp = __attrs_136948327986768
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948328155664 = _static_136948418207568('path', u'column/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'column/label' (17:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc473ca90> -> __condition
                __expression = __cache_136948328155664

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'title')
                else:
                    __content = __cache_136948328155664
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc4713cd0> name=None at 7c8dc47138d0> -> __attrs_136948327988560
                __attrs_136948327988560 = _static_136948327988432

                # <Value u'column/required' (19:33)> -> __condition
                __token = 901
                try:
                    __zt_tmp = __attrs_136948327988560
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'column/required', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:
                    __previous_i18n_domain_136948327989200 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="required"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988048
                    __default_136948327988048 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7c8dc4713910> at 7c8dc4713550> -> __attr_title
                    __attr_title = u'Required'
                    __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>&nbsp;</span>')
                    __i18n_domain = __previous_i18n_domain_136948327989200
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc4713210> name=None at 7c8dc4713090> -> __attrs_136948308624848
                __attrs_136948308624848 = _static_136948327985680

                # <Value u'column/description' (20:50)> -> __condition
                __token = 1058
                try:
                    __zt_tmp = __attrs_136948308624848
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'column/description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp">')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988688
                    __default_136948327988688 = _DEFAULT_MARKER

                    # <Value u'column/description' (20:83)> -> __cache_136948327986704
                    __token = 1091
                    try:
                        __zt_tmp = __attrs_136948308624848
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948327986704 = _static_136948418207568('path', u'column/description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'column/description' (20:83)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc4713290> -> __condition
                    __expression = __cache_136948327986704

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Description')
                    else:
                        __content = __cache_136948327986704
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                __append(u'\n          </th>')
                if (__backup_cssclass_136948325800784 is __marker):
                    del econtext['cssclass']
                else:
                    econtext['cssclass'] = __backup_cssclass_136948325800784
                if (__backup_cssclass_136948328046480 is __marker):
                    del econtext['cssclass']
                else:
                    econtext['cssclass'] = __backup_cssclass_136948328046480
                __append(u'\n        ')
                ____index_136948328153488 -= 1
                if (____index_136948328153488 > 0):
                    __append('')
            if (__backup_column_136948309523856 is __marker):
                del econtext['column']
            else:
                econtext['column'] = __backup_column_136948309523856
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc473cf10> name=None at 7c8dc473cc50> -> __attrs_136948309525712
            __attrs_136948309525712 = _static_136948328156944

            # <Value u'view/allow_insert' (23:42)> -> __condition
            __token = 1209
            try:
                __zt_tmp = __attrs_136948309525712
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/allow_insert', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc3578050> name=None at 7c8dc35785d0> -> __attrs_136948309526480
            __attrs_136948309526480 = _static_136948309524560

            # <Value u'view/allow_delete' (24:42)> -> __condition
            __token = 1276
            try:
                __zt_tmp = __attrs_136948309526480
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/allow_delete', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc3578a50> name=None at 7c8dc3578a10> -> __attrs_136948309526864
            __attrs_136948309526864 = _static_136948309527120

            # <Value u'view/allow_reorder' (25:42)> -> __condition
            __token = 1343
            try:
                __zt_tmp = __attrs_136948309526864
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/allow_reorder', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc4715250> name=None at 7c8dc4715fd0> -> __attrs_136948327997136
            __attrs_136948327997136 = _static_136948327993936

            # <Value u'view/allow_reorder' (26:42)> -> __condition
            __token = 1411
            try:
                __zt_tmp = __attrs_136948327997136
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/allow_reorder', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\n      </tr>\n    </thead>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dc4725ed0> name=None at 7c8dc4725b50> -> __attrs_136948327994576
            __attrs_136948327994576 = _static_136948328062672

            # <tbody ... (0:0)
            # --------------------------------------------------------
            __append(u'<tbody class="datagridwidget-body"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327996048
            __default_136948327996048 = _DEFAULT_MARKER

            # <Substitution u'view/name_prefix' (29:72)> -> __attr_data_name_prefix
            __token = 1534
            try:
                __zt_tmp = __attrs_136948327994576
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_name_prefix = _static_136948418207568('path', u'view/name_prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_data_name_prefix = __quote(__attr_data_name_prefix, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_name_prefix is not None):
                __append((u' data-name_prefix="%s"' % __attr_data_name_prefix))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327996944
            __default_136948327996944 = _DEFAULT_MARKER

            # <Substitution u'view/id_prefix' (29:104)> -> __attr_data_id_prefix
            __token = 1566
            try:
                __zt_tmp = __attrs_136948327994576
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_id_prefix = _static_136948418207568('path', u'view/id_prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_data_id_prefix = __quote(__attr_data_id_prefix, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_id_prefix is not None):
                __append((u' data-id_prefix="%s"' % __attr_data_id_prefix))
            __append(u'>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948327995408
            __attrs_136948327995408 = _static_136948501914768
            __backup_widget_136948308596432 = get('widget', __marker)

            # <Value u'view/widgets' (30:32)> -> __iterator
            __token = 1616
            try:
                __zt_tmp = __attrs_136948327995408
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/widgets', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948327996752, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dc35565d0> name=None at 7c8dc3556b90> -> __attrs_136948309386768
                __attrs_136948309386768 = _static_136948309386704

                # <Value u'python:view._includeRow(widget.name)' (33:27)> -> __condition
                __token = 1876
                try:
                    __zt_tmp = __attrs_136948309386768
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u'view._includeRow(widget.name)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309385872
                    __default_136948309385872 = _DEFAULT_MARKER

                    # <Substitution u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')" (31:34)> -> __attr_class
                    __token = 1665
                    try:
                        __zt_tmp = __attrs_136948309386768
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136948418207568('python', u"'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309388368
                    __default_136948309388368 = _DEFAULT_MARKER

                    # <Substitution u"python:widget.name.split('.')[-1]" (32:38)> -> __attr_data_index
                    __token = 1812
                    try:
                        __zt_tmp = __attrs_136948309386768
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_index = _static_136948418207568('python', u"widget.name.split('.')[-1]", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_data_index = __quote(__attr_data_index, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_index is not None):
                        __append((u' data-index="%s"' % __attr_data_index))
                    __append(u'>\n          ')
                    __token = None
                    render_widget_row(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    __append(u'\n        </tr>')
                __append(u'\n      ')
                ____index_136948327996752 -= 1
                if (____index_136948327996752 > 0):
                    __append('')
            if (__backup_widget_136948308596432 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_136948308596432
            __append(u'\n    </tbody>\n  </table>\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc4715190> name=None at 7c8dc3578450> -> __attrs_136948323751504
            __attrs_136948323751504 = _static_136948327993744

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323750672
            __default_136948323750672 = _DEFAULT_MARKER

            # <Value u'view/counterMarker' (41:46)> -> __cache_136948309388752
            __token = 2155
            try:
                __zt_tmp = __attrs_136948323751504
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_136948309388752 = _static_136948418207568('path', u'view/counterMarker', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/counterMarker' (41:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc4309a50> -> __condition
            __expression = __cache_136948309388752

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" />')
            else:
                __content = __cache_136948309388752
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n  <!-- static resources -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc4309d10> name=None at 7c8dc4309f10> -> __attrs_136948308597008
            __attrs_136948308597008 = _static_136948323753232

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323750544
            __default_136948323750544 = _DEFAULT_MARKER

            # <Substitution u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js' (43:60)> -> __attr_src
            __token = 2266
            try:
                __zt_tmp = __attrs_136948308597008
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_136948418207568('string', u'${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc3495790> name=None at 7c8dc3495310> -> __attrs_136948308598352
            __attrs_136948308598352 = _static_136948308596624

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308598160
            __default_136948308598160 = _DEFAULT_MARKER

            # <Substitution u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css' (44:86)> -> __attr_href
            __token = 2441
            try:
                __zt_tmp = __attrs_136948308598352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_136948418207568('string', u'${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' type="text/css" media="screen"/>\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_row': render_widget_row, 'render': render, }