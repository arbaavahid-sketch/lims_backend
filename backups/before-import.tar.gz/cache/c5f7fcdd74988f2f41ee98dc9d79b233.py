# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/toolbar.pt'

__tokens = {105: (u'view/context_state', 3, 31), 154: (u' view/portal_stat', 4, 29), 205: (u's python:view.get_global_sections', 5, 31), 274: (u'or python:view.get_language_selecto', 6, 32), 340: (u'bar python:view.get_personal_b', 7, 26), 495: (u'portal_state/portal_url', 11, 56), 550: (u'python:view.get_toolbar_logo()', 12, 29), 586: (u' python:view.get_toolbar_styles(', 12, 65), 1141: (u'view/base_render', 26, 34), 1306: (u'personal_bar/user_name', 33, 42), 1367: (u'global_sections/render', 34, 36), 1508: (u'language_selector/template', 39, 36), 1628: (u'personal_bar/user_name', 43, 42), 1816: (u'string:${portal_state/portal_url}/spotlight', 47, 32), 1996: (u'view/is_manager', 53, 42), 2074: (u'view/get_lims_setup_url', 55, 32), 2300: (u'personal_bar/user_name', 63, 51), 2580: (u'personal_bar/homelink_url', 71, 32), 2637: (u'personal_bar/user_name', 72, 29), 2804: (u'view/context_state/current_page_url', 76, 28), 2906: (u'personal_bar/user_actions', 78, 33), 2993: (u"python:action['href'] == url", 80, 36), 3054: (u'action', 81, 31), 3067: (u" python:selected and 'active nav-link' or 'nav-link", 81, 44), 3158: (u"python:action['id'] == 'personaltools-site-setup'", 82, 36), 3328: (u"python:action['id'] == 'personaltools-my-organization'", 85, 45), 3508: (u"python:action['id'] == 'personaltools-logout'", 88, 39), 3682: (u"python:action['id'] == 'personaltools-user-profile'", 91, 44), 3862: (u'action/title', 94, 43), 4070: (u'not:personal_bar/user_name', 103, 42), 4155: (u'personal_bar/user_actions', 104, 56), 4126: (u'python:1', 104, 27), 4225: (u'action/href', 105, 42), 4243: (u' string:nav-lin', 105, 60), 4303: (u'action/title', 106, 41), 4412: (u"python:action['id'] == 'personaltools-logout'", 109, 37)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757075231760 = {u'class': u'fas fa-user-cog', }
_static_135757136196624 = {u'class': u'nav-item', }
_static_135757182311952 = {u'class': u'fas fa-sign-out-alt', }
_static_135757152173840 = {u'class': u'nav navbar-nav mr-auto content-views', }
_static_135757163436496 = {u'class': u'fas fa-bars', }
_static_135757163479440 = {u'class': u'fas fa-search', }
_static_135757137861584 = {u'class': u'fas fa-cog', }
_static_135757166283664 = {u'href': u'', u'class': u'string:nav-link', }
_static_135757163045968 = {u'class': u'icon-logout', }
_static_135757137794000 = {u'class': u'nav-item', }
_static_135757148692752 = {u'class': u'fas fa-wrench', }
_static_135757163482576 = {u'class': u'nav-item', }
_static_135757327983760 = {}
_static_135757237110608 = {u'aria-label': u'Toggle navigation', u'aria-controls': u'toolbarContent', u'data-target': u'#toolbarContent', u'aria-expanded': u'false', u'data-toggle': u'collapse', u'type': u'button', u'class': u'navbar-toggler btn btn-outline-light', }
_static_135757166676944 = {u'class': u'collapse navbar-collapse', u'id': u'toolbarContent', }
_static_135757150475344 = {u'src': u'python:view.get_toolbar_logo()', u'style': u'python:view.get_toolbar_styles()', }
_static_135757150465616 = {u'href': u'#', u'class': u'navbar-brand', }
_static_135757148782288 = {u'aria-haspopup': u'true', u'aria-expanded': u'false', u'id': u'navbarUserDropdown', u'href': u'#', u'role': u'button', u'data-toggle': u'dropdown', u'class': u'nav-link dropdown-toggle', }
_static_135757148768720 = {u'href': u'string:${portal_state/portal_url}/spotlight', u'class': u'nav-link', u'title': u'Press Ctrl+Space to trigger the Spotlight search', }
_static_135757244280656 = __compile_zt_expr
_static_135757182309968 = {u'class': u'fas fa-building', }
_static_135757148736592 = {u'class': u'nav-item', }
_static_135757136197968 = {u'href': u'', u'class': u"python:selected and 'active nav-link' or 'nav-link'", }
_static_135757153017040 = {u'class': u'nav-item', }
_static_135757072274576 = {u'class': u'nav-item dropdown', }
_static_135757153014352 = {u'class': u'dropdown-menu dropdown-menu-right', }
_static_135757075407952 = set([u'class', ])
_static_135757152171152 = {u'class': u'navbar-nav ml-auto', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757074137488 = {u'class': u'nav-item', }
_static_135757152277072 = {u'id': u'senaite-toolbar', u'class': u'navbar static-top navbar-expand-md', }
_static_135757072274128 = {u'href': u'view/get_lims_setup_url', u'class': u'nav-link', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786cd65250> name=None at 7b786cd65a10> -> __attrs_135757152279440
            __attrs_135757152279440 = _static_135757152277072
            __backup_context_state_135757074242256 = get('context_state', __marker)

            # <Value u'view/context_state' (3:31)> -> __value
            __token = 105
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/context_state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_portal_state_135757137793552 = get('portal_state', __marker)

            # <Value u'view/portal_state' (4:29)> -> __value
            __token = 154
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/portal_state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_global_sections_135757226787664 = get('global_sections', __marker)

            # <Value u'python:view.get_global_sections()' (5:31)> -> __value
            __token = 205
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.get_global_sections()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['global_sections'] = __value
            __backup_language_selector_135757152277264 = get('language_selector', __marker)

            # <Value u'python:view.get_language_selector()' (6:32)> -> __value
            __token = 274
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.get_language_selector()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['language_selector'] = __value
            __backup_personal_bar_135757226788880 = get('personal_bar', __marker)

            # <Value u'python:view.get_personal_bar()' (7:26)> -> __value
            __token = 340
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.get_personal_bar()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['personal_bar'] = __value
            __previous_i18n_domain_135757150462224 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <nav ... (0:0)
            # --------------------------------------------------------
            __append(u'<nav id="senaite-toolbar" class="navbar static-top navbar-expand-md">\n\n  <!-- Navbar Brand Icon -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b786cbaae50> name=None at 7b786cbaabd0> -> __attrs_135757150477776
            __attrs_135757150477776 = _static_135757150465616

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="navbar-brand"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150478032
            __default_135757150478032 = _DEFAULT_MARKER

            # <Substitution u'portal_state/portal_url' (11:56)> -> __attr_href
            __token = 495
            try:
                __zt_tmp = __attrs_135757150477776
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('path', u'portal_state/portal_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cbad450> name=None at 7b786cbadbd0> -> __attrs_135757155288656
            __attrs_135757155288656 = _static_135757150475344

            # <img ... (0:0)
            # --------------------------------------------------------
            __append(u'<img')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137685968
            __default_135757137685968 = _DEFAULT_MARKER

            # <Substitution u'python:view.get_toolbar_logo()' (12:29)> -> __attr_src
            __token = 550
            try:
                __zt_tmp = __attrs_135757155288656
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('python', u'view.get_toolbar_logo()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137686288
            __default_135757137686288 = _DEFAULT_MARKER

            # <Substitution u'python:view.get_toolbar_styles()' (12:65)> -> __attr_style
            __token = 586
            try:
                __zt_tmp = __attrs_135757155288656
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_135757244280656('python', u'view.get_toolbar_styles()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))
            __append(u' />\n  </a>\n\n  <!-- Navbar Toggle Button -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b7871e4c750> name=None at 7b7871e4c610> -> __attrs_135757163434896
            __attrs_135757163434896 = _static_135757237110608

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button class="navbar-toggler btn btn-outline-light" type="button" data-toggle="collapse" data-target="#toolbarContent" aria-controls="toolbarContent" aria-expanded="false" aria-label="Toggle navigation">\n    ')

            # <Static value=<_ast.Dict object at 0x7b786d8099d0> name=None at 7b786d809190> -> __attrs_135757166675152
            __attrs_135757166675152 = _static_135757163436496

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-bars"></i>\n  </button>\n\n  <!-- Navbar Menu Items -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b786db20bd0> name=None at 7b786db20950> -> __attrs_135757134639376
            __attrs_135757134639376 = _static_135757166676944

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="collapse navbar-collapse" id="toolbarContent">\n\n    <!-- left -->\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cd4bf10> name=None at 7b786cd4ba10> -> __attrs_135757152173008
            __attrs_135757152173008 = _static_135757152173840

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="nav navbar-nav mr-auto content-views">\n      <!-- contentviews -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152171344
            __attrs_135757152171344 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152171536
            __default_135757152171536 = _DEFAULT_MARKER

            # <Value u'view/base_render' (26:34)> -> __cache_135757152170128
            __token = 1141
            try:
                __zt_tmp = __attrs_135757152171344
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757152170128 = _static_135757244280656('path', u'view/base_render', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/base_render' (26:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cd4b450> -> __condition
            __expression = __cache_135757152170128

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_135757152170128
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n    </ul>\n\n    <!-- right -->\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cd4b490> name=None at 7b786cd4b350> -> __attrs_135757148737360
            __attrs_135757148737360 = _static_135757152171152

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="navbar-nav ml-auto">\n\n      <!-- Global Sections -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786ca04c50> name=None at 7b786ca04d90> -> __attrs_135757148737296
            __attrs_135757148737296 = _static_135757148736592

            # <Value u'personal_bar/user_name' (33:42)> -> __condition
            __token = 1306
            try:
                __zt_tmp = __attrs_135757148737296
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'personal_bar/user_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074137552
                __attrs_135757074137552 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074137744
                __default_135757074137744 = _DEFAULT_MARKER

                # <Value u'global_sections/render' (34:36)> -> __cache_135757074138256
                __token = 1367
                try:
                    __zt_tmp = __attrs_135757074137552
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074138256 = _static_135757244280656('path', u'global_sections/render', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'global_sections/render' (34:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78682e0ed0> -> __condition
                __expression = __cache_135757074138256

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div></div>')
                else:
                    __content = __cache_135757074138256
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n      </li>')
            __append(u'\n\n      <!-- Language Selector -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b78682e0190> name=None at 7b78682e0b50> -> __attrs_135757137796944
            __attrs_135757137796944 = _static_135757074137488

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="nav-item">\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137793936
            __attrs_135757137793936 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137794128
            __default_135757137794128 = _DEFAULT_MARKER

            # <Value u'language_selector/template' (39:36)> -> __cache_135757137795024
            __token = 1508
            try:
                __zt_tmp = __attrs_135757137793936
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757137795024 = _static_135757244280656('path', u'language_selector/template', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'language_selector/template' (39:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bf950d0> -> __condition
            __expression = __cache_135757137795024

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_135757137795024
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n      </li>\n\n      <!-- Search trigger -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786bf953d0> name=None at 7b786bf95250> -> __attrs_135757148769680
            __attrs_135757148769680 = _static_135757137794000

            # <Value u'personal_bar/user_name' (43:42)> -> __condition
            __token = 1628
            try:
                __zt_tmp = __attrs_135757148769680
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'personal_bar/user_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\n        ')

                # <Static value=<_ast.Dict object at 0x7b786ca0c9d0> name=None at 7b786ca0c0d0> -> __attrs_135757163481936
                __attrs_135757163481936 = _static_135757148768720

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="nav-link"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163480592
                __default_135757163480592 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7b786d814950> at 7b786d814490> -> __attr_title
                __attr_title = u'Press Ctrl+Space to trigger the Spotlight search'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163480400
                __default_135757163480400 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_state/portal_url}/spotlight' (47:32)> -> __attr_href
                __token = 1816
                try:
                    __zt_tmp = __attrs_135757163481936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_135757244280656('string', u'${portal_state/portal_url}/spotlight', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\n          ')

                # <Static value=<_ast.Dict object at 0x7b786d814190> name=None at 7b786d814910> -> __attrs_135757163483024
                __attrs_135757163483024 = _static_135757163479440

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-search"></i>\n        </a>\n      </li>')
            __append(u'\n\n      <!-- LIMS Setup -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786d814dd0> name=None at 7b786d814c90> -> __attrs_135757163482512
            __attrs_135757163482512 = _static_135757163482576

            # <Value u'view/is_manager' (53:42)> -> __condition
            __token = 1996
            try:
                __zt_tmp = __attrs_135757163482512
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'view/is_manager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\n        ')

                # <Static value=<_ast.Dict object at 0x7b78681192d0> name=None at 7b7868119fd0> -> __attrs_135757072276176
                __attrs_135757072276176 = _static_135757072274128

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="nav-link"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072276560
                __default_135757072276560 = _DEFAULT_MARKER

                # <Substitution u'view/get_lims_setup_url' (55:32)> -> __attr_href
                __token = 2074
                try:
                    __zt_tmp = __attrs_135757072276176
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_135757244280656('path', u'view/get_lims_setup_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072276880
                __attrs_135757072276880 = _static_135757327983760
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b786bfa5bd0> name=None at 7b786bfa5810> -> __attrs_135757137862480
                __attrs_135757137862480 = _static_135757137861584

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-cog"></i>\n          \n        </a>\n      </li>')
            __append(u'\n\n      <!-- Personal Bar Menu -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b7868119490> name=None at 7b7868119790> -> __attrs_135757137860880
            __attrs_135757137860880 = _static_135757072274576

            # <Value u'personal_bar/user_name' (63:51)> -> __condition
            __token = 2300
            try:
                __zt_tmp = __attrs_135757137860880
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'personal_bar/user_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item dropdown">\n        ')

                # <Static value=<_ast.Dict object at 0x7b786ca0fed0> name=None at 7b786ca0f710> -> __attrs_135757153017424
                __attrs_135757153017424 = _static_135757148782288

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148781776
                __default_135757148781776 = _DEFAULT_MARKER

                # <Substitution u'personal_bar/homelink_url' (71:32)> -> __attr_href
                __token = 2580
                try:
                    __zt_tmp = __attrs_135757153017424
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_135757244280656('path', u'personal_bar/homelink_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' class="nav-link dropdown-toggle" id="navbarUserDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153016912
                __attrs_135757153016912 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153016016
                __default_135757153016016 = _DEFAULT_MARKER

                # <Value u'personal_bar/user_name' (72:29)> -> __cache_135757153014544
                __token = 2637
                try:
                    __zt_tmp = __attrs_135757153016912
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757153014544 = _static_135757244280656('path', u'personal_bar/user_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'personal_bar/user_name' (72:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ce19d50> -> __condition
                __expression = __cache_135757153014544

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_135757153014544
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n        </a>\n        <!-- Personal Bar Dropdown Items -->\n        ')

                # <Static value=<_ast.Dict object at 0x7b786ce19250> name=None at 7b786ce19d90> -> __attrs_135757153014608
                __attrs_135757153014608 = _static_135757153014352
                __backup_url_135757074137680 = get('url', __marker)

                # <Value u'view/context_state/current_page_url' (76:28)> -> __value
                __token = 2804
                try:
                    __zt_tmp = __attrs_135757153014608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'view/context_state/current_page_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['url'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="dropdown-menu dropdown-menu-right">\n          ')

                # <Static value=<_ast.Dict object at 0x7b786ce19cd0> name=None at 7b786ce19650> -> __attrs_135757136196176
                __attrs_135757136196176 = _static_135757153017040
                __backup_action_135757152171856 = get('action', __marker)

                # <Value u'personal_bar/user_actions' (78:33)> -> __iterator
                __token = 2906
                try:
                    __zt_tmp = __attrs_135757136196176
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'personal_bar/user_actions', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757136199632, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item">\n            ')

                    # <Static value=<_ast.Dict object at 0x7b786be0f950> name=None at 7b786be0fed0> -> __attrs_135757136197264
                    __attrs_135757136197264 = _static_135757136197968
                    __backup_selected_135757137860944 = get('selected', __marker)

                    # <Value u"python:action['href'] == url" (80:36)> -> __value
                    __token = 2993
                    try:
                        __zt_tmp = __attrs_135757136197264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u"action['href'] == url", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['selected'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Value u'action' (81:31)> -> __cache_135757136195856
                    __token = 3054
                    try:
                        __zt_tmp = __attrs_135757136197264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757136195856 = _static_135757244280656('path', u'action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (u'href' not in __chain(__cache_135757136195856)):
                        __append(u' href=""')
                    __attr_135757136198480 = __cache_135757136195856
                    for (name, value, ) in __attr_135757136198480.items():
                        if ((name not in _static_135757075407952) and (value is not None)):
                            __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136196560
                    __default_135757136196560 = _DEFAULT_MARKER

                    # <Substitution u"python:selected and 'active nav-link' or 'nav-link'" (81:44)> -> __attr_class
                    __token = 3067
                    try:
                        __zt_tmp = __attrs_135757136197264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('python', u"selected and 'active nav-link' or 'nav-link'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148693904
                    __attrs_135757148693904 = _static_135757327983760

                    # <Value u"python:action['id'] == 'personaltools-site-setup'" (82:36)> -> __condition
                    __token = 3158
                    try:
                        __zt_tmp = __attrs_135757148693904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"action['id'] == 'personaltools-site-setup'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b786c9fa110> name=None at 7b786c9fa710> -> __attrs_135757148692944
                        __attrs_135757148692944 = _static_135757148692752

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-wrench"></i>\n              ')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148695312
                    __attrs_135757148695312 = _static_135757327983760

                    # <Value u"python:action['id'] == 'personaltools-my-organization'" (85:45)> -> __condition
                    __token = 3328
                    try:
                        __zt_tmp = __attrs_135757148695312
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"action['id'] == 'personaltools-my-organization'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b786ea09650> name=None at 7b786ea09c50> -> __attrs_135757182308624
                        __attrs_135757182308624 = _static_135757182309968

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-building"></i>\n              ')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757182309904
                    __attrs_135757182309904 = _static_135757327983760

                    # <Value u"python:action['id'] == 'personaltools-logout'" (88:39)> -> __condition
                    __token = 3508
                    try:
                        __zt_tmp = __attrs_135757182309904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"action['id'] == 'personaltools-logout'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b786ea09e10> name=None at 7b786ea09450> -> __attrs_135757182312272
                        __attrs_135757182312272 = _static_135757182311952

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-sign-out-alt"></i>\n              ')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757182309648
                    __attrs_135757182309648 = _static_135757327983760

                    # <Value u"python:action['id'] == 'personaltools-user-profile'" (91:44)> -> __condition
                    __token = 3682
                    try:
                        __zt_tmp = __attrs_135757182309648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"action['id'] == 'personaltools-user-profile'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78683eb410> name=None at 7b78683eb450> -> __attrs_135757075234704
                        __attrs_135757075234704 = _static_135757075231760

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-user-cog"></i>\n              ')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075233040
                    __attrs_135757075233040 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075234512
                    __default_135757075234512 = _DEFAULT_MARKER

                    # <Value u'action/title' (94:43)> -> __cache_135757075232144
                    __token = 3862
                    try:
                        __zt_tmp = __attrs_135757075233040
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075232144 = _static_135757244280656('path', u'action/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/title' (94:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683ebd50> -> __condition
                    __expression = __cache_135757075232144

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                action title\n              ')
                    else:
                        __content = __cache_135757075232144
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n            </a>')
                    if (__backup_selected_135757137860944 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_135757137860944
                    __append(u'\n          </li>')
                    ____index_135757136199632 -= 1
                    if (____index_135757136199632 > 0):
                        __append('\n          ')
                if (__backup_action_135757152171856 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_135757152171856
                __append(u'\n        </ul>')
                if (__backup_url_135757074137680 is __marker):
                    del econtext['url']
                else:
                    econtext['url'] = __backup_url_135757074137680
                __append(u'\n      </li>')
            __append(u'\n\n      <!-- Login/Register -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786be0f410> name=None at 7b7871e4cad0> -> __attrs_135757075232976
            __attrs_135757075232976 = _static_135757136196624

            # <Value u'not:personal_bar/user_name' (103:42)> -> __condition
            __token = 4070
            try:
                __zt_tmp = __attrs_135757075232976
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'personal_bar/user_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="nav-item">\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075231696
                __attrs_135757075231696 = _static_135757327983760
                __backup_action_135757152280080 = get('action', __marker)

                # <Value u'personal_bar/user_actions' (104:56)> -> __iterator
                __token = 4155
                try:
                    __zt_tmp = __attrs_135757075231696
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'personal_bar/user_actions', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757166282960, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item

                    # <Negate value=<Value u'python:1' (104:27)> at 7b78683eb5d0> -> __cache_135757075232208

                    # <Value u'python:1' (104:27)> -> __cache_135757075232208
                    __token = 4126
                    try:
                        __zt_tmp = __attrs_135757075231696
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075232208 = _static_135757244280656('python', u'1', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __cache_135757075232208 = not __cache_135757075232208
                    __condition = __cache_135757075232208
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b786dac0b90> name=None at 7b786dac0790> -> __attrs_135757166284688
                    __attrs_135757166284688 = _static_135757166283664

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166282896
                    __default_135757166282896 = _DEFAULT_MARKER

                    # <Substitution u'action/href' (105:42)> -> __attr_href
                    __token = 4225
                    try:
                        __zt_tmp = __attrs_135757166284688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('path', u'action/href', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166284368
                    __default_135757166284368 = _DEFAULT_MARKER

                    # <Substitution u'string:nav-link' (105:60)> -> __attr_class
                    __token = 4243
                    try:
                        __zt_tmp = __attrs_135757166284688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('string', u'nav-link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163048400
                    __attrs_135757163048400 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163048720
                    __default_135757163048720 = _DEFAULT_MARKER

                    # <Value u'action/title' (106:41)> -> __cache_135757166284752
                    __token = 4303
                    try:
                        __zt_tmp = __attrs_135757163048400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757166284752 = _static_135757244280656('path', u'action/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/title' (106:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786d7aa910> -> __condition
                    __expression = __cache_135757166284752

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n              action title\n            ')
                    else:
                        __content = __cache_135757166284752
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163046288
                    __attrs_135757163046288 = _static_135757327983760

                    # <Value u"python:action['id'] == 'personaltools-logout'" (109:37)> -> __condition
                    __token = 4412
                    try:
                        __zt_tmp = __attrs_135757163046288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"action['id'] == 'personaltools-logout'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n              ')

                        # <Static value=<_ast.Dict object at 0x7b786d7aa450> name=None at 7b786d7aa290> -> __attrs_135757163047568
                        __attrs_135757163047568 = _static_135757163045968

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="icon-logout"></span>\n            ')
                    __append(u'\n          </a>\n        ')
                    __condition = __cache_135757075232208
                    if __condition:
                        __append(u'</div>')
                    ____index_135757166282960 -= 1
                    if (____index_135757166282960 > 0):
                        __append('\n        ')
                if (__backup_action_135757152280080 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_135757152280080
                __append(u'\n      </li>')
            __append(u'\n\n    </ul>\n  </div>\n</nav>')
            __i18n_domain = __previous_i18n_domain_135757150462224
            if (__backup_personal_bar_135757226788880 is __marker):
                del econtext['personal_bar']
            else:
                econtext['personal_bar'] = __backup_personal_bar_135757226788880
            if (__backup_language_selector_135757152277264 is __marker):
                del econtext['language_selector']
            else:
                econtext['language_selector'] = __backup_language_selector_135757152277264
            if (__backup_global_sections_135757226787664 is __marker):
                del econtext['global_sections']
            else:
                econtext['global_sections'] = __backup_global_sections_135757226787664
            if (__backup_portal_state_135757137793552 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_135757137793552
            if (__backup_context_state_135757074242256 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_135757074242256
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }