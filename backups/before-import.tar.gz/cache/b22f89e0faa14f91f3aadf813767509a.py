# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/uidreference/input.pt'

__tokens = {147: (u'python:view.get_input_widget_attributes()', 5, 23), 219: (u' view/klas', 6, 28), 260: (u'e view/sty', 7, 27), 301: (u'le view/ti', 8, 26), 607: (u'python:view.name', 14, 32), 658: (u" python:'\\r\\n'.join(view.get_value()", 15, 32)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402100432080 = set([u'style', u'class', u'title', ])
_static_140402100294352 = {u'type': u'hidden', u'name': u'python:view.name', u'value': u"python:'\\r\\n'.join(view.get_value())", }
_static_140402272508048 = __compile_zt_expr
_static_140402100259024 = {u'style': u'view/style', u'class': u'view/klass', u'title': u'view/title', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402100257808 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e94fc410> name=None at 7fb1e94fc3d0> -> __attrs_140402100258384
            __attrs_140402100258384 = _static_140402100257808
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e94fc8d0> name=None at 7fb1e94fc850> -> __attrs_140402100260560
            __attrs_140402100260560 = _static_140402100259024

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Value u'python:view.get_input_widget_attributes()' (5:23)> -> __cache_140402100259472
            __token = 147
            try:
                __zt_tmp = __attrs_140402100260560
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402100259472 = _static_140402272508048('python', u'view.get_input_widget_attributes()', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_140402100765136 = __cache_140402100259472
            for (name, value, ) in __attr_140402100765136.items():
                if ((name not in _static_140402100432080) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100259664
            __default_140402100259664 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (6:28)> -> __attr_class
            __token = 219
            try:
                __zt_tmp = __attrs_140402100260560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100259920
            __default_140402100259920 = _DEFAULT_MARKER

            # <Substitution u'view/style' (7:27)> -> __attr_style
            __token = 260
            try:
                __zt_tmp = __attrs_140402100260560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100260176
            __default_140402100260176 = _DEFAULT_MARKER

            # <Substitution u'view/title' (8:26)> -> __attr_title
            __token = 301
            try:
                __zt_tmp = __attrs_140402100260560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))
            __append(u'>\r\n    <!-- ReactJS controlled component -->\r\n\r\n    <!-- The hidden input field provides the field value before the widget is rendered.\r\n         This is necessary if e.g. a JS requires the value directly after DOM loaded event -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e95052d0> name=None at 7fb1e9505310> -> __attrs_140402100295760
            __attrs_140402100295760 = _static_140402100294352

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100295248
            __default_140402100295248 = _DEFAULT_MARKER

            # <Substitution u'python:view.name' (14:32)> -> __attr_name
            __token = 607
            try:
                __zt_tmp = __attrs_140402100295760
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('python', u'view.name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100295504
            __default_140402100295504 = _DEFAULT_MARKER

            # <Substitution u"python:'\\r\\n'.join(view.get_value())" (15:32)> -> __attr_value
            __token = 658
            try:
                __zt_tmp = __attrs_140402100295760
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_140402272508048('python', u"'\\r\\n'.join(view.get_value())", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\r\n  </div>\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }