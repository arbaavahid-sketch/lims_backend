# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/controlpanel/templates/overview.pt'

__tokens = {440: (u"python:request.set('disable_plone.leftcolumn',1)", 11, 51), 541: (u" python:request.set('disable_plone.rightcolumn',1", 12, 50), 1022: (u'view/upgrade_warning', 25, 26), 1317: (u'string:${context/portal_url}/@@plone-upgrade', 33, 34), 1741: (u'view/mailhost_warning', 45, 26), 2321: (u'string:${portal_url}/@@mail-controlpanel', 56, 36), 2595: (u'view/timezone_warning', 65, 26), 3138: (u'string:${portal_url}/@@dateandtime-controlpanel', 77, 36), 3437: (u'not:view/pil', 86, 26), 3743: (u'view/categories', 95, 41), 3800: (u"python:view.sublists(category.get('id'))", 96, 38), 3933: (u'sublist', 97, 89), 4014: (u'category/title', 98, 70), 4215: (u'sublist', 102, 57), 4283: (u'sublist', 103, 57), 4344: (u'sublist', 104, 50), 4420: (u'action/visible', 105, 65), 4558: (u'action/icon', 108, 42), 4618: (u'action/url', 109, 46), 4684: (u"python:'icon-controlpanel-' + action['id'].replace('.', '_')", 110, 52), 4803: (u'action/title', 111, 48), 5189: (u'not:sublist', 124, 32), 5587: (u'view/version_overview', 137, 43), 5639: (u'version', 138, 27), 5736: (u'view/server_info', 140, 44), 5795: (u' server_info/wsg', 141, 40), 5942: (u'has_wsgi', 144, 51), 6014: (u'not:has_wsgi', 145, 51), 6151: (u'${server_info/server_name}', 149, 18), 6153: (u'server_info/server_name', 149, 20), 6204: (u'${server_info/version}', 150, 18), 6206: (u'server_info/version', 150, 20), 6314: (u'not:view/is_dev_mode', 155, 24), 6943: (u'view/is_dev_mode', 167, 24), 266: (u'here/prefs_main_template/macros/master', 6, 23), 266: (u'here/prefs_main_template/macros/master', 6, 23)}

from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525979686032 = {}
_static_124525521496080 = {u'class': u'documentFirstHeading', }
_static_124525521438544 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_124525734948688 = {u'href': u'#', u'title': u'Go to the upgrade page', }
_static_124525732010896 = {u'class': u'documentDescription text-secondary', }
_static_124525732329232 = {u'class': u'discreet', }
_static_124525521355152 = {u'class': u'portlet portletNavigationTree portletSiteSetup', }
_static_124525521604688 = {u'class': u'nav nav-pills', }
_static_124525521410512 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_124525521564304 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_124525521356496 = {u'class': u'portletHeader text-secondary', }
_static_124525732329936 = {u'class': u'row', }
_static_124525732293712 = u'master'
_static_124525896002064 = __C2ZContextWrapper
_static_124525520819984 = {u'href': u'', }
_static_124525732568080 = {u'class': u'nav-item col-sm-3', }
_static_124525896001680 = __compile_zt_expr
_static_124525779539984 = {u'class': u'discreet text-muted small', }
_static_124525732179728 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_124525520848528 = {u'class': u'discreet text-muted small', }
_static_124525520655312 = {u'class': u"python:'icon-controlpanel-' + action['id'].replace('.', '_')", }
_static_124525732329424 = {u'class': u'col-sm-12', }
_static_124525732566224 = {u'href': u'#', u'class': u'nav-link', }
_static_124525732330000 = {u'class': u'portletContent', }
_static_124525521437584 = {u'href': u'', }
_static_124525521057936 = {u'class': u'visualClear', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732293520
            __attrs_124525732293520 = _static_124525979686032
            __previous_i18n_domain_124525732292432 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_124525771001600 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x71416809ec50> name=None at 71416809ee10> -> __value
            __value = _static_124525732293712
            econtext['macroname'] = __value

            def __fill_top_slot(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521512080
                __attrs_124525521512080 = _static_124525979686032
                __backup_disable_column_one_124525735145808 = get('disable_column_one', __marker)

                # <Value u"python:request.set('disable_plone.leftcolumn',1)" (11:51)> -> __value
                __token = 440
                try:
                    __zt_tmp = __attrs_124525521512080
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u"request.set('disable_plone.leftcolumn',1)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['disable_column_one'] = __value
                __backup_disable_column_two_124525521408336 = get('disable_column_two', __marker)

                # <Value u"python:request.set('disable_plone.rightcolumn',1)" (12:50)> -> __value
                __token = 541
                try:
                    __zt_tmp = __attrs_124525521512080
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u"request.set('disable_plone.rightcolumn',1)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['disable_column_two'] = __value
                if (__backup_disable_column_two_124525521408336 is __marker):
                    del econtext['disable_column_two']
                else:
                    econtext['disable_column_two'] = __backup_disable_column_two_124525521408336
                if (__backup_disable_column_one_124525735145808 is __marker):
                    del econtext['disable_column_one']
                else:
                    econtext['disable_column_one'] = __backup_disable_column_one_124525735145808
            _slots = econtext[u'__slot_top_slot'] = _deque((__fill_top_slot, ))

            def __fill_prefs_configlet_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732306640
                __attrs_124525732306640 = _static_124525979686032

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b796810> name=None at 71415b7a3110> -> __attrs_124525731963472
                __attrs_124525731963472 = _static_124525521496080

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')
                __stream_124525521497104 = []
                __append_124525521497104 = __stream_124525521497104.append
                __append_124525521497104(u'Site Setup')
                __msgid_124525521497104 = __re_whitespace(''.join(__stream_124525521497104)).strip()
                if __msgid_124525521497104:
                    __append(translate(__msgid_124525521497104, mapping=None, default=__msgid_124525521497104, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h1>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x714168059b90> name=None at 714168059450> -> __attrs_124525521411664
                __attrs_124525521411664 = _static_124525732010896

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="documentDescription text-secondary">')
                __stream_124525732009872 = []
                __append_124525732009872 = __stream_124525732009872.append
                __append_124525732009872(u'\r\n        Configuration area for Plone and add-on Products.\r\n      ')
                __msgid_124525732009872 = __re_whitespace(''.join(__stream_124525732009872)).strip()
                if u'description_control_panel':
                    __append(translate(u'description_control_panel', mapping=None, default=__msgid_124525732009872, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b7819d0> name=None at 71415b781090> -> __attrs_124525732478288
                __attrs_124525732478288 = _static_124525521410512

                # <Value u'view/upgrade_warning' (25:26)> -> __condition
                __token = 1022
                try:
                    __zt_tmp = __attrs_124525732478288
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'view/upgrade_warning', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning"            role="status">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732178192
                    __attrs_124525732178192 = _static_124525979686032

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_124525732177680 = []
                    __append_124525732177680 = __stream_124525732177680.append
                    __append_124525732177680(u'\r\n          Warning\r\n        ')
                    __msgid_124525732177680 = __re_whitespace(''.join(__stream_124525732177680)).strip()
                    if __msgid_124525732177680:
                        __append(translate(__msgid_124525732177680, mapping=None, default=__msgid_124525732177680, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732178128
                    __attrs_124525732178128 = _static_124525979686032
                    __stream_124525521652864_link_continue_with_the_upgrade = ''
                    __stream_124525732179920 = []
                    __append_124525732179920 = __stream_124525732179920.append
                    __append_124525732179920(u'\r\n          The site configuration is outdated and needs to be\r\n          upgraded. Please\r\n          ')
                    __stream_124525521652864_link_continue_with_the_upgrade = []
                    __append_124525521652864_link_continue_with_the_upgrade = __stream_124525521652864_link_continue_with_the_upgrade.append

                    # <Static value=<_ast.Dict object at 0x714168326f50> name=None at 714168326f10> -> __attrs_124525521566608
                    __attrs_124525521566608 = _static_124525734948688

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_124525521652864_link_continue_with_the_upgrade(u'<a')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521564240
                    __default_124525521564240 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/portal_url}/@@plone-upgrade' (33:34)> -> __attr_href
                    __token = 1317
                    try:
                        __zt_tmp = __attrs_124525521566608
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('string', u'${context/portal_url}/@@plone-upgrade', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_124525521652864_link_continue_with_the_upgrade((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521565392
                    __default_124525521565392 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x71415b7a7650> at 71415b7a7fd0> -> __attr_title
                    __attr_title = u'Go to the upgrade page'
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append_124525521652864_link_continue_with_the_upgrade((u'              title="%s"' % __attr_title))
                    __append_124525521652864_link_continue_with_the_upgrade(u'>')
                    __stream_124525734944976 = []
                    __append_124525734944976 = __stream_124525734944976.append
                    __append_124525734944976(u'\r\n            continue with the upgrade\r\n          ')
                    __msgid_124525734944976 = __re_whitespace(''.join(__stream_124525734944976)).strip()
                    if __msgid_124525734944976:
                        __append_124525521652864_link_continue_with_the_upgrade(translate(__msgid_124525734944976, mapping=None, default=__msgid_124525734944976, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_124525521652864_link_continue_with_the_upgrade(u'</a>')
                    __append_124525732179920(u'${link_continue_with_the_upgrade}')
                    __stream_124525521652864_link_continue_with_the_upgrade = ''.join(__stream_124525521652864_link_continue_with_the_upgrade)
                    __append_124525732179920(u'.\r\n        ')
                    __msgid_124525732179920 = __re_whitespace(''.join(__stream_124525732179920)).strip()
                    if __msgid_124525732179920:
                        __append(translate(__msgid_124525732179920, mapping={u'link_continue_with_the_upgrade': __stream_124525521652864_link_continue_with_the_upgrade, }, default=__msgid_124525732179920, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\r\n      </div>')
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x714168082f10> name=None at 714168082f50> -> __attrs_124525521565456
                __attrs_124525521565456 = _static_124525732179728

                # <Value u'view/mailhost_warning' (45:26)> -> __condition
                __token = 1741
                try:
                    __zt_tmp = __attrs_124525521565456
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'view/mailhost_warning', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning"            role="status">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521567568
                    __attrs_124525521567568 = _static_124525979686032

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_124525521567376 = []
                    __append_124525521567376 = __stream_124525521567376.append
                    __append_124525521567376(u'\r\n          Warning\r\n        ')
                    __msgid_124525521567376 = __re_whitespace(''.join(__stream_124525521567376)).strip()
                    if __msgid_124525521567376:
                        __append(translate(__msgid_124525521567376, mapping=None, default=__msgid_124525521567376, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525800801488
                    __attrs_124525800801488 = _static_124525979686032
                    __stream_124525521652864_label_mail_control_panel_link = ''
                    __stream_124525521567440 = []
                    __append_124525521567440 = __stream_124525521567440.append
                    __append_124525521567440(u"\r\n          You have not configured a mail host or a site 'From'\r\n          address, various features including contact forms, email\r\n          notification and password reset will not work. Go to the\r\n          ")
                    __stream_124525521652864_label_mail_control_panel_link = []
                    __append_124525521652864_label_mail_control_panel_link = __stream_124525521652864_label_mail_control_panel_link.append

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525520819728
                    __attrs_124525520819728 = _static_124525979686032
                    __append_124525521652864_label_mail_control_panel_link(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x71415b6f1710> name=None at 71415b6f1f10> -> __attrs_124525520818384
                    __attrs_124525520818384 = _static_124525520819984

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_124525521652864_label_mail_control_panel_link(u'<a')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520820048
                    __default_124525520820048 = _DEFAULT_MARKER

                    # <Substitution u'string:${portal_url}/@@mail-controlpanel' (56:36)> -> __attr_href
                    __token = 2321
                    try:
                        __zt_tmp = __attrs_124525520818384
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('string', u'${portal_url}/@@mail-controlpanel', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_124525521652864_label_mail_control_panel_link((u' href="%s"' % __attr_href))
                    __append_124525521652864_label_mail_control_panel_link(u'             >')
                    __stream_124525520821072 = []
                    __append_124525520821072 = __stream_124525520821072.append
                    __append_124525520821072(u'Mail control panel')
                    __msgid_124525520821072 = __re_whitespace(''.join(__stream_124525520821072)).strip()
                    if u'text_no_mailhost_configured_control_panel_link':
                        __append_124525521652864_label_mail_control_panel_link(translate(u'text_no_mailhost_configured_control_panel_link', mapping=None, default=__msgid_124525520821072, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_124525521652864_label_mail_control_panel_link(u'</a>\r\n          ')
                    __append_124525521567440(u'${label_mail_control_panel_link}')
                    __stream_124525521652864_label_mail_control_panel_link = ''.join(__stream_124525521652864_label_mail_control_panel_link)
                    __append_124525521567440(u'\r\n          to fix this.\r\n        ')
                    __msgid_124525521567440 = __re_whitespace(''.join(__stream_124525521567440)).strip()
                    if u'text_no_mailhost_configured':
                        __append(translate(u'text_no_mailhost_configured', mapping={u'label_mail_control_panel_link': __stream_124525521652864_label_mail_control_panel_link, }, default=__msgid_124525521567440, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\r\n      </div>')
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b7a7290> name=None at 71415b7a7390> -> __attrs_124525520818832
                __attrs_124525520818832 = _static_124525521564304

                # <Value u'view/timezone_warning' (65:26)> -> __condition
                __token = 2595
                try:
                    __zt_tmp = __attrs_124525520818832
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'view/timezone_warning', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning"            role="status">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521439312
                    __attrs_124525521439312 = _static_124525979686032

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_124525521438288 = []
                    __append_124525521438288 = __stream_124525521438288.append
                    __append_124525521438288(u'\r\n          Warning\r\n        ')
                    __msgid_124525521438288 = __re_whitespace(''.join(__stream_124525521438288)).strip()
                    if __msgid_124525521438288:
                        __append(translate(__msgid_124525521438288, mapping=None, default=__msgid_124525521438288, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521437712
                    __attrs_124525521437712 = _static_124525979686032
                    __stream_124525521652864_label_mail_event_settings_link = ''
                    __stream_124525521437072 = []
                    __append_124525521437072 = __stream_124525521437072.append
                    __append_124525521437072(u'\r\n\r\n          You have not set the portal timezone. Date/Time handling will not\r\n          work properly for timezone aware date/time values.\r\n          Go to the\r\n          ')
                    __stream_124525521652864_label_mail_event_settings_link = []
                    __append_124525521652864_label_mail_event_settings_link = __stream_124525521652864_label_mail_event_settings_link.append

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521440464
                    __attrs_124525521440464 = _static_124525979686032
                    __append_124525521652864_label_mail_event_settings_link(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x71415b788390> name=None at 71415b788b50> -> __attrs_124525521058768
                    __attrs_124525521058768 = _static_124525521437584

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_124525521652864_label_mail_event_settings_link(u'<a')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521056464
                    __default_124525521056464 = _DEFAULT_MARKER

                    # <Substitution u'string:${portal_url}/@@dateandtime-controlpanel' (77:36)> -> __attr_href
                    __token = 3138
                    try:
                        __zt_tmp = __attrs_124525521058768
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('string', u'${portal_url}/@@dateandtime-controlpanel', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_124525521652864_label_mail_event_settings_link((u' href="%s"' % __attr_href))
                    __append_124525521652864_label_mail_event_settings_link(u'             >')
                    __stream_124525521438096 = []
                    __append_124525521438096 = __stream_124525521438096.append
                    __append_124525521438096(u'Date and Time Settings control panel')
                    __msgid_124525521438096 = __re_whitespace(''.join(__stream_124525521438096)).strip()
                    if u'text_no_timezone_configured_control_panel_link':
                        __append_124525521652864_label_mail_event_settings_link(translate(u'text_no_timezone_configured_control_panel_link', mapping=None, default=__msgid_124525521438096, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_124525521652864_label_mail_event_settings_link(u'</a>\r\n          ')
                    __append_124525521437072(u'${label_mail_event_settings_link}')
                    __stream_124525521652864_label_mail_event_settings_link = ''.join(__stream_124525521652864_label_mail_event_settings_link)
                    __append_124525521437072(u'\r\n          to fix this.\r\n        ')
                    __msgid_124525521437072 = __re_whitespace(''.join(__stream_124525521437072)).strip()
                    if u'text_no_timezone_configured':
                        __append(translate(u'text_no_timezone_configured', mapping={u'label_mail_event_settings_link': __stream_124525521652864_label_mail_event_settings_link, }, default=__msgid_124525521437072, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\r\n      </div>')
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b788750> name=None at 71415b788cd0> -> __attrs_124525521058256
                __attrs_124525521058256 = _static_124525521438544

                # <Value u'not:view/pil' (86:26)> -> __condition
                __token = 3437
                try:
                    __zt_tmp = __attrs_124525521058256
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('not', u'view/pil', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning"            role="status">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521058576
                    __attrs_124525521058576 = _static_124525979686032

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_124525521058320 = []
                    __append_124525521058320 = __stream_124525521058320.append
                    __append_124525521058320(u'\r\n          Warning\r\n        ')
                    __msgid_124525521058320 = __re_whitespace(''.join(__stream_124525521058320)).strip()
                    if __msgid_124525521058320:
                        __append(translate(__msgid_124525521058320, mapping=None, default=__msgid_124525521058320, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521059472
                    __attrs_124525521059472 = _static_124525979686032
                    __stream_124525521056208 = []
                    __append_124525521056208 = __stream_124525521056208.append
                    __append_124525521056208(u'\r\n          PIL is not installed properly, image scaling will not work.\r\n        ')
                    __msgid_124525521056208 = __re_whitespace(''.join(__stream_124525521056208)).strip()
                    if u'text_no_pil_installed':
                        __append(translate(u'text_no_pil_installed', mapping=None, default=__msgid_124525521056208, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\r\n      </div>')
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521056336
                __attrs_124525521056336 = _static_124525979686032
                __backup_category_124525520819664 = get('category', __marker)

                # <Value u'view/categories' (95:41)> -> __iterator
                __token = 3743
                try:
                    __zt_tmp = __attrs_124525521056336
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'view/categories', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525521057680, ) = getitem('repeat')(u'category', __iterator)
                econtext['category'] = None
                for __item in __iterator:
                    econtext['category'] = __item
                    __append(u'\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521057040
                    __attrs_124525521057040 = _static_124525979686032
                    __backup_sublist_124525734945744 = get('sublist', __marker)

                    # <Value u"python:view.sublists(category.get('id'))" (96:38)> -> __value
                    __token = 3800
                    try:
                        __zt_tmp = __attrs_124525521057040
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"view.sublists(category.get('id'))", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['sublist'] = __value
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x71415b774190> name=None at 71415b774090> -> __attrs_124525521357200
                    __attrs_124525521357200 = _static_124525521355152

                    # <Value u'sublist' (97:89)> -> __condition
                    __token = 3933
                    try:
                        __zt_tmp = __attrs_124525521357200
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('path', u'sublist', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <section ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<section class="portlet portletNavigationTree portletSiteSetup">\r\n            ')

                        # <Static value=<_ast.Dict object at 0x71415b7746d0> name=None at 71415b774390> -> __attrs_124525521355024
                        __attrs_124525521355024 = _static_124525521356496

                        # <strong ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<strong class="portletHeader text-secondary">')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521358096
                        __default_124525521358096 = _DEFAULT_MARKER

                        # <Value u'category/title' (98:70)> -> __cache_124525521357456
                        __token = 4014
                        try:
                            __zt_tmp = __attrs_124525521355024
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_124525521357456 = _static_124525896001680('path', u'category/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                        # <BinOp left=<Value u'category/title' (98:70)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b774050> -> __condition
                        __expression = __cache_124525521357456

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'Category')
                        else:
                            __content = __cache_124525521357456
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</strong>\r\n            ')

                        # <Static value=<_ast.Dict object at 0x7141680a79d0> name=None at 71415b7749d0> -> __attrs_124525732328592
                        __attrs_124525732328592 = _static_124525732329936

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="row">\r\n              ')

                        # <Static value=<_ast.Dict object at 0x7141680a77d0> name=None at 7141680a7210> -> __attrs_124525732330512
                        __attrs_124525732330512 = _static_124525732329424

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="col-sm-12">\r\n              ')

                        # <Static value=<_ast.Dict object at 0x7141680a7a10> name=None at 7141680a7590> -> __attrs_124525732328784
                        __attrs_124525732328784 = _static_124525732330000

                        # <Value u'sublist' (102:57)> -> __condition
                        __token = 4215
                        try:
                            __zt_tmp = __attrs_124525732328784
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_124525896001680('path', u'sublist', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        if __condition:

                            # <nav ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<nav class="portletContent">\r\n                ')

                            # <Static value=<_ast.Dict object at 0x71415b7b1050> name=None at 71415b7b1750> -> __attrs_124525521605520
                            __attrs_124525521605520 = _static_124525521604688

                            # <Value u'sublist' (103:57)> -> __condition
                            __token = 4283
                            try:
                                __zt_tmp = __attrs_124525521605520
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_124525896001680('path', u'sublist', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                            if __condition:

                                # <ul ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<ul class="nav nav-pills">\r\n                  ')

                                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521605584
                                __attrs_124525521605584 = _static_124525979686032
                                __backup_action_124525521496208 = get('action', __marker)

                                # <Value u'sublist' (104:50)> -> __iterator
                                __token = 4344
                                try:
                                    __zt_tmp = __attrs_124525521605584
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __iterator = _static_124525896001680('path', u'sublist', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                                (__iterator, ____index_124525521605456, ) = getitem('repeat')(u'action', __iterator)
                                econtext['action'] = None
                                for __item in __iterator:
                                    econtext['action'] = __item
                                    __append(u'\r\n                    ')

                                    # <Static value=<_ast.Dict object at 0x7141680e1c10> name=None at 71415b7b1ed0> -> __attrs_124525732568976
                                    __attrs_124525732568976 = _static_124525732568080

                                    # <Value u'action/visible' (105:65)> -> __condition
                                    __token = 4420
                                    try:
                                        __zt_tmp = __attrs_124525732568976
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __condition = _static_124525896001680('path', u'action/visible', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                                    if __condition:

                                        # <li ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<li class="nav-item col-sm-3">\r\n                      ')

                                        # <Static value=<_ast.Dict object at 0x7141680e14d0> name=None at 7141680e1b90> -> __attrs_124525732566608
                                        __attrs_124525732566608 = _static_124525732566224
                                        __backup_icon_124525732340880 = get('icon', __marker)

                                        # <Value u'action/icon' (108:42)> -> __value
                                        __token = 4558
                                        try:
                                            __zt_tmp = __attrs_124525732566608
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_124525896001680('path', u'action/icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                                        econtext['icon'] = __value

                                        # <a ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<a')

                                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732565776
                                        __default_124525732565776 = _DEFAULT_MARKER

                                        # <Substitution u'action/url' (109:46)> -> __attr_href
                                        __token = 4618
                                        try:
                                            __zt_tmp = __attrs_124525732566608
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_href = _static_124525896001680('path', u'action/url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                        if (__attr_href is not None):
                                            __append((u' href="%s"' % __attr_href))
                                        __append(u'                          class="nav-link">\r\n                        ')

                                        # <Static value=<_ast.Dict object at 0x71415b6c93d0> name=None at 71415b6c94d0> -> __attrs_124525520656912
                                        __attrs_124525520656912 = _static_124525520655312

                                        # <span ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<span')

                                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520654480
                                        __default_124525520654480 = _DEFAULT_MARKER

                                        # <Substitution u"python:'icon-controlpanel-' + action['id'].replace('.', '_')" (110:52)> -> __attr_class
                                        __token = 4684
                                        try:
                                            __zt_tmp = __attrs_124525520656912
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_124525896001680('python', u"'icon-controlpanel-' + action['id'].replace('.', '_')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'></span>\r\n                        ')

                                        # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732262224
                                        __attrs_124525732262224 = _static_124525979686032

                                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732262288
                                        __default_124525732262288 = _DEFAULT_MARKER

                                        # <Value u'action/title' (111:48)> -> __cache_124525732265296
                                        __token = 4803
                                        try:
                                            __zt_tmp = __attrs_124525732262224
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __cache_124525732265296 = _static_124525896001680('path', u'action/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                                        # <BinOp left=<Value u'action/title' (111:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168097c90> -> __condition
                                        __expression = __cache_124525732265296

                                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                                        __value = _DEFAULT_MARKER
                                        __condition = (__expression is __value)
                                        if __condition:
                                            __append(u'\r\n                          Title\r\n                        ')
                                        else:
                                            __content = __cache_124525732265296
                                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                            __content = __quote(__content, None, '\xad', None, None)
                                            if (__content is not None):
                                                __append(__content)
                                        __append(u'\r\n                      </a>')
                                        if (__backup_icon_124525732340880 is __marker):
                                            del econtext['icon']
                                        else:
                                            econtext['icon'] = __backup_icon_124525732340880
                                        __append(u'\r\n                    </li>')
                                    __append(u'\r\n                  ')
                                    ____index_124525521605456 -= 1
                                    if (____index_124525521605456 > 0):
                                        __append('')
                                if (__backup_action_124525521496208 is __marker):
                                    del econtext['action']
                                else:
                                    econtext['action'] = __backup_action_124525521496208
                                __append(u'\r\n                </ul>')
                            __append(u'\r\n              </nav>')
                        __append(u'\r\n              </div>\r\n            </div>\r\n\r\n            ')

                        # <Static value=<_ast.Dict object at 0x7141680a7710> name=None at 7141680a7510> -> __attrs_124525521605392
                        __attrs_124525521605392 = _static_124525732329232

                        # <Value u'not:sublist' (124:32)> -> __condition
                        __token = 5189
                        try:
                            __zt_tmp = __attrs_124525521605392
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_124525896001680('not', u'sublist', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="discreet">')
                            __stream_124525732331280 = []
                            __append_124525732331280 = __stream_124525732331280.append
                            __append_124525732331280(u'\r\n              No preference panels available.\r\n            ')
                            __msgid_124525732331280 = __re_whitespace(''.join(__stream_124525732331280)).strip()
                            if u'label_no_prefs_panels_available':
                                __append(translate(u'label_no_prefs_panels_available', mapping=None, default=__msgid_124525732331280, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</div>')
                        __append(u'\r\n\r\n          </section>')
                    __append(u'\r\n        ')
                    if (__backup_sublist_124525734945744 is __marker):
                        del econtext['sublist']
                    else:
                        econtext['sublist'] = __backup_sublist_124525734945744
                    __append(u'\r\n      ')
                    ____index_124525521057680 -= 1
                    if (____index_124525521057680 > 0):
                        __append('')
                if (__backup_category_124525520819664 is __marker):
                    del econtext['category']
                else:
                    econtext['category'] = __backup_category_124525520819664
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b72b890> name=None at 71415b72b050> -> __attrs_124525521357008
                __attrs_124525521357008 = _static_124525521057936

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="visualClear"><!-- --></div>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732265488
                __attrs_124525732265488 = _static_124525979686032

                # <h2 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h2>')
                __stream_124525732565136 = []
                __append_124525732565136 = __stream_124525732565136.append
                __append_124525732565136(u'Version Overview')
                __msgid_124525732565136 = __re_whitespace(''.join(__stream_124525732565136)).strip()
                if u'heading_version_overview':
                    __append(translate(u'heading_version_overview', mapping=None, default=__msgid_124525732565136, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h2>\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732262864
                __attrs_124525732262864 = _static_124525979686032

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul>\r\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732265872
                __attrs_124525732265872 = _static_124525979686032
                __backup_version_124525732341712 = get('version', __marker)

                # <Value u'view/version_overview' (137:43)> -> __iterator
                __token = 5587
                try:
                    __zt_tmp = __attrs_124525732265872
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'view/version_overview', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525732262096, ) = getitem('repeat')(u'version', __iterator)
                econtext['version'] = None
                for __item in __iterator:
                    econtext['version'] = __item
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521712400
                    __attrs_124525521712400 = _static_124525979686032

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734498704
                    __default_124525734498704 = _DEFAULT_MARKER

                    # <Value u'version' (138:27)> -> __cache_124525734656016
                    __token = 5639
                    try:
                        __zt_tmp = __attrs_124525521712400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525734656016 = _static_124525896001680('path', u'version', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'version' (138:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141682b9f10> -> __condition
                    __expression = __cache_124525734656016

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Version')
                    else:
                        __content = __cache_124525734656016
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</li>\r\n        ')
                    ____index_124525732262096 -= 1
                    if (____index_124525732262096 > 0):
                        __append('')
                if (__backup_version_124525732341712 is __marker):
                    del econtext['version']
                else:
                    econtext['version'] = __backup_version_124525732341712
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521714640
                __attrs_124525521714640 = _static_124525979686032
                __backup_server_info_124525521583440 = get('server_info', __marker)

                # <Value u'view/server_info' (140:44)> -> __value
                __token = 5736
                try:
                    __zt_tmp = __attrs_124525521714640
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'view/server_info', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['server_info'] = __value
                __backup_has_wsgi_124525521510672 = get('has_wsgi', __marker)

                # <Value u'server_info/wsgi' (141:40)> -> __value
                __token = 5795
                try:
                    __zt_tmp = __attrs_124525521714640
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'server_info/wsgi', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['has_wsgi'] = __value
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521523152
                __attrs_124525521523152 = _static_124525979686032

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521522960
                __attrs_124525521522960 = _static_124525979686032
                __stream_124525521525072 = []
                __append_124525521525072 = __stream_124525521525072.append
                __append_124525521525072(u'WSGI:')
                __msgid_124525521525072 = __re_whitespace(''.join(__stream_124525521525072)).strip()
                if __msgid_124525521525072:
                    __append(translate(__msgid_124525521525072, mapping=None, default=__msgid_124525521525072, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525734553872
                __attrs_124525734553872 = _static_124525979686032

                # <Value u'has_wsgi' (144:51)> -> __condition
                __token = 5942
                try:
                    __zt_tmp = __attrs_124525734553872
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'has_wsgi', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_124525521523408 = []
                    __append_124525521523408 = __stream_124525521523408.append
                    __append_124525521523408(u'On')
                    __msgid_124525521523408 = __re_whitespace(''.join(__stream_124525521523408)).strip()
                    if __msgid_124525521523408:
                        __append(translate(__msgid_124525521523408, mapping=None, default=__msgid_124525521523408, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732308880
                __attrs_124525732308880 = _static_124525979686032

                # <Value u'not:has_wsgi' (145:51)> -> __condition
                __token = 6014
                try:
                    __zt_tmp = __attrs_124525732308880
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('not', u'has_wsgi', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_124525732308816 = []
                    __append_124525732308816 = __stream_124525732308816.append
                    __append_124525732308816(u'Off')
                    __msgid_124525732308816 = __re_whitespace(''.join(__stream_124525732308816)).strip()
                    if __msgid_124525732308816:
                        __append(translate(__msgid_124525732308816, mapping=None, default=__msgid_124525732308816, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\r\n          </li>\r\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525779539280
                __attrs_124525779539280 = _static_124525979686032

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732573008
                __attrs_124525732573008 = _static_124525979686032
                __stream_124525734743568 = []
                __append_124525734743568 = __stream_124525734743568.append
                __append_124525734743568(u'Server:')
                __msgid_124525734743568 = __re_whitespace(''.join(__stream_124525734743568)).strip()
                if __msgid_124525734743568:
                    __append(translate(__msgid_124525734743568, mapping=None, default=__msgid_124525734743568, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732571920
                __attrs_124525732571920 = _static_124525979686032

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Interpolation value=<Substitution u'${server_info/server_name}' (149:18)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7141680e2490> -> __content_124526048908512
                __token = 6151
                __token = 6153
                try:
                    __zt_tmp = __attrs_124525732571920
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_124526048908512 = _static_124525896001680('path', u'server_info/server_name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __content_124526048908512 = __quote(__content_124526048908512, '\x00', '&#0;', None, None)
                __content_124526048908512 = __content_124526048908512
                if (__content_124526048908512 is None):
                    pass
                else:
                    if (__content_124526048908512 is None):
                        __content_124526048908512 = None
                    else:
                        __tt = type(__content_124526048908512)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_124526048908512 = unicode(__content_124526048908512)
                        else:
                            if (__tt is str):
                                __content_124526048908512 = decode(__content_124526048908512)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_124526048908512 = __content_124526048908512.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_124526048908512)
                                        __content_124526048908512 = (unicode(__content_124526048908512) if (__content_124526048908512 is __converted) else __converted)
                                    else:
                                        __content_124526048908512 = __content_124526048908512()
                if (__content_124526048908512 is not None):
                    __append(__content_124526048908512)
                __append(u'</span>\r\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521496144
                __attrs_124525521496144 = _static_124525979686032

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Interpolation value=<Substitution u'${server_info/version}' (150:18)> braces_required=True translation=False default='"?"' default_marker='"?"' at 71415b6f8250> -> __content_124526048908512
                __token = 6204
                __token = 6206
                try:
                    __zt_tmp = __attrs_124525521496144
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_124526048908512 = _static_124525896001680('path', u'server_info/version', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __content_124526048908512 = __quote(__content_124526048908512, '\x00', '&#0;', None, None)
                __content_124526048908512 = __content_124526048908512
                if (__content_124526048908512 is None):
                    pass
                else:
                    if (__content_124526048908512 is None):
                        __content_124526048908512 = None
                    else:
                        __tt = type(__content_124526048908512)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_124526048908512 = unicode(__content_124526048908512)
                        else:
                            if (__tt is str):
                                __content_124526048908512 = decode(__content_124526048908512)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_124526048908512 = __content_124526048908512.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_124526048908512)
                                        __content_124526048908512 = (unicode(__content_124526048908512) if (__content_124526048908512 is __converted) else __converted)
                                    else:
                                        __content_124526048908512 = __content_124526048908512()
                if (__content_124526048908512 is not None):
                    __append(__content_124526048908512)
                __append(u'</span>\r\n          </li>\r\n        ')
                if (__backup_has_wsgi_124525521510672 is __marker):
                    del econtext['has_wsgi']
                else:
                    econtext['has_wsgi'] = __backup_has_wsgi_124525521510672
                if (__backup_server_info_124525521583440 is __marker):
                    del econtext['server_info']
                else:
                    econtext['server_info'] = __backup_server_info_124525521583440
                __append(u'\r\n      </ul>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71416adad810> name=None at 71415b7cb150> -> __attrs_124525520848144
                __attrs_124525520848144 = _static_124525779539984

                # <Value u'not:view/is_dev_mode' (155:24)> -> __condition
                __token = 6314
                try:
                    __zt_tmp = __attrs_124525520848144
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('not', u'view/is_dev_mode', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p          class="discreet text-muted small">')
                    __stream_124525521712848 = []
                    __append_124525521712848 = __stream_124525521712848.append
                    __append_124525521712848(u'\r\n        You are running in "production mode". This is the preferred mode of\r\n        operation for a live Plone site, but means that some\r\n        configuration changes will not take effect until your server is\r\n        restarted or a product refreshed. If this is a development instance,\r\n        and you want to enable debug mode, stop the server, set \'debug-mode=on\'\r\n        in your buildout.cfg, re-run bin/buildout and then restart the server\r\n        process.\r\n      ')
                    __msgid_124525521712848 = __re_whitespace(''.join(__stream_124525521712848)).strip()
                    if u'description_production_mode':
                        __append(translate(u'description_production_mode', mapping=None, default=__msgid_124525521712848, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>')
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b6f8690> name=None at 71415b6f8490> -> __attrs_124525521675216
                __attrs_124525521675216 = _static_124525520848528

                # <Value u'view/is_dev_mode' (167:24)> -> __condition
                __token = 6943
                try:
                    __zt_tmp = __attrs_124525521675216
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'view/is_dev_mode', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p          class="discreet text-muted small">')
                    __stream_124525520847504 = []
                    __append_124525520847504 = __stream_124525520847504.append
                    __append_124525520847504(u'\r\n        You are running in "debug mode". This mode is intended for sites that\r\n        are under development. This allows many configuration changes to be\r\n        immediately visible, but will make your site run more slowly. To turn\r\n        off debug mode, stop the server, set \'debug-mode=off\' in your\r\n        buildout.cfg, re-run bin/buildout and then restart the server\r\n        process.\r\n      ')
                    __msgid_124525520847504 = __re_whitespace(''.join(__stream_124525520847504)).strip()
                    if u'description_debug_mode':
                        __append(translate(u'description_debug_mode', mapping=None, default=__msgid_124525520847504, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>')
                __append(u'\r\n\r\n    </div>')
            _slots = econtext[u'__slot_prefs_configlet_main'] = _deque((__fill_prefs_configlet_main, ))

            # <Value u'here/prefs_main_template/macros/master' (6:23)> -> __macro
            __token = 266
            try:
                __zt_tmp = __attrs_124525732293520
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_124525896001680('path', u'here/prefs_main_template/macros/master', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __token = 266
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_124525771001600 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_124525771001600
            __i18n_domain = __previous_i18n_domain_124525732292432
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }