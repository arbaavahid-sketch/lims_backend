# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.formwidget.namedfile-2.1.3-py2.7.egg/plone/formwidget/namedfile/image_input.pt'

__tokens = {972: (u'view/download_url', 24, 29), 1013: (u' python: view.value is not Non', 25, 22), 1067: (u'n view/acti', 26, 21), 1110: (u'ge view/allow_nocha', 27, 28), 1155: (u'ype view/file_content_', 28, 21), 1199: (u'icon view/file', 29, 16), 1239: (u'ename view/fi', 30, 19), 53: (u'view/id', 3, 23), 87: (u' view/klas', 4, 25), 124: (u'e view/sty', 5, 24), 161: (u'le view/ti', 6, 23), 197: (u'ang view/', 7, 21), 235: (u'lick view/on', 8, 23), 279: (u'click view/ondb', 9, 25), 327: (u'sedown view/onmo', 10, 25), 374: (u'mouseup view/o', 11, 22), 421: (u'ouseover view/on', 12, 23), 470: (u'mousemove view/o', 13, 22), 518: (u'onmouseout view', 14, 20), 565: (u' onkeypress vie', 15, 19), 611: (u'   onkeydown v', 16, 17), 654: (u'      onkeyu', 17, 14), 695: (u'       onfoc', 18, 13), 735: (u'         on', 19, 11), 776: (u'        oncha', 20, 12), 819: (u'         read', 21, 11), 863: (u'         acces', 22, 11), 907: (u'           on', 23, 9), 1292: (u'view/file_upload_id', 31, 30), 1328: (u'up_id', 31, 66), 1369: (u'${view/name}.file_upload_id', 32, 33), 1371: (u'view/name', 32, 35), 1405: (u'${up_id}', 32, 69), 1407: (u'up_id', 32, 71), 1531: (u'${view/value/filename}', 35, 8), 1533: (u'view/value/filename', 35, 10), 1607: (u"python:exists and download_url and action=='nochange'", 38, 25), 1693: (u'download_url', 39, 30), 1746: (u'view/thumb_tag', 40, 38), 1809: (u'icon', 42, 28), 1862: (u'icon', 43, 33), 1900: (u' doc_typ', 44, 32), 1944: (u'e filena', 45, 33), 2038: (u'download_url', 48, 33), 1995: (u'filename', 47, 25), 2142: (u'doc_type', 50, 64), 2184: (u'doc_type', 51, 31), 2302: (u'view/file_size', 53, 37), 2331: (u'sizekb', 53, 66), 2438: (u'allow_nochange', 57, 24), 2612: (u'string:${view/name}.action', 62, 33), 2670: (u' string:${view/id}-nochang', 63, 30), 2733: (u"k string:document.getElementById('${view/id}-input').disabled=tr", 64, 34), 2834: (u"ed python:'checked' if action == 'nochange' else N", 65, 33), 2951: (u'string:${view/id}-nochange', 68, 32), 3065: (u'not:view/field/required', 69, 30), 3259: (u'string:${view/name}.action', 75, 37), 3321: (u' string:${view/id}-remov', 76, 34), 3386: (u"k string:document.getElementById('${view/id}-input').disabled=tr", 77, 38), 3491: (u"ed python:'checked' if action == 'remove' else N", 78, 37), 3618: (u'string:${view/id}-remove', 81, 36), 3870: (u'string:${view/name}.action', 88, 33), 3928: (u' string:${view/id}-replac', 89, 30), 3990: (u"k string:document.getElementById('${view/id}-input').disabled=fal", 90, 34), 4092: (u"ed python:'checked' if action == 'replace' else N", 91, 33), 4208: (u'string:${view/id}-replace', 94, 32), 4331: (u'not:allow_nochange', 96, 23), 4471: (u'string:${view/id}-input', 99, 31), 4528: (u' view/nam', 100, 32), 4571: (u'e view/si', 101, 31), 4618: (u'ed view/disab', 102, 34), 4670: (u'gth view/maxle', 103, 34), 4737: (u"python:allow_nochange and action != 'replace'", 105, 31), 4832: (u"string:document.getElementById('${view/id}-input').disabled=true;", 106, 25)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525732513488 = {u'checked': u"python:'checked' if action == 'replace' else None", u'name': u'string:${view/name}.action', u'value': u'replace', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=false", u'type': u'radio', u'id': u'string:${view/id}-replace', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525732570704 = {u'name': u'view/name', u'disabled': u'view/disabled', u'maxlength': u'view/maxlength', u'type': u'file', u'id': u'string:${view/id}-input', u'size': u'view/size', }
_static_124525979686032 = {}
_static_124525521705296 = {u'src': u'', u'alt': u'', u'title': u'filename', }
_static_124525732572816 = {u'style': u'padding-left: 1.5em; padding-top: 0.5em;', }
_static_124525521508688 = {u'checked': u"python:'checked' if action == 'nochange' else None", u'name': u'string:${view/name}.action', u'value': u'nochange', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=true", u'type': u'radio', u'id': u'string:${view/id}-nochange', }
_static_124525732187536 = {u'href': u'download_url', }
_static_124525732203536 = {u'for': u'string:${view/id}-nochange', }
_static_124525732512080 = {u'for': u'string:${view/id}-remove', }
_static_124525732011920 = {u'lang': u'view/lang', u'style': u'view/style', u'onchange': u'view/onchange', u'onmousedown': u'view/onmousedown', u'onmouseup': u'view/onmouseup', u'onmouseout': u'view/onmouseout', u'title': u'view/title', u'accesskey': u'view/accesskey', u'onkeypress': u'view/onkeypress', u'onblur': u'view/onblur', u'onkeydown': u'view/onkeydown', u'class': u'view/klass', u'readonly': u'view/readonly', u'onselect': u'view/onselect', u'onmousemove': u'view/onmousemove', u'onmouseover': u'view/onmouseover', u'onclick': u'view/onclick', u'onkeyup': u'view/onkeyup', u'onfocus': u'view/onfocus', u'ondblclick': u'view/ondblclick', u'id': u'view/id', }
_static_124525732571408 = {u'for': u'string:${view/id}-replace', }
_static_124525732223760 = {u'type': u'hidden', u'name': u'${view/name}.file_upload_id', u'value': u'${up_id}', }
_static_124525735173072 = {u'href': u'download_url', }
_static_124525731872976 = {u'checked': u"python:'checked' if action == 'remove' else None", u'name': u'string:${view/name}.action', u'value': u'remove', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=true", u'type': u'radio', u'id': u'string:${view/id}-remove', }
_static_124525733246352 = {u'type': u'text/javascript', }
_static_124525732184784 = {u'class': u'discreet', }
_static_124525896001680 = __compile_zt_expr
_static_124525732186000 = {u'style': u'padding-top: 1em;', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714168059f90> name=None at 714168059f10> -> __attrs_124525521886992
            __attrs_124525521886992 = _static_124525732011920
            __backup_download_url_124525732518928 = get('download_url', __marker)

            # <Value u'view/download_url' (24:29)> -> __value
            __token = 972
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/download_url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['download_url'] = __value
            __backup_exists_124525732010384 = get('exists', __marker)

            # <Value u'python: view.value is not None' (25:22)> -> __value
            __token = 1013
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u' view.value is not None', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['exists'] = __value
            __backup_action_124525521579536 = get('action', __marker)

            # <Value u'view/action' (26:21)> -> __value
            __token = 1067
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/action', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['action'] = __value
            __backup_allow_nochange_124525732008784 = get('allow_nochange', __marker)

            # <Value u'view/allow_nochange' (27:28)> -> __value
            __token = 1110
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/allow_nochange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['allow_nochange'] = __value
            __backup_doc_type_124525732011280 = get('doc_type', __marker)

            # <Value u'view/file_content_type' (28:21)> -> __value
            __token = 1155
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/file_content_type', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['doc_type'] = __value
            __backup_icon_124525521886672 = get('icon', __marker)

            # <Value u'view/file_icon' (29:16)> -> __value
            __token = 1199
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/file_icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['icon'] = __value
            __backup_filename_124525521886800 = get('filename', __marker)

            # <Value u'view/filename' (30:19)> -> __value
            __token = 1239
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/filename', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['filename'] = __value
            __previous_i18n_domain_124525521883536 = __i18n_domain
            __i18n_domain = u'plone'

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732250896
            __default_124525732250896 = _DEFAULT_MARKER

            # <Substitution u'view/id' (3:23)> -> __attr_id
            __token = 53
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_124525896001680('path', u'view/id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732252880
            __default_124525732252880 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (4:25)> -> __attr_class
            __token = 87
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_124525896001680('path', u'view/klass', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732252944
            __default_124525732252944 = _DEFAULT_MARKER

            # <Substitution u'view/style' (5:24)> -> __attr_style
            __token = 124
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_124525896001680('path', u'view/style', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734553744
            __default_124525734553744 = _DEFAULT_MARKER

            # <Substitution u'view/title' (6:23)> -> __attr_title
            __token = 161
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_124525896001680('path', u'view/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732192912
            __default_124525732192912 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (7:21)> -> __attr_lang
            __token = 197
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_124525896001680('path', u'view/lang', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732194768
            __default_124525732194768 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (8:23)> -> __attr_onclick
            __token = 235
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_124525896001680('path', u'view/onclick', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732193296
            __default_124525732193296 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (9:25)> -> __attr_ondblclick
            __token = 279
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_124525896001680('path', u'view/ondblclick', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732194384
            __default_124525732194384 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (10:25)> -> __attr_onmousedown
            __token = 327
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_124525896001680('path', u'view/onmousedown', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732195920
            __default_124525732195920 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (11:22)> -> __attr_onmouseup
            __token = 374
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_124525896001680('path', u'view/onmouseup', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732195088
            __default_124525732195088 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (12:23)> -> __attr_onmouseover
            __token = 421
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_124525896001680('path', u'view/onmouseover', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732194064
            __default_124525732194064 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (13:22)> -> __attr_onmousemove
            __token = 470
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_124525896001680('path', u'view/onmousemove', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732196304
            __default_124525732196304 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (14:20)> -> __attr_onmouseout
            __token = 518
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_124525896001680('path', u'view/onmouseout', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732194576
            __default_124525732194576 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (15:19)> -> __attr_onkeypress
            __token = 565
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_124525896001680('path', u'view/onkeypress', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732193104
            __default_124525732193104 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (16:17)> -> __attr_onkeydown
            __token = 611
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_124525896001680('path', u'view/onkeydown', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732192784
            __default_124525732192784 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (17:14)> -> __attr_onkeyup
            __token = 654
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_124525896001680('path', u'view/onkeyup', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521883344
            __default_124525521883344 = _DEFAULT_MARKER

            # <Substitution u'view/onfocus' (18:13)> -> __attr_onfocus
            __token = 695
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onfocus = _static_124525896001680('path', u'view/onfocus', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onfocus = __quote(__attr_onfocus, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onfocus is not None):
                __append((u' onfocus="%s"' % __attr_onfocus))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521883472
            __default_124525521883472 = _DEFAULT_MARKER

            # <Substitution u'view/onblur' (19:11)> -> __attr_onblur
            __token = 735
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onblur = _static_124525896001680('path', u'view/onblur', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onblur = __quote(__attr_onblur, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onblur is not None):
                __append((u' onblur="%s"' % __attr_onblur))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521884432
            __default_124525521884432 = _DEFAULT_MARKER

            # <Substitution u'view/onchange' (20:12)> -> __attr_onchange
            __token = 776
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onchange = _static_124525896001680('path', u'view/onchange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onchange = __quote(__attr_onchange, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onchange is not None):
                __append((u' onchange="%s"' % __attr_onchange))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521884880
            __default_124525521884880 = _DEFAULT_MARKER

            # <Boolean u'view/readonly' (21:11)> -> __attr_readonly
            __token = 819
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_readonly = _static_124525896001680('path', u'view/readonly', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if (__attr_readonly is _DEFAULT_MARKER):
                __attr_readonly = None
            else:
                if __attr_readonly:
                    __attr_readonly = u'readonly'
                else:
                    __attr_readonly = None
            if (__attr_readonly is not None):
                __append((u' readonly="%s"' % __attr_readonly))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521883600
            __default_124525521883600 = _DEFAULT_MARKER

            # <Substitution u'view/accesskey' (22:11)> -> __attr_accesskey
            __token = 863
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_accesskey = _static_124525896001680('path', u'view/accesskey', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_accesskey = __quote(__attr_accesskey, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_accesskey is not None):
                __append((u' accesskey="%s"' % __attr_accesskey))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521883664
            __default_124525521883664 = _DEFAULT_MARKER

            # <Substitution u'view/onselect' (23:9)> -> __attr_onselect
            __token = 907
            try:
                __zt_tmp = __attrs_124525521886992
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onselect = _static_124525896001680('path', u'view/onselect', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_onselect = __quote(__attr_onselect, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onselect is not None):
                __append((u' onselect="%s"' % __attr_onselect))
            __append(u'>\n    ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732222608
            __attrs_124525732222608 = _static_124525979686032
            __backup_up_id_124525521886864 = get('up_id', __marker)

            # <Value u'view/file_upload_id' (31:30)> -> __value
            __token = 1292
            try:
                __zt_tmp = __attrs_124525732222608
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/file_upload_id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['up_id'] = __value

            # <Value u'up_id' (31:66)> -> __condition
            __token = 1328
            try:
                __zt_tmp = __attrs_124525732222608
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'up_id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x71416808db10> name=None at 71416808db50> -> __attrs_124525732224720
                __attrs_124525732224720 = _static_124525732223760

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732221072
                __default_124525732221072 = _DEFAULT_MARKER

                # <Interpolation value=<Substitution u'${view/name}.file_upload_id' (32:33)> braces_required=True translation=False default='"?"' default_marker='"?"' at 71416808dd90> -> __attr_name
                __token = 1369
                __token = 1371
                try:
                    __zt_tmp = __attrs_124525732224720
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_124525896001680('path', u'view/name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_name = ('%s%s' % ((__attr_name if (__attr_name is not None) else ''), u'.file_upload_id', ))
                if (__attr_name is None):
                    pass
                else:
                    if (__attr_name is _DEFAULT_MARKER):
                        __attr_name = None
                    else:
                        __tt = type(__attr_name)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __attr_name = unicode(__attr_name)
                        else:
                            if (__tt is str):
                                __attr_name = decode(__attr_name)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __attr_name = __attr_name.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__attr_name)
                                        __attr_name = (unicode(__attr_name) if (__attr_name is __converted) else __converted)
                                    else:
                                        __attr_name = __attr_name()
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732224912
                __default_124525732224912 = _DEFAULT_MARKER

                # <Interpolation value=<Substitution u'${up_id}' (32:69)> braces_required=True translation=False default='"?"' default_marker='"?"' at 71416808de90> -> __attr_value
                __token = 1405
                __token = 1407
                try:
                    __zt_tmp = __attrs_124525732224720
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_124525896001680('path', u'up_id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_value = __attr_value
                if (__attr_value is None):
                    pass
                else:
                    if (__attr_value is _DEFAULT_MARKER):
                        __attr_value = None
                    else:
                        __tt = type(__attr_value)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __attr_value = unicode(__attr_value)
                        else:
                            if (__tt is str):
                                __attr_value = decode(__attr_value)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __attr_value = __attr_value.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__attr_value)
                                        __attr_value = (unicode(__attr_value) if (__attr_value is __converted) else __converted)
                                    else:
                                        __attr_value = __attr_value()
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732222224
                __attrs_124525732222224 = _static_124525979686032

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525735012240
                __attrs_124525735012240 = _static_124525979686032
                __stream_124525732224848 = []
                __append_124525732224848 = __stream_124525732224848.append
                __append_124525732224848(u'Image already uploaded:')
                __msgid_124525732224848 = __re_whitespace(''.join(__stream_124525732224848)).strip()
                if u'image_already_uploaded':
                    __append(translate(u'image_already_uploaded', mapping=None, default=__msgid_124525732224848, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))

                # <Interpolation value=<Substitution u'\n        ${view/value/filename}\n      ' (34:92)> braces_required=True translation=False default='"?"' default_marker='"?"' at 71416808d910> -> __content_124526048908512
                __token = 1531
                __token = 1533
                try:
                    __zt_tmp = __attrs_124525732222224
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_124526048908512 = _static_124525896001680('path', u'view/value/filename', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __content_124526048908512 = __quote(__content_124526048908512, '\x00', '&#0;', None, None)
                __content_124526048908512 = ('%s%s%s' % (u'\n        ', (__content_124526048908512 if (__content_124526048908512 is not None) else ''), u'\n      ', ))
                if (__content_124526048908512 is None):
                    pass
                else:
                    if (__content_124526048908512 is None):
                        __content_124526048908512 = None
                    else:
                        __tt = type(__content_124526048908512)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_124526048908512 = unicode(__content_124526048908512)
                        else:
                            if (__tt is str):
                                __content_124526048908512 = decode(__content_124526048908512)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_124526048908512 = __content_124526048908512.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_124526048908512)
                                        __content_124526048908512 = (unicode(__content_124526048908512) if (__content_124526048908512 is __converted) else __converted)
                                    else:
                                        __content_124526048908512 = __content_124526048908512()
                if (__content_124526048908512 is not None):
                    __append(__content_124526048908512)
                __append(u'</span>\n    ')
            if (__backup_up_id_124525521886864 is __marker):
                del econtext['up_id']
            else:
                econtext['up_id'] = __backup_up_id_124525521886864
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732224464
            __attrs_124525732224464 = _static_124525979686032

            # <Value u"python:exists and download_url and action=='nochange'" (38:25)> -> __condition
            __token = 1607
            try:
                __zt_tmp = __attrs_124525732224464
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u"exists and download_url and action=='nochange'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>\n      ')

                # <Static value=<_ast.Dict object at 0x71416835dbd0> name=None at 71416835d750> -> __attrs_124525734609232
                __attrs_124525734609232 = _static_124525735173072

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525735171856
                __default_124525735171856 = _DEFAULT_MARKER

                # <Substitution u'download_url' (39:30)> -> __attr_href
                __token = 1693
                try:
                    __zt_tmp = __attrs_124525734609232
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_124525896001680('path', u'download_url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521704976
                __attrs_124525521704976 = _static_124525979686032

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521706128
                __default_124525521706128 = _DEFAULT_MARKER

                # <Value u'view/thumb_tag' (40:38)> -> __cache_124525521703184
                __token = 1746
                try:
                    __zt_tmp = __attrs_124525521704976
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521703184 = _static_124525896001680('path', u'view/thumb_tag', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/thumb_tag' (40:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c9d90> -> __condition
                __expression = __cache_124525521703184

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img/>')
                else:
                    __content = __cache_124525521703184
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n      </a>')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521706320
                __attrs_124525521706320 = _static_124525979686032

                # <br ... (0:0)
                # --------------------------------------------------------
                __append(u'<br />\n        ')

                # <Static value=<_ast.Dict object at 0x71415b7c9950> name=None at 71415b7c91d0> -> __attrs_124525521704336
                __attrs_124525521704336 = _static_124525521705296

                # <Value u'icon' (42:28)> -> __condition
                __token = 1809
                try:
                    __zt_tmp = __attrs_124525521704336
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521704208
                    __default_124525521704208 = _DEFAULT_MARKER

                    # <Substitution u'icon' (43:33)> -> __attr_src
                    __token = 1862
                    try:
                        __zt_tmp = __attrs_124525521704336
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_src = _static_124525896001680('path', u'icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_src is not None):
                        __append((u' src="%s"' % __attr_src))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521705744
                    __default_124525521705744 = _DEFAULT_MARKER

                    # <Substitution u'doc_type' (44:32)> -> __attr_alt
                    __token = 1900
                    try:
                        __zt_tmp = __attrs_124525521704336
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_alt = _static_124525896001680('path', u'doc_type', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_alt is not None):
                        __append((u' alt="%s"' % __attr_alt))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521705424
                    __default_124525521705424 = _DEFAULT_MARKER

                    # <Substitution u'filename' (45:33)> -> __attr_title
                    __token = 1944
                    try:
                        __zt_tmp = __attrs_124525521704336
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_124525896001680('path', u'filename', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'/>')
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x714168084d90> name=None at 71415b7c9a50> -> __attrs_124525732186640
                __attrs_124525732186640 = _static_124525732187536

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732184592
                __default_124525732184592 = _DEFAULT_MARKER

                # <Substitution u'download_url' (48:33)> -> __attr_href
                __token = 2038
                try:
                    __zt_tmp = __attrs_124525732186640
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_124525896001680('path', u'download_url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' >')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521703632
                __default_124525521703632 = _DEFAULT_MARKER

                # <Value u'filename' (47:25)> -> __cache_124525521703312
                __token = 1995
                try:
                    __zt_tmp = __attrs_124525732186640
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521703312 = _static_124525896001680('path', u'filename', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'filename' (47:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c9f10> -> __condition
                __expression = __cache_124525521703312

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Filename')
                else:
                    __content = __cache_124525521703312
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</a>\n        ')

                # <Static value=<_ast.Dict object at 0x7141680842d0> name=None at 714168084650> -> __attrs_124525732185872
                __attrs_124525732185872 = _static_124525732184784

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="discreet"> &mdash;')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732184848
                __attrs_124525732184848 = _static_124525979686032

                # <Value u'doc_type' (50:64)> -> __condition
                __token = 2142
                try:
                    __zt_tmp = __attrs_124525732184848
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'doc_type', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521508048
                    __attrs_124525521508048 = _static_124525979686032

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521506704
                    __default_124525521506704 = _DEFAULT_MARKER

                    # <Value u'doc_type' (51:31)> -> __cache_124525732185232
                    __token = 2184
                    try:
                        __zt_tmp = __attrs_124525521508048
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732185232 = _static_124525896001680('path', u'doc_type', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'doc_type' (51:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168084d10> -> __condition
                    __expression = __cache_124525732185232

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>ContentType</span>')
                    else:
                        __content = __cache_124525732185232
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u',')
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521507600
                __attrs_124525521507600 = _static_124525979686032
                __backup_sizekb_124525732221776 = get('sizekb', __marker)

                # <Value u'view/file_size' (53:37)> -> __value
                __token = 2302
                try:
                    __zt_tmp = __attrs_124525521507600
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'view/file_size', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['sizekb'] = __value

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521509968
                __default_124525521509968 = _DEFAULT_MARKER

                # <Value u'sizekb' (53:66)> -> __cache_124525521510288
                __token = 2331
                try:
                    __zt_tmp = __attrs_124525521507600
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521510288 = _static_124525896001680('path', u'sizekb', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'sizekb' (53:66)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b799c10> -> __condition
                __expression = __cache_124525521510288

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>100</span>')
                else:
                    __content = __cache_124525521510288
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                if (__backup_sizekb_124525732221776 is __marker):
                    del econtext['sizekb']
                else:
                    econtext['sizekb'] = __backup_sizekb_124525732221776
                __append(u'\n        </span>\n    </span>')
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x714168084790> name=None at 7141680848d0> -> __attrs_124525521508496
            __attrs_124525521508496 = _static_124525732186000

            # <Value u'allow_nochange' (57:24)> -> __condition
            __token = 2438
            try:
                __zt_tmp = __attrs_124525521508496
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'allow_nochange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-top: 1em;">\n        ')

                # <Static value=<_ast.Dict object at 0x71415b799950> name=None at 71415b799910> -> __attrs_124525732202512
                __attrs_124525732202512 = _static_124525521508688

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="radio" value="nochange" class="noborder"')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732204432
                __default_124525732204432 = _DEFAULT_MARKER

                # <Substitution u'string:${view/name}.action' (62:33)> -> __attr_name
                __token = 2612
                try:
                    __zt_tmp = __attrs_124525732202512
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_124525896001680('string', u'${view/name}.action', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732201232
                __default_124525732201232 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-nochange' (63:30)> -> __attr_id
                __token = 2670
                try:
                    __zt_tmp = __attrs_124525732202512
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_124525896001680('string', u'${view/id}-nochange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732200720
                __default_124525732200720 = _DEFAULT_MARKER

                # <Substitution u"string:document.getElementById('${view/id}-input').disabled=true" (64:34)> -> __attr_onclick
                __token = 2733
                try:
                    __zt_tmp = __attrs_124525732202512
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onclick = _static_124525896001680('string', u"document.getElementById('${view/id}-input').disabled=true", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onclick is not None):
                    __append((u' onclick="%s"' % __attr_onclick))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732200656
                __default_124525732200656 = _DEFAULT_MARKER

                # <Boolean u"python:'checked' if action == 'nochange' else None" (65:33)> -> __attr_checked
                __token = 2834
                try:
                    __zt_tmp = __attrs_124525732202512
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_checked = _static_124525896001680('python', u"'checked' if action == 'nochange' else None", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if (__attr_checked is _DEFAULT_MARKER):
                    __attr_checked = None
                else:
                    if __attr_checked:
                        __attr_checked = u'checked'
                    else:
                        __attr_checked = None
                if (__attr_checked is not None):
                    __append((u' checked="%s"' % __attr_checked))
                __append(u' />\n        ')

                # <Static value=<_ast.Dict object at 0x714168088c10> name=None at 714168088bd0> -> __attrs_124525732200976
                __attrs_124525732200976 = _static_124525732203536

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732202384
                __default_124525732202384 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-nochange' (68:32)> -> __attr_for
                __token = 2951
                try:
                    __zt_tmp = __attrs_124525732200976
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_124525896001680('string', u'${view/id}-nochange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_124525732202960 = []
                __append_124525732202960 = __stream_124525732202960.append
                __append_124525732202960(u'Keep existing image')
                __msgid_124525732202960 = __re_whitespace(''.join(__stream_124525732202960)).strip()
                if u'image_keep':
                    __append(translate(u'image_keep', mapping=None, default=__msgid_124525732202960, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732202896
                __attrs_124525732202896 = _static_124525979686032

                # <Value u'not:view/field/required' (69:30)> -> __condition
                __token = 3065
                try:
                    __zt_tmp = __attrs_124525732202896
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('not', u'view/field/required', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731876176
                    __attrs_124525731876176 = _static_124525979686032

                    # <br ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<br />\n            ')

                    # <Static value=<_ast.Dict object at 0x7141680380d0> name=None at 7141680385d0> -> __attrs_124525731876368
                    __attrs_124525731876368 = _static_124525731872976

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="radio" value="remove" class="noborder"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731874128
                    __default_124525731874128 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/name}.action' (75:37)> -> __attr_name
                    __token = 3259
                    try:
                        __zt_tmp = __attrs_124525731876368
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_124525896001680('string', u'${view/name}.action', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731875472
                    __default_124525731875472 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/id}-remove' (76:34)> -> __attr_id
                    __token = 3321
                    try:
                        __zt_tmp = __attrs_124525731876368
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_124525896001680('string', u'${view/id}-remove', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731874448
                    __default_124525731874448 = _DEFAULT_MARKER

                    # <Substitution u"string:document.getElementById('${view/id}-input').disabled=true" (77:38)> -> __attr_onclick
                    __token = 3386
                    try:
                        __zt_tmp = __attrs_124525731876368
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_onclick = _static_124525896001680('string', u"document.getElementById('${view/id}-input').disabled=true", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_onclick is not None):
                        __append((u' onclick="%s"' % __attr_onclick))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731875408
                    __default_124525731875408 = _DEFAULT_MARKER

                    # <Boolean u"python:'checked' if action == 'remove' else None" (78:37)> -> __attr_checked
                    __token = 3491
                    try:
                        __zt_tmp = __attrs_124525731876368
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_checked = _static_124525896001680('python', u"'checked' if action == 'remove' else None", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if (__attr_checked is _DEFAULT_MARKER):
                        __attr_checked = None
                    else:
                        if __attr_checked:
                            __attr_checked = u'checked'
                        else:
                            __attr_checked = None
                    if (__attr_checked is not None):
                        __append((u' checked="%s"' % __attr_checked))
                    __append(u' />\n            ')

                    # <Static value=<_ast.Dict object at 0x7141680d4150> name=None at 714168038b90> -> __attrs_124525732513296
                    __attrs_124525732513296 = _static_124525732512080

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732512784
                    __default_124525732512784 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/id}-remove' (81:36)> -> __attr_for
                    __token = 3618
                    try:
                        __zt_tmp = __attrs_124525732513296
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_124525896001680('string', u'${view/id}-remove', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_124525731875600 = []
                    __append_124525731875600 = __stream_124525731875600.append
                    __append_124525731875600(u'Remove existing image')
                    __msgid_124525731875600 = __re_whitespace(''.join(__stream_124525731875600)).strip()
                    if u'image_remove':
                        __append(translate(u'image_remove', mapping=None, default=__msgid_124525731875600, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n        ')
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521507024
                __attrs_124525521507024 = _static_124525979686032

                # <br ... (0:0)
                # --------------------------------------------------------
                __append(u'<br />\n        ')

                # <Static value=<_ast.Dict object at 0x7141680d46d0> name=None at 7141680d4c90> -> __attrs_124525732570128
                __attrs_124525732570128 = _static_124525732513488

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="radio" value="replace" class="noborder"')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732514128
                __default_124525732514128 = _DEFAULT_MARKER

                # <Substitution u'string:${view/name}.action' (88:33)> -> __attr_name
                __token = 3870
                try:
                    __zt_tmp = __attrs_124525732570128
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_124525896001680('string', u'${view/name}.action', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732512464
                __default_124525732512464 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-replace' (89:30)> -> __attr_id
                __token = 3928
                try:
                    __zt_tmp = __attrs_124525732570128
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_124525896001680('string', u'${view/id}-replace', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732515472
                __default_124525732515472 = _DEFAULT_MARKER

                # <Substitution u"string:document.getElementById('${view/id}-input').disabled=false" (90:34)> -> __attr_onclick
                __token = 3990
                try:
                    __zt_tmp = __attrs_124525732570128
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onclick = _static_124525896001680('string', u"document.getElementById('${view/id}-input').disabled=false", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onclick is not None):
                    __append((u' onclick="%s"' % __attr_onclick))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732571344
                __default_124525732571344 = _DEFAULT_MARKER

                # <Boolean u"python:'checked' if action == 'replace' else None" (91:33)> -> __attr_checked
                __token = 4092
                try:
                    __zt_tmp = __attrs_124525732570128
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_checked = _static_124525896001680('python', u"'checked' if action == 'replace' else None", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if (__attr_checked is _DEFAULT_MARKER):
                    __attr_checked = None
                else:
                    if __attr_checked:
                        __attr_checked = u'checked'
                    else:
                        __attr_checked = None
                if (__attr_checked is not None):
                    __append((u' checked="%s"' % __attr_checked))
                __append(u' />\n        ')

                # <Static value=<_ast.Dict object at 0x7141680e2910> name=None at 7141680e2a90> -> __attrs_124525732570832
                __attrs_124525732570832 = _static_124525732571408

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732570512
                __default_124525732570512 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-replace' (94:32)> -> __attr_for
                __token = 4208
                try:
                    __zt_tmp = __attrs_124525732570832
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_124525896001680('string', u'${view/id}-replace', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_124525732569616 = []
                __append_124525732569616 = __stream_124525732569616.append
                __append_124525732569616(u'Replace with new image')
                __msgid_124525732569616 = __re_whitespace(''.join(__stream_124525732569616)).strip()
                if u'image_replace':
                    __append(translate(u'image_replace', mapping=None, default=__msgid_124525732569616, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n    </div>')
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7141680e2e90> name=None at 7141680e23d0> -> __attrs_124525732569680
            __attrs_124525732569680 = _static_124525732572816

            # <Negate value=<Value u'not:allow_nochange' (96:23)> at 7141680e22d0> -> __cache_124525732569808

            # <Value u'not:allow_nochange' (96:23)> -> __cache_124525732569808
            __token = 4331
            try:
                __zt_tmp = __attrs_124525732569680
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_124525732569808 = _static_124525896001680('not', u'allow_nochange', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __cache_124525732569808 = not __cache_124525732569808
            __condition = __cache_124525732569808
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-left: 1.5em; padding-top: 0.5em;">')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7141680e2650> name=None at 7141680e2d50> -> __attrs_124525521715088
            __attrs_124525521715088 = _static_124525732570704

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="file"')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521713616
            __default_124525521713616 = _DEFAULT_MARKER

            # <Substitution u'string:${view/id}-input' (99:31)> -> __attr_id
            __token = 4471
            try:
                __zt_tmp = __attrs_124525521715088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_124525896001680('string', u'${view/id}-input', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521713424
            __default_124525521713424 = _DEFAULT_MARKER

            # <Substitution u'view/name' (100:32)> -> __attr_name
            __token = 4528
            try:
                __zt_tmp = __attrs_124525521715088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_124525896001680('path', u'view/name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521714064
            __default_124525521714064 = _DEFAULT_MARKER

            # <Substitution u'view/size' (101:31)> -> __attr_size
            __token = 4571
            try:
                __zt_tmp = __attrs_124525521715088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_size = _static_124525896001680('path', u'view/size', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_size = __quote(__attr_size, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_size is not None):
                __append((u' size="%s"' % __attr_size))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521714192
            __default_124525521714192 = _DEFAULT_MARKER

            # <Boolean u'view/disabled' (102:34)> -> __attr_disabled
            __token = 4618
            try:
                __zt_tmp = __attrs_124525521715088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_disabled = _static_124525896001680('path', u'view/disabled', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if (__attr_disabled is _DEFAULT_MARKER):
                __attr_disabled = None
            else:
                if __attr_disabled:
                    __attr_disabled = u'disabled'
                else:
                    __attr_disabled = None
            if (__attr_disabled is not None):
                __append((u' disabled="%s"' % __attr_disabled))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521713488
            __default_124525521713488 = _DEFAULT_MARKER

            # <Substitution u'view/maxlength' (103:34)> -> __attr_maxlength
            __token = 4670
            try:
                __zt_tmp = __attrs_124525521715088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_maxlength = _static_124525896001680('path', u'view/maxlength', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_maxlength is not None):
                __append((u' maxlength="%s"' % __attr_maxlength))
            __append(u' />\n        ')

            # <Static value=<_ast.Dict object at 0x714168187590> name=None at 714168187e90> -> __attrs_124525732650896
            __attrs_124525732650896 = _static_124525733246352

            # <Value u"python:allow_nochange and action != 'replace'" (105:31)> -> __condition
            __token = 4737
            try:
                __zt_tmp = __attrs_124525732650896
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u"allow_nochange and action != 'replace'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript">')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525811476496
                __default_124525811476496 = _DEFAULT_MARKER

                # <Value u"string:document.getElementById('${view/id}-input').disabled=true;" (106:25)> -> __cache_124525521713808
                __token = 4832
                try:
                    __zt_tmp = __attrs_124525732650896
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521713808 = _static_124525896001680('string', u"document.getElementById('${view/id}-input').disabled=true;", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u"string:document.getElementById('${view/id}-input').disabled=true;" (106:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7cbc50> -> __condition
                __expression = __cache_124525521713808

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n        ')
                else:
                    __content = __cache_124525521713808
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</script>')
            __append(u'\n    ')
            __condition = __cache_124525732569808
            if __condition:
                __append(u'</div>')
            __append(u'\n</span>')
            __i18n_domain = __previous_i18n_domain_124525521883536
            if (__backup_filename_124525521886800 is __marker):
                del econtext['filename']
            else:
                econtext['filename'] = __backup_filename_124525521886800
            if (__backup_icon_124525521886672 is __marker):
                del econtext['icon']
            else:
                econtext['icon'] = __backup_icon_124525521886672
            if (__backup_doc_type_124525732011280 is __marker):
                del econtext['doc_type']
            else:
                econtext['doc_type'] = __backup_doc_type_124525732011280
            if (__backup_allow_nochange_124525732008784 is __marker):
                del econtext['allow_nochange']
            else:
                econtext['allow_nochange'] = __backup_allow_nochange_124525732008784
            if (__backup_action_124525521579536 is __marker):
                del econtext['action']
            else:
                econtext['action'] = __backup_action_124525521579536
            if (__backup_exists_124525732010384 is __marker):
                del econtext['exists']
            else:
                econtext['exists'] = __backup_exists_124525732010384
            if (__backup_download_url_124525732518928 is __marker):
                del econtext['download_url']
            else:
                econtext['download_url'] = __backup_download_url_124525732518928
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }