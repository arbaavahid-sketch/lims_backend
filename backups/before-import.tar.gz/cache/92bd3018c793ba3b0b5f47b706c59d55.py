# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/main_template/templates/main_template.pt'

__tokens = {5367: (u'provider:plone.abovecontenttitle', 121, 87), 5527: (u'context/@@title', 123, 55), 5675: (u'provider:plone.belowcontenttitle', 125, 87), 5847: (u'context/@@description', 128, 54), 6039: (u'provider:plone.abovecontentbody', 132, 84), 6201: (u'nothing', 134, 78), 6409: (u'provider:plone.belowcontentbody', 138, 84), 73: (u'string:&lt;!DOCTYPE ht', 2, 38), 357: (u"python:context.restrictedTraverse('@@senaite_theme')", 8, 34), 443: (u" python:context.restrictedTraverse('@@senaite_view'", 9, 32), 520: (u't nocall:senaite_view/te', 10, 23), 578: (u"te python:context.restrictedTraverse('@@plone_portal_stat", 11, 30), 670: (u"ate python:context.restrictedTraverse('@@plone_context_sta", 12, 30), 760: (u"view python:context.restrictedTraverse('@@pl", 13, 26), 838: (u"ayout python:context.restrictedTraverse('@@plone_la", 14, 27), 924: (u"apview python:context.restrictedTraverse('@@bootstra", 15, 27), 1002: (u'   lang python:portal_state.la', 16, 17), 1058: (u'    view nocall:view | nocall: p', 17, 16), 1117: (u'    dummy python: plone_layout.mark_', 18, 16), 1185: (u'portal_url python:portal_state.p', 19, 20), 1254: (u"kPermission python:context.restrictedTraverse('portal_membership').che", 20, 24), 1361: (u"e_properties python:context.restrictedTraverse('portal_properties').si", 21, 23), 1470: (u"_include_head python:request.get('ajax_include", 22, 24), 1547: (u'     ajax_lo', 23, 15), 1634: (u'lang', 25, 29), 1683: (u'provider:plone.httpheaders', 27, 40), 1753: (u'provider:plone.htmlhead', 29, 38), 1810: (u'nothing', 31, 28), 2570: (u'bootstrapview/get_viewport_values', 49, 39), 2641: (u'viewportvalues', 50, 36), 2805: (u'portal_state/is_rtl', 54, 28), 2850: (u" python:plone_layout.have_portlets('plone.leftcolumn', view", 55, 24), 2935: (u"r python:plone_layout.have_portlets('plone.rightcolumn', vie", 56, 23), 3029: (u'ss python:plone_layout.bodyClass(template, vi', 57, 30), 3101: (u'cls python:bootstrapview.get_columns_classes(v', 58, 22), 3307: (u'  python:bootstrapview.get_data_settings', 61, 24), 3185: (u'string:${body_class} senaite-body', 59, 32), 3249: (u" python:isRTL and 'rtl' or 'ltr", 60, 29), 3560: (u'provider:plone.toolbar', 69, 36), 3691: (u'provider:senaite.sidebar', 75, 36), 3952: (u'provider:plone.portaltop', 83, 44), 4175: (u'provider:plone.mainnavigation', 90, 69), 4465: (u'provider:plone.globalstatusmessage', 99, 52), 4782: (u'provider:plone.abovecontent', 108, 69), 4981: (u'cls/content', 114, 70), 6697: (u'provider:plone.belowcontent', 148, 71), 6938: (u'sl', 155, 34), 6983: (u'cls/one', 156, 41), 7102: (u'provider:plone.leftcolumn', 158, 46), 7347: (u'sr', 165, 34), 7392: (u'cls/two', 166, 41), 7511: (u'provider:plone.rightcolumn', 168, 46), 7720: (u'provider:plone.portalfooter', 175, 40)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757163048144 = {u'id': u'portal-column-one', u'class': u'cls/one', }
_static_135757159532496 = {u'id': u'viewlet-above-content', }
_static_135757226657488 = {u'id': u'viewlet-below-content', }
_static_135757152170832 = {u'id': u'content-core', }
_static_135757154665040 = {u'id': u'portal-column-content', u'class': u'cls/content', }
_static_135757148780560 = {u'class': u'row', }
_static_135757137885008 = {u'id': u'portal-top', }
_static_135757148779152 = {u'class': u'container-fluid', }
_static_135757148782096 = {u'class': u'col-sm-12', }
_static_135757137885904 = {u'class': u'row', }
_static_135757166282960 = {u'class': u'col-sm-12', }
_static_135757152275920 = {u'class': u'col-sm-12', }
_static_135757226787920 = {u'id': u'portal-footer-wrapper', }
_static_135757152253904 = {u'id': u'visual-portal-wrapper', u'dir': u"python:isRTL and 'rtl' or 'ltr'", u'class': u'string:${body_class} senaite-body', }
_static_135757152185488 = {u'content': u'SENAITE - https://www.senaite.com', u'name': u'generator', }
_static_135757152253456 = {u'content': u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', u'name': u'viewport', }
_static_135757148734800 = {u'class': u'col-sm-12', }
_static_135757327983760 = {}
_static_135757137685648 = {u'id': u'global_statusmessage', }
_static_135757159487184 = {u'id': u'viewlet-above-content-body', }
_static_135757152159696 = {u'id': u'content', }
_static_135757075304336 = set([])
_static_135757071883024 = {u'id': u'portal-column-two', u'class': u'cls/two', }
_static_135757137689232 = {u'id': u'loader', u'i18n-translate': u'', }
_static_135757244280656 = __compile_zt_expr
_static_135757163479312 = {u'class': u'mb-2', }
_static_135757163045136 = {u'id': u'viewlet-below-content-body', }
_static_135757226772688 = {u'class': u'row', }
_static_135757148678800 = {u'id': u'viewlet-above-content-title', }
_static_135757163480336 = {u'class': u'wrapper', }
_static_135757166283600 = {u'id': u'portal-mainnavigation', }
_static_135757137684432 = {u'class': u'row', }
_static_135757136195920 = {u'lang': u'lang', u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757166283984 = {u'class': u'row', }
_static_135757137861520 = {u'id': u'viewlet-below-content-title', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_content(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_content_description = econtext[u'__slot_content_description'].pop()
        except:
            __slot_content_description = None

        try:
            __slot_main = econtext[u'__slot_main'].pop()
        except:
            __slot_main = None

        try:
            __slot_body = econtext[u'__slot_body'].pop()
        except:
            __slot_body = None

        try:
            __slot_content_core = econtext[u'__slot_content_core'].pop()
        except:
            __slot_content_core = None

        try:
            __slot_content_title = econtext[u'__slot_content_title'].pop()
        except:
            __slot_content_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150475408
            __attrs_135757150475408 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n                  ')
            if (__slot_body is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150477648
                __attrs_135757150477648 = _static_135757327983760
                __append(u'\n                    ')

                # <Static value=<_ast.Dict object at 0x7b786cd487d0> name=None at 7b786cd48150> -> __attrs_135757152243152
                __attrs_135757152243152 = _static_135757152159696

                # <article ... (0:0)
                # --------------------------------------------------------
                __append(u'<article id="content">\n                      ')
                if (__slot_main is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226656272
                    __attrs_135757226656272 = _static_135757327983760
                    __append(u'\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148768272
                    __attrs_135757148768272 = _static_135757327983760

                    # <header ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<header>\n                          ')

                    # <Static value=<_ast.Dict object at 0x7b786c9f6a90> name=None at 7b786ca0cd90> -> __attrs_135757163436816
                    __attrs_135757163436816 = _static_135757148678800

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-title">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148768912
                    __default_135757148768912 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontenttitle' (121:87)> -> __cache_135757148768720
                    __token = 5367
                    try:
                        __zt_tmp = __attrs_135757163436816
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757148768720 = _static_135757244280656('provider', u'plone.abovecontenttitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontenttitle' (121:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ca0cf50> -> __condition
                    __expression = __cache_135757148768720

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757148768720
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n                          ')
                    if (__slot_content_title is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163434704
                        __attrs_135757163434704 = _static_135757327983760
                        __append(u'\n                            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154873872
                        __attrs_135757154873872 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154875280
                        __default_135757154875280 = _DEFAULT_MARKER

                        # <Value u'context/@@title' (123:55)> -> __cache_135757163434128
                        __token = 5527
                        try:
                            __zt_tmp = __attrs_135757154873872
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757163434128 = _static_135757244280656('path', u'context/@@title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@title' (123:55)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786d809d50> -> __condition
                        __expression = __cache_135757163434128

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <h1 ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<h1 />')
                        else:
                            __content = __cache_135757163434128
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n                          ')
                    else:
                        __slot_content_title(__stream, econtext.copy(), rcontext)
                    __append(u'\n                          ')

                    # <Static value=<_ast.Dict object at 0x7b786bfa5b90> name=None at 7b786bfa5a10> -> __attrs_135757137860432
                    __attrs_135757137860432 = _static_135757137861520

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-title">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154875792
                    __default_135757154875792 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontenttitle' (125:87)> -> __cache_135757163437712
                    __token = 5675
                    try:
                        __zt_tmp = __attrs_135757137860432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757163437712 = _static_135757244280656('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontenttitle' (125:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ca0c050> -> __condition
                    __expression = __cache_135757163437712

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757163437712
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n\n                          ')
                    if (__slot_content_description is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137859408
                        __attrs_135757137859408 = _static_135757327983760
                        __append(u'\n                            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159486544
                        __attrs_135757159486544 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137861904
                        __default_135757137861904 = _DEFAULT_MARKER

                        # <Value u'context/@@description' (128:54)> -> __cache_135757137860816
                        __token = 5847
                        try:
                            __zt_tmp = __attrs_135757159486544
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757137860816 = _static_135757244280656('path', u'context/@@description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@description' (128:54)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bfa5e50> -> __condition
                        __expression = __cache_135757137860816

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <p ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<p />')
                        else:
                            __content = __cache_135757137860816
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n                          ')
                    else:
                        __slot_content_description(__stream, econtext.copy(), rcontext)
                    __append(u'\n                        </header>\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786d4456d0> name=None at 7b786d809290> -> __attrs_135757152171984
                    __attrs_135757152171984 = _static_135757159487184

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-body">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163437776
                    __default_135757163437776 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontentbody' (132:84)> -> __cache_135757137859472
                    __token = 6039
                    try:
                        __zt_tmp = __attrs_135757152171984
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757137859472 = _static_135757244280656('provider', u'plone.abovecontentbody', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontentbody' (132:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bfa5110> -> __condition
                    __expression = __cache_135757137859472

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757137859472
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786cd4b350> name=None at 7b786cd4b710> -> __attrs_135757152173712
                    __attrs_135757152173712 = _static_135757152170832

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\n                          ')
                    if (__slot_content_core is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152171536
                        __attrs_135757152171536 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152173264
                        __default_135757152173264 = _DEFAULT_MARKER

                        # <Value u'nothing' (134:78)> -> __cache_135757152172880
                        __token = 6201
                        try:
                            __zt_tmp = __attrs_135757152171536
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757152172880 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'nothing' (134:78)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cd4bd50> -> __condition
                        __expression = __cache_135757152172880

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                            Page body text\n                          ')
                        else:
                            __content = __cache_135757152172880
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                    else:
                        __slot_content_core(__stream, econtext.copy(), rcontext)
                    __append(u'\n                        </div>\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786d7aa110> name=None at 7b786cd4bf90> -> __attrs_135757163045328
                    __attrs_135757163045328 = _static_135757163045136

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-body">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152170512
                    __default_135757152170512 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontentbody' (138:84)> -> __cache_135757152170064
                    __token = 6409
                    try:
                        __zt_tmp = __attrs_135757163045328
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757152170064 = _static_135757244280656('provider', u'plone.belowcontentbody', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontentbody' (138:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cd4bed0> -> __condition
                    __expression = __cache_135757152170064

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757152170064
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n\n                      ')
                else:
                    __slot_main(__stream, econtext.copy(), rcontext)
                __append(u'\n                    </article>\n\n                  ')
            else:
                __slot_body(__stream, econtext.copy(), rcontext)
            __append(u'\n                </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_master(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_senaite_legacy_js = econtext[u'__slot_senaite_legacy_js'].pop()
        except:
            __slot_senaite_legacy_js = None

        try:
            __slot_senaite_legacy_resources = econtext[u'__slot_senaite_legacy_resources'].pop()
        except:
            __slot_senaite_legacy_resources = None

        try:
            __slot_head_slot = econtext[u'__slot_head_slot'].pop()
        except:
            __slot_head_slot = None

        try:
            __slot_column_two_slot = econtext[u'__slot_column_two_slot'].pop()
        except:
            __slot_column_two_slot = None

        try:
            __slot_column_one_slot = econtext[u'__slot_column_one_slot'].pop()
        except:
            __slot_column_one_slot = None

        try:
            __slot_global_statusmessage = econtext[u'__slot_global_statusmessage'].pop()
        except:
            __slot_global_statusmessage = None

        try:
            __slot_senaite_legacy_css = econtext[u'__slot_senaite_legacy_css'].pop()
        except:
            __slot_senaite_legacy_css = None

        try:
            __slot_top_slot = econtext[u'__slot_top_slot'].pop()
        except:
            __slot_top_slot = None

        try:
            __slot_portlets_one_slot = econtext[u'__slot_portlets_one_slot'].pop()
        except:
            __slot_portlets_one_slot = None

        try:
            __slot_portlets_two_slot = econtext[u'__slot_portlets_two_slot'].pop()
        except:
            __slot_portlets_two_slot = None

        try:
            __slot_content = econtext[u'__slot_content'].pop()
        except:
            __slot_content = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136195856
            __attrs_135757136195856 = _static_135757327983760
            __append(u'\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136196560
            __attrs_135757136196560 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136197072
            __default_135757136197072 = _DEFAULT_MARKER

            # <Value u'string:<!DOCTYPE html>' (2:38)> -> __cache_135757136197392
            __token = 73
            try:
                __zt_tmp = __attrs_135757136196560
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757136197392 = _static_135757244280656('string', u'<!DOCTYPE html>', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'string:<!DOCTYPE html>' (2:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786be0f6d0> -> __condition
            __expression = __cache_135757136197392

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757136197392
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786be0f150> name=None at 7b786be0f590> -> __attrs_135757136196496
            __attrs_135757136196496 = _static_135757136195920
            __backup_senaite_theme_135757073819856 = get('senaite_theme', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_theme')" (8:34)> -> __value
            __token = 357
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@senaite_theme')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['senaite_theme'] = __value
            __backup_senaite_view_135757072969936 = get('senaite_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_view')" (9:32)> -> __value
            __token = 443
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@senaite_view')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['senaite_view'] = __value
            __backup_test_135757073013072 = get('test', __marker)

            # <Value u'nocall:senaite_view/test' (10:23)> -> __value
            __token = 520
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'senaite_view/test', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['test'] = __value
            __backup_portal_state_135757075995408 = get('portal_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_portal_state')" (11:30)> -> __value
            __token = 578
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_portal_state')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_context_state_135757072971472 = get('context_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_context_state')" (12:30)> -> __value
            __token = 670
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_context_state')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_plone_view_135757073821008 = get('plone_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone')" (13:26)> -> __value
            __token = 760
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['plone_view'] = __value
            __backup_plone_layout_135757075994128 = get('plone_layout', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_layout')" (14:27)> -> __value
            __token = 838
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@plone_layout')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['plone_layout'] = __value
            __backup_bootstrapview_135757137870672 = get('bootstrapview', __marker)

            # <Value u"python:context.restrictedTraverse('@@bootstrapview')" (15:27)> -> __value
            __token = 924
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('@@bootstrapview')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['bootstrapview'] = __value
            __backup_lang_135757074219152 = get('lang', __marker)

            # <Value u'python:portal_state.language()' (16:17)> -> __value
            __token = 1002
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'portal_state.language()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['lang'] = __value
            __backup_view_135757074219216 = get('view', __marker)

            # <Value u'nocall:view | nocall: plone_view' (17:16)> -> __value
            __token = 1058
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'view | nocall: plone_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['view'] = __value
            __backup_dummy_135757074219280 = get('dummy', __marker)

            # <Value u'python: plone_layout.mark_view(view)' (18:16)> -> __value
            __token = 1117
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u' plone_layout.mark_view(view)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_portal_url_135757074219472 = get('portal_url', __marker)

            # <Value u'python:portal_state.portal_url()' (19:20)> -> __value
            __token = 1185
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'portal_state.portal_url()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_checkPermission_135757074140816 = get('checkPermission', __marker)

            # <Value u"python:context.restrictedTraverse('portal_membership').checkPermission" (20:24)> -> __value
            __token = 1254
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('portal_membership').checkPermission", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['checkPermission'] = __value
            __backup_site_properties_135757074219536 = get('site_properties', __marker)

            # <Value u"python:context.restrictedTraverse('portal_properties').site_properties" (21:23)> -> __value
            __token = 1361
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.restrictedTraverse('portal_properties').site_properties", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['site_properties'] = __value
            __backup_ajax_include_head_135757074141008 = get('ajax_include_head', __marker)

            # <Value u"python:request.get('ajax_include_head', False)" (22:24)> -> __value
            __token = 1470
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"request.get('ajax_include_head', False)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['ajax_include_head'] = __value
            __backup_ajax_load_135757074140688 = get('ajax_load', __marker)

            # <Value u'python:False' (23:15)> -> __value
            __token = 1547
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'False', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['ajax_load'] = __value
            __previous_i18n_domain_135757237310352 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136199440
            __default_135757136199440 = _DEFAULT_MARKER

            # <Substitution u'lang' (25:29)> -> __attr_lang
            __token = 1634
            try:
                __zt_tmp = __attrs_135757136196496
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_135757244280656('path', u'lang', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u'>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757151760208
            __attrs_135757151760208 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757231982928
            __default_135757231982928 = _DEFAULT_MARKER

            # <Value u'provider:plone.httpheaders' (27:40)> -> __cache_135757231981008
            __token = 1683
            try:
                __zt_tmp = __attrs_135757151760208
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757231981008 = _static_135757244280656('provider', u'plone.httpheaders', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.httpheaders' (27:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871968d90> -> __condition
            __expression = __cache_135757231981008

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757231981008
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757166258064
            __attrs_135757166258064 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152277136
            __attrs_135757152277136 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152280464
            __default_135757152280464 = _DEFAULT_MARKER

            # <Value u'provider:plone.htmlhead' (29:38)> -> __cache_135757152278480
            __token = 1753
            try:
                __zt_tmp = __attrs_135757152277136
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757152278480 = _static_135757244280656('provider', u'plone.htmlhead', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.htmlhead' (29:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cd65850> -> __condition
            __expression = __cache_135757152278480

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757152278480
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152277712
            __attrs_135757152277712 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152278416
            __default_135757152278416 = _DEFAULT_MARKER

            # <Value u'nothing' (31:28)> -> __cache_135757152279568
            __token = 1810
            try:
                __zt_tmp = __attrs_135757152277712
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757152279568 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'nothing' (31:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cd65a90> -> __condition
            __expression = __cache_135757152279568

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n        Various slots where you can insert elements in the header from a template.\n      ')
            else:
                __content = __cache_135757152279568
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n      ')
            if (__slot_top_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152277776
                __attrs_135757152277776 = _static_135757327983760
            else:
                __slot_top_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n      ')
            if (__slot_head_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152277328
                __attrs_135757152277328 = _static_135757327983760
            else:
                __slot_head_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n      <!-- Disable all Plone JS/CSS -->\n      <!-- <div tal:replace="structure provider:plone.scripts" /> -->\n      <!-- <metal:javascriptslot define-slot="javascript_head_slot" /> -->\n      <!-- <link tal:replace="structure provider:plone.htmlhead.links" /> -->\n      <!-- <metal:styleslot define-slot="style_slot" /> -->\n\n      <!-- NOTE: All Legacy JS/CSS are rendered at the bottom of the page! -->\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b786cd4ec90> name=None at 7b786cd65e50> -> __attrs_135757152253520
            __attrs_135757152253520 = _static_135757152185488

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="generator" content="SENAITE - https://www.senaite.com" />\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b786cd5f610> name=None at 7b786cd5f4d0> -> __attrs_135757075127504
            __attrs_135757075127504 = _static_135757152253456
            __backup_viewportvalues_135757074220560 = get('viewportvalues', __marker)

            # <Value u'bootstrapview/get_viewport_values' (49:39)> -> __value
            __token = 2570
            try:
                __zt_tmp = __attrs_135757075127504
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'bootstrapview/get_viewport_values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['viewportvalues'] = __value

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075127824
            __default_135757075127824 = _DEFAULT_MARKER

            # <Substitution u'viewportvalues' (50:36)> -> __attr_content
            __token = 2641
            try:
                __zt_tmp = __attrs_135757075127504
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_content = _static_135757244280656('path', u'viewportvalues', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_content = __quote(__attr_content, '"', '&quot;', u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', _DEFAULT_MARKER)
            if (__attr_content is not None):
                __append((u' content="%s"' % __attr_content))
            __append(u' />')
            if (__backup_viewportvalues_135757074220560 is __marker):
                del econtext['viewportvalues']
            else:
                econtext['viewportvalues'] = __backup_viewportvalues_135757074220560
            __append(u'\n    </head>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cd5f7d0> name=None at 7b786cd5f050> -> __attrs_135757075124432
            __attrs_135757075124432 = _static_135757152253904
            __backup_isRTL_135757074219920 = get('isRTL', __marker)

            # <Value u'portal_state/is_rtl' (54:28)> -> __value
            __token = 2805
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'portal_state/is_rtl', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isRTL'] = __value
            __backup_sl_135757074220432 = get('sl', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.leftcolumn', view)" (55:24)> -> __value
            __token = 2850
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"plone_layout.have_portlets('plone.leftcolumn', view)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['sl'] = __value
            __backup_sr_135757074219856 = get('sr', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.rightcolumn', view)" (56:23)> -> __value
            __token = 2935
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"plone_layout.have_portlets('plone.rightcolumn', view)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['sr'] = __value
            __backup_body_class_135757074220624 = get('body_class', __marker)

            # <Value u'python:plone_layout.bodyClass(template, view)' (57:30)> -> __value
            __token = 3029
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'plone_layout.bodyClass(template, view)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['body_class'] = __value
            __backup_cls_135757074220816 = get('cls', __marker)

            # <Value u'python:bootstrapview.get_columns_classes(view)' (58:22)> -> __value
            __token = 3101
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'bootstrapview.get_columns_classes(view)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['cls'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body')

            # <Value u'python:bootstrapview.get_data_settings()' (61:24)> -> __cache_135757075125200
            __token = 3307
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075125200 = _static_135757244280656('python', u'bootstrapview.get_data_settings()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if (u'id' not in __chain(__cache_135757075125200)):
                __append(u' id="visual-portal-wrapper"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075125904
            __default_135757075125904 = _DEFAULT_MARKER

            # <Substitution u'string:${body_class} senaite-body' (59:32)> -> __attr_class
            __token = 3185
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('string', u'${body_class} senaite-body', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_135757075125200))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075125008
            __default_135757075125008 = _DEFAULT_MARKER

            # <Substitution u"python:isRTL and 'rtl' or 'ltr'" (60:29)> -> __attr_dir
            __token = 3249
            try:
                __zt_tmp = __attrs_135757075124432
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_135757244280656('python', u"isRTL and 'rtl' or 'ltr'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_dir is not None) and (u'dir' not in __chain(__cache_135757075125200))):
                __append((u' dir="%s"' % __attr_dir))
            __attr_135757075124304 = __cache_135757075125200
            for (name, value, ) in __attr_135757075124304.items():
                if ((name not in _static_135757075304336) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\n\n      <!-- Ajax Loader -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786bf7ba90> name=None at 7b786bf7bbd0> -> __attrs_135757163483024
            __attrs_135757163483024 = _static_135757137689232

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="loader" i18n-translate="">Loading...</div>\n\n      <!-- Toolbar -->\n      ')

            # <Static value=<_ast.Dict object at 0x7b786d814110> name=None at 7b786d814610> -> __attrs_135757163479120
            __attrs_135757163479120 = _static_135757163479312

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="mb-2">\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163480400
            __attrs_135757163480400 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163481360
            __default_135757163481360 = _DEFAULT_MARKER

            # <Value u'provider:plone.toolbar' (69:36)> -> __cache_135757163481680
            __token = 3560
            try:
                __zt_tmp = __attrs_135757163480400
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757163481680 = _static_135757244280656('provider', u'plone.toolbar', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.toolbar' (69:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786d814c90> -> __condition
            __expression = __cache_135757163481680

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757163481680
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n      </div>\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b786d814510> name=None at 7b786d814a90> -> __attrs_135757163482960
            __attrs_135757163482960 = _static_135757163480336

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="wrapper">\n\n        <!-- Sidebar -->\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148778832
            __attrs_135757148778832 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159719760
            __default_135757159719760 = _DEFAULT_MARKER

            # <Value u'provider:senaite.sidebar' (75:36)> -> __cache_135757229633680
            __token = 3691
            try:
                __zt_tmp = __attrs_135757148778832
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757229633680 = _static_135757244280656('provider', u'senaite.sidebar', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:senaite.sidebar' (75:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786b90cf90> -> __condition
            __expression = __cache_135757229633680

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757229633680
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n        <!-- Content -->\n        ')

            # <Static value=<_ast.Dict object at 0x7b786ca0f290> name=None at 7b786ca0f2d0> -> __attrs_135757148780240
            __attrs_135757148780240 = _static_135757148779152

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786ca0f810> name=None at 7b786ca0f110> -> __attrs_135757148781328
            __attrs_135757148781328 = _static_135757148780560

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786ca0fe10> name=None at 7b786ca0ff10> -> __attrs_135757148781136
            __attrs_135757148781136 = _static_135757148782096

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b786bfab750> name=None at 7b786bfab8d0> -> __attrs_135757137885968
            __attrs_135757137885968 = _static_135757137885008
            __previous_i18n_domain_135757137885264 = __i18n_domain
            __i18n_domain = u'plone'

            # <header ... (0:0)
            # --------------------------------------------------------
            __append(u'<header id="portal-top">\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137887056
            __attrs_135757137887056 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137883472
            __default_135757137883472 = _DEFAULT_MARKER

            # <Value u'provider:plone.portaltop' (83:44)> -> __cache_135757137884560
            __token = 3952
            try:
                __zt_tmp = __attrs_135757137887056
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757137884560 = _static_135757244280656('provider', u'plone.portaltop', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portaltop' (83:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bfaba50> -> __condition
            __expression = __cache_135757137884560

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757137884560
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n              </header>')
            __i18n_domain = __previous_i18n_domain_135757137885264
            __append(u'\n            </div>\n          </div>\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786bfabad0> name=None at 7b786ca0fc90> -> __attrs_135757166283344
            __attrs_135757166283344 = _static_135757137885904

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786dac08d0> name=None at 7b786dac07d0> -> __attrs_135757166282128
            __attrs_135757166282128 = _static_135757166282960

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b786dac0b50> name=None at 7b786dac0c50> -> __attrs_135757073014032
            __attrs_135757073014032 = _static_135757166283600

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="portal-mainnavigation">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166284624
            __default_135757166284624 = _DEFAULT_MARKER

            # <Value u'provider:plone.mainnavigation' (90:69)> -> __cache_135757166284304
            __token = 4175
            try:
                __zt_tmp = __attrs_135757073014032
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757166284304 = _static_135757244280656('provider', u'plone.mainnavigation', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.mainnavigation' (90:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786dac0e90> -> __condition
            __expression = __cache_135757166284304

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n                The main navigation\n              ')
            else:
                __content = __cache_135757166284304
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n            </div>\n          </div>\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786dac0cd0> name=None at 7b786dac0850> -> __attrs_135757152274384
            __attrs_135757152274384 = _static_135757166283984

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cd64dd0> name=None at 7b786cd64e50> -> __attrs_135757152275408
            __attrs_135757152275408 = _static_135757152275920

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b786bf7ac90> name=None at 7b786bf7af50> -> __attrs_135757137683536
            __attrs_135757137683536 = _static_135757137685648

            # <aside ... (0:0)
            # --------------------------------------------------------
            __append(u'<aside id="global_statusmessage">\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137683984
            __attrs_135757137683984 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137685200
            __default_135757137685200 = _DEFAULT_MARKER

            # <Value u'provider:plone.globalstatusmessage' (99:52)> -> __cache_135757137686224
            __token = 4465
            try:
                __zt_tmp = __attrs_135757137683984
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757137686224 = _static_135757244280656('provider', u'plone.globalstatusmessage', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.globalstatusmessage' (99:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bf7ab10> -> __condition
            __expression = __cache_135757137686224

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757137686224
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n                ')
            if (__slot_global_statusmessage is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137685968
                __attrs_135757137685968 = _static_135757327983760

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n                </div>')
            else:
                __slot_global_statusmessage(__stream, econtext.copy(), rcontext)
            __append(u'\n              </aside>\n            </div>\n          </div>\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786bf7a7d0> name=None at 7b786cd642d0> -> __attrs_135757148735120
            __attrs_135757148735120 = _static_135757137684432

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786ca04550> name=None at 7b786ca04050> -> __attrs_135757148734224
            __attrs_135757148734224 = _static_135757148734800

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b786d4507d0> name=None at 7b786d450490> -> __attrs_135757226773904
            __attrs_135757226773904 = _static_135757159532496

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-above-content">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159531984
            __default_135757159531984 = _DEFAULT_MARKER

            # <Value u'provider:plone.abovecontent' (108:69)> -> __cache_135757159532368
            __token = 4782
            try:
                __zt_tmp = __attrs_135757226773904
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757159532368 = _static_135757244280656('provider', u'plone.abovecontent', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.abovecontent' (108:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786d450ed0> -> __condition
            __expression = __cache_135757159532368

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757159532368
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n            </div>\n          </div>\n\n          <!-- Main content -->\n          ')

            # <Static value=<_ast.Dict object at 0x7b78714708d0> name=None at 7b786ca046d0> -> __attrs_135757153414416
            __attrs_135757153414416 = _static_135757226772688

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cfac250> name=None at 7b786cfac710> -> __attrs_135757154666704
            __attrs_135757154666704 = _static_135757154665040

            # <article ... (0:0)
            # --------------------------------------------------------
            __append(u'<article id="portal-column-content"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154667856
            __default_135757154667856 = _DEFAULT_MARKER

            # <Substitution u'cls/content' (114:70)> -> __attr_class
            __token = 4981
            try:
                __zt_tmp = __attrs_135757154666704
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'cls/content', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\n              ')
            if (__slot_content is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154665616
                __attrs_135757154665616 = _static_135757327983760
                __append(u'\n                ')
                __token = None
                render_content(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n\n              ')
            else:
                __slot_content(__stream, econtext.copy(), rcontext)
            __append(u'\n              ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150475088
            __attrs_135757150475088 = _static_135757327983760

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer>\n                ')

            # <Static value=<_ast.Dict object at 0x7b78714546d0> name=None at 7b7871454d90> -> __attrs_135757163045584
            __attrs_135757163045584 = _static_135757226657488

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-below-content">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226657360
            __default_135757226657360 = _DEFAULT_MARKER

            # <Value u'provider:plone.belowcontent' (148:71)> -> __cache_135757150477840
            __token = 6697
            try:
                __zt_tmp = __attrs_135757163045584
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757150477840 = _static_135757244280656('provider', u'plone.belowcontent', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.belowcontent' (148:71)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cbad6d0> -> __condition
            __expression = __cache_135757150477840

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757150477840
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n              </footer>\n            </article>\n\n            <!-- Column 1 -->\n            ')
            if (__slot_column_one_slot is None):

                # <Static value=<_ast.Dict object at 0x7b786d7aacd0> name=None at 7b786cfac550> -> __attrs_135757163048400
                __attrs_135757163048400 = _static_135757163048144

                # <Value u'sl' (155:34)> -> __condition
                __token = 6938
                try:
                    __zt_tmp = __attrs_135757163048400
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'sl', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-one"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163047760
                    __default_135757163047760 = _DEFAULT_MARKER

                    # <Substitution u'cls/one' (156:41)> -> __attr_class
                    __token = 6983
                    try:
                        __zt_tmp = __attrs_135757163048400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('path', u'cls/one', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n              ')
                    if (__slot_portlets_one_slot is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163046480
                        __attrs_135757163046480 = _static_135757327983760
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757166253520
                        __attrs_135757166253520 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166255120
                        __default_135757166255120 = _DEFAULT_MARKER

                        # <Value u'provider:plone.leftcolumn' (158:46)> -> __cache_135757136994832
                        __token = 7102
                        try:
                            __zt_tmp = __attrs_135757166253520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757136994832 = _static_135757244280656('provider', u'plone.leftcolumn', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.leftcolumn' (158:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786dab93d0> -> __condition
                        __expression = __cache_135757136994832

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757136994832
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n              ')
                    else:
                        __slot_portlets_one_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\n            </aside>')
            else:
                __slot_column_one_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n            <!-- Column 2 -->\n            ')
            if (__slot_column_two_slot is None):

                # <Static value=<_ast.Dict object at 0x7b78680b9b10> name=None at 7b786dab9350> -> __attrs_135757166677456
                __attrs_135757166677456 = _static_135757071883024

                # <Value u'sr' (165:34)> -> __condition
                __token = 7347
                try:
                    __zt_tmp = __attrs_135757166677456
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'sr', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-two"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166677840
                    __default_135757166677840 = _DEFAULT_MARKER

                    # <Substitution u'cls/two' (166:41)> -> __attr_class
                    __token = 7392
                    try:
                        __zt_tmp = __attrs_135757166677456
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('path', u'cls/two', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n              ')
                    if (__slot_portlets_two_slot is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226787024
                        __attrs_135757226787024 = _static_135757327983760
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235271952
                        __attrs_135757235271952 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071862928
                        __default_135757071862928 = _DEFAULT_MARKER

                        # <Value u'provider:plone.rightcolumn' (168:46)> -> __cache_135757135284368
                        __token = 7511
                        try:
                            __zt_tmp = __attrs_135757235271952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757135284368 = _static_135757244280656('provider', u'plone.rightcolumn', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.rightcolumn' (168:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78680b4290> -> __condition
                        __expression = __cache_135757135284368

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757135284368
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n              ')
                    else:
                        __slot_portlets_two_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\n            </aside>')
            else:
                __slot_column_two_slot(__stream, econtext.copy(), rcontext)
            __append(u'\n\n          </div>\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b7871474450> name=None at 7b7871474690> -> __attrs_135757235273424
            __attrs_135757235273424 = _static_135757226787920
            __previous_i18n_domain_135757235269712 = __i18n_domain
            __i18n_domain = u'plone'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer id="portal-footer-wrapper">\n            ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235269904
            __attrs_135757235269904 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235271184
            __default_135757235271184 = _DEFAULT_MARKER

            # <Value u'provider:plone.portalfooter' (175:40)> -> __cache_135757235270160
            __token = 7720
            try:
                __zt_tmp = __attrs_135757235269904
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757235270160 = _static_135757244280656('provider', u'plone.portalfooter', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portalfooter' (175:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871c8bfd0> -> __condition
            __expression = __cache_135757235270160

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757235270160
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n          </footer>')
            __i18n_domain = __previous_i18n_domain_135757235269712
            __append(u'\n\n        </div>\n\n      </div>\n\n      <!-- NOTE:\n           We define all legacy resource slots at the bottom to ensure these are\n           loaded *after* the JS/CSS from the resources viewlet (rendered in the\n           IHtmlHead viewlet manager) and the HTML is completely loaded.\n      -->\n\n      <!-- SENAITE legacy resouces -->\n      ')
            if (__slot_senaite_legacy_resources is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235273232
                __attrs_135757235273232 = _static_135757327983760
            else:
                __slot_senaite_legacy_resources(__stream, econtext.copy(), rcontext)
            __append(u'\n      <!-- SENAITE legacy JS -->\n      ')
            if (__slot_senaite_legacy_js is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235272720
                __attrs_135757235272720 = _static_135757327983760
            else:
                __slot_senaite_legacy_js(__stream, econtext.copy(), rcontext)
            __append(u'\n      <!-- SENAITE legacy CSS -->\n      ')
            if (__slot_senaite_legacy_css is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235270096
                __attrs_135757235270096 = _static_135757327983760
            else:
                __slot_senaite_legacy_css(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    </body>')
            if (__backup_cls_135757074220816 is __marker):
                del econtext['cls']
            else:
                econtext['cls'] = __backup_cls_135757074220816
            if (__backup_body_class_135757074220624 is __marker):
                del econtext['body_class']
            else:
                econtext['body_class'] = __backup_body_class_135757074220624
            if (__backup_sr_135757074219856 is __marker):
                del econtext['sr']
            else:
                econtext['sr'] = __backup_sr_135757074219856
            if (__backup_sl_135757074220432 is __marker):
                del econtext['sl']
            else:
                econtext['sl'] = __backup_sl_135757074220432
            if (__backup_isRTL_135757074219920 is __marker):
                del econtext['isRTL']
            else:
                econtext['isRTL'] = __backup_isRTL_135757074219920
            __append(u'\n  </html>')
            __i18n_domain = __previous_i18n_domain_135757237310352
            if (__backup_ajax_load_135757074140688 is __marker):
                del econtext['ajax_load']
            else:
                econtext['ajax_load'] = __backup_ajax_load_135757074140688
            if (__backup_ajax_include_head_135757074141008 is __marker):
                del econtext['ajax_include_head']
            else:
                econtext['ajax_include_head'] = __backup_ajax_include_head_135757074141008
            if (__backup_site_properties_135757074219536 is __marker):
                del econtext['site_properties']
            else:
                econtext['site_properties'] = __backup_site_properties_135757074219536
            if (__backup_checkPermission_135757074140816 is __marker):
                del econtext['checkPermission']
            else:
                econtext['checkPermission'] = __backup_checkPermission_135757074140816
            if (__backup_portal_url_135757074219472 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_135757074219472
            if (__backup_dummy_135757074219280 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_135757074219280
            if (__backup_view_135757074219216 is __marker):
                del econtext['view']
            else:
                econtext['view'] = __backup_view_135757074219216
            if (__backup_lang_135757074219152 is __marker):
                del econtext['lang']
            else:
                econtext['lang'] = __backup_lang_135757074219152
            if (__backup_bootstrapview_135757137870672 is __marker):
                del econtext['bootstrapview']
            else:
                econtext['bootstrapview'] = __backup_bootstrapview_135757137870672
            if (__backup_plone_layout_135757075994128 is __marker):
                del econtext['plone_layout']
            else:
                econtext['plone_layout'] = __backup_plone_layout_135757075994128
            if (__backup_plone_view_135757073821008 is __marker):
                del econtext['plone_view']
            else:
                econtext['plone_view'] = __backup_plone_view_135757073821008
            if (__backup_context_state_135757072971472 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_135757072971472
            if (__backup_portal_state_135757075995408 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_135757075995408
            if (__backup_test_135757073013072 is __marker):
                del econtext['test']
            else:
                econtext['test'] = __backup_test_135757073013072
            if (__backup_senaite_view_135757072969936 is __marker):
                del econtext['senaite_view']
            else:
                econtext['senaite_view'] = __backup_senaite_view_135757072969936
            if (__backup_senaite_theme_135757073819856 is __marker):
                del econtext['senaite_theme']
            else:
                econtext['senaite_theme'] = __backup_senaite_theme_135757073819856
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_master(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_content': render_content, u'render_master': render_master, 'render': render, }