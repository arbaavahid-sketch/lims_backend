# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/datagrid/datagrid_input.pt'

__tokens = {2039: (u'widget/render', 35, 40), 405: (u'view/extra', 9, 36), 419: (u' view/id_prefi', 9, 50), 497: (u'view/columns', 12, 34), 578: (u'string:header cell-${repeat/column/number}', 14, 35), 652: (u" python: cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or ''", 15, 29), 779: (u'cssclass', 16, 36), 822: (u'column/label', 17, 31), 919: (u'column/required', 19, 33), 1077: (u'column/description', 20, 50), 1110: (u'column/description', 20, 83), 1231: (u'view/allow_insert', 23, 42), 1299: (u'view/allow_delete', 24, 42), 1367: (u'view/allow_reorder', 25, 42), 1436: (u'view/allow_reorder', 26, 42), 1562: (u'view/name_prefix', 29, 72), 1594: (u' view/id_prefi', 29, 104), 1645: (u'view/widgets', 30, 32), 1908: (u'python:view._includeRow(widget.name)', 33, 27), 1695: (u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", 31, 34), 1843: (u" python:widget.name.split('.')[-1", 32, 38), 2195: (u'view/counterMarker', 41, 46), 2308: (u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js', 43, 60), 2484: (u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css', 44, 86)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402102894416 = {u'class': u'header', }
_static_140402099282512 = {u'type': u'hidden', }
_static_140402102541584 = {u'class': u'header', }
_static_140402099605392 = {u'class': u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", u'data-index': u"python:widget.name.split('.')[-1]", }
_static_140402356200592 = {}
_static_140402272508048 = __compile_zt_expr
_static_140402102065104 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402099875408 = {u'class': u'formHelp', }
_static_140402102375504 = {u'class': u'header', }
_static_140402101741712 = {u'data-mode': u'row', u'data-extra': u'view/extra', u'class': u'table table-hover table-responsive table-sm table-borderless datagridwidget-table-view', u'id': u'view/id_prefix', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402099873424 = {u'class': u'required', u'title': u'Required', }
_static_140402101419600 = {u'media': u'screen', u'href': u'', u'type': u'text/css', u'rel': u'stylesheet', }
_static_140402099284432 = {u'class': u'header', }
_static_140402102515664 = {u'class': u'header', }
_static_140402102515856 = {u'data-id_prefix': u'view/id_prefix', u'class': u'datagridwidget-body', u'data-name_prefix': u'view/name_prefix', }
_static_140402101416592 = {u'src': u'', u'type': u'text/javascript', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_row(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099602832
            __attrs_140402099602832 = _static_140402356200592
            __append(u'\r\n            ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101751056
            __attrs_140402101751056 = _static_140402356200592

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101748432
            __default_140402101748432 = _DEFAULT_MARKER

            # <Value u'widget/render' (35:40)> -> __cache_140402099604240
            __token = 2039
            try:
                __zt_tmp = __attrs_140402101751056
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402099604240 = _static_140402272508048('path', u'widget/render', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

            # <BinOp left=<Value u'widget/render' (35:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e945ced0> -> __condition
            __expression = __cache_140402099604240

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div></div>')
            else:
                __content = __cache_140402099604240
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n          ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e96b57d0> name=None at 7fb1e96b5a10> -> __attrs_140402098895120
            __attrs_140402098895120 = _static_140402102065104
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9666890> name=None at 7fb1e9666490> -> __attrs_140402102710608
            __attrs_140402102710608 = _static_140402101741712

            # <table ... (0:0)
            # --------------------------------------------------------
            __append(u'<table class="table table-hover table-responsive table-sm table-borderless datagridwidget-table-view"          data-mode="row"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099285008
            __default_140402099285008 = _DEFAULT_MARKER

            # <Substitution u'view/extra' (9:36)> -> __attr_data_extra
            __token = 405
            try:
                __zt_tmp = __attrs_140402102710608
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_extra = _static_140402272508048('path', u'view/extra', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_data_extra = __quote(__attr_data_extra, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_extra is not None):
                __append((u' data-extra="%s"' % __attr_data_extra))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099283728
            __default_140402099283728 = _DEFAULT_MARKER

            # <Substitution u'view/id_prefix' (9:50)> -> __attr_id
            __token = 419
            try:
                __zt_tmp = __attrs_140402102710608
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'view/id_prefix', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099285264
            __attrs_140402099285264 = _static_140402356200592

            # <thead ... (0:0)
            # --------------------------------------------------------
            __append(u'<thead>\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099284688
            __attrs_140402099284688 = _static_140402356200592

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099285392
            __attrs_140402099285392 = _static_140402356200592
            __backup_column_140402101920592 = get('column', __marker)

            # <Value u'view/columns' (12:34)> -> __iterator
            __token = 497
            try:
                __zt_tmp = __attrs_140402099285392
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_140402272508048('path', u'view/columns', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            (__iterator, ____index_140402099285328, ) = getitem('repeat')(u'column', __iterator)
            econtext['column'] = None
            for __item in __iterator:
                econtext['column'] = __item
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x7fb1e977ff50> name=None at 7fb1e977f1d0> -> __attrs_140402102632400
                __attrs_140402102632400 = _static_140402102894416
                __backup_cssclass_140402099859152 = get('cssclass', __marker)

                # <Value u'string:header cell-${repeat/column/number}' (14:35)> -> __value
                __token = 578
                try:
                    __zt_tmp = __attrs_140402102632400
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_140402272508048('string', u'header cell-${repeat/column/number}', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                econtext['cssclass'] = __value
                __backup_cssclass_140402098331280 = get('cssclass', __marker)

                # <Value u"python: cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or '')" (15:29)> -> __value
                __token = 652
                try:
                    __zt_tmp = __attrs_140402102632400
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_140402272508048('python', u" cssclass + (column['mode'] == 'hidden' and ' datagridwidget-hidden-data' or '')", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                econtext['cssclass'] = __value

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102205392
                __default_140402102205392 = _DEFAULT_MARKER

                # <Substitution u'cssclass' (16:36)> -> __attr_class
                __token = 779
                try:
                    __zt_tmp = __attrs_140402102632400
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_140402272508048('path', u'cssclass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', u'header', _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\r\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101284432
                __attrs_140402101284432 = _static_140402356200592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102172880
                __default_140402102172880 = _DEFAULT_MARKER

                # <Value u'column/label' (17:31)> -> __cache_140402100050960
                __token = 822
                try:
                    __zt_tmp = __attrs_140402101284432
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402100050960 = _static_140402272508048('path', u'column/label', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'column/label' (17:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e94c9910> -> __condition
                __expression = __cache_140402100050960

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'title')
                else:
                    __content = __cache_140402100050960
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1e949e690> name=None at 7fb1f7406910> -> __attrs_140402099875472
                __attrs_140402099875472 = _static_140402099873424

                # <Value u'column/required' (19:33)> -> __condition
                __token = 919
                try:
                    __zt_tmp = __attrs_140402099875472
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'column/required', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:
                    __previous_i18n_domain_140402099872336 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="required"')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099874576
                    __default_140402099874576 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7fb1e949e790> at 7fb1e949e550> -> __attr_title
                    __attr_title = u'Required'
                    __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>&nbsp;</span>')
                    __i18n_domain = __previous_i18n_domain_140402099872336
                __append(u'\r\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1e949ee50> name=None at 7fb1e949e4d0> -> __attrs_140402099874128
                __attrs_140402099874128 = _static_140402099875408

                # <Value u'column/description' (20:50)> -> __condition
                __token = 1077
                try:
                    __zt_tmp = __attrs_140402099874128
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'column/description', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp">')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099874320
                    __default_140402099874320 = _DEFAULT_MARKER

                    # <Value u'column/description' (20:83)> -> __cache_140402099871952
                    __token = 1110
                    try:
                        __zt_tmp = __attrs_140402099874128
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402099871952 = _static_140402272508048('path', u'column/description', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'column/description' (20:83)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e949e150> -> __condition
                    __expression = __cache_140402099871952

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Description')
                    else:
                        __content = __cache_140402099871952
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                __append(u'\r\n          </th>')
                if (__backup_cssclass_140402098331280 is __marker):
                    del econtext['cssclass']
                else:
                    econtext['cssclass'] = __backup_cssclass_140402098331280
                if (__backup_cssclass_140402099859152 is __marker):
                    del econtext['cssclass']
                else:
                    econtext['cssclass'] = __backup_cssclass_140402099859152
                __append(u'\r\n        ')
                ____index_140402099285328 -= 1
                if (____index_140402099285328 > 0):
                    __append('')
            if (__backup_column_140402101920592 is __marker):
                del econtext['column']
            else:
                econtext['column'] = __backup_column_140402101920592
            __append(u'\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e940e9d0> name=None at 7fb1e940e390> -> __attrs_140402099874896
            __attrs_140402099874896 = _static_140402099284432

            # <Value u'view/allow_insert' (23:42)> -> __condition
            __token = 1231
            try:
                __zt_tmp = __attrs_140402099874896
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/allow_insert', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9729d10> name=None at 7fb1e9729190> -> __attrs_140402102539280
            __attrs_140402102539280 = _static_140402102541584

            # <Value u'view/allow_delete' (24:42)> -> __condition
            __token = 1299
            try:
                __zt_tmp = __attrs_140402102539280
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/allow_delete', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9701450> name=None at 7fb1e97293d0> -> __attrs_140402102517584
            __attrs_140402102517584 = _static_140402102375504

            # <Value u'view/allow_reorder' (25:42)> -> __condition
            __token = 1367
            try:
                __zt_tmp = __attrs_140402102517584
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/allow_reorder', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e97237d0> name=None at 7fb1e9723310> -> __attrs_140402102516816
            __attrs_140402102516816 = _static_140402102515664

            # <Value u'view/allow_reorder' (26:42)> -> __condition
            __token = 1436
            try:
                __zt_tmp = __attrs_140402102516816
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/allow_reorder', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th class="header"></th>')
            __append(u'\r\n      </tr>\r\n    </thead>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e9723890> name=None at 7fb1e940e3d0> -> __attrs_140402101436688
            __attrs_140402101436688 = _static_140402102515856

            # <tbody ... (0:0)
            # --------------------------------------------------------
            __append(u'<tbody class="datagridwidget-body"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099006288
            __default_140402099006288 = _DEFAULT_MARKER

            # <Substitution u'view/name_prefix' (29:72)> -> __attr_data_name_prefix
            __token = 1562
            try:
                __zt_tmp = __attrs_140402101436688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_name_prefix = _static_140402272508048('path', u'view/name_prefix', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_data_name_prefix = __quote(__attr_data_name_prefix, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_name_prefix is not None):
                __append((u' data-name_prefix="%s"' % __attr_data_name_prefix))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101716688
            __default_140402101716688 = _DEFAULT_MARKER

            # <Substitution u'view/id_prefix' (29:104)> -> __attr_data_id_prefix
            __token = 1594
            try:
                __zt_tmp = __attrs_140402101436688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_id_prefix = _static_140402272508048('path', u'view/id_prefix', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_data_id_prefix = __quote(__attr_data_id_prefix, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_id_prefix is not None):
                __append((u' data-id_prefix="%s"' % __attr_data_id_prefix))
            __append(u'>\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101899920
            __attrs_140402101899920 = _static_140402356200592
            __backup_widget_140402099855696 = get('widget', __marker)

            # <Value u'view/widgets' (30:32)> -> __iterator
            __token = 1645
            try:
                __zt_tmp = __attrs_140402101899920
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_140402272508048('path', u'view/widgets', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            (__iterator, ____index_140402099602896, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e945cf90> name=None at 7fb1e945c2d0> -> __attrs_140402099604880
                __attrs_140402099604880 = _static_140402099605392

                # <Value u'python:view._includeRow(widget.name)' (33:27)> -> __condition
                __token = 1908
                try:
                    __zt_tmp = __attrs_140402099604880
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('python', u'view._includeRow(widget.name)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099602640
                    __default_140402099602640 = _DEFAULT_MARKER

                    # <Substitution u"python:'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')" (31:34)> -> __attr_class
                    __token = 1695
                    try:
                        __zt_tmp = __attrs_140402099604880
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_140402272508048('python', u"'%s row-%d%s' % (widget.klass, repeat['widget'].number(), widget.mode=='hidden' and ' hidden' or '')", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099605072
                    __default_140402099605072 = _DEFAULT_MARKER

                    # <Substitution u"python:widget.name.split('.')[-1]" (32:38)> -> __attr_data_index
                    __token = 1843
                    try:
                        __zt_tmp = __attrs_140402099604880
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_index = _static_140402272508048('python', u"widget.name.split('.')[-1]", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_data_index = __quote(__attr_data_index, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_index is not None):
                        __append((u' data-index="%s"' % __attr_data_index))
                    __append(u'>\r\n          ')
                    __token = None
                    render_widget_row(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    __append(u'\r\n        </tr>')
                __append(u'\r\n      ')
                ____index_140402099602896 -= 1
                if (____index_140402099602896 > 0):
                    __append('')
            if (__backup_widget_140402099855696 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_140402099855696
            __append(u'\r\n    </tbody>\r\n  </table>\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e940e250> name=None at 7fb1e940e310> -> __attrs_140402099601680
            __attrs_140402099601680 = _static_140402099282512

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099601488
            __default_140402099601488 = _DEFAULT_MARKER

            # <Value u'view/counterMarker' (41:46)> -> __cache_140402099603728
            __token = 2195
            try:
                __zt_tmp = __attrs_140402099601680
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402099603728 = _static_140402272508048('path', u'view/counterMarker', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/counterMarker' (41:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e945cf10> -> __condition
            __expression = __cache_140402099603728

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" />')
            else:
                __content = __cache_140402099603728
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n  <!-- static resources -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9617290> name=None at 7fb1e9617710> -> __attrs_140402101419152
            __attrs_140402101419152 = _static_140402101416592

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101416080
            __default_140402101416080 = _DEFAULT_MARKER

            # <Substitution u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js' (43:60)> -> __attr_src
            __token = 2308
            try:
                __zt_tmp = __attrs_140402101419152
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_140402272508048('string', u'${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.js', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9617e50> name=None at 7fb1e9617890> -> __attrs_140402101418384
            __attrs_140402101418384 = _static_140402101419600

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101418320
            __default_140402101418320 = _DEFAULT_MARKER

            # <Substitution u'string:${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css' (44:86)> -> __attr_href
            __token = 2484
            try:
                __zt_tmp = __attrs_140402101418384
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_140402272508048('string', u'${view/portal_url}/++resource++senaite.core.z3cform.static/datagrid.css', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' type="text/css" media="screen"/>\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_row': render_widget_row, 'render': render, }