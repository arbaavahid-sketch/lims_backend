# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFPlone-5.2.15-py2.7.egg/Products/CMFPlone/browser/templates/basic_error_message.pt'

__tokens = {293: (u'python:view.is_manager()', 8, 27), 352: (u'not:isManager', 11, 24), 423: (u'isManager', 12, 24), 434: (u'${options/error_type}', 12, 35), 436: (u'options/error_type', 12, 37), 694: (u'isManager', 23, 21), 705: (u'${options/error_type}', 23, 32), 707: (u'options/error_type', 23, 34), 755: (u'isManager', 25, 22), 786: (u'options/error_tb', 26, 20), 834: (u'not:isManager', 28, 26)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757134642832 = {u'class': u'documentFirstHeading', }
_static_135757134635344 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135757244280656 = __compile_zt_expr
_static_135757134640784 = {u'class': u'documentFirstHeading', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786bc92150> name=None at 7b786bc92110> -> __attrs_135757232037584
            __attrs_135757232037584 = _static_135757134635344
            __previous_i18n_domain_135757232033936 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226770576
            __attrs_135757226770576 = _static_135757327983760
            __backup_isManager_135757134641104 = get('isManager', __marker)

            # <Value u'python:view.is_manager()' (8:27)> -> __value
            __token = 293
            try:
                __zt_tmp = __attrs_135757226770576
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.is_manager()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isManager'] = __value
            __append(u'\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232037072
            __attrs_135757232037072 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232034832
            __attrs_135757232034832 = _static_135757327983760

            # <Value u'not:isManager' (11:24)> -> __condition
            __token = 352
            try:
                __zt_tmp = __attrs_135757232034832
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <title ... (0:0)
                # --------------------------------------------------------
                __append(u'<title>')
                __stream_135757232036944 = []
                __append_135757232036944 = __stream_135757232036944.append
                __append_135757232036944(u'Error')
                __msgid_135757232036944 = __re_whitespace(''.join(__stream_135757232036944)).strip()
                if __msgid_135757232036944:
                    __append(translate(__msgid_135757232036944, mapping=None, default=__msgid_135757232036944, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</title>')
            __append(u'\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134639312
            __attrs_135757134639312 = _static_135757327983760

            # <Value u'isManager' (12:24)> -> __condition
            __token = 423
            try:
                __zt_tmp = __attrs_135757134639312
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <title ... (0:0)
                # --------------------------------------------------------
                __append(u'<title>')

                # <Interpolation value=<Substitution u'${options/error_type}' (12:35)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b786bc93d50> -> __content_135757397202144
                __token = 434
                __token = 436
                try:
                    __zt_tmp = __attrs_135757134639312
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_135757397202144 = _static_135757244280656('path', u'options/error_type', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __content_135757397202144 = __quote(__content_135757397202144, '\x00', '&#0;', None, None)
                __content_135757397202144 = __content_135757397202144
                if (__content_135757397202144 is None):
                    pass
                else:
                    if (__content_135757397202144 is None):
                        __content_135757397202144 = None
                    else:
                        __tt = type(__content_135757397202144)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_135757397202144 = unicode(__content_135757397202144)
                        else:
                            if (__tt is str):
                                __content_135757397202144 = decode(__content_135757397202144)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_135757397202144 = __content_135757397202144.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_135757397202144)
                                        __content_135757397202144 = (unicode(__content_135757397202144) if (__content_135757397202144 is __converted) else __converted)
                                    else:
                                        __content_135757397202144 = __content_135757397202144()
                if (__content_135757397202144 is not None):
                    __append(__content_135757397202144)
                __append(u'</title>')
            __append(u'\n</head>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134639440
            __attrs_135757134639440 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786bc93e90> name=None at 7b786bc93490> -> __attrs_135757134641680
            __attrs_135757134641680 = _static_135757134642832

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1 class="documentFirstHeading">')
            __stream_135757134640144 = []
            __append_135757134640144 = __stream_135757134640144.append
            __append_135757134640144(u'\n      We&#8217;re sorry, but there seems to be an error&hellip;\n  ')
            __msgid_135757134640144 = __re_whitespace(''.join(__stream_135757134640144)).strip()
            if u'heading_site_error_sorry':
                __append(translate(u'heading_site_error_sorry', mapping=None, default=__msgid_135757134640144, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</h1>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786bc93690> name=None at 7b786bc936d0> -> __attrs_135757134642960
            __attrs_135757134642960 = _static_135757134640784

            # <Value u'isManager' (23:21)> -> __condition
            __token = 694
            try:
                __zt_tmp = __attrs_135757134642960
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <h2 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h2 class="documentFirstHeading">')

                # <Interpolation value=<Substitution u'${options/error_type}' (23:32)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b786bc933d0> -> __content_135757397202144
                __token = 705
                __token = 707
                try:
                    __zt_tmp = __attrs_135757134642960
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_135757397202144 = _static_135757244280656('path', u'options/error_type', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __content_135757397202144 = __quote(__content_135757397202144, '\x00', '&#0;', None, None)
                __content_135757397202144 = __content_135757397202144
                if (__content_135757397202144 is None):
                    pass
                else:
                    if (__content_135757397202144 is None):
                        __content_135757397202144 = None
                    else:
                        __tt = type(__content_135757397202144)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_135757397202144 = unicode(__content_135757397202144)
                        else:
                            if (__tt is str):
                                __content_135757397202144 = decode(__content_135757397202144)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_135757397202144 = __content_135757397202144.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_135757397202144)
                                        __content_135757397202144 = (unicode(__content_135757397202144) if (__content_135757397202144 is __converted) else __converted)
                                    else:
                                        __content_135757397202144 = __content_135757397202144()
                if (__content_135757397202144 is not None):
                    __append(__content_135757397202144)
                __append(u'</h2>')
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365996240
            __attrs_135757365996240 = _static_135757327983760

            # <Value u'isManager' (25:22)> -> __condition
            __token = 755
            try:
                __zt_tmp = __attrs_135757365996240
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <pre ... (0:0)
                # --------------------------------------------------------
                __append(u'<pre>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134641744
                __default_135757134641744 = _DEFAULT_MARKER

                # <Value u'options/error_tb' (26:20)> -> __cache_135757134639184
                __token = 786
                try:
                    __zt_tmp = __attrs_135757365996240
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757134639184 = _static_135757244280656('path', u'options/error_tb', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'options/error_tb' (26:20)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bc93910> -> __condition
                __expression = __cache_135757134639184

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135757134639184
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</pre>')
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365994640
            __attrs_135757365994640 = _static_135757327983760

            # <Value u'not:isManager' (28:26)> -> __condition
            __token = 834
            try:
                __zt_tmp = __attrs_135757365994640
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365994448
                __attrs_135757365994448 = _static_135757327983760

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p>')
                __stream_135757365959328_site_admin = ''
                __stream_135757365995216 = []
                __append_135757365995216 = __stream_135757365995216.append
                __append_135757365995216(u'\n      If you are certain you have the correct web address but are encountering an error, please\n      contact the ')
                __stream_135757365959328_site_admin = []
                __append_135757365959328_site_admin = __stream_135757365959328_site_admin.append

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365995536
                __attrs_135757365995536 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append_135757365959328_site_admin(u'<span>')
                __stream_135757365994832 = []
                __append_135757365994832 = __stream_135757365994832.append
                __append_135757365994832(u'site administration')
                __msgid_135757365994832 = __re_whitespace(''.join(__stream_135757365994832)).strip()
                if u'label_site_admin':
                    __append_135757365959328_site_admin(translate(u'label_site_admin', mapping=None, default=__msgid_135757365994832, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append_135757365959328_site_admin(u'</span>')
                __append_135757365995216(u'${site_admin}')
                __stream_135757365959328_site_admin = ''.join(__stream_135757365959328_site_admin)
                __append_135757365995216(u'.\n      ')
                __msgid_135757365995216 = __re_whitespace(''.join(__stream_135757365995216)).strip()
                if u'description_site_error_mail_site_admin':
                    __append(translate(u'description_site_error_mail_site_admin', mapping={u'site_admin': __stream_135757365959328_site_admin, }, default=__msgid_135757365995216, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\n  ')
            __append(u'\n\n</body>\n')
            if (__backup_isManager_135757134641104 is __marker):
                del econtext['isManager']
            else:
                econtext['isManager'] = __backup_isManager_135757134641104
            __append(u'\n</html>')
            __i18n_domain = __previous_i18n_domain_135757232033936
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }