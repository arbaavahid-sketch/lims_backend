# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.portlets-4.4.9-py2.7.egg/plone/app/portlets/browser/templates/edit-manager-contextual.pt'

__tokens = {305: (u'string:portletmanager-${view/normalized_manager_name}', 7, 24), 412: (u'context/@@manage-portlets-macros/macros/portlet-add-form', 10, 24), 412: (u'context/@@manage-portlets-macros/macros/portlet-add-form', 10, 24), 498: (u'context/@@manage-portlets-macros/macros/current-portlets-list', 12, 24), 498: (u'context/@@manage-portlets-macros/macros/current-portlets-list', 12, 24), 742: (u'view/blacklist_status_action', 20, 47), 834: (u'context/@@authenticator/authenticator', 21, 35), 940: (u'view/manager_name', 22, 64), 993: (u'view/context_blacklist_status', 24, 30), 1314: (u"python:status == True and 'selected' or None", 34, 45), 1540: (u"python:(status == False or status == None) and 'selected' or None", 40, 45), 1772: (u'view/inherited_portlets', 47, 36), 1828: (u'portlets', 48, 30), 2002: (u'portlets', 50, 162), 1877: (u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", 50, 37), 2085: (u'not:portlet/editview', 53, 31), 2144: (u'string:${portlet/editview}?referer=${view/url_quote_referer}', 54, 37), 2235: (u'portlet/title', 55, 29), 2351: (u'status', 58, 31), 2661: (u'view/group_blacklist_status', 71, 30), 2955: (u"python:status == None and 'selected' or None", 79, 45), 3199: (u"python:status == True and 'selected' or None", 85, 45), 3425: (u"python:status == False and 'selected' or None", 91, 45), 3637: (u'view/group_portlets', 98, 36), 3691: (u' python:view.group_blacklist_status(check_parent=True', 99, 33), 3911: (u'portlets', 101, 162), 3786: (u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", 101, 37), 3994: (u'not:portlet/editview', 104, 31), 4053: (u'string:${portlet/editview}?referer=${view/url_quote_referer}', 105, 37), 4144: (u'portlet/title', 106, 29), 4260: (u'status', 109, 31), 4572: (u'view/content_type_blacklist_status', 124, 30), 4916: (u"python:status == None and 'selected' or None", 134, 45), 5160: (u"python:status == True and 'selected' or None", 140, 45), 5386: (u"python:status == False and 'selected' or None", 146, 45), 5597: (u'view/content_type_portlets', 152, 36), 5650: (u' python:view.content_type_blacklist_status(check_parent=True', 153, 25), 5889: (u'portlets', 156, 32), 5752: (u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", 155, 37), 5971: (u'not:portlet/editview', 158, 31), 6030: (u'string:${portlet/editview}?referer=${view/url_quote_referer}', 159, 37), 6121: (u'portlet/title', 160, 29), 6237: (u'status', 163, 31)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133987276028048 = __compile_zt_expr
_static_133987185472848 = {u'class': u'portletAssignments', }
_static_133987185547408 = {u'class': u'portletHeader', }
_static_133987186844432 = {u'type': u'hidden', u'name': u'manager', u'value': u'view/manager_name', }
_static_133987186869840 = {u'selected': u"python:status == False and 'selected' or None", u'value': u'-1', }
_static_133987185483664 = {u'type': u'submit', u'class': u'context', u'value': u'Save settings', }
_static_133987186811216 = {u'class': u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", }
_static_133987185467920 = {u'class': u'portletHeader', }
_static_133987186681552 = {u'name': u'group_status:int', u'size': u'1', }
_static_133987180771024 = u'portlet-add-form'
_static_133987186681360 = {u'class': u'portletBlockedMessage hiddenStructure', u'title': u'Blocked', }
_static_133987186723856 = {u'selected': u"python:status == None and 'selected' or None", u'value': u'0', }
_static_133987185547280 = {u'href': u'string:${portlet/editview}?referer=${view/url_quote_referer}', }
_static_133987276028432 = __C2ZContextWrapper
_static_133987185473808 = {u'action': u'view/blacklist_status_action', u'method': u'post', u'class': u'portlets-settings', }
_static_133987180596240 = {u'name': u'content_type_status:int', u'size': u'1', }
_static_133987186872016 = {u'selected': u"python:status == True and 'selected' or None", u'value': u'1', }
_static_133987180771728 = {u'class': u'portlets-manager pat-manage-portlets', u'id': u'string:portletmanager-${view/normalized_manager_name}', }
_static_133987186682256 = {u'class': u'portlet-group', }
_static_133987186635472 = {u'class': u'portletBlockedMessage hiddenStructure', u'title': u'Blocked', }
_static_133987359720592 = {}
_static_133987180593808 = {u'selected': u"python:status == None and 'selected' or None", u'value': u'0', }
_static_133987184225808 = {u'class': u'portlet-group', }
_static_133987186638160 = {u'href': u'string:${portlet/editview}?referer=${view/url_quote_referer}', }
_static_133987185497424 = {u'name': u'context_status:int', u'size': u'1', }
_static_133987184240464 = {u'class': u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", }
_static_133987185483472 = {u'class': u'formControls', }
_static_133987184240848 = {u'class': u'portletHeader', }
_static_133987186665872 = {u'class': u'portletBlockedMessage hiddenStructure', u'title': u'Blocked', }
_static_133987185552848 = {u'class': u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", }
_static_133987180773072 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_133987185550416 = {u'selected': u"python:status == True and 'selected' or None", u'value': u'1', }
_static_133987186813648 = {u'selected': u"python:(status == False or status == None) and 'selected' or None", u'value': u'-1', }
_static_133987185499984 = {u'class': u'portlet-group', }
_static_133987185498320 = {u'selected': u"python:status == True and 'selected' or None", u'value': u'1', }
_static_133987185472528 = u'current-portlets-list'
_static_133987185552208 = {u'selected': u"python:status == False and 'selected' or None", u'value': u'-1', }
_static_133987186664336 = {u'href': u'string:${portlet/editview}?referer=${view/url_quote_referer}', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc52507ed0> name=None at 79dc52507d90> -> __attrs_133987165432976
            __attrs_133987165432976 = _static_133987180773072
            __append(u'\n')

            # <Static value=<_ast.Dict object at 0x79dc52507990> name=None at 79dc525079d0> -> __attrs_133987180770000
            __attrs_133987180770000 = _static_133987180771728
            __previous_i18n_domain_133987180770192 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portlets-manager pat-manage-portlets"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180771280
            __default_133987180771280 = _DEFAULT_MARKER

            # <Substitution u'string:portletmanager-${view/normalized_manager_name}' (7:24)> -> __attr_id
            __token = 305
            try:
                __zt_tmp = __attrs_133987180770000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_133987276028048('string', u'portletmanager-${view/normalized_manager_name}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n\n  ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987180772048
            __attrs_133987180772048 = _static_133987359720592
            __backup_macroname_133987146417888 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79dc525076d0> name=None at 79dc525070d0> -> __value
            __value = _static_133987180771024
            econtext['macroname'] = __value

            # <Value u'context/@@manage-portlets-macros/macros/portlet-add-form' (10:24)> -> __macro
            __token = 412
            try:
                __zt_tmp = __attrs_133987180772048
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133987276028048('path', u'context/@@manage-portlets-macros/macros/portlet-add-form', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __token = 412
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133987146417888 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133987146417888
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185472336
            __attrs_133987185472336 = _static_133987359720592
            __backup_macroname_133987146243920 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79dc52983410> name=None at 79dc529830d0> -> __value
            __value = _static_133987185472528
            econtext['macroname'] = __value

            # <Value u'context/@@manage-portlets-macros/macros/current-portlets-list' (12:24)> -> __macro
            __token = 498
            try:
                __zt_tmp = __attrs_133987185472336
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133987276028048('path', u'context/@@manage-portlets-macros/macros/current-portlets-list', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __token = 498
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133987146243920 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133987146243920
            __append(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x79dc52983550> name=None at 79dc52983450> -> __attrs_133987185473936
            __attrs_133987185473936 = _static_133987185472848

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portletAssignments">\n\n    ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185474576
            __attrs_133987185474576 = _static_133987359720592

            # <h4 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h4>')
            __stream_133987185471952 = []
            __append_133987185471952 = __stream_133987185471952.append
            __append_133987185471952(u'\n        Block/unblock portlets\n    ')
            __msgid_133987185471952 = __re_whitespace(''.join(__stream_133987185471952)).strip()
            if u'heading_un_block_portlets':
                __append(translate(u'heading_un_block_portlets', mapping=None, default=__msgid_133987185471952, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</h4>\n\n    ')

            # <Static value=<_ast.Dict object at 0x79dc52983910> name=None at 79dc529835d0> -> __attrs_133987185475792
            __attrs_133987185475792 = _static_133987185473808

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form method="post" class="portlets-settings"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185478672
            __default_133987185478672 = _DEFAULT_MARKER

            # <Substitution u'view/blacklist_status_action' (20:47)> -> __attr_action
            __token = 742
            try:
                __zt_tmp = __attrs_133987185475792
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_133987276028048('path', u'view/blacklist_status_action', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u'>\n      ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186844560
            __attrs_133987186844560 = _static_133987359720592

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186844112
            __default_133987186844112 = _DEFAULT_MARKER

            # <Value u'context/@@authenticator/authenticator' (21:35)> -> __cache_133987186846352
            __token = 834
            try:
                __zt_tmp = __attrs_133987186844560
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133987186846352 = _static_133987276028048('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

            # <BinOp left=<Value u'context/@@authenticator/authenticator' (21:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52ad2dd0> -> __condition
            __expression = __cache_133987186846352

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span />')
            else:
                __content = __cache_133987186846352
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x79dc52ad2310> name=None at 79dc52ad2f50> -> __attrs_133987184224464
            __attrs_133987184224464 = _static_133987186844432

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="manager"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186844752
            __default_133987186844752 = _DEFAULT_MARKER

            # <Substitution u'view/manager_name' (22:64)> -> __attr_value
            __token = 940
            try:
                __zt_tmp = __attrs_133987184224464
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_133987276028048('path', u'view/manager_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n\n      ')

            # <Static value=<_ast.Dict object at 0x79dc52852e10> name=None at 79dc52852cd0> -> __attrs_133987185497488
            __attrs_133987185497488 = _static_133987184225808
            __backup_status_133987185472208 = get('status', __marker)

            # <Value u'view/context_blacklist_status' (24:30)> -> __value
            __token = 993
            try:
                __zt_tmp = __attrs_133987185497488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/context_blacklist_status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['status'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portlet-group">\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185498000
            __attrs_133987185498000 = _static_133987359720592
            __stream_133987185499216 = []
            __append_133987185499216 = __stream_133987185499216.append
            __append_133987185499216(u'\n            Parent portlets:\n        ')
            __msgid_133987185499216 = __re_whitespace(''.join(__stream_133987185499216)).strip()
            if u'label_portlets_parent_folders':
                __append(translate(u'label_portlets_parent_folders', mapping=None, default=__msgid_133987185499216, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc52989550> name=None at 79dc52989d10> -> __attrs_133987185497360
            __attrs_133987185497360 = _static_133987185497424

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select name="context_status:int" size="1">\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc529898d0> name=None at 79dc52989a50> -> __attrs_133987186813008
            __attrs_133987186813008 = _static_133987185498320

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186812048
            __default_133987186812048 = _DEFAULT_MARKER

            # <Boolean u"python:status == True and 'selected' or None" (34:45)> -> __attr_selected
            __token = 1314
            try:
                __zt_tmp = __attrs_133987186813008
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == True and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987185498064 = []
            __append_133987185498064 = __stream_133987185498064.append
            __append_133987185498064(u'\n                Block\n            ')
            __msgid_133987185498064 = __re_whitespace(''.join(__stream_133987185498064)).strip()
            if u'portlets_value_block':
                __append(translate(u'portlets_value_block', mapping=None, default=__msgid_133987185498064, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52acaad0> name=None at 79dc52aca990> -> __attrs_133987186811728
            __attrs_133987186811728 = _static_133987186813648

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="-1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186813392
            __default_133987186813392 = _DEFAULT_MARKER

            # <Boolean u"python:(status == False or status == None) and 'selected' or None" (40:45)> -> __attr_selected
            __token = 1540
            try:
                __zt_tmp = __attrs_133987186811728
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"(status == False or status == None) and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987186814928 = []
            __append_133987186814928 = __stream_133987186814928.append
            __append_133987186814928(u'\n                Do not block\n            ')
            __msgid_133987186814928 = __re_whitespace(''.join(__stream_133987186814928)).strip()
            if u'portlets_value_show':
                __append(translate(u'portlets_value_show', mapping=None, default=__msgid_133987186814928, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n        </select>\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186813200
            __attrs_133987186813200 = _static_133987359720592
            __backup_portlets_133987185497872 = get('portlets', __marker)

            # <Value u'view/inherited_portlets' (47:36)> -> __value
            __token = 1772
            try:
                __zt_tmp = __attrs_133987186813200
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/inherited_portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['portlets'] = __value

            # <Value u'portlets' (48:30)> -> __condition
            __token = 1828
            try:
                __zt_tmp = __attrs_133987186813200
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if __condition:
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x79dc52aca150> name=None at 79dc52aca8d0> -> __attrs_133987185545936
                __attrs_133987185545936 = _static_133987186811216
                __backup_portlet_133987180769360 = get('portlet', __marker)

                # <Value u'portlets' (50:162)> -> __iterator
                __token = 2002
                try:
                    __zt_tmp = __attrs_133987185545936
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                (__iterator, ____index_133987185546640, ) = getitem('repeat')(u'portlet', __iterator)
                econtext['portlet'] = None
                for __item in __iterator:
                    econtext['portlet'] = __item

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185547856
                    __default_133987185547856 = _DEFAULT_MARKER

                    # <Substitution u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'" (50:37)> -> __attr_class
                    __token = 1877
                    try:
                        __zt_tmp = __attrs_133987185545936
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133987276028048('python', u"status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52995890> name=None at 79dc529956d0> -> __attrs_133987185548112
                    __attrs_133987185548112 = _static_133987185547408

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portletHeader">\n\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52995810> name=None at 79dc52995f50> -> __attrs_133987186681232
                    __attrs_133987186681232 = _static_133987185547280

                    # <Negate value=<Value u'not:portlet/editview' (53:31)> at 79dc52aaacd0> -> __cache_133987186683088

                    # <Value u'not:portlet/editview' (53:31)> -> __cache_133987186683088
                    __token = 2085
                    try:
                        __zt_tmp = __attrs_133987186681232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987186683088 = _static_133987276028048('not', u'portlet/editview', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __cache_133987186683088 = not __cache_133987186683088
                    __condition = __cache_133987186683088
                    if __condition:

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185549200
                        __default_133987185549200 = _DEFAULT_MARKER

                        # <Substitution u'string:${portlet/editview}?referer=${view/url_quote_referer}' (54:37)> -> __attr_href
                        __token = 2144
                        try:
                            __zt_tmp = __attrs_133987186681232
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_133987276028048('string', u'${portlet/editview}?referer=${view/url_quote_referer}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'>')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185545616
                    __default_133987185545616 = _DEFAULT_MARKER

                    # <Value u'portlet/title' (55:29)> -> __cache_133987185548560
                    __token = 2235
                    try:
                        __zt_tmp = __attrs_133987186681232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987185548560 = _static_133987276028048('path', u'portlet/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'portlet/title' (55:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52995450> -> __condition
                    __expression = __cache_133987185548560

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133987185548560
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __condition = __cache_133987186683088
                    if __condition:
                        __append(u'</a>')
                    __append(u'\n\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52aaa610> name=None at 79dc52aaa510> -> __attrs_133987186680528
                    __attrs_133987186680528 = _static_133987186681360

                    # <Value u'status' (58:31)> -> __condition
                    __token = 2351
                    try:
                        __zt_tmp = __attrs_133987186680528
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133987276028048('path', u'status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="portletBlockedMessage hiddenStructure"')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186683664
                        __default_133987186683664 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_portlet_blocked' node=<_ast.Str object at 0x79dc52aaa710> at 79dc52aaaf50> -> __attr_title
                        __attr_title = u'Blocked'
                        __attr_title = translate(u'title_portlet_blocked', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>')
                        __stream_133987186682064 = []
                        __append_133987186682064 = __stream_133987186682064.append
                        __append_133987186682064(u'\n                (Blocked)\n              ')
                        __msgid_133987186682064 = __re_whitespace(''.join(__stream_133987186682064)).strip()
                        if u'label_portlet_blocked':
                            __append(translate(u'label_portlet_blocked', mapping=None, default=__msgid_133987186682064, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>')
                    __append(u'\n\n            </div>\n          </div>')
                    ____index_133987185546640 -= 1
                    if (____index_133987185546640 > 0):
                        __append('\n          ')
                if (__backup_portlet_133987180769360 is __marker):
                    del econtext['portlet']
                else:
                    econtext['portlet'] = __backup_portlet_133987180769360
                __append(u'\n        ')
            if (__backup_portlets_133987185497872 is __marker):
                del econtext['portlets']
            else:
                econtext['portlets'] = __backup_portlets_133987185497872
            __append(u'\n\n      </div>')
            if (__backup_status_133987185472208 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_133987185472208
            __append(u'\n\n      ')

            # <Static value=<_ast.Dict object at 0x79dc52989f50> name=None at 79dc52989110> -> __attrs_133987186680016
            __attrs_133987186680016 = _static_133987185499984
            __backup_status_133987186846544 = get('status', __marker)

            # <Value u'view/group_blacklist_status' (71:30)> -> __value
            __token = 2661
            try:
                __zt_tmp = __attrs_133987186680016
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/group_blacklist_status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['status'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portlet-group">\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186682320
            __attrs_133987186682320 = _static_133987359720592
            __stream_133987186682128 = []
            __append_133987186682128 = __stream_133987186682128.append
            __append_133987186682128(u'Group portlets:')
            __msgid_133987186682128 = __re_whitespace(''.join(__stream_133987186682128)).strip()
            if u'label_portlets_group_portlets':
                __append(translate(u'label_portlets_group_portlets', mapping=None, default=__msgid_133987186682128, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc52aaa6d0> name=None at 79dc52aaaf90> -> __attrs_133987186625872
            __attrs_133987186625872 = _static_133987186681552

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select name="group_status:int" size="1">\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52ab4c10> name=None at 79dc52ab4d50> -> __attrs_133987185551120
            __attrs_133987185551120 = _static_133987186723856

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="0"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185551952
            __default_133987185551952 = _DEFAULT_MARKER

            # <Boolean u"python:status == None and 'selected' or None" (79:45)> -> __attr_selected
            __token = 2955
            try:
                __zt_tmp = __attrs_133987185551120
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == None and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987186721232 = []
            __append_133987186721232 = __stream_133987186721232.append
            __append_133987186721232(u'\n                Use parent settings\n            ')
            __msgid_133987186721232 = __re_whitespace(''.join(__stream_133987186721232)).strip()
            if u'portlets_value_use_parent':
                __append(translate(u'portlets_value_use_parent', mapping=None, default=__msgid_133987186721232, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52996450> name=None at 79dc52996e10> -> __attrs_133987185552592
            __attrs_133987185552592 = _static_133987185550416

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185550096
            __default_133987185550096 = _DEFAULT_MARKER

            # <Boolean u"python:status == True and 'selected' or None" (85:45)> -> __attr_selected
            __token = 3199
            try:
                __zt_tmp = __attrs_133987185552592
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == True and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987185553232 = []
            __append_133987185553232 = __stream_133987185553232.append
            __append_133987185553232(u'\n                Block\n            ')
            __msgid_133987185553232 = __re_whitespace(''.join(__stream_133987185553232)).strip()
            if u'portlets_value_block':
                __append(translate(u'portlets_value_block', mapping=None, default=__msgid_133987185553232, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52996b50> name=None at 79dc52996c50> -> __attrs_133987186646800
            __attrs_133987186646800 = _static_133987185552208

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="-1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185549648
            __default_133987185549648 = _DEFAULT_MARKER

            # <Boolean u"python:status == False and 'selected' or None" (91:45)> -> __attr_selected
            __token = 3425
            try:
                __zt_tmp = __attrs_133987186646800
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == False and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987185552144 = []
            __append_133987185552144 = __stream_133987185552144.append
            __append_133987185552144(u'\n                Do not block\n            ')
            __msgid_133987185552144 = __re_whitespace(''.join(__stream_133987185552144)).strip()
            if u'portlets_value_show':
                __append(translate(u'portlets_value_show', mapping=None, default=__msgid_133987185552144, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n        </select>\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185469136
            __attrs_133987185469136 = _static_133987359720592
            __backup_portlets_133987185496208 = get('portlets', __marker)

            # <Value u'view/group_portlets' (98:36)> -> __value
            __token = 3637
            try:
                __zt_tmp = __attrs_133987185469136
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/group_portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['portlets'] = __value
            __backup_status_133987186813584 = get('status', __marker)

            # <Value u'python:view.group_blacklist_status(check_parent=True)' (99:33)> -> __value
            __token = 3691
            try:
                __zt_tmp = __attrs_133987185469136
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('python', u'view.group_blacklist_status(check_parent=True)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['status'] = __value
            __append(u'\n\n          ')

            # <Static value=<_ast.Dict object at 0x79dc52996dd0> name=None at 79dc52996d50> -> __attrs_133987185471184
            __attrs_133987185471184 = _static_133987185552848
            __backup_portlet_133987180820368 = get('portlet', __marker)

            # <Value u'portlets' (101:162)> -> __iterator
            __token = 3911
            try:
                __zt_tmp = __attrs_133987185471184
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            (__iterator, ____index_133987185469584, ) = getitem('repeat')(u'portlet', __iterator)
            econtext['portlet'] = None
            for __item in __iterator:
                econtext['portlet'] = __item

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185470032
                __default_133987185470032 = _DEFAULT_MARKER

                # <Substitution u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'" (101:37)> -> __attr_class
                __token = 3786
                try:
                    __zt_tmp = __attrs_133987185471184
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_133987276028048('python', u"status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\n            ')

                # <Static value=<_ast.Dict object at 0x79dc52982210> name=None at 79dc52982b90> -> __attrs_133987185468624
                __attrs_133987185468624 = _static_133987185467920

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="portletHeader">\n\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52aa6390> name=None at 79dc52aa68d0> -> __attrs_133987186665424
                __attrs_133987186665424 = _static_133987186664336

                # <Negate value=<Value u'not:portlet/editview' (104:31)> at 79dc52aa6050> -> __cache_133987186663504

                # <Value u'not:portlet/editview' (104:31)> -> __cache_133987186663504
                __token = 3994
                try:
                    __zt_tmp = __attrs_133987186665424
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186663504 = _static_133987276028048('not', u'portlet/editview', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __cache_133987186663504 = not __cache_133987186663504
                __condition = __cache_133987186663504
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186665808
                    __default_133987186665808 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/editview}?referer=${view/url_quote_referer}' (105:37)> -> __attr_href
                    __token = 4053
                    try:
                        __zt_tmp = __attrs_133987186665424
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133987276028048('string', u'${portlet/editview}?referer=${view/url_quote_referer}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186667344
                __default_133987186667344 = _DEFAULT_MARKER

                # <Value u'portlet/title' (106:29)> -> __cache_133987186664656
                __token = 4144
                try:
                    __zt_tmp = __attrs_133987186665424
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186664656 = _static_133987276028048('path', u'portlet/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'portlet/title' (106:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52aa6090> -> __condition
                __expression = __cache_133987186664656

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_133987186664656
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __condition = __cache_133987186663504
                if __condition:
                    __append(u'</a>')
                __append(u'\n\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52aa6990> name=None at 79dc52aa6890> -> __attrs_133987186664208
                __attrs_133987186664208 = _static_133987186665872

                # <Value u'status' (109:31)> -> __condition
                __token = 4260
                try:
                    __zt_tmp = __attrs_133987186664208
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="portletBlockedMessage hiddenStructure"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186663888
                    __default_133987186663888 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_portlet_blocked' node=<_ast.Str object at 0x79dc52aa6d90> at 79dc52aa6510> -> __attr_title
                    __attr_title = u'Blocked'
                    __attr_title = translate(u'title_portlet_blocked', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>')
                    __stream_133987186664528 = []
                    __append_133987186664528 = __stream_133987186664528.append
                    __append_133987186664528(u'\n                (Blocked)\n              ')
                    __msgid_133987186664528 = __re_whitespace(''.join(__stream_133987186664528)).strip()
                    if u'label_portlet_blocked':
                        __append(translate(u'label_portlet_blocked', mapping=None, default=__msgid_133987186664528, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\n\n            </div>\n          </div>')
                ____index_133987185469584 -= 1
                if (____index_133987185469584 > 0):
                    __append('\n          ')
            if (__backup_portlet_133987180820368 is __marker):
                del econtext['portlet']
            else:
                econtext['portlet'] = __backup_portlet_133987180820368
            __append(u'\n\n        ')
            if (__backup_status_133987186813584 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_133987186813584
            if (__backup_portlets_133987185496208 is __marker):
                del econtext['portlets']
            else:
                econtext['portlets'] = __backup_portlets_133987185496208
            __append(u'\n\n      </div>')
            if (__backup_status_133987186846544 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_133987186846544
            __append(u'\n\n\n      ')

            # <Static value=<_ast.Dict object at 0x79dc52aaa990> name=None at 79dc52aaa790> -> __attrs_133987185470288
            __attrs_133987185470288 = _static_133987186682256
            __backup_status_133987185498448 = get('status', __marker)

            # <Value u'view/content_type_blacklist_status' (124:30)> -> __value
            __token = 4572
            try:
                __zt_tmp = __attrs_133987185470288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/content_type_blacklist_status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['status'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portlet-group">\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987180596176
            __attrs_133987180596176 = _static_133987359720592
            __stream_133987180595792 = []
            __append_133987180595792 = __stream_133987180595792.append
            __append_133987180595792(u'\n            Content type portlets:\n        ')
            __msgid_133987180595792 = __re_whitespace(''.join(__stream_133987180595792)).strip()
            if u'label_portlets_content_type_portlets':
                __append(translate(u'label_portlets_content_type_portlets', mapping=None, default=__msgid_133987180595792, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc524dcc10> name=None at 79dc524dcdd0> -> __attrs_133987180593296
            __attrs_133987180593296 = _static_133987180596240

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select name="content_type_status:int" size="1">\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc524dc290> name=None at 79dc524dc7d0> -> __attrs_133987186871120
            __attrs_133987186871120 = _static_133987180593808

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="0"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186868816
            __default_133987186868816 = _DEFAULT_MARKER

            # <Boolean u"python:status == None and 'selected' or None" (134:45)> -> __attr_selected
            __token = 4916
            try:
                __zt_tmp = __attrs_133987186871120
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == None and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987180593680 = []
            __append_133987180593680 = __stream_133987180593680.append
            __append_133987180593680(u'\n                Use parent settings\n            ')
            __msgid_133987180593680 = __re_whitespace(''.join(__stream_133987180593680)).strip()
            if u'portlets_value_use_parent':
                __append(translate(u'portlets_value_use_parent', mapping=None, default=__msgid_133987180593680, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52ad8ed0> name=None at 79dc52ad85d0> -> __attrs_133987186870032
            __attrs_133987186870032 = _static_133987186872016

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186871824
            __default_133987186871824 = _DEFAULT_MARKER

            # <Boolean u"python:status == True and 'selected' or None" (140:45)> -> __attr_selected
            __token = 5160
            try:
                __zt_tmp = __attrs_133987186870032
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == True and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987186870096 = []
            __append_133987186870096 = __stream_133987186870096.append
            __append_133987186870096(u'\n                Block\n            ')
            __msgid_133987186870096 = __re_whitespace(''.join(__stream_133987186870096)).strip()
            if u'portlets_value_block':
                __append(translate(u'portlets_value_block', mapping=None, default=__msgid_133987186870096, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n\n            ')

            # <Static value=<_ast.Dict object at 0x79dc52ad8650> name=None at 79dc52ad8090> -> __attrs_133987186869136
            __attrs_133987186869136 = _static_133987186869840

            # <option ... (0:0)
            # --------------------------------------------------------
            __append(u'<option value="-1"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186871888
            __default_133987186871888 = _DEFAULT_MARKER

            # <Boolean u"python:status == False and 'selected' or None" (146:45)> -> __attr_selected
            __token = 5386
            try:
                __zt_tmp = __attrs_133987186869136
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_selected = _static_133987276028048('python', u"status == False and 'selected' or None", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if (__attr_selected is _DEFAULT_MARKER):
                __attr_selected = None
            else:
                if __attr_selected:
                    __attr_selected = u'selected'
                else:
                    __attr_selected = None
            if (__attr_selected is not None):
                __append((u' selected="%s"' % __attr_selected))
            __append(u'>')
            __stream_133987186868432 = []
            __append_133987186868432 = __stream_133987186868432.append
            __append_133987186868432(u'\n                Do not block\n            ')
            __msgid_133987186868432 = __re_whitespace(''.join(__stream_133987186868432)).strip()
            if u'portlets_value_show':
                __append(translate(u'portlets_value_show', mapping=None, default=__msgid_133987186868432, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</option>\n        </select>\n\n        ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186868560
            __attrs_133987186868560 = _static_133987359720592
            __backup_portlets_133987180820112 = get('portlets', __marker)

            # <Value u'view/content_type_portlets' (152:36)> -> __value
            __token = 5597
            try:
                __zt_tmp = __attrs_133987186868560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/content_type_portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['portlets'] = __value
            __backup_status_133987180773456 = get('status', __marker)

            # <Value u'python:view.content_type_blacklist_status(check_parent=True)' (153:25)> -> __value
            __token = 5650
            try:
                __zt_tmp = __attrs_133987186868560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('python', u'view.content_type_blacklist_status(check_parent=True)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['status'] = __value
            __append(u'\n\n          ')

            # <Static value=<_ast.Dict object at 0x79dc52856750> name=None at 79dc52856e10> -> __attrs_133987184240080
            __attrs_133987184240080 = _static_133987184240464
            __backup_portlet_133987186811600 = get('portlet', __marker)

            # <Value u'portlets' (156:32)> -> __iterator
            __token = 5889
            try:
                __zt_tmp = __attrs_133987184240080
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            (__iterator, ____index_133987184242320, ) = getitem('repeat')(u'portlet', __iterator)
            econtext['portlet'] = None
            for __item in __iterator:
                econtext['portlet'] = __item

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184240400
                __default_133987184240400 = _DEFAULT_MARKER

                # <Substitution u"python:status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'" (155:37)> -> __attr_class
                __token = 5752
                try:
                    __zt_tmp = __attrs_133987184240080
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_133987276028048('python', u"status and 'managedPortlet inheritedPortlet blockedPortlet' or 'managedPortlet inheritedPortlet'", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\n            ')

                # <Static value=<_ast.Dict object at 0x79dc528568d0> name=None at 79dc52856d10> -> __attrs_133987184239952
                __attrs_133987184239952 = _static_133987184240848

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="portletHeader">\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52a9fd50> name=None at 79dc52a9fa90> -> __attrs_133987186636944
                __attrs_133987186636944 = _static_133987186638160

                # <Negate value=<Value u'not:portlet/editview' (158:31)> at 79dc52a9fcd0> -> __cache_133987186638032

                # <Value u'not:portlet/editview' (158:31)> -> __cache_133987186638032
                __token = 5971
                try:
                    __zt_tmp = __attrs_133987186636944
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186638032 = _static_133987276028048('not', u'portlet/editview', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __cache_133987186638032 = not __cache_133987186638032
                __condition = __cache_133987186638032
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186637264
                    __default_133987186637264 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/editview}?referer=${view/url_quote_referer}' (159:37)> -> __attr_href
                    __token = 6030
                    try:
                        __zt_tmp = __attrs_133987186636944
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133987276028048('string', u'${portlet/editview}?referer=${view/url_quote_referer}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186636112
                __default_133987186636112 = _DEFAULT_MARKER

                # <Value u'portlet/title' (160:29)> -> __cache_133987186636432
                __token = 6121
                try:
                    __zt_tmp = __attrs_133987186636944
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987186636432 = _static_133987276028048('path', u'portlet/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'portlet/title' (160:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52a9f5d0> -> __condition
                __expression = __cache_133987186636432

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_133987186636432
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __condition = __cache_133987186638032
                if __condition:
                    __append(u'</a>')
                __append(u'\n\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52a9f2d0> name=None at 79dc52a9f910> -> __attrs_133987186635728
                __attrs_133987186635728 = _static_133987186635472

                # <Value u'status' (163:31)> -> __condition
                __token = 6237
                try:
                    __zt_tmp = __attrs_133987186635728
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'status', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="portletBlockedMessage hiddenStructure"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186636624
                    __default_133987186636624 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_portlet_blocked' node=<_ast.Str object at 0x79dc52a9fb50> at 79dc52a9f1d0> -> __attr_title
                    __attr_title = u'Blocked'
                    __attr_title = translate(u'title_portlet_blocked', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>')
                    __stream_133987186634896 = []
                    __append_133987186634896 = __stream_133987186634896.append
                    __append_133987186634896(u'\n                (Blocked)\n              ')
                    __msgid_133987186634896 = __re_whitespace(''.join(__stream_133987186634896)).strip()
                    if u'label_portlet_blocked':
                        __append(translate(u'label_portlet_blocked', mapping=None, default=__msgid_133987186634896, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\n\n            </div>\n          </div>')
                ____index_133987184242320 -= 1
                if (____index_133987184242320 > 0):
                    __append('\n          ')
            if (__backup_portlet_133987186811600 is __marker):
                del econtext['portlet']
            else:
                econtext['portlet'] = __backup_portlet_133987186811600
            __append(u'\n        ')
            if (__backup_status_133987180773456 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_133987180773456
            if (__backup_portlets_133987180820112 is __marker):
                del econtext['portlets']
            else:
                econtext['portlets'] = __backup_portlets_133987180820112
            __append(u'\n\n      </div>')
            if (__backup_status_133987185498448 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_133987185498448
            __append(u'\n\n      ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184239760
            __attrs_133987184239760 = _static_133987359720592

            # <noscript ... (0:0)
            # --------------------------------------------------------
            __append(u'<noscript>\n      ')

            # <Static value=<_ast.Dict object at 0x79dc52985ed0> name=None at 79dc52a9f8d0> -> __attrs_133987185481104
            __attrs_133987185481104 = _static_133987185483472

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="formControls">\n          ')

            # <Static value=<_ast.Dict object at 0x79dc52985f90> name=None at 79dc52985fd0> -> __attrs_133987185481936
            __attrs_133987185481936 = _static_133987185483664

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input class="context" type="submit"')

            # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185482256
            __default_133987185482256 = _DEFAULT_MARKER

            # <Translate msgid=u'label_save_settings' node=<_ast.Str object at 0x79dc52985910> at 79dc529856d0> -> __attr_value
            __attr_value = u'Save settings'
            __attr_value = translate(u'label_save_settings', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\n      </div>\n      </noscript>\n\n    </form>\n  </div>\n</div>')
            __i18n_domain = __previous_i18n_domain_133987180770192
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }