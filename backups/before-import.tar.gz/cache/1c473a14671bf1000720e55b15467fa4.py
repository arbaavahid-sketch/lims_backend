# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/languageselector.pt'

__tokens = {29: (u'view/available', 1, 29), 490: (u'view/languages', 18, 30), 535: (u' context/@@plone_context_state/current_base_ur', 19, 28), 622: (u'languages', 21, 33), 667: (u'lang/code', 23, 30), 706: (u' request/QUERY_STRIN', 24, 27), 760: (u"s python:filter(lambda x: x and not x.startswith('set_language'), qs.split('&'", 25, 30), 876: (u'am string:set_language=${co', 26, 33), 941: (u"ams python:'&'.join(params + [lang_par", 27, 32), 1015: (u'cted lang/sel', 28, 29), 1065: (u'class string:language-$', 29, 29), 1123: (u"urrent python: selected and 'currentLanguage active dropdown-item' or 'dropdow", 30, 26), 1241: (u"nt_item python: selected and 'text-ligh", 31, 30), 1327: (u'string:${codeclass} ${current}', 32, 35), 1414: (u'lang/native|lang/name', 34, 30), 1473: (u'string:${base_url}?${new_params}', 35, 34), 1542: (u' string:${current_item} text-decoration-non', 36, 34), 1622: (u'e na', 37, 33), 1663: (u'name', 38, 31)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133838686153808 = {u'data-toggle': u'dropdown', u'href': u'#', u'class': u'nav-link dropdown-toggle', u'aria-expanded': u'false', u'aria-haspopup': u'true', }
_static_133838686153168 = {u'class': u'dropdown', }
_static_133838700752400 = {u'aria-labelledby': u'portal-languageselector', u'role': u'menu', u'class': u'dropdown-menu dropdown-menu-right', }
_static_133838700749264 = {u'class': u'fas fa-globe', }
_static_133838794967184 = __compile_zt_expr
_static_133838686001424 = {u'href': u'#', u'class': u'string:${current_item} text-decoration-none', u'title': u'name', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838686046800 = {u'class': u'string:${codeclass} ${current}', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698768784
            __attrs_133838698768784 = _static_133838878659728

            # <Value u'view/available' (1:29)> -> __condition
            __token = 29
            try:
                __zt_tmp = __attrs_133838698768784
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'view/available', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9bf5869d0> name=None at 79b9bf586390> -> __attrs_133838686153296
                __attrs_133838686153296 = _static_133838686153168

                # <nav ... (0:0)
                # --------------------------------------------------------
                __append(u'<nav class="dropdown">\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9bf586c50> name=None at 79b9bf586690> -> __attrs_133838700752848
                __attrs_133838700752848 = _static_133838686153808
                __previous_i18n_domain_133838700751312 = __i18n_domain
                __i18n_domain = u'plone'

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a href="#"        class="nav-link dropdown-toggle"        data-toggle="dropdown"        aria-haspopup="true"        aria-expanded="false">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9c03721d0> name=None at 79b9c0372d90> -> __attrs_133838700750096
                __attrs_133838700750096 = _static_133838700749264

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-globe"></i>\r\n    </a>')
                __i18n_domain = __previous_i18n_domain_133838700751312
                __append(u'\r\n\r\n    <!-- Available Languages -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9c0372e10> name=None at 79b9c0372d50> -> __attrs_133838686044368
                __attrs_133838686044368 = _static_133838700752400
                __backup_languages_133838716874448 = get('languages', __marker)

                # <Value u'view/languages' (18:30)> -> __value
                __token = 490
                try:
                    __zt_tmp = __attrs_133838686044368
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'view/languages', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['languages'] = __value
                __backup_base_url_133838685911632 = get('base_url', __marker)

                # <Value u'context/@@plone_context_state/current_base_url' (19:28)> -> __value
                __token = 535
                try:
                    __zt_tmp = __attrs_133838686044368
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'context/@@plone_context_state/current_base_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['base_url'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="dropdown-menu dropdown-menu-right"         role="menu"         aria-labelledby="portal-languageselector">\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686046160
                __attrs_133838686046160 = _static_133838878659728
                __backup_lang_133838705509776 = get('lang', __marker)

                # <Value u'languages' (21:33)> -> __iterator
                __token = 622
                try:
                    __zt_tmp = __attrs_133838686046160
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'languages', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838686045520, ) = getitem('repeat')(u'lang', __iterator)
                econtext['lang'] = None
                for __item in __iterator:
                    econtext['lang'] = __item
                    __append(u'\r\n\r\n        ')

                    # <Static value=<_ast.Dict object at 0x79b9bf56ca50> name=None at 79b9bf56c090> -> __attrs_133838685999248
                    __attrs_133838685999248 = _static_133838686046800
                    __backup_code_133838698893776 = get('code', __marker)

                    # <Value u'lang/code' (23:30)> -> __value
                    __token = 667
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'lang/code', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['code'] = __value
                    __backup_qs_133838698786256 = get('qs', __marker)

                    # <Value u'request/QUERY_STRING' (24:27)> -> __value
                    __token = 706
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'request/QUERY_STRING', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['qs'] = __value
                    __backup_params_133838698709200 = get('params', __marker)

                    # <Value u"python:filter(lambda x: x and not x.startswith('set_language'), qs.split('&'))" (25:30)> -> __value
                    __token = 760
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u"filter(lambda x: x and not x.startswith('set_language'), qs.split('&'))", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['params'] = __value
                    __backup_lang_param_133838681387600 = get('lang_param', __marker)

                    # <Value u'string:set_language=${code}' (26:33)> -> __value
                    __token = 876
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('string', u'set_language=${code}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['lang_param'] = __value
                    __backup_new_params_133838685970896 = get('new_params', __marker)

                    # <Value u"python:'&'.join(params + [lang_param])" (27:32)> -> __value
                    __token = 941
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u"'&'.join(params + [lang_param])", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['new_params'] = __value
                    __backup_selected_133838698914320 = get('selected', __marker)

                    # <Value u'lang/selected' (28:29)> -> __value
                    __token = 1015
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'lang/selected', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['selected'] = __value
                    __backup_codeclass_133838681335312 = get('codeclass', __marker)

                    # <Value u'string:language-${code}' (29:29)> -> __value
                    __token = 1065
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('string', u'language-${code}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['codeclass'] = __value
                    __backup_current_133838705510416 = get('current', __marker)

                    # <Value u"python: selected and 'currentLanguage active dropdown-item' or 'dropdown-item'" (30:26)> -> __value
                    __token = 1123
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u" selected and 'currentLanguage active dropdown-item' or 'dropdown-item'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['current'] = __value
                    __backup_current_item_133838681433680 = get('current_item', __marker)

                    # <Value u"python: selected and 'text-light' or ''" (31:30)> -> __value
                    __token = 1241
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u" selected and 'text-light' or ''", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['current_item'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686044752
                    __default_133838686044752 = _DEFAULT_MARKER

                    # <Substitution u'string:${codeclass} ${current}' (32:35)> -> __attr_class
                    __token = 1327
                    try:
                        __zt_tmp = __attrs_133838685999248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('string', u'${codeclass} ${current}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79b9bf561910> name=None at 79b9bf5613d0> -> __attrs_133838686100496
                    __attrs_133838686100496 = _static_133838686001424
                    __backup_name_133838681432400 = get('name', __marker)

                    # <Value u'lang/native|lang/name' (34:30)> -> __value
                    __token = 1414
                    try:
                        __zt_tmp = __attrs_133838686100496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('path', u'lang/native|lang/name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['name'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686002192
                    __default_133838686002192 = _DEFAULT_MARKER

                    # <Substitution u'string:${base_url}?${new_params}' (35:34)> -> __attr_href
                    __token = 1473
                    try:
                        __zt_tmp = __attrs_133838686100496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133838794967184('string', u'${base_url}?${new_params}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686001872
                    __default_133838686001872 = _DEFAULT_MARKER

                    # <Substitution u'string:${current_item} text-decoration-none' (36:34)> -> __attr_class
                    __token = 1542
                    try:
                        __zt_tmp = __attrs_133838686100496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('string', u'${current_item} text-decoration-none', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838685999376
                    __default_133838685999376 = _DEFAULT_MARKER

                    # <Substitution u'name' (37:33)> -> __attr_title
                    __token = 1622
                    try:
                        __zt_tmp = __attrs_133838686100496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_133838794967184('path', u'name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686099408
                    __attrs_133838686099408 = _static_133838878659728

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686098704
                    __default_133838686098704 = _DEFAULT_MARKER

                    # <Value u'name' (38:31)> -> __cache_133838686100688
                    __token = 1663
                    try:
                        __zt_tmp = __attrs_133838686099408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838686100688 = _static_133838794967184('path', u'name', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'name' (38:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf579110> -> __condition
                    __expression = __cache_133838686100688

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133838686100688
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n          </a>')
                    if (__backup_name_133838681432400 is __marker):
                        del econtext['name']
                    else:
                        econtext['name'] = __backup_name_133838681432400
                    __append(u'\r\n        </div>')
                    if (__backup_current_item_133838681433680 is __marker):
                        del econtext['current_item']
                    else:
                        econtext['current_item'] = __backup_current_item_133838681433680
                    if (__backup_current_133838705510416 is __marker):
                        del econtext['current']
                    else:
                        econtext['current'] = __backup_current_133838705510416
                    if (__backup_codeclass_133838681335312 is __marker):
                        del econtext['codeclass']
                    else:
                        econtext['codeclass'] = __backup_codeclass_133838681335312
                    if (__backup_selected_133838698914320 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_133838698914320
                    if (__backup_new_params_133838685970896 is __marker):
                        del econtext['new_params']
                    else:
                        econtext['new_params'] = __backup_new_params_133838685970896
                    if (__backup_lang_param_133838681387600 is __marker):
                        del econtext['lang_param']
                    else:
                        econtext['lang_param'] = __backup_lang_param_133838681387600
                    if (__backup_params_133838698709200 is __marker):
                        del econtext['params']
                    else:
                        econtext['params'] = __backup_params_133838698709200
                    if (__backup_qs_133838698786256 is __marker):
                        del econtext['qs']
                    else:
                        econtext['qs'] = __backup_qs_133838698786256
                    if (__backup_code_133838698893776 is __marker):
                        del econtext['code']
                    else:
                        econtext['code'] = __backup_code_133838698893776
                    __append(u'\r\n      ')
                    ____index_133838686045520 -= 1
                    if (____index_133838686045520 > 0):
                        __append('')
                if (__backup_lang_133838705509776 is __marker):
                    del econtext['lang']
                else:
                    econtext['lang'] = __backup_lang_133838705509776
                __append(u'\r\n    </div>')
                if (__backup_base_url_133838685911632 is __marker):
                    del econtext['base_url']
                else:
                    econtext['base_url'] = __backup_base_url_133838685911632
                if (__backup_languages_133838716874448 is __marker):
                    del econtext['languages']
                else:
                    econtext['languages'] = __backup_languages_133838716874448
                __append(u'\r\n  </nav>\r\n')
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }