# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/documentactions.pt'

__tokens = {105: (u'view/actions', 4, 33), 200: (u'nocall: context/@@plone/normalizeString', 6, 36), 273: (u'view/actions', 7, 30), 317: (u"python:'document-action-' + normalizeString(daction['id'])", 8, 29), 462: (u'daction/url', 11, 33), 510: (u' daction/link_target|nothin', 12, 34), 573: (u'e daction/descripti', 13, 32), 628: (u'daction/icon', 14, 30), 679: (u"python:daction.get('icon')", 15, 36), 743: (u" python:daction.get('title'", 16, 35), 810: (u"e python:daction.get('title", 17, 36), 873: (u'not:daction/icon', 18, 29), 919: (u"python:daction.get('id')", 19, 27)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525979686032 = {}
_static_124525521408464 = {u'id': u'senaite-document-actions', }
_static_124525735408656 = {u'title': u'daction/description', u'href': u'', u'class': u'nav-link', u'target': u'daction/link_target|nothing', }
_static_124525732131088 = {u'class': u'nav nav-pills float-right', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525731902864 = {u'src': u"python:daction.get('icon')", u'alt': u"python:daction.get('title')", u'title': u"python:daction.get('title')", }
_static_124525732134288 = {u'id': u"python:'document-action-' + normalizeString(daction['id'])", }
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7811d0> name=None at 71415b781bd0> -> __attrs_124525732179664
            __attrs_124525732179664 = _static_124525521408464
            __previous_i18n_domain_124525732176080 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="senaite-document-actions">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732133776
            __attrs_124525732133776 = _static_124525979686032

            # <Value u'view/actions' (4:33)> -> __condition
            __token = 105
            try:
                __zt_tmp = __attrs_124525732133776
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'view/actions', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x714168077110> name=None at 714168077ed0> -> __attrs_124525732133264
                __attrs_124525732133264 = _static_124525732131088
                __backup_normalizeString_124525732091792 = get('normalizeString', __marker)

                # <Value u'nocall: context/@@plone/normalizeString' (6:36)> -> __value
                __token = 200
                try:
                    __zt_tmp = __attrs_124525732133264
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('nocall', u' context/@@plone/normalizeString', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['normalizeString'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-pills float-right">\r\n      ')

                # <Static value=<_ast.Dict object at 0x714168077d90> name=None at 7141680779d0> -> __attrs_124525732134160
                __attrs_124525732134160 = _static_124525732134288
                __backup_daction_124525521546064 = get('daction', __marker)

                # <Value u'view/actions' (7:30)> -> __iterator
                __token = 273
                try:
                    __zt_tmp = __attrs_124525732134160
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'view/actions', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525732134736, ) = getitem('repeat')(u'daction', __iterator)
                econtext['daction'] = None
                for __item in __iterator:
                    econtext['daction'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732134224
                    __default_124525732134224 = _DEFAULT_MARKER

                    # <Substitution u"python:'document-action-' + normalizeString(daction['id'])" (8:29)> -> __attr_id
                    __token = 317
                    try:
                        __zt_tmp = __attrs_124525732134160
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_124525896001680('python', u"'document-action-' + normalizeString(daction['id'])", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714168397410> name=None at 714168397510> -> __attrs_124525521512784
                    __attrs_124525521512784 = _static_124525735408656

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731902800
                    __default_124525731902800 = _DEFAULT_MARKER

                    # <Substitution u'daction/url' (11:33)> -> __attr_href
                    __token = 462
                    try:
                        __zt_tmp = __attrs_124525521512784
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('path', u'daction/url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'             class="nav-link"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732176144
                    __default_124525732176144 = _DEFAULT_MARKER

                    # <Substitution u'daction/link_target|nothing' (12:34)> -> __attr_target
                    __token = 510
                    try:
                        __zt_tmp = __attrs_124525521512784
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_target = _static_124525896001680('path', u'daction/link_target|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_target = __quote(__attr_target, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_target is not None):
                        __append((u' target="%s"' % __attr_target))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732179408
                    __default_124525732179408 = _DEFAULT_MARKER

                    # <Substitution u'daction/description' (13:32)> -> __attr_title
                    __token = 573
                    try:
                        __zt_tmp = __attrs_124525521512784
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_124525896001680('path', u'daction/description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\r\n          ')

                    # <Static value=<_ast.Dict object at 0x71416803f590> name=None at 71416803fe90> -> __attrs_124525731901712
                    __attrs_124525731901712 = _static_124525731902864

                    # <Value u'daction/icon' (14:30)> -> __condition
                    __token = 628
                    try:
                        __zt_tmp = __attrs_124525731901712
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('path', u'daction/icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731905232
                        __default_124525731905232 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('icon')" (15:36)> -> __attr_src
                        __token = 679
                        try:
                            __zt_tmp = __attrs_124525731901712
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_124525896001680('python', u"daction.get('icon')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731901520
                        __default_124525731901520 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('title')" (16:35)> -> __attr_alt
                        __token = 743
                        try:
                            __zt_tmp = __attrs_124525731901712
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_alt = _static_124525896001680('python', u"daction.get('title')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        __attr_alt = __quote(__attr_alt, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_alt is not None):
                            __append((u' alt="%s"' % __attr_alt))

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731903760
                        __default_124525731903760 = _DEFAULT_MARKER

                        # <Substitution u"python:daction.get('title')" (17:36)> -> __attr_title
                        __token = 810
                        try:
                            __zt_tmp = __attrs_124525731901712
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_124525896001680('python', u"daction.get('title')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'/>')
                    __append(u'\r\n        ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731903952
                    __attrs_124525731903952 = _static_124525979686032

                    # <Value u'not:daction/icon' (18:29)> -> __condition
                    __token = 873
                    try:
                        __zt_tmp = __attrs_124525731903952
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('not', u'daction/icon', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731905424
                        __default_124525731905424 = _DEFAULT_MARKER

                        # <Value u"python:daction.get('id')" (19:27)> -> __cache_124525731902160
                        __token = 919
                        try:
                            __zt_tmp = __attrs_124525731903952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_124525731902160 = _static_124525896001680('python', u"daction.get('id')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                        # <BinOp left=<Value u"python:daction.get('id')" (19:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71416803f390> -> __condition
                        __expression = __cache_124525731902160

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_124525731902160
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>')
                    __append(u'\r\n        </a>\r\n      </li>')
                    ____index_124525732134736 -= 1
                    if (____index_124525732134736 > 0):
                        __append('\n      ')
                if (__backup_daction_124525521546064 is __marker):
                    del econtext['daction']
                else:
                    econtext['daction'] = __backup_daction_124525521546064
                __append(u'\r\n    </ul>')
                if (__backup_normalizeString_124525732091792 is __marker):
                    del econtext['normalizeString']
                else:
                    econtext['normalizeString'] = __backup_normalizeString_124525732091792
                __append(u'\r\n  ')
            __append(u'\r\n</div>')
            __i18n_domain = __previous_i18n_domain_124525732176080
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }