# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/colophon.pt'

__tokens = {}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info

_static_135757071748240 = {u'class': u'row', }
_static_135757152171024 = {u'class': u'container-fluid', }
_static_135757074403728 = {u'href': u'http://plone.org', u'title': u'This site was built using the Plone Open Source CMS/WCM.', }
_static_135757073133776 = {u'class': u'list-inline', }
_static_135757073137360 = {u'class': u'text-center text-muted', }
_static_135757071745168 = {u'class': u'col-md-12', }
_static_135757152171536 = {u'id': u'senaite-colophon', }
_static_135757327983760 = {}

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786cd4b610> name=None at 7b786cd4b3d0> -> __attrs_135757152171152
            __attrs_135757152171152 = _static_135757152171536
            __previous_i18n_domain_135757152172816 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="senaite-colophon">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786cd4b410> name=None at 7b786cd4b450> -> __attrs_135757152173968
            __attrs_135757152173968 = _static_135757152171024

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\n    ')

            # <Static value=<_ast.Dict object at 0x7b7868098c90> name=None at 7b7868098150> -> __attrs_135757071745936
            __attrs_135757071745936 = _static_135757071748240

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n      ')

            # <Static value=<_ast.Dict object at 0x7b7868098090> name=None at 7b7868098050> -> __attrs_135757305639952
            __attrs_135757305639952 = _static_135757071745168

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b78681ebed0> name=None at 7b78681eb950> -> __attrs_135757073134352
            __attrs_135757073134352 = _static_135757073137360

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="text-center text-muted">\n          ')

            # <Static value=<_ast.Dict object at 0x7b78681eb0d0> name=None at 7b78681ebcd0> -> __attrs_135757073133968
            __attrs_135757073133968 = _static_135757073133776

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-inline">\n            ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075399696
            __attrs_135757075399696 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>\n              ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074406864
            __attrs_135757074406864 = _static_135757327983760

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span>')
            __stream_135757075400720 = []
            __append_135757075400720 = __stream_135757075400720.append
            __append_135757075400720(u'SENAITE is powered by')
            __msgid_135757075400720 = __re_whitespace(''.join(__stream_135757075400720)).strip()
            if u'label_powered_by':
                __append(translate(u'label_powered_by', mapping=None, default=__msgid_135757075400720, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</span>\n              ')

            # <Static value=<_ast.Dict object at 0x7b7868321190> name=None at 7b7868321e10> -> __attrs_135757074406800
            __attrs_135757074406800 = _static_135757074403728

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a href="http://plone.org"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074406608
            __default_135757074406608 = _DEFAULT_MARKER

            # <Translate msgid=u'title_built_with_plone' node=<_ast.Str object at 0x7b7868321690> at 7b7868321d10> -> __attr_title
            __attr_title = u'This site was built using the Plone Open Source CMS/WCM.'
            __attr_title = translate(u'title_built_with_plone', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))
            __append(u'>')
            __stream_135757074407248 = []
            __append_135757074407248 = __stream_135757074407248.append
            __append_135757074407248(u'\n                Plone &amp; Python')
            __msgid_135757074407248 = __re_whitespace(''.join(__stream_135757074407248)).strip()
            if u'label_powered_by_plone':
                __append(translate(u'label_powered_by_plone', mapping=None, default=__msgid_135757074407248, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\n            </li>\n          </ul>\n        </div>\n\n      </div>\n    </div>\n  </div>\n\n</div>')
            __i18n_domain = __previous_i18n_domain_135757152172816
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }