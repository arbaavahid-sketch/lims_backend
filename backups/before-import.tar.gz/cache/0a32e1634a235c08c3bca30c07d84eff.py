# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/install/templates/senaite-overview.pt'

__tokens = {662: (u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', 16, 31), 895: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 19, 31), 1017: (u'view/sites', 22, 26), 1294: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', 33, 39), 1579: (u'sites', 39, 40), 1628: (u'python:len(sites) == 1', 40, 40), 1694: (u'sites', 41, 40), 1953: (u'site/absolute_url', 46, 47), 2224: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 51, 50), 2543: (u'python:view.outdated(site)', 56, 41), 2940: (u'python:view.upgrade_url(site)', 63, 53), 3021: (u'not:view/can_manage', 64, 48), 3161: (u'python:view.upgrade_url(site, can_manage=True)', 66, 54), 3646: (u'python:len(sites) &gt', 77, 41), 3882: (u'sites', 80, 65), 4024: (u'site/absolute_url', 83, 48), 4082: (u' site/Titl', 84, 38), 4312: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 88, 51), 4441: (u'site/Title', 89, 45), 4521: (u'string: (${site/getId})', 90, 59), 4710: (u'python:view.outdated(site)', 94, 42), 5133: (u'python:view.upgrade_url(site)', 102, 53), 5214: (u'not:view/can_manage', 103, 48), 5356: (u'python:view.upgrade_url(site, can_manage=True)', 105, 55), 5984: (u'not:sites', 121, 55), 6138: (u'sites', 124, 55), 6384: (u"python: '' if not sites else len(sites) + 1", 130, 46), 6475: (u'string:${context/absolute_url}/@@senaite-addsite', 131, 45), 6588: (u'senaite${site_number}', 132, 61), 6597: (u'site_number', 132, 70), 7039: (u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&amp;advanc', 140, 42)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_138366755600016 = {u'class': u'small', }
_static_138366756149968 = {u'action': u'', u'style': u'display: inline;', u'method': u'get', }
_static_138366755688912 = {u'type': u'submit', u'class': u'btn btn-success', u'value': u'Create a new SENAITE site', }
_static_138366755727440 = {u'class': u'lead', }
_static_138366755924112 = {u'class': u'list-group', }
_static_138366756314704 = {u'id': u'text', }
_static_138366756314000 = {u'class': u'col-sm-6 offset-sm-3', }
_static_138366756045072 = {u'href': u'favicon.ico', u'type': u'image/x-icon', u'rel': u'icon', }
_static_138366755860880 = {u'class': u'list-group-item', }
_static_138366755803280 = {u'class': u'list-inline-item', }
_static_138366755612880 = {u'type': u'hidden', u'name': u'came_from', u'value': u'python:view.upgrade_url(site, can_manage=True)', }
_static_138366755924752 = {u'class': u'list-group-item', }
_static_138366755533712 = {u'class': u'list-group', }
_static_138366755536464 = {u'class': u'prominent', }
_static_138366755669136 = {u'type': u'hidden', u'name': u'site_id', u'value': u'senaite${site_number}', }
_static_138366755641104 = {u'class': u'row', }
_static_138366930725392 = __C2ZContextWrapper
_static_138366755559760 = {u'class': u'upgrade-warning', }
_static_138366755496272 = {u'id': u'multiple-sites', }
_static_138367014417552 = {}
_static_138366755939728 = {u'src': u'favicon.ico', u'height': u'16', }
_static_138366755558160 = {u'href': u'#', u'class': u'btn btn-outline-secondary btn-sm', u'title': u'site/Title', }
_static_138366755062864 = {u'href': u'https://twitter.com/senaitelims', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Twitter', }
_static_138366755941520 = {u'class': u'upgrade-warning', }
_static_138366756288144 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_138366755778512 = {u'class': u'list-inline-item', }
_static_138366756363344 = {u'class': u'lead', }
_static_138366756311184 = {u'class': u'row', }
_static_138366755496656 = {u'type': u'hidden', u'name': u'came_from', u'value': u'python:view.upgrade_url(site, can_manage=True)', }
_static_138366755806480 = {u'href': u'https://gitter.im/senaite/Lobby', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Gitter Chat', }
_static_138366930725008 = __compile_zt_expr
_static_138366755534992 = {u'class': u'list-group-item', }
_static_138366755863440 = {u'class': u'prominent', }
_static_138366755803536 = {u'href': u'https://community.senaite.com', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'SENAITE community', }
_static_138366756270736 = {u'charset': u'utf-8', }
_static_138366755825872 = {u'href': u'https://github.com/senaite', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'GitHub', }
_static_138366755498448 = {u'type': u'submit', u'class': u'plone-btn-secondary', u'value': u'Upgrade&hellip;', }
_static_138366755610832 = {u'action': u'', u'style': u'display: inline;', u'method': u'get', }
_static_138366756237200 = {u'href': u'bootstrap.min.css', u'type': u'text/css', u'rel': u'stylesheet', }
_static_138366755642256 = {u'action': u'#', u'id': u'add-plone-site', u'method': u'get', }
_static_138366755614672 = {u'type': u'submit', u'class': u'btn btn-secondary', u'value': u'Upgrade&hellip;', }
_static_138366756047888 = {u'class': u'container', }
_static_138366755939472 = {u'href': u'#', u'class': u'btn btn-outline-secondary btn-sm', u'title': u'Go to your instance', }
_static_138366755775760 = {u'class': u'list-inline-item', }
_static_138366755825552 = {u'class': u'list-inline-item', }
_static_138366755560272 = {u'src': u'favicon.ico', u'height': u'16', }
_static_138366755670672 = {u'type': u'hidden', u'name': u'site_title', u'value': u'SENAITE LIMS', }
_static_138366756363664 = {u'src': u'senaite-logo.png', u'height': u'30', }
_static_138366755728400 = {u'class': u'list-inline flex-column flex-sm-row', }
_static_138366755690704 = {u'href': u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1', u'class': u'btn btn-outline-secondary', }
_static_138366755776080 = {u'href': u'https://www.senaite.com', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Website', }
_static_138366755774800 = {u'class': u'list-inline-item', }
_static_138366755725648 = {u'class': u'col-sm-12', }
_static_138366756234000 = {u'content': u'width=device-width, initial-scale=1', u'name': u'viewport', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n\r\n')

            # <Static value=<_ast.Dict object at 0x7dd8055b7690> name=None at 7dd8055b71d0> -> __attrs_138366756271568
            __attrs_138366756271568 = _static_138366756288144
            __previous_i18n_domain_138366756272464 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"       lang="en">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756274064
            __attrs_138366756274064 = _static_138367014417552

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd8055b3290> name=None at 7dd8055b3dd0> -> __attrs_138366756272976
            __attrs_138366756272976 = _static_138366756270736

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta charset="utf-8"/>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd8055aa310> name=None at 7dd8055aa2d0> -> __attrs_138366756236176
            __attrs_138366756236176 = _static_138366756234000

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport" content="width=device-width, initial-scale=1"/>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756236048
            __attrs_138366756236048 = _static_138367014417552

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title>')
            __stream_138366756236624 = []
            __append_138366756236624 = __stream_138366756236624.append
            __append_138366756236624(u'Welcome to SENAITE')
            __msgid_138366756236624 = __re_whitespace(''.join(__stream_138366756236624)).strip()
            if __msgid_138366756236624:
                __append(translate(__msgid_138366756236624, mapping=None, default=__msgid_138366756236624, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</title>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd8055aaf90> name=None at 7dd80581d990> -> __attrs_138366756235344
            __attrs_138366756235344 = _static_138366756237200

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet" type="text/css"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756236240
            __default_138366756236240 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css' (16:31)> -> __attr_href
            __token = 662
            try:
                __zt_tmp = __attrs_138366756235344
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_138366930725008('string', u'${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'bootstrap.min.css', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u'           href="%s"' % __attr_href))
            __append(u' />\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd80557c110> name=None at 7dd80557c490> -> __attrs_138366756048656
            __attrs_138366756048656 = _static_138366756045072

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756045584
            __default_138366756045584 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (19:31)> -> __attr_href
            __token = 895
            try:
                __zt_tmp = __attrs_138366756048656
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_138366930725008('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="icon" type="image/x-icon"/>\r\n  </head>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756046736
            __attrs_138366756046736 = _static_138367014417552
            __backup_sites_138366756289104 = get('sites', __marker)

            # <Value u'view/sites' (22:26)> -> __value
            __token = 1017
            try:
                __zt_tmp = __attrs_138366756046736
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('path', u'view/sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['sites'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd80557cc10> name=None at 7dd80557cad0> -> __attrs_138366756048144
            __attrs_138366756048144 = _static_138366756047888

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container">\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd8055bd090> name=None at 7dd805856e90> -> __attrs_138366756312080
            __attrs_138366756312080 = _static_138366756311184

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n        ')

            # <Static value=<_ast.Dict object at 0x7dd8055bdb90> name=None at 7dd8055bda50> -> __attrs_138366756313424
            __attrs_138366756313424 = _static_138366756314000

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-6 offset-sm-3">\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd8055bde50> name=None at 7dd8055bd890> -> __attrs_138366756519376
            __attrs_138366756519376 = _static_138366756314704

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="text">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756362128
            __attrs_138366756362128 = _static_138367014417552

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1>\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd8055c9d90> name=None at 7dd8055c9dd0> -> __attrs_138366756363536
            __attrs_138366756363536 = _static_138366756363664

            # <img ... (0:0)
            # --------------------------------------------------------
            __append(u'<img')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756360656
            __default_138366756360656 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg' (33:39)> -> __attr_src
            __token = 1294
            try:
                __zt_tmp = __attrs_138366756363536
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_138366930725008('string', u'${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'senaite-logo.png', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'                    height="30" />\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd8055c9c50> name=None at 7dd8055c9a10> -> __attrs_138366756364176
            __attrs_138366756364176 = _static_138366756363344

            # <small ... (0:0)
            # --------------------------------------------------------
            __append(u'<small class="lead">Enterprise Open Source Laboratory System</small>\r\n            </h1>\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756757328
            __attrs_138366756757328 = _static_138367014417552

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\r\n\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80555e890> name=None at 7dd8056298d0> -> __attrs_138366755924816
            __attrs_138366755924816 = _static_138366755924112

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-group">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755925520
            __attrs_138366755925520 = _static_138367014417552

            # <Value u'sites' (39:40)> -> __condition
            __token = 1579
            try:
                __zt_tmp = __attrs_138366755925520
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_138366930725008('path', u'sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755922512
                __attrs_138366755922512 = _static_138367014417552

                # <Value u'python:len(sites) == 1' (40:40)> -> __condition
                __token = 1628
                try:
                    __zt_tmp = __attrs_138366755922512
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('python', u'len(sites) == 1', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755863760
                    __attrs_138366755863760 = _static_138367014417552
                    __backup_site_138366756519312 = get('site', __marker)

                    # <Value u'sites' (41:40)> -> __iterator
                    __token = 1694
                    try:
                        __zt_tmp = __attrs_138366755863760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_138366930725008('path', u'sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    (__iterator, ____index_138366755862608, ) = getitem('repeat')(u'site', __iterator)
                    econtext['site'] = None
                    for __item in __iterator:
                        econtext['site'] = __item

                        # <tal ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<tal>\r\n                    ')

                        # <Static value=<_ast.Dict object at 0x7dd80554f190> name=None at 7dd80554f110> -> __attrs_138366755861840
                        __attrs_138366755861840 = _static_138366755860880

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="list-group-item">\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x7dd80554fb90> name=None at 7dd80554ff10> -> __attrs_138366755862864
                        __attrs_138366755862864 = _static_138366755863440

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="prominent">\r\n                        ')

                        # <Static value=<_ast.Dict object at 0x7dd805562490> name=None at 7dd805562f10> -> __attrs_138366755940752
                        __attrs_138366755940752 = _static_138366755939472

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755942096
                        __default_138366755942096 = _DEFAULT_MARKER

                        # <Substitution u'site/absolute_url' (46:47)> -> __attr_href
                        __token = 1953
                        try:
                            __zt_tmp = __attrs_138366755940752
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_138366930725008('path', u'site/absolute_url', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'                           class="btn btn-outline-secondary btn-sm"')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755938512
                        __default_138366755938512 = _DEFAULT_MARKER

                        # <Translate msgid=None node=<_ast.Str object at 0x7dd805562790> at 7dd805562310> -> __attr_title
                        __attr_title = u'Go to your instance'
                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u'                           title="%s"' % __attr_title))
                        __append(u'>\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd805562590> name=None at 7dd8055628d0> -> __attrs_138366755942288
                        __attrs_138366755942288 = _static_138366755939728

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755938704
                        __default_138366755938704 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (51:50)> -> __attr_src
                        __token = 2224
                        try:
                            __zt_tmp = __attrs_138366755942288
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_138366930725008('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))
                        __append(u'                               height="16" />\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756148048
                        __attrs_138366756148048 = _static_138367014417552

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                        __stream_138366756147280 = []
                        __append_138366756147280 = __stream_138366756147280.append
                        __append_138366756147280(u'View your SENAITE site')
                        __msgid_138366756147280 = __re_whitespace(''.join(__stream_138366756147280)).strip()
                        if __msgid_138366756147280:
                            __append(translate(__msgid_138366756147280, mapping=None, default=__msgid_138366756147280, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\r\n                        </a>\r\n                      </span>\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x7dd805562c90> name=None at 7dd805562d50> -> __attrs_138366756149392
                        __attrs_138366756149392 = _static_138366755941520

                        # <Value u'python:view.outdated(site)' (56:41)> -> __condition
                        __token = 2543
                        try:
                            __zt_tmp = __attrs_138366756149392
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_138366930725008('python', u'view.outdated(site)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="upgrade-warning">\r\n                        ')

                            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756149648
                            __attrs_138366756149648 = _static_138367014417552

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_138366756149776 = []
                            __append_138366756149776 = __stream_138366756149776.append
                            __append_138366756149776(u'\r\n                          This site configuration is outdated and needs to be\r\n                          upgraded:')
                            __msgid_138366756149776 = __re_whitespace(''.join(__stream_138366756149776)).strip()
                            if __msgid_138366756149776:
                                __append(translate(__msgid_138366756149776, mapping=None, default=__msgid_138366756149776, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>\r\n                        ')

                            # <Static value=<_ast.Dict object at 0x7dd805595ad0> name=None at 7dd805595c10> -> __attrs_138366756148368
                            __attrs_138366756148368 = _static_138366756149968

                            # <form ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<form')

                            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756147728
                            __default_138366756147728 = _DEFAULT_MARKER

                            # <Substitution u'python:view.upgrade_url(site)' (63:53)> -> __attr_action
                            __token = 2940
                            try:
                                __zt_tmp = __attrs_138366756148368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_action = _static_138366930725008('python', u'view.upgrade_url(site)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                            __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_action is not None):
                                __append((u' action="%s"' % __attr_action))
                            __append(u'                               style="display: inline;"                               method="get">\r\n                          ')

                            # <Static value=<_ast.Dict object at 0x7dd8054f62d0> name=None at 7dd8054f6290> -> __attrs_138366755497872
                            __attrs_138366755497872 = _static_138366755496656

                            # <Value u'not:view/can_manage' (64:48)> -> __condition
                            __token = 3021
                            try:
                                __zt_tmp = __attrs_138366755497872
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_138366930725008('not', u'view/can_manage', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                            if __condition:

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input                                 type="hidden" name="came_from"')

                                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755497616
                                __default_138366755497616 = _DEFAULT_MARKER

                                # <Substitution u'python:view.upgrade_url(site, can_manage=True)' (66:54)> -> __attr_value
                                __token = 3161
                                try:
                                    __zt_tmp = __attrs_138366755497872
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_138366930725008('python', u'view.upgrade_url(site, can_manage=True)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u'/>')
                            __append(u'\r\n                          ')

                            # <Static value=<_ast.Dict object at 0x7dd8054f69d0> name=None at 7dd8054f6910> -> __attrs_138366755499856
                            __attrs_138366755499856 = _static_138366755498448

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="submit"                                 class="plone-btn-secondary"')

                            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755499600
                            __default_138366755499600 = _DEFAULT_MARKER

                            # <Translate msgid=u'label_upgrade_hellip' node=<_ast.Str object at 0x7dd8054f6d90> at 7dd8054f6dd0> -> __attr_value
                            __attr_value = u'Upgrade&hellip;'
                            __attr_value = translate(u'label_upgrade_hellip', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_value is not None):
                                __append((u'                                 value="%s"' % __attr_value))
                            __append(u' />\r\n                        </form>\r\n                      </div>')
                        __append(u'\r\n                    </li>\r\n                  </tal>')
                        ____index_138366755862608 -= 1
                        if (____index_138366755862608 > 0):
                            __append('\n                  ')
                    if (__backup_site_138366756519312 is __marker):
                        del econtext['site']
                    else:
                        econtext['site'] = __backup_site_138366756519312
                    __append(u'\r\n                ')
                __append(u'\r\n\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755862480
                __attrs_138366755862480 = _static_138367014417552

                # <Value u'python:len(sites) > 1' (77:41)> -> __condition
                __token = 3646
                try:
                    __zt_tmp = __attrs_138366755862480
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('python', u'len(sites) > 1', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x7dd8054f6150> name=None at 7dd8054f6050> -> __attrs_138366755533264
                    __attrs_138366755533264 = _static_138366755496272

                    # <h2 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h2 id="multiple-sites">')
                    __stream_138366756149904 = []
                    __append_138366756149904 = __stream_138366756149904.append
                    __append_138366756149904(u' You have multiple SENAITE sites:')
                    __msgid_138366756149904 = __re_whitespace(''.join(__stream_138366756149904)).strip()
                    if __msgid_138366756149904:
                        __append(translate(__msgid_138366756149904, mapping=None, default=__msgid_138366756149904, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h2>\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x7dd8054ff390> name=None at 7dd8054ff2d0> -> __attrs_138366755534288
                    __attrs_138366755534288 = _static_138366755533712

                    # <ul ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<ul class="list-group">\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x7dd8054ff890> name=None at 7dd8054ff850> -> __attrs_138366755535632
                    __attrs_138366755535632 = _static_138366755534992
                    __backup_site_138366755924304 = get('site', __marker)

                    # <Value u'sites' (80:65)> -> __iterator
                    __token = 3882
                    try:
                        __zt_tmp = __attrs_138366755535632
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_138366930725008('path', u'sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    (__iterator, ____index_138366755535824, ) = getitem('repeat')(u'site', __iterator)
                    econtext['site'] = None
                    for __item in __iterator:
                        econtext['site'] = __item

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="list-group-item">\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x7dd8054ffe50> name=None at 7dd8054ffdd0> -> __attrs_138366755557584
                        __attrs_138366755557584 = _static_138366755536464

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="prominent">\r\n                        ')

                        # <Static value=<_ast.Dict object at 0x7dd805505310> name=None at 7dd805505350> -> __attrs_138366755559696
                        __attrs_138366755559696 = _static_138366755558160

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755558928
                        __default_138366755558928 = _DEFAULT_MARKER

                        # <Substitution u'site/absolute_url' (83:48)> -> __attr_href
                        __token = 4024
                        try:
                            __zt_tmp = __attrs_138366755559696
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_138366930725008('path', u'site/absolute_url', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'                            class="btn btn-outline-secondary btn-sm"')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755559376
                        __default_138366755559376 = _DEFAULT_MARKER

                        # <Substitution u'site/Title' (84:38)> -> __attr_title
                        __token = 4082
                        try:
                            __zt_tmp = __attrs_138366755559696
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_138366930725008('path', u'site/Title', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd805505b50> name=None at 7dd805505bd0> -> __attrs_138366755561360
                        __attrs_138366755561360 = _static_138366755560272

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755560912
                        __default_138366755560912 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (88:51)> -> __attr_src
                        __token = 4312
                        try:
                            __zt_tmp = __attrs_138366755561360
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_138366930725008('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))
                        __append(u'                                height="16" />\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755599184
                        __attrs_138366755599184 = _static_138367014417552

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755598800
                        __default_138366755598800 = _DEFAULT_MARKER

                        # <Value u'site/Title' (89:45)> -> __cache_138366755598480
                        __token = 4441
                        try:
                            __zt_tmp = __attrs_138366755599184
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366755598480 = _static_138366930725008('path', u'site/Title', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'site/Title' (89:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd805562610> -> __condition
                        __expression = __cache_138366755598480

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_138366755598480
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd80550f690> name=None at 7dd80550f650> -> __attrs_138366755600592
                        __attrs_138366755600592 = _static_138366755600016

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="small">')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755599760
                        __default_138366755599760 = _DEFAULT_MARKER

                        # <Value u'string: (${site/getId})' (90:59)> -> __cache_138366755599376
                        __token = 4521
                        try:
                            __zt_tmp = __attrs_138366755600592
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366755599376 = _static_138366930725008('string', u' (${site/getId})', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'string: (${site/getId})' (90:59)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80550f4d0> -> __condition
                        __expression = __cache_138366755599376

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_138366755599376
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n                        </a>\r\n                      </span>\r\n                      ')

                        # <Static value=<_ast.Dict object at 0x7dd805505950> name=None at 7dd8055052d0> -> __attrs_138366755601104
                        __attrs_138366755601104 = _static_138366755559760

                        # <Value u'python:view.outdated(site)' (94:42)> -> __condition
                        __token = 4710
                        try:
                            __zt_tmp = __attrs_138366755601104
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_138366930725008('python', u'view.outdated(site)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="upgrade-warning">\r\n                        ')

                            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755602128
                            __attrs_138366755602128 = _static_138367014417552

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_138366755601808 = []
                            __append_138366755601808 = __stream_138366755601808.append
                            __append_138366755601808(u'\r\n                          This site configuration is outdated and\r\n                          needs to be upgraded:\r\n                        ')
                            __msgid_138366755601808 = __re_whitespace(''.join(__stream_138366755601808)).strip()
                            if __msgid_138366755601808:
                                __append(translate(__msgid_138366755601808, mapping=None, default=__msgid_138366755601808, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>\r\n                        ')

                            # <Static value=<_ast.Dict object at 0x7dd8055120d0> name=None at 7dd80550ffd0> -> __attrs_138366755612176
                            __attrs_138366755612176 = _static_138366755610832

                            # <form ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<form')

                            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755611472
                            __default_138366755611472 = _DEFAULT_MARKER

                            # <Substitution u'python:view.upgrade_url(site)' (102:53)> -> __attr_action
                            __token = 5133
                            try:
                                __zt_tmp = __attrs_138366755612176
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_action = _static_138366930725008('python', u'view.upgrade_url(site)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                            __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_action is not None):
                                __append((u' action="%s"' % __attr_action))
                            __append(u'                               style="display: inline;"                               method="get">\r\n                          ')

                            # <Static value=<_ast.Dict object at 0x7dd8055128d0> name=None at 7dd805512890> -> __attrs_138366755614096
                            __attrs_138366755614096 = _static_138366755612880

                            # <Value u'not:view/can_manage' (103:48)> -> __condition
                            __token = 5214
                            try:
                                __zt_tmp = __attrs_138366755614096
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_138366930725008('not', u'view/can_manage', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                            if __condition:

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input                                  type="hidden" name="came_from"')

                                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755613840
                                __default_138366755613840 = _DEFAULT_MARKER

                                # <Substitution u'python:view.upgrade_url(site, can_manage=True)' (105:55)> -> __attr_value
                                __token = 5356
                                try:
                                    __zt_tmp = __attrs_138366755614096
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_138366930725008('python', u'view.upgrade_url(site, can_manage=True)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u'/>')
                            __append(u'\r\n                          ')

                            # <Static value=<_ast.Dict object at 0x7dd805512fd0> name=None at 7dd805512f10> -> __attrs_138366755640720
                            __attrs_138366755640720 = _static_138366755614672

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="submit"                                  class="btn btn-secondary"')

                            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755640464
                            __default_138366755640464 = _DEFAULT_MARKER

                            # <Translate msgid=u'label_upgrade_hellip' node=<_ast.Str object at 0x7dd8055193d0> at 7dd805519410> -> __attr_value
                            __attr_value = u'Upgrade&hellip;'
                            __attr_value = translate(u'label_upgrade_hellip', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_value is not None):
                                __append((u'                                  value="%s"' % __attr_value))
                            __append(u' />\r\n                        </form>\r\n\r\n                      </div>')
                        __append(u'\r\n                    </li>')
                        ____index_138366755535824 -= 1
                        if (____index_138366755535824 > 0):
                            __append('\n                    ')
                    if (__backup_site_138366755924304 is __marker):
                        del econtext['site']
                    else:
                        econtext['site'] = __backup_site_138366755924304
                    __append(u'\r\n                  </ul>\r\n                ')
                __append(u'\r\n\r\n              ')
            __append(u'\r\n\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd80555eb10> name=None at 7dd80555e350> -> __attrs_138366755534672
            __attrs_138366755534672 = _static_138366755924752

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-group-item">\r\n                <!-- No SENAITE site added yet -->\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755640976
            __attrs_138366755640976 = _static_138367014417552

            # <Value u'not:sites' (121:55)> -> __condition
            __token = 5984
            try:
                __zt_tmp = __attrs_138366755640976
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_138366930725008('not', u'sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_138366755612240 = []
                __append_138366755612240 = __stream_138366755612240.append
                __append_138366755612240(u'\r\n                  Your SENAITE site has not been added yet:\r\n                ')
                __msgid_138366755612240 = __re_whitespace(''.join(__stream_138366755612240)).strip()
                if __msgid_138366755612240:
                    __append(translate(__msgid_138366755612240, mapping=None, default=__msgid_138366755612240, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>')
            __append(u'\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755641744
            __attrs_138366755641744 = _static_138367014417552

            # <Value u'sites' (124:55)> -> __condition
            __token = 6138
            try:
                __zt_tmp = __attrs_138366755641744
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_138366930725008('path', u'sites', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_138366755641360 = []
                __append_138366755641360 = __stream_138366755641360.append
                __append_138366755641360(u'\r\n                  You can add another SENAITE site:\r\n                ')
                __msgid_138366755641360 = __re_whitespace(''.join(__stream_138366755641360)).strip()
                if __msgid_138366755641360:
                    __append(translate(__msgid_138366755641360, mapping=None, default=__msgid_138366755641360, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>')
            __append(u'\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd805519b90> name=None at 7dd805519bd0> -> __attrs_138366755668368
            __attrs_138366755668368 = _static_138366755642256
            __backup_site_number_138366756360336 = get('site_number', __marker)

            # <Value u"python: '' if not sites else len(sites) + 1" (130:46)> -> __value
            __token = 6384
            try:
                __zt_tmp = __attrs_138366755668368
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u" '' if not sites else len(sites) + 1", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['site_number'] = __value

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form id="add-plone-site"                       method="get"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755668048
            __default_138366755668048 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/@@senaite-addsite' (131:45)> -> __attr_action
            __token = 6475
            try:
                __zt_tmp = __attrs_138366755668368
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_138366930725008('string', u'${context/absolute_url}/@@senaite-addsite', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u'                       action="%s"' % __attr_action))
            __append(u'>\r\n                  ')

            # <Static value=<_ast.Dict object at 0x7dd805520490> name=None at 7dd8055204d0> -> __attrs_138366755670480
            __attrs_138366755670480 = _static_138366755669136

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="site_id"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755670224
            __default_138366755670224 = _DEFAULT_MARKER

            # <Interpolation value=<Substitution u'senaite${site_number}' (132:61)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7dd805520850> -> __attr_value
            __token = 6588
            __token = 6597
            try:
                __zt_tmp = __attrs_138366755670480
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_138366930725008('path', u'site_number', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            __attr_value = ('%s%s' % (u'senaite', (__attr_value if (__attr_value is not None) else ''), ))
            if (__attr_value is None):
                pass
            else:
                if (__attr_value is _DEFAULT_MARKER):
                    __attr_value = None
                else:
                    __tt = type(__attr_value)
                    if ((__tt is int) or (__tt is float) or (__tt is long)):
                        __attr_value = unicode(__attr_value)
                    else:
                        if (__tt is str):
                            __attr_value = decode(__attr_value)
                        else:
                            if (__tt is not unicode):
                                try:
                                    __attr_value = __attr_value.__html__
                                except get('AttributeError', AttributeError):
                                    __converted = convert(__attr_value)
                                    __attr_value = (unicode(__attr_value) if (__attr_value is __converted) else __converted)
                                else:
                                    __attr_value = __attr_value()
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\r\n                  ')

            # <Static value=<_ast.Dict object at 0x7dd805520a90> name=None at 7dd805520b50> -> __attrs_138366755688528
            __attrs_138366755688528 = _static_138366755670672

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="site_title" value="SENAITE LIMS" />\r\n                  ')

            # <Static value=<_ast.Dict object at 0x7dd8055251d0> name=None at 7dd805525110> -> __attrs_138366755690320
            __attrs_138366755690320 = _static_138366755688912

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="submit"                          class="btn btn-success"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755690064
            __default_138366755690064 = _DEFAULT_MARKER

            # <Translate msgid=None node=<_ast.Str object at 0x7dd805525590> at 7dd8055255d0> -> __attr_value
            __attr_value = u'Create a new SENAITE site'
            __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_value is not None):
                __append((u'                          value="%s"' % __attr_value))
            __append(u' />\r\n                  ')

            # <Static value=<_ast.Dict object at 0x7dd8055258d0> name=None at 7dd805525890> -> __attrs_138366755691728
            __attrs_138366755691728 = _static_138366755690704

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755691408
            __default_138366755691408 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1' (140:42)> -> __attr_href
            __token = 7039
            try:
                __zt_tmp = __attrs_138366755691728
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_138366930725008('string', u'${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_138366755690512 = []
            __append_138366755690512 = __stream_138366755690512.append
            __append_138366755690512(u'\r\n                    Advanced\r\n                  ')
            __msgid_138366755690512 = __re_whitespace(''.join(__stream_138366755690512)).strip()
            if __msgid_138366755690512:
                __append(translate(__msgid_138366755690512, mapping=None, default=__msgid_138366755690512, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\r\n                </form>')
            if (__backup_site_number_138366756360336 is __marker):
                del econtext['site_number']
            else:
                econtext['site_number'] = __backup_site_number_138366756360336
            __append(u'\r\n              </li>\r\n\r\n            </ul>\r\n          </div>\r\n\r\n          <!-- Community Links -->\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd805519710> name=None at 7dd805519a10> -> __attrs_138366755692048
            __attrs_138366755692048 = _static_138366755641104

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80552e150> name=None at 7dd80552e0d0> -> __attrs_138366755726224
            __attrs_138366755726224 = _static_138366755725648

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755726992
            __attrs_138366755726992 = _static_138367014417552

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd80552e850> name=None at 7dd80552e810> -> __attrs_138366755728016
            __attrs_138366755728016 = _static_138366755727440

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="lead">')
            __stream_138366755727184 = []
            __append_138366755727184 = __stream_138366755727184.append
            __append_138366755727184(u'\r\n                Meet the community, browse the code and get support on\r\n              ')
            __msgid_138366755727184 = __re_whitespace(''.join(__stream_138366755727184)).strip()
            if __msgid_138366755727184:
                __append(translate(__msgid_138366755727184, mapping=None, default=__msgid_138366755727184, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd80552ec10> name=None at 7dd80552eb90> -> __attrs_138366755729040
            __attrs_138366755729040 = _static_138366755728400

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-inline flex-column flex-sm-row">\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd80553a150> name=None at 7dd80553a110> -> __attrs_138366755775440
            __attrs_138366755775440 = _static_138366755774800

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7dd80553a650> name=None at 7dd80553a5d0> -> __attrs_138366755777616
            __attrs_138366755777616 = _static_138366755776080

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://www.senaite.com" title="Website" target="_blank">Website</a></li>\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd80553a510> name=None at 7dd80553a0d0> -> __attrs_138366755778320
            __attrs_138366755778320 = _static_138366755775760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7dd805541190> name=None at 7dd805541150> -> __attrs_138366755805136
            __attrs_138366755805136 = _static_138366755803536

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://community.senaite.com" title="SENAITE community" target="_blank">Community Site</a></li>\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd805541090> name=None at 7dd805541110> -> __attrs_138366755805904
            __attrs_138366755805904 = _static_138366755803280

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7dd805541d10> name=None at 7dd805541cd0> -> __attrs_138366755824528
            __attrs_138366755824528 = _static_138366755806480

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://gitter.im/senaite/Lobby" title="Gitter Chat" target="_blank">Gitter Chat</a></li>\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd80553afd0> name=None at 7dd80553af50> -> __attrs_138366755825232
            __attrs_138366755825232 = _static_138366755778512

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7dd8055468d0> name=None at 7dd805546850> -> __attrs_138366755827408
            __attrs_138366755827408 = _static_138366755825872

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://github.com/senaite" title="GitHub" target="_blank">GitHub</a></li>\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd805546790> name=None at 7dd805546710> -> __attrs_138366755062224
            __attrs_138366755062224 = _static_138366755825552

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7dd80548c450> name=None at 7dd80548c3d0> -> __attrs_138366755064400
            __attrs_138366755064400 = _static_138366755062864

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://twitter.com/senaitelims" title="Twitter" target="_blank">Twitter</a></li>\r\n              </ul>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </body>')
            if (__backup_sites_138366756289104 is __marker):
                del econtext['sites']
            else:
                econtext['sites'] = __backup_sites_138366756289104
            __append(u'\r\n</html>')
            __i18n_domain = __previous_i18n_domain_138366756272464
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }