# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFPlone-5.2.15-py2.7.egg/Products/CMFPlone/browser/templates/plone-frontpage.pt'

__tokens = {}

from sys import exc_info as _exc_info

_static_135757148490768 = {u'href': u'https://plone.org', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136406800 = {u'class': u'discreet', }
_static_135757136411408 = {u'href': u'@@overview-controlpanel', u'target': u'_blank', }
_static_135757136396752 = {u'href': u'https://plone.com/success-stories/', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136250064 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135757136405328 = {u'href': u'@@content-controlpanel', u'target': u'_blank', }
_static_135757136394448 = {u'href': u'https://plone.org/support', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136374864 = {u'class': u'discreet', }
_static_135757136373392 = {u'href': u'@@mail-controlpanel', u'target': u'_blank', }
_static_135757136403792 = {u'class': u'discreet', }
_static_135757136402128 = {u'href': u'https://plone.org/download/add-ons', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136408400 = {u'class': u'discreet', }
_static_135757136333840 = {u'class': u'discreet', }
_static_135757136372048 = {u'class': u'discreet', }
_static_135757136334160 = {u'href': u'https://plone.com', u'class': u'context', u'target': u'_blank', }
_static_135757327983760 = {}
_static_135757136381840 = {u'class': u'discreet', }
_static_135757148484432 = {u'href': u'https://plone.com/success-stories/', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136380368 = {u'href': u'@@security-controlpanel', u'target': u'_blank', }
_static_135757148502736 = {u'href': u'https://plone.org/sponsors/be-a-hero', u'target': u'_blank', }
_static_135757148488528 = {u'href': u'https://plone.com', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136331408 = {u'class': u'hero', }
_static_135757136409616 = {u'href': u'@@markup-controlpanel', u'target': u'_blank', }
_static_135757136387472 = {u'href': u'https://docs.plone.org', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136389840 = {u'href': u'https://training.plone.org', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136385232 = {u'href': u'https://plone.com/features/', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136400656 = {u'href': u'@@theming-controlpanel', u'target': u'_blank', }
_static_135757148621392 = {u'href': u'https://plone.com/providers/', u'class': u'link-plain', u'target': u'_blank', }
_static_135757148497168 = {u'href': u'https://www.python.org', u'class': u'link-plain', u'target': u'_blank', }
_static_135757136392080 = {u'href': u'https://plone.org/download/add-ons', u'class': u'link-plain', u'target': u'_blank', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786be1c4d0> name=None at 7b786be1c510> -> __attrs_135757136251408
            __attrs_135757136251408 = _static_135757136250064
            __previous_i18n_domain_135757136251536 = __i18n_domain
            __i18n_domain = u'plonefrontpage'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136252240
            __attrs_135757136252240 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head></head>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136252752
            __attrs_135757136252752 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>')
            __stream_135757136252496 = []
            __append_135757136252496 = __stream_135757136252496.append
            __append_135757136252496(u'\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786be30290> name=None at 7b786be30250> -> __attrs_135757136331984
            __attrs_135757136331984 = _static_135757136331408

            # <div ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<div class="hero">\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136332880
            __attrs_135757136332880 = _static_135757327983760

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h1>Welcome!</h1>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136333520
            __attrs_135757136333520 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>')

            # <Static value=<_ast.Dict object at 0x7b786be30d50> name=None at 7b786be30cd0> -> __attrs_135757136335440
            __attrs_135757136335440 = _static_135757136334160

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="context" href="https://plone.com" target="_blank">Learn more about Plone</a></p>\n  </div>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786be30c10> name=None at 7b786be30b10> -> __attrs_135757136336080
            __attrs_135757136336080 = _static_135757136333840

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p class="discreet">\nIf you\'re seeing this instead of the web site you were expecting, the owner of\nthis web site has just installed Plone. Do not contact the Plone Team or the\nPlone support channels about this.\n</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136336656
            __attrs_135757136336656 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Get started</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136337232
            __attrs_135757136337232 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>\nBefore you start exploring your newly created Plone site, please do the following:\n</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136337808
            __attrs_135757136337808 = _static_135757327983760

            # <ol ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ol>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136338576
            __attrs_135757136338576 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Make sure you are logged in as an admin/manager user.\n        ')

            # <Static value=<_ast.Dict object at 0x7b786be3a150> name=None at 7b786be3a110> -> __attrs_135757136372624
            __attrs_135757136372624 = _static_135757136372048

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(You should have a Site Setup entry in the user menu)</span></li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136372944
            __attrs_135757136372944 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b786be3a690> name=None at 7b786be3a6d0> -> __attrs_135757136374416
            __attrs_135757136374416 = _static_135757136373392

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@mail-controlpanel" target="_blank">Set up your mail server</a>. ')

            # <Static value=<_ast.Dict object at 0x7b786be3ac50> name=None at 7b786be3ac10> -> __attrs_135757136375440
            __attrs_135757136375440 = _static_135757136374864

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(Plone needs a valid SMTP server to verify users and send out password reminders)</span></li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136375760
            __attrs_135757136375760 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b786be3c1d0> name=None at 7b786be3c210> -> __attrs_135757136381392
            __attrs_135757136381392 = _static_135757136380368

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@security-controlpanel" target="_blank">Decide what security level you want on your site</a>. ')

            # <Static value=<_ast.Dict object at 0x7b786be3c790> name=None at 7b786be3c750> -> __attrs_135757136382416
            __attrs_135757136382416 = _static_135757136381840

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(Allow self registration, password policies, etc)</span></li>\n</ol>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136380112
            __attrs_135757136380112 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Get comfortable</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136383184
            __attrs_135757136383184 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>After that, we suggest you do one or more of the following:</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136383760
            __attrs_135757136383760 = _static_135757327983760

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ul>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136384592
            __attrs_135757136384592 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Find out ')

            # <Static value=<_ast.Dict object at 0x7b786be3d4d0> name=None at 7b786be3d490> -> __attrs_135757136386448
            __attrs_135757136386448 = _static_135757136385232

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.com/features/" target="_blank">What\'s new in Plone</a>.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136386832
            __attrs_135757136386832 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Read the ')

            # <Static value=<_ast.Dict object at 0x7b786be3dd90> name=None at 7b786be3dd50> -> __attrs_135757136388752
            __attrs_135757136388752 = _static_135757136387472

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://docs.plone.org" target="_blank">documentation</a>.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136389200
            __attrs_135757136389200 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Follow a ')

            # <Static value=<_ast.Dict object at 0x7b786be3e6d0> name=None at 7b786be3e690> -> __attrs_135757136391056
            __attrs_135757136391056 = _static_135757136389840

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://training.plone.org" target="_blank">training</a>.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136391440
            __attrs_135757136391440 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Explore the ')

            # <Static value=<_ast.Dict object at 0x7b786be3ef90> name=None at 7b786be3efd0> -> __attrs_135757136393488
            __attrs_135757136393488 = _static_135757136392080

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.org/download/add-ons" target="_blank">available add-ons</a> for Plone.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136393808
            __attrs_135757136393808 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Read and/or subscribe to the ')

            # <Static value=<_ast.Dict object at 0x7b786be3f8d0> name=None at 7b786be3f890> -> __attrs_135757136395664
            __attrs_135757136395664 = _static_135757136394448

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.org/support" target="_blank">support channels</a>.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136396048
            __attrs_135757136396048 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Find out ')

            # <Static value=<_ast.Dict object at 0x7b786be401d0> name=None at 7b786be40190> -> __attrs_135757136397968
            __attrs_135757136397968 = _static_135757136396752

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.com/success-stories/" target="_blank">how others are using Plone</a>.</li>\n</ul>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136398032
            __attrs_135757136398032 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Make it your own</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136398736
            __attrs_135757136398736 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>Plone has a lot of different settings that can be used to make it do what you want it to. Some examples:</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136399312
            __attrs_135757136399312 = _static_135757327983760

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ul>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136400080
            __attrs_135757136400080 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\n    Try out a different theme, either pick from\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be41110> name=None at 7b786be41150> -> __attrs_135757136401680
            __attrs_135757136401680 = _static_135757136400656

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@theming-controlpanel" target="_blank">the included ones</a>, or one of the\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be416d0> name=None at 7b786be41690> -> __attrs_135757136403344
            __attrs_135757136403344 = _static_135757136402128

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.org/download/add-ons" target="_blank">available themes\n       from plone.org</a>. ')

            # <Static value=<_ast.Dict object at 0x7b786be41d50> name=None at 7b786be41d10> -> __attrs_135757136404368
            __attrs_135757136404368 = _static_135757136403792

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(Make sure the theme is\n       compatible with the version of Plone you are currently using)</span>\n    </li>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136404816
            __attrs_135757136404816 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be42350> name=None at 7b786be42390> -> __attrs_135757136406352
            __attrs_135757136406352 = _static_135757136405328

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@content-controlpanel" target="_blank">\n    Decide what kind of workflow you want in your site.</a>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be42910> name=None at 7b786be428d0> -> __attrs_135757136407376
            __attrs_135757136407376 = _static_135757136406800

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(The default is typical for a\n    public web site; if you want to use Plone as a closed intranet or extranet,\n    you can choose a different workflow.)</span>\n    </li>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136407760
            __attrs_135757136407760 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\n    By default, Plone uses a visual editor for content.\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be42f50> name=None at 7b786be42f10> -> __attrs_135757136409040
            __attrs_135757136409040 = _static_135757136408400

            # <span ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<span class="discreet">(If you prefer text-based syntax and/or wiki\n        syntax, you can change this in the\n    ')

            # <Static value=<_ast.Dict object at 0x7b786be43410> name=None at 7b786be43450> -> __attrs_135757136410640
            __attrs_135757136410640 = _static_135757136409616

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@markup-controlpanel" target="_blank">markup control panel</a>)</span>\n    </li>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136410704
            __attrs_135757136410704 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\u2026and many more settings are available in the\n        ')

            # <Static value=<_ast.Dict object at 0x7b786be43b10> name=None at 7b786be43b50> -> __attrs_135757136412432
            __attrs_135757136412432 = _static_135757136411408

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="@@overview-controlpanel" target="_blank">Site Setup</a>.\n    </li>\n\n</ul>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136412496
            __attrs_135757136412496 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Tell us how you use it</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148619344
            __attrs_135757148619344 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>\nAre you doing something interesting with Plone? Big site deployments,\ninteresting use cases? Do you have a company that delivers Plone-based\nsolutions?\n</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148619920
            __attrs_135757148619920 = _static_135757327983760

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ul>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148620688
            __attrs_135757148620688 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Add your company as a ')

            # <Static value=<_ast.Dict object at 0x7b786c9e8a50> name=None at 7b786c9e8a10> -> __attrs_135757148622608
            __attrs_135757148622608 = _static_135757148621392

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.com/providers/" target="_blank">Plone provider</a>.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148483792
            __attrs_135757148483792 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>Add a ')

            # <Static value=<_ast.Dict object at 0x7b786c9c7350> name=None at 7b786c9c7310> -> __attrs_135757148485648
            __attrs_135757148485648 = _static_135757148484432

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.com/success-stories/" target="_blank">success story</a> describing your\n        deployed project and customer.</li>\n</ul>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148485712
            __attrs_135757148485712 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Find out more about Plone</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148486480
            __attrs_135757148486480 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>\nPlone is a powerful content management system built on a rock-solid application stack written using the Python programming\nlanguage. More about these technologies:\n</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148487056
            __attrs_135757148487056 = _static_135757327983760

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ul>\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148487888
            __attrs_135757148487888 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>The ')

            # <Static value=<_ast.Dict object at 0x7b786c9c8350> name=None at 7b786c9c8310> -> __attrs_135757148489744
            __attrs_135757148489744 = _static_135757148488528

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.com" target="_blank">Plone open source\n    Content Management System</a> web site for evaluators and decision makers.</li>\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148490128
            __attrs_135757148490128 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>The ')

            # <Static value=<_ast.Dict object at 0x7b786c9c8c10> name=None at 7b786c9c8bd0> -> __attrs_135757148496144
            __attrs_135757148496144 = _static_135757148490768

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://plone.org" target="_blank">Plone community\n    </a> web site for developers.</li>\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148496528
            __attrs_135757148496528 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>The ')

            # <Static value=<_ast.Dict object at 0x7b786c9ca510> name=None at 7b786c9ca4d0> -> __attrs_135757148498384
            __attrs_135757148498384 = _static_135757148497168

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a class="link-plain" href="https://www.python.org" target="_blank">Python\n    programming language</a> web site.</li>\n</ul>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148498448
            __attrs_135757148498448 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<h2>Support the Plone Foundation</h2>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148499152
            __attrs_135757148499152 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>\nPlone is made possible only through the efforts of thousands of dedicated\nindividuals and hundreds of companies. The Plone Foundation:\n</p>\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148499728
            __attrs_135757148499728 = _static_135757327983760

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<ul>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148500560
            __attrs_135757148500560 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\u2026protects and promotes Plone.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148501136
            __attrs_135757148501136 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\u2026is a registered 501(c)(3) charitable organization.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148501712
            __attrs_135757148501712 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>\u2026donations are tax-deductible.</li>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148502288
            __attrs_135757148502288 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b786c9cbad0> name=None at 7b786c9cbb10> -> __attrs_135757148503760
            __attrs_135757148503760 = _static_135757148502736

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<a href="https://plone.org/sponsors/be-a-hero" target="_blank">Support the Foundation and help make Plone better!</a></li>\n</ul>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148500048
            __attrs_135757148500048 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>Thanks for using our product; we hope you like it!</p>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148602832
            __attrs_135757148602832 = _static_135757327983760

            # <p ... (0:0)
            # --------------------------------------------------------
            __append_135757136252496(u'<p>\u2014The Plone Team</p>\n')
            __msgid_135757136252496 = __re_whitespace(''.join(__stream_135757136252496)).strip()
            if u'front-text':
                __append(translate(u'front-text', mapping=None, default=__msgid_135757136252496, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135757136251536
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }