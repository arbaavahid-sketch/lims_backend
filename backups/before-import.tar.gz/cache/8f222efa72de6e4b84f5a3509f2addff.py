# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/edit.pt'

__tokens = {371: (u'provider:plone.abovecontenttitle', 10, 32), 470: (u'view/label | nothing', 13, 21), 530: (u'provider:plone.belowcontenttitle', 15, 32), 633: (u'view/contents', 18, 34), 262: (u'context/main_template/macros/master', 6, 23), 262: (u'context/main_template/macros/master', 6, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402098623056 = {u'id': u'content-core', }
_static_140402356200592 = {}
_static_140402102398288 = {u'class': u'documentFirstHeading', }
_static_140402272508048 = __compile_zt_expr
_static_140402099605456 = u'master'
_static_140402272508432 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099601616
            __attrs_140402099601616 = _static_140402356200592
            __previous_i18n_domain_140402099602704 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_140402142478656 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7fb1e945cfd0> name=None at 7fb1e945c410> -> __value
            __value = _static_140402099605456
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402181848848
                __attrs_140402181848848 = _static_140402356200592
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402102297808
                __attrs_140402102297808 = _static_140402356200592

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102888016
                __default_140402102888016 = _DEFAULT_MARKER

                # <Value u'provider:plone.abovecontenttitle' (10:32)> -> __cache_140402100336784
                __token = 371
                try:
                    __zt_tmp = __attrs_140402102297808
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402100336784 = _static_140402272508048('provider', u'plone.abovecontenttitle', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:plone.abovecontenttitle' (10:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1ed110690> -> __condition
                __expression = __cache_140402100336784

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_140402100336784
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e9706d50> name=None at 7fb1e9706810> -> __attrs_140402098625232
                __attrs_140402098625232 = _static_140402102398288

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102397904
                __default_140402102397904 = _DEFAULT_MARKER

                # <Value u'view/label | nothing' (13:21)> -> __cache_140402102299984
                __token = 470
                try:
                    __zt_tmp = __attrs_140402098625232
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402102299984 = _static_140402272508048('path', u'view/label | nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/label | nothing' (13:21)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e96ee950> -> __condition
                __expression = __cache_140402102299984

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_140402102299984
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</h1>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402098625680
                __attrs_140402098625680 = _static_140402356200592

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402098624400
                __default_140402098624400 = _DEFAULT_MARKER

                # <Value u'provider:plone.belowcontenttitle' (15:32)> -> __cache_140402098623888
                __token = 530
                try:
                    __zt_tmp = __attrs_140402098625680
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402098623888 = _static_140402272508048('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:plone.belowcontenttitle' (15:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e936d290> -> __condition
                __expression = __cache_140402098623888

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_140402098623888
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e936d250> name=None at 7fb1e936d2d0> -> __attrs_140402098622800
                __attrs_140402098622800 = _static_140402098623056

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="content-core">\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101423184
                __attrs_140402101423184 = _static_140402356200592

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101423952
                __default_140402101423952 = _DEFAULT_MARKER

                # <Value u'view/contents' (18:34)> -> __cache_140402098624912
                __token = 633
                try:
                    __zt_tmp = __attrs_140402101423184
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402098624912 = _static_140402272508048('path', u'view/contents', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/contents' (18:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e96184d0> -> __condition
                __expression = __cache_140402098624912

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_140402098624912
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n    </div>\r\n\r\n  ')
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/main_template/macros/master' (6:23)> -> __macro
            __token = 262
            try:
                __zt_tmp = __attrs_140402099601616
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_140402272508048('path', u'context/main_template/macros/master', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __token = 262
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_140402142478656 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_140402142478656
            __i18n_domain = __previous_i18n_domain_140402099602704
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }