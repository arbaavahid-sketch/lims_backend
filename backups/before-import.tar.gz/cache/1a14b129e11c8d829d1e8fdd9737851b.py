# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.contenttypes-2.2.3-py2.7.egg/plone/app/contenttypes/browser/templates/archetypes_warning_viewlet.pt'

__tokens = {26: (u'view/available', 1, 26), 200: (u'not:view/can_migrate', 4, 32), 388: (u'view/can_migrate', 7, 32), 565: (u'string:${context/plone_portal_state/portal_url}/@@atct_migrator', 10, 31)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757166676944 = {u'href': u'#', }
_static_135757244280656 = __compile_zt_expr
_static_135757148726544 = {u'type': u'text/css', }
_static_135757075273232 = {u'class': u'portalMessage alert-box secondary warning', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075273680
            __attrs_135757075273680 = _static_135757327983760

            # <Value u'view/available' (1:26)> -> __condition
            __token = 26
            try:
                __zt_tmp = __attrs_135757075273680
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'view/available', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n  ')

                # <Static value=<_ast.Dict object at 0x7b78683f5610> name=None at 7b78683f5250> -> __attrs_135757075275728
                __attrs_135757075275728 = _static_135757075273232
                __previous_i18n_domain_135757075272528 = __i18n_domain
                __i18n_domain = u'plone'

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="portalMessage alert-box secondary warning">\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073581968
                __attrs_135757073581968 = _static_135757327983760

                # <strong ... (0:0)
                # --------------------------------------------------------
                __append(u'<strong>')
                __stream_135757074252880 = []
                __append_135757074252880 = __stream_135757074252880.append
                __append_135757074252880(u'Warning')
                __msgid_135757074252880 = __re_whitespace(''.join(__stream_135757074252880)).strip()
                if __msgid_135757074252880:
                    __append(translate(__msgid_135757074252880, mapping=None, default=__msgid_135757074252880, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</strong>\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148727952
                __attrs_135757148727952 = _static_135757327983760

                # <Value u'not:view/can_migrate' (4:32)> -> __condition
                __token = 200
                try:
                    __zt_tmp = __attrs_135757148727952
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('not', u'view/can_migrate', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148710032
                    __attrs_135757148710032 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_135757148711952 = []
                    __append_135757148711952 = __stream_135757148711952.append
                    __append_135757148711952(u"You can't edit this content. Ask your administrator to migrate to Dexterity!")
                    __msgid_135757148711952 = __re_whitespace(''.join(__stream_135757148711952)).strip()
                    if __msgid_135757148711952:
                        __append(translate(__msgid_135757148711952, mapping=None, default=__msgid_135757148711952, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\n    ')
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148709328
                __attrs_135757148709328 = _static_135757327983760

                # <Value u'view/can_migrate' (7:32)> -> __condition
                __token = 388
                try:
                    __zt_tmp = __attrs_135757148709328
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'view/can_migrate', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075533648
                    __attrs_135757075533648 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_135757075743280_migrate = ''
                    __stream_135757075532240 = []
                    __append_135757075532240 = __stream_135757075532240.append
                    __append_135757075532240(u"You can't edit this content unless you\n        ")
                    __stream_135757075743280_migrate = []
                    __append_135757075743280_migrate = __stream_135757075743280_migrate.append

                    # <Static value=<_ast.Dict object at 0x7b786db20bd0> name=None at 7b786db20590> -> __attrs_135757150052752
                    __attrs_135757150052752 = _static_135757166676944

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075743280_migrate(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166674448
                    __default_135757166674448 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/plone_portal_state/portal_url}/@@atct_migrator' (10:31)> -> __attr_href
                    __token = 565
                    try:
                        __zt_tmp = __attrs_135757150052752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('string', u'${context/plone_portal_state/portal_url}/@@atct_migrator', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_135757075743280_migrate((u' href="%s"' % __attr_href))
                    __append_135757075743280_migrate(u'>')
                    __stream_135757166674000 = []
                    __append_135757166674000 = __stream_135757166674000.append
                    __append_135757166674000(u'\n          migrate the default content-types to Dexterity.\n        ')
                    __msgid_135757166674000 = __re_whitespace(''.join(__stream_135757166674000)).strip()
                    if __msgid_135757166674000:
                        __append_135757075743280_migrate(translate(__msgid_135757166674000, mapping=None, default=__msgid_135757166674000, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_135757075743280_migrate(u'</a>')
                    __append_135757075532240(u'${migrate}')
                    __stream_135757075743280_migrate = ''.join(__stream_135757075743280_migrate)
                    __append_135757075532240(u'\n      ')
                    __msgid_135757075532240 = __re_whitespace(''.join(__stream_135757075532240)).strip()
                    if __msgid_135757075532240:
                        __append(translate(__msgid_135757075532240, mapping={u'migrate': __stream_135757075743280_migrate, }, default=__msgid_135757075532240, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\n    ')
                __append(u'\n  </div>')
                __i18n_domain = __previous_i18n_domain_135757075272528
                __append(u'\n  ')

                # <Static value=<_ast.Dict object at 0x7b786ca02510> name=None at 7b786ca02c10> -> __attrs_135757150055248
                __attrs_135757150055248 = _static_135757148726544

                # <style ... (0:0)
                # --------------------------------------------------------
                __append(u'<style type="text/css">\n    #contentview-edit {display: None;}\n  </style>\n')
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }