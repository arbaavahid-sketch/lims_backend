# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/decimal.pt'

__tokens = {1690: (u'string:${fieldName}', 36, 36), 1791: (u'e val', 38, 35), 1833: (u'ze widget/s', 39, 33), 1744: (u' fieldNam', 37, 33), 1888: (u'der widget/placeholder|not', 40, 39), 1956: (u'ngth widget/maxlength|no', 41, 36), 2039: (u'widget/unit', 42, 51), 1389: (u'field_macro | context/widgets/field/macros/edit', 28, 28), 1389: (u'field_macro | context/widgets/field/macros/edit', 28, 28), 2177: (u'context/widgets/decimal/macros/edit', 49, 28), 2177: (u'context/widgets/decimal/macros/edit', 49, 28), 388: (u'widget/dollars_and_cents', 13, 41), 450: (u' widget/whole_dollar', 14, 36), 511: (u's widget/thousands_comm', 15, 38), 568: (u'at python:dollars_and_cents or whole_dollars or thousands_com', 16, 30), 660: (u'ult acce', 17, 26), 702: (u'tted python:r', 18, 28), 743: (u'  pps modules/Products/PythonScripts/st', 19, 21), 816: (u'matted python:(dollars_and_cents and pps.dollars_and_cents(formatted)) or fo', 20, 26), 926: (u'rmatted python:(whole_dollars and pps.whole_dollars(formatted)) or f', 21, 25), 1028: (u'ormatted python:(thousands_commas and pps.thousands_commas(formatted)) or ', 22, 24), 1133: (u'   result python:(if_format and formatted)', 23, 20), 1204: (u'      unit ', 24, 17), 1265: (u"python: '%s %s' % (result, unit) if unit else result", 25, 36)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757244280656 = __compile_zt_expr
_static_135757072927248 = u'edit'
_static_135757075222416 = {u'class': u'discreet', }
_static_135756868130384 = u'edit'
_static_135756868131024 = {u'name': u'', u'placeholder': u'widget/placeholder|nothing', u'value': u'', u'class': u'blurrable firstToFocus numeric', u'maxlength': u'widget/maxlength|nothing', u'type': u'text', u'id': u'fieldName', u'size': u'30', }
_static_135757072721552 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868132112
            __attrs_135756868132112 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868130192
            __attrs_135756868130192 = _static_135757327983760
            __backup_macroname_135757117613072 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785be69650> name=None at 7b785be690d0> -> __value
            __value = _static_135756868130384
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868131728
                __attrs_135756868131728 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>\n          ')

                # <Static value=<_ast.Dict object at 0x7b785be698d0> name=None at 7b785be69ed0> -> __attrs_135756869327760
                __attrs_135756869327760 = _static_135756868131024

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="text" class="blurrable firstToFocus numeric"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869325200
                __default_135756869325200 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}' (36:36)> -> __attr_name
                __token = 1690
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('string', u'${fieldName}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869328848
                __default_135756869328848 = _DEFAULT_MARKER

                # <Substitution u'value' (38:35)> -> __attr_value
                __token = 1791
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869328272
                __default_135756869328272 = _DEFAULT_MARKER

                # <Substitution u'widget/size' (39:33)> -> __attr_size
                __token = 1833
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_size = _static_135757244280656('path', u'widget/size', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_size = __quote(__attr_size, '"', '&quot;', u'30', _DEFAULT_MARKER)
                if (__attr_size is not None):
                    __append((u' size="%s"' % __attr_size))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869327888
                __default_135756869327888 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (37:33)> -> __attr_id
                __token = 1744
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869328656
                __default_135756869328656 = _DEFAULT_MARKER

                # <Substitution u'widget/placeholder|nothing' (40:39)> -> __attr_placeholder
                __token = 1888
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_placeholder = _static_135757244280656('path', u'widget/placeholder|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_placeholder = __quote(__attr_placeholder, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_placeholder is not None):
                    __append((u' placeholder="%s"' % __attr_placeholder))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869327120
                __default_135756869327120 = _DEFAULT_MARKER

                # <Substitution u'widget/maxlength|nothing' (41:36)> -> __attr_maxlength
                __token = 1956
                try:
                    __zt_tmp = __attrs_135756869327760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_maxlength = _static_135757244280656('path', u'widget/maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_maxlength is not None):
                    __append((u' maxlength="%s"' % __attr_maxlength))
                __append(u' />')

                # <Static value=<_ast.Dict object at 0x7b78683e8f90> name=None at 7b7868483b50> -> __attrs_135757072926736
                __attrs_135757072926736 = _static_135757075222416

                # <em ... (0:0)
                # --------------------------------------------------------
                __append(u"<em class='discreet'>")

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869328208
                __default_135756869328208 = _DEFAULT_MARKER

                # <Value u'widget/unit' (42:51)> -> __cache_135756869327952
                __token = 2039
                try:
                    __zt_tmp = __attrs_135757072926736
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135756869327952 = _static_135757244280656('path', u'widget/unit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'widget/unit' (42:51)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf8d210> -> __condition
                __expression = __cache_135756869327952

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135756869327952
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</em>\n        </span>')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | context/widgets/field/macros/edit' (28:28)> -> __macro
            __token = 1389
            try:
                __zt_tmp = __attrs_135756868130192
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'field_macro | context/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 1389
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757117613072 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757117613072
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868129680
            __attrs_135756868129680 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072928080
            __attrs_135757072928080 = _static_135757327983760
            __backup_macroname_135757245156960 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b78681b8a10> name=None at 7b78681b82d0> -> __value
            __value = _static_135757072927248
            econtext['macroname'] = __value

            # <Value u'context/widgets/decimal/macros/edit' (49:28)> -> __macro
            __token = 2177
            try:
                __zt_tmp = __attrs_135757072928080
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/decimal/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 2177
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757245156960 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757245156960
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075900688
            __attrs_135757075900688 = _static_135757327983760
            __backup_dollars_and_cents_135757071566096 = get('dollars_and_cents', __marker)

            # <Value u'widget/dollars_and_cents' (13:41)> -> __value
            __token = 388
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'widget/dollars_and_cents', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dollars_and_cents'] = __value
            __backup_whole_dollars_135756866374288 = get('whole_dollars', __marker)

            # <Value u'widget/whole_dollars' (14:36)> -> __value
            __token = 450
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'widget/whole_dollars', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['whole_dollars'] = __value
            __backup_thousands_commas_135756867964624 = get('thousands_commas', __marker)

            # <Value u'widget/thousands_commas' (15:38)> -> __value
            __token = 511
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'widget/thousands_commas', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['thousands_commas'] = __value
            __backup_if_format_135756865899472 = get('if_format', __marker)

            # <Value u'python:dollars_and_cents or whole_dollars or thousands_commas' (16:30)> -> __value
            __token = 568
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'dollars_and_cents or whole_dollars or thousands_commas', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['if_format'] = __value
            __backup_result_135757151773648 = get('result', __marker)

            # <Value u'accessor' (17:26)> -> __value
            __token = 660
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'accessor', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['result'] = __value
            __backup_formatted_135756866374096 = get('formatted', __marker)

            # <Value u'python:result' (18:28)> -> __value
            __token = 702
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'result', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['formatted'] = __value
            __backup_pps_135756869493648 = get('pps', __marker)

            # <Value u'modules/Products/PythonScripts/standard' (19:21)> -> __value
            __token = 743
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'modules/Products/PythonScripts/standard', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['pps'] = __value
            __backup_formatted_135757072742288 = get('formatted', __marker)

            # <Value u'python:(dollars_and_cents and pps.dollars_and_cents(formatted)) or formatted' (20:26)> -> __value
            __token = 816
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'(dollars_and_cents and pps.dollars_and_cents(formatted)) or formatted', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['formatted'] = __value
            __backup_formatted_135756865897872 = get('formatted', __marker)

            # <Value u'python:(whole_dollars and pps.whole_dollars(formatted)) or formatted' (21:25)> -> __value
            __token = 926
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'(whole_dollars and pps.whole_dollars(formatted)) or formatted', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['formatted'] = __value
            __backup_formatted_135757072742928 = get('formatted', __marker)

            # <Value u'python:(thousands_commas and pps.thousands_commas(formatted)) or formatted' (22:24)> -> __value
            __token = 1028
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'(thousands_commas and pps.thousands_commas(formatted)) or formatted', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['formatted'] = __value
            __backup_result_135756867964560 = get('result', __marker)

            # <Value u'python:(if_format and formatted) or result' (23:20)> -> __value
            __token = 1133
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'(if_format and formatted) or result', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['result'] = __value
            __backup_unit_135756865900368 = get('unit', __marker)

            # <Value u'widget/unit' (24:17)> -> __value
            __token = 1204
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'widget/unit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['unit'] = __value

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075899728
            __default_135757075899728 = _DEFAULT_MARKER

            # <Value u"python: '%s %s' % (result, unit) if unit else result" (25:36)> -> __cache_135757075908816
            __token = 1265
            try:
                __zt_tmp = __attrs_135757075900688
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075908816 = _static_135757244280656('python', u" '%s %s' % (result, unit) if unit else result", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u"python: '%s %s' % (result, unit) if unit else result" (25:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786848e590> -> __condition
            __expression = __cache_135757075908816

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757075908816
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            if (__backup_unit_135756865900368 is __marker):
                del econtext['unit']
            else:
                econtext['unit'] = __backup_unit_135756865900368
            if (__backup_result_135756867964560 is __marker):
                del econtext['result']
            else:
                econtext['result'] = __backup_result_135756867964560
            if (__backup_formatted_135757072742928 is __marker):
                del econtext['formatted']
            else:
                econtext['formatted'] = __backup_formatted_135757072742928
            if (__backup_formatted_135756865897872 is __marker):
                del econtext['formatted']
            else:
                econtext['formatted'] = __backup_formatted_135756865897872
            if (__backup_formatted_135757072742288 is __marker):
                del econtext['formatted']
            else:
                econtext['formatted'] = __backup_formatted_135757072742288
            if (__backup_pps_135756869493648 is __marker):
                del econtext['pps']
            else:
                econtext['pps'] = __backup_pps_135756869493648
            if (__backup_formatted_135756866374096 is __marker):
                del econtext['formatted']
            else:
                econtext['formatted'] = __backup_formatted_135756866374096
            if (__backup_result_135757151773648 is __marker):
                del econtext['result']
            else:
                econtext['result'] = __backup_result_135757151773648
            if (__backup_if_format_135756865899472 is __marker):
                del econtext['if_format']
            else:
                econtext['if_format'] = __backup_if_format_135756865899472
            if (__backup_thousands_commas_135756867964624 is __marker):
                del econtext['thousands_commas']
            else:
                econtext['thousands_commas'] = __backup_thousands_commas_135756867964624
            if (__backup_whole_dollars_135756866374288 is __marker):
                del econtext['whole_dollars']
            else:
                econtext['whole_dollars'] = __backup_whole_dollars_135756866374288
            if (__backup_dollars_and_cents_135757071566096 is __marker):
                del econtext['dollars_and_cents']
            else:
                econtext['dollars_and_cents'] = __backup_dollars_and_cents_135757071566096
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b7868186690> name=None at 7b7868186310> -> __attrs_135757075908432
            __attrs_135757075908432 = _static_135757072721552
            __previous_i18n_domain_135757075909584 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075910096
            __attrs_135757075910096 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075906640
            __attrs_135757075906640 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075909072
            __attrs_135757075909072 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Float Widgets -->\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_135757075909584
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_view': render_view, 'render': render, }