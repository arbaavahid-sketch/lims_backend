# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/listingtitle.pt'

__tokens = {143: (u'view/icon', 4, 32), 243: (u'view/title', 8, 19)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757075275664 = {u'class': u'd-inline-block align-middle', }
_static_135757073379024 = {u'class': u'listing-title-viewlet d-inline-block', }
_static_135757244280656 = __compile_zt_expr
_static_135757073377296 = {u'class': u'd-inline-block align-middle', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b7868226ed0> name=None at 7b7868226d50> -> __attrs_135757073375504
            __attrs_135757073375504 = _static_135757073379024

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="listing-title-viewlet d-inline-block">\n  <!-- icon -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b7868226810> name=None at 7b7868226e90> -> __attrs_135757073377552
            __attrs_135757073377552 = _static_135757073377296

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="d-inline-block align-middle">\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075274768
            __attrs_135757075274768 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075274192
            __default_135757075274192 = _DEFAULT_MARKER

            # <Value u'view/icon' (4:32)> -> __cache_135757075273680
            __token = 143
            try:
                __zt_tmp = __attrs_135757075274768
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075273680 = _static_135757244280656('path', u'view/icon', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/icon' (4:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683f5b90> -> __condition
            __expression = __cache_135757075273680

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <img ... (0:0)
                # --------------------------------------------------------
                __append(u'<img/>')
            else:
                __content = __cache_135757075273680
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n  </div>\n  <!-- title -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b78683f5f90> name=None at 7b78683f5990> -> __attrs_135757075010640
            __attrs_135757075010640 = _static_135757075275664

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1 class="d-inline-block align-middle">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075272016
            __default_135757075272016 = _DEFAULT_MARKER

            # <Value u'view/title' (8:19)> -> __cache_135757075272656
            __token = 243
            try:
                __zt_tmp = __attrs_135757075010640
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075272656 = _static_135757244280656('path', u'view/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/title' (8:19)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683f5250> -> __condition
            __expression = __cache_135757075272656

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n  ')
            else:
                __content = __cache_135757075272656
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</h1>\n</div>\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }