# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/recordswidget.pt'

__tokens = {1961: (u'context/@@authenticator/authenticator', 46, 39), 2131: (u'python:field.getEditAccessor(here)()', 51, 31), 2207: (u' python:here.session_restore_value(fieldName, values', 52, 38), 2298: (u's python:request.get(fieldName,session_value', 53, 36), 2374: (u'es python:cached_values or val', 54, 28), 2441: (u'ain field/widget/i18n_domain|context/i18n_domain|string:p', 55, 32), 2616: (u'string:${fieldName}_table', 59, 33), 2718: (u'python:field.getSubfields()', 62, 39), 2785: (u"python:field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)", 63, 37), 3064: (u'python:\n                                          here.translate(domain=i18n_domain,\n                                          msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))', 66, 48), 3319: (u'python:\n                                       here.translate(domain=i18n_domain,\n                                       msgid=field.getSubfieldLabel(key), default=field.getSubfieldLabel(key))', 69, 49), 3611: (u'python:key in field.required_subfields', 74, 41), 3800: (u'widget/allowDelete', 78, 39), 4118: (u"python:hasattr(widget, 'combogrid_options') and widget.combogrid_options or {}", 85, 46), 4033: (u'python:range(field.getEditSize(here))', 84, 32), 3968: (u'string:records_row_${fieldName}', 83, 38), 4242: (u'python:field.getSubfields()', 87, 42), 4318: (u'python: here.translate(domain=i18n_domain, msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))', 88, 46), 4478: (u"python:field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)", 89, 37), 4775: (u'python:field.getSubfieldType(key)', 93, 35), 4848: (u" python:key in field.required_subfields and ' required' or '", 94, 38), 4949: (u'h python:field.getSubfieldMaxlength(ke', 95, 38), 5028: (u'th python:maxlength&gt;0 and maxlength o', 96, 37), 5163: (u"python: type == 'string' and not field.isSelection(key)", 100, 45), 5478: (u'python: field.getSubfieldWidth(key, default=235)', 107, 44), 5571: (u' string: ${width}p', 108, 43), 5804: (u'e string:${fieldName}.${key}:records:ignore_emp', 111, 45), 5992: (u'lue python:field.getSubfieldValue(values, idx, ', 113, 44), 6424: (u' tabindex tabindex/ne', 117, 41), 5641: (u'string:records_inputstring form-control form-control-sm', 109, 48), 5745: (u' descriptio', 110, 47), 5897: (u'id string:${fieldName}-${key}-${repeat/idx/ind', 112, 42), 6088: (u"tyle python:'width:%s;;min-width:%s;;max-width:%s' % (width, width,", 114, 43), 6208: (u'xlength maxlength', 115, 44), 6277: (u"readonly python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False)", 116, 42), 6506: (u'id_options python: widget.jsondumps(combogrid_options.ge', 118, 49), 6704: (u'python: field.isSelection(key)', 123, 48), 6816: (u'python:field.getSubfieldValue(values, idx, key)', 125, 44), 6908: (u' python:field.getVocabularyFor(key, here', 126, 43), 6992: (u'e python:field.getSubfieldSize(ke', 127, 41), 7173: (u'python:size and size < 2 or False', 130, 43), 7257: (u'string:${fieldName}.${key}:records:ignore_empty', 131, 49), 7355: (u' descriptio', 132, 49), 7414: (u'd string:${fieldName}-${key}-${repeat/idx/inde', 133, 45), 7514: (u'ex tabindex/next|noth', 134, 50), 7686: (u'vocab', 137, 47), 7745: (u'item', 138, 52), 7801: (u" python:test(here.checkSelected(item, value), 'selected', None", 139, 50), 7910: (u'python: vocab.getValue(item)', 140, 43), 8228: (u'python:size and size > 1 or False', 148, 43), 8360: (u'string:${fieldName}.${key}:records:list', 150, 49), 8450: (u' descriptio', 151, 49), 8509: (u'd string:${fieldName}-${key}-${repeat/idx/inde', 152, 45), 8609: (u'ex tabindex/next|noth', 153, 50), 8680: (u'ize ', 154, 45), 8836: (u'vocab', 157, 47), 8895: (u'item', 158, 52), 8951: (u" python:here.checkSelected(item, value) and 'selected' or Non", 159, 50), 9059: (u'python: vocab.getValue(item)', 160, 43), 9332: (u"python: type == 'lines'", 168, 43), 9660: (u' string:${fieldName}.${key}:records:ignore_empty:line', 173, 46), 9825: (u'ex tabindex/next|noth', 175, 48), 9566: (u'string:${fieldName}-${key}-${repeat/idx/index}', 172, 45), 9762: (u'e descripti', 174, 46), 9891: (u"python:'\\n'.join(field.getSubfieldValue(values, idx, key, []))", 176, 39), 10114: (u"python: type == 'boolean'", 182, 46), 10369: (u'string:${fieldName}.${key}:records:ignore_empty', 186, 47), 10620: (u'ex tabindex/next|noth', 189, 48), 10465: (u' descriptio', 187, 47), 10522: (u'd string:${fieldName}-${key}-${repeat/idx/inde', 188, 43), 10692: (u"ked python:field.getSubfieldValue(values, idx, key) and 'checked' o", 190, 46), 10893: (u"python: type == 'datepicker'", 195, 45), 11279: (u' string:${fieldName}.${key}:records:ignore_empt', 203, 46), 11527: (u'lue python:field.getSubfieldValue(values, idx, ', 206, 44), 11622: (u'size python:field.getSubfieldSize', 207, 42), 11924: (u'abindex tabindex/next', 210, 43), 11185: (u'string:datepicker form-control form-control-sm', 202, 48), 11375: (u'e descripti', 204, 46), 11432: (u'id string:${fieldName}-${key}-${repeat/idx/ind', 205, 42), 11708: (u'ength maxlength|n', 208, 46), 11777: (u"adonly python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) o", 209, 44), 12076: (u"python: type == 'int'", 215, 45), 12319: (u'string:${fieldName}.${key}:${type}:records:ignore_empty:int', 219, 47), 12577: (u'ue python:field.getSubfieldValue(values, idx, k', 222, 45), 12672: (u'ize python:field.getSubfieldSize(', 223, 43), 12827: (u'index tabindex/next|n', 225, 45), 12425: (u' descriptio', 220, 45), 12482: (u'd string:${fieldName}-${key}-${repeat/idx/inde', 221, 43), 12758: (u'ngth maxlength|no', 224, 47), 12984: (u"python: type in ['float', 'long']", 230, 45), 13239: (u'string:${fieldName}.${key}:${type}:records:ignore_empty', 234, 47), 13495: (u'ue python:field.getSubfieldValue(values, idx, k', 237, 45), 13590: (u'ize python:field.getSubfieldSize(', 238, 43), 13745: (u'index tabindex/next|n', 240, 45), 13343: (u' descriptio', 235, 47), 13400: (u'd string:${fieldName}-${key}-${repeat/idx/inde', 236, 43), 13676: (u'ngth maxlength|no', 239, 47), 14015: (u'widget/allowDelete', 252, 35), 14155: (u'string:delete-row-${repeat/idx/index}', 255, 39), 14233: (u' string:${portal/absolute_url}/senaite_theme/icon/delet', 256, 39), 14379: (u'python:field.getSubfields()', 259, 44), 14509: (u"python:hasattr(field, 'subfield_hidden')\n                            and field.subfield_hidden.get(key, False) == True", 262, 37), 14811: (u' string:${fieldName}.${key}:records:ignore_empt', 267, 32), 14893: (u'e python:field.getSubfieldValue(values, idx, ke', 268, 32), 14731: (u'string:${fieldName}-${key}-${repeat/idx/index}', 266, 41), 15208: (u'python: field.showMore(values) or not field.fixedSize', 279, 29), 15296: (u'string:${fieldName}_more', 280, 33), 15329: (u' tabindex/next|nothin', 280, 66), 1839: (u'here/widgets/field/macros/edit', 44, 28), 1839: (u'here/widgets/field/macros/edit', 44, 28), 15543: (u'here/widgets/string/macros/edit', 288, 28), 15543: (u'here/widgets/string/macros/edit', 288, 28), 577: (u"python:getKssClasses(fieldName,\n                    templateId='records_widget', macro='records-field-view')", 18, 30), 718: (u'kss_class', 20, 30), 755: (u' string:parent-fieldname-$fieldNam', 21, 26), 950: (u'python:field.getSubfields()', 24, 41), 1016: (u" python:getattr(field, 'subfield_hidden', {}", 25, 37), 1102: (u'n field/outerJo', 26, 39), 1159: (u'in field/innerJ', 27, 38), 874: (u'python:range(field.getSize(here))', 23, 35), 1263: (u'subfields', 29, 43), 1311: (u'python:field.getViewFor(context, idx, subfield, innerJoin)', 30, 36), 1404: (u'python:value and hidden.get(subfield, False) is False', 31, 33), 1619: (u'value', 34, 47), 366: (u'context/@@kss_field_decorator_view', 14, 33), 433: (u' nocall:kssClassesView/getKssClassesInlineEditabl', 15, 31)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756865912336 = {u'class': u'list-inline m-0', }
_static_135757074798672 = {u'class': u'header', }
_static_135756866131152 = {u'class': u'list-inline-item mr-0 mb-2', }
_static_135757109864848 = {u'id': u'delete_this_entry', }
_static_135757072927696 = {u'class': u'string:records_row_${fieldName}', }
_static_135756864572880 = {u'type': u'hidden', u'name': u'', u'value': u'', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', }
_static_135756866278544 = u'edit'
_static_135756866086864 = {u'style': u"python:'width:%s;min-width:%s;max-width:%s' % (width, width, width)", u'name': u'', u'title': u'description', u'combogrid_options': u"python: widget.jsondumps(combogrid_options.get(key, ''))", u'value': u'', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'readonly': u"python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False", u'maxlength': u'maxlength|nothing', u'size': u'30', u'type': u'text', u'class': u'string:records_inputstring form-control form-control-sm', u'tabindex': u'#', }
_static_135756866133072 = {u'class': u'p-1 bg-light border rounded', }
_static_135757075860304 = {u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'tabindex': u'tabindex/next|nothing', u'title': u'description', u'class': u'form-control form-control-sm', u'name': u'string:${fieldName}.${key}:records:ignore_empty', }
_static_135756866073104 = {u'name': u'', u'title': u'description', u'value': u'', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'maxlength': u'maxlength|nothing', u'size': u'10', u'type': u'text', u'class': u'form-control form-control-sm', u'tabindex': u'#', }
_static_135756869494352 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135756865930896 = {u'class': u'kss_class', u'id': u'string:parent-fieldname-$fieldName', }
_static_135757327983760 = {}
_static_135756866338000 = {u'name': u'', u'title': u'description', u'value': u'', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'readonly': u"python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False", u'maxlength': u'maxlength|nothing', u'size': u'30', u'type': u'text', u'class': u'string:datepicker form-control form-control-sm', u'tabindex': u'#', }
_static_135757244280656 = __compile_zt_expr
_static_135756866016464 = {u'selected': u"python:test(here.checkSelected(item, value), 'selected', None)", u'value': u'item', }
_static_135756866017168 = {u'multiple': u'multiple', u'name': u'string:${fieldName}.${key}:records:list', u'title': u'description', u'class': u'form-control form-control-sm', u'size': u'size', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'tabindex': u'tabindex/next|nothing', }
_static_135756866278096 = {u'style': u'border:none;', u'class': u'ArchetypesRecordsWidget', }
_static_135757109776976 = {u'class': u'recordswidget nosort table table-sm', u'id': u'string:${fieldName}_table', }
_static_135756864706064 = {u'selected': u"python:here.checkSelected(item, value) and 'selected' or None", u'value': u'item', }
_static_135756866373968 = {u'name': u'', u'title': u'description', u'value': u'', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'maxlength': u'maxlength|nothing', u'size': u'10', u'type': u'text', u'class': u'form-control form-control-sm', u'tabindex': u'#', }
_static_135756865714896 = {u'checked': u"python:field.getSubfieldValue(values, idx, key) and 'checked' or ''", u'name': u'', u'title': u'description', u'type': u'checkbox', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'tabindex': u'#', }
_static_135756866131856 = u'edit'
_static_135757074973136 = {u'title': u'python:\n                                          here.translate(domain=i18n_domain,\n                                          msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))', }
_static_135757109863248 = {u'tabindex': u'tabindex/next|nothing', u'type': u'button', u'class': u'context btn btn-outline-secondary btn-sm', u'value': u'More', u'id': u'string:${fieldName}_more', }
_static_135757109937232 = {u'class': u'fieldRequired', }
_static_135757244301584 = __C2ZContextWrapper
_static_135756869378768 = {u'width': u'16', u'src': u'string:${portal/absolute_url}/senaite_theme/icon/delete', u'class': u'rw_deletebtn btn-link', u'id': u'string:delete-row-${repeat/idx/index}', }
_static_135756865715984 = {u'style': u'width:100%;border-bottom:1px solid red;', }
_static_135756864691664 = {u'rows': u'5', u'name': u'', u'title': u'description', u'cols': u'30', u'class': u'form-control form-control-sm', u'id': u'string:${fieldName}-${key}-${repeat/idx/index}', u'tabindex': u'#', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865911760
            __attrs_135756865911760 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866130704
            __attrs_135756866130704 = _static_135757327983760
            __backup_macroname_135757119365840 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bc81790> name=None at 7b785bc81dd0> -> __value
            __value = _static_135756866131856
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866278352
                __attrs_135756866278352 = _static_135757327983760
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866279248
                __attrs_135756866279248 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866280528
                __default_135756866280528 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (46:39)> -> __cache_135756866280656
                __token = 1961
                try:
                    __zt_tmp = __attrs_135756866279248
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135756866280656 = _static_135757244280656('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (46:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bca5710> -> __condition
                __expression = __cache_135756866280656

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span/>')
                else:
                    __content = __cache_135756866280656
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b785bca52d0> name=None at 7b785bca5150> -> __attrs_135757109778192
                __attrs_135757109778192 = _static_135756866278096
                __backup_values_135756865931152 = get('values', __marker)

                # <Value u'python:field.getEditAccessor(here)()' (51:31)> -> __value
                __token = 2131
                try:
                    __zt_tmp = __attrs_135757109778192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.getEditAccessor(here)()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value
                __backup_session_values_135756865908880 = get('session_values', __marker)

                # <Value u'python:here.session_restore_value(fieldName, values)' (52:38)> -> __value
                __token = 2207
                try:
                    __zt_tmp = __attrs_135757109778192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'here.session_restore_value(fieldName, values)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['session_values'] = __value
                __backup_cached_values_135756865909840 = get('cached_values', __marker)

                # <Value u'python:request.get(fieldName,session_values)' (53:36)> -> __value
                __token = 2298
                try:
                    __zt_tmp = __attrs_135757109778192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'request.get(fieldName,session_values)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['cached_values'] = __value
                __backup_values_135756866131600 = get('values', __marker)

                # <Value u'python:cached_values or values' (54:28)> -> __value
                __token = 2374
                try:
                    __zt_tmp = __attrs_135757109778192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'cached_values or values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value
                __backup_i18n_domain_135756866133840 = get('i18n_domain', __marker)

                # <Value u'field/widget/i18n_domain|context/i18n_domain|string:plone' (55:32)> -> __value
                __token = 2441
                try:
                    __zt_tmp = __attrs_135757109778192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'field/widget/i18n_domain|context/i18n_domain|string:plone', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['i18n_domain'] = __value

                # <fieldset ... (0:0)
                # --------------------------------------------------------
                __append(u'<fieldset style="border:none;" class="ArchetypesRecordsWidget">\n\n            ')

                # <Static value=<_ast.Dict object at 0x7b786a4dd250> name=None at 7b786a4dd050> -> __attrs_135757074797008
                __attrs_135757074797008 = _static_135757109776976

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="recordswidget nosort table table-sm"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074796816
                __default_135757074796816 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_table' (59:33)> -> __attr_id
                __token = 2616
                try:
                    __zt_tmp = __attrs_135757074797008
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}_table', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\n\n              ')

                # <Static value=<_ast.Dict object at 0x7b7868381850> name=None at 7b7868381510> -> __attrs_135757074797712
                __attrs_135757074797712 = _static_135757074798672

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr class="header">\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074797200
                __attrs_135757074797200 = _static_135757327983760
                __backup_key_135756866131728 = get('key', __marker)

                # <Value u'python:field.getSubfields()' (62:39)> -> __iterator
                __token = 2718
                try:
                    __zt_tmp = __attrs_135757074797200
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u'field.getSubfields()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757074800400, ) = getitem('repeat')(u'key', __iterator)
                econtext['key'] = None
                for __item in __iterator:
                    econtext['key'] = __item
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075238032
                    __attrs_135757075238032 = _static_135757327983760

                    # <Value u"python:field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)" (63:37)> -> __condition
                    __token = 2785
                    try:
                        __zt_tmp = __attrs_135757075238032
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <th ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<th>\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b78683ac1d0> name=None at 7b78683ac190> -> __attrs_135757109937296
                        __attrs_135757109937296 = _static_135757074973136

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109938768
                        __default_135757109938768 = _DEFAULT_MARKER

                        # <Substitution u'python:\n                                          here.translate(domain=i18n_domain,\n                                          msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))' (66:48)> -> __attr_title
                        __token = 3064
                        try:
                            __zt_tmp = __attrs_135757109937296
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('python', u'\n                                          here.translate(domain=i18n_domain,\n                                          msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072926160
                        __default_135757072926160 = _DEFAULT_MARKER

                        # <Value u'python:\n                                       here.translate(domain=i18n_domain,\n                                       msgid=field.getSubfieldLabel(key), default=field.getSubfieldLabel(key))' (69:49)> -> __cache_135757072926352
                        __token = 3319
                        try:
                            __zt_tmp = __attrs_135757109937296
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757072926352 = _static_135757244280656('python', u'\n                                       here.translate(domain=i18n_domain,\n                                       msgid=field.getSubfieldLabel(key), default=field.getSubfieldLabel(key))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:\n                                       here.translate(domain=i18n_domain,\n                                       msgid=field.getSubfieldLabel(key), default=field.getSubfieldLabel(key))' (69:49)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78681b8a90> -> __condition
                        __expression = __cache_135757072926352

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                      Label\n                    ')
                        else:
                            __content = __cache_135757072926352
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b786a504450> name=None at 7b786a504e50> -> __attrs_135757150009360
                        __attrs_135757150009360 = _static_135757109937232

                        # <Value u'python:key in field.required_subfields' (74:41)> -> __condition
                        __token = 3611
                        try:
                            __zt_tmp = __attrs_135757150009360
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'key in field.required_subfields', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="fieldRequired">&nbsp;</span>')
                        __append(u'\n                  </th>')
                    __append(u'\n                ')
                    ____index_135757074800400 -= 1
                    if (____index_135757074800400 > 0):
                        __append('')
                if (__backup_key_135756866131728 is __marker):
                    del econtext['key']
                else:
                    econtext['key'] = __backup_key_135756866131728
                __append(u'\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074797136
                __attrs_135757074797136 = _static_135757327983760

                # <th ... (0:0)
                # --------------------------------------------------------
                __append(u'<th>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b786a4f2990> name=None at 7b786a4f2b50> -> __attrs_135757109866256
                __attrs_135757109866256 = _static_135757109864848

                # <Value u'widget/allowDelete' (78:39)> -> __condition
                __token = 3800
                try:
                    __zt_tmp = __attrs_135757109866256
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'widget/allowDelete', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span id="delete_this_entry">')
                    __stream_135757109863056 = []
                    __append_135757109863056 = __stream_135757109863056.append
                    __msgid_135757109863056 = __re_whitespace(''.join(__stream_135757109863056)).strip()
                    if __msgid_135757109863056:
                        __append(translate(__msgid_135757109863056, mapping=None, default=__msgid_135757109863056, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\n                </th>\n              </tr>\n\n              ')

                # <Static value=<_ast.Dict object at 0x7b78681b8bd0> name=None at 7b7868381450> -> __attrs_135757109863760
                __attrs_135757109863760 = _static_135757072927696
                __backup_combogrid_options_135756866280720 = get('combogrid_options', __marker)

                # <Value u"python:hasattr(widget, 'combogrid_options') and widget.combogrid_options or {}" (85:46)> -> __value
                __token = 4118
                try:
                    __zt_tmp = __attrs_135757109863760
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"hasattr(widget, 'combogrid_options') and widget.combogrid_options or {}", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['combogrid_options'] = __value
                __backup_idx_135757074797328 = get('idx', __marker)

                # <Value u'python:range(field.getEditSize(here))' (84:32)> -> __iterator
                __token = 4033
                try:
                    __zt_tmp = __attrs_135757109863760
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u'range(field.getEditSize(here))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757109865744, ) = getitem('repeat')(u'idx', __iterator)
                econtext['idx'] = None
                for __item in __iterator:
                    econtext['idx'] = __item

                    # <tr ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tr')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109866320
                    __default_135757109866320 = _DEFAULT_MARKER

                    # <Substitution u'string:records_row_${fieldName}' (83:38)> -> __attr_class
                    __token = 3968
                    try:
                        __zt_tmp = __attrs_135757109863760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('string', u'records_row_${fieldName}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109863632
                    __attrs_135757109863632 = _static_135757327983760
                    __backup_key_135757072925008 = get('key', __marker)

                    # <Value u'python:field.getSubfields()' (87:42)> -> __iterator
                    __token = 4242
                    try:
                        __zt_tmp = __attrs_135757109863632
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('python', u'field.getSubfields()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757109865168, ) = getitem('repeat')(u'key', __iterator)
                    econtext['key'] = None
                    for __item in __iterator:
                        econtext['key'] = __item
                        __append(u'\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869380560
                        __attrs_135756869380560 = _static_135757327983760
                        __backup_description_135756866278800 = get('description', __marker)

                        # <Value u'python: here.translate(domain=i18n_domain, msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))' (88:46)> -> __value
                        __token = 4318
                        try:
                            __zt_tmp = __attrs_135756869380560
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u' here.translate(domain=i18n_domain, msgid=field.getSubfieldDescription(key), default=field.getSubfieldLabel(key))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['description'] = __value

                        # <Value u"python:field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)" (89:37)> -> __condition
                        __token = 4478
                        try:
                            __zt_tmp = __attrs_135756869380560
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"field.testSubfieldCondition(key,here,portal,template)\n                                     and (not hasattr(field, 'subfield_hidden')\n                                     or field.subfield_hidden.get(key, False) == False)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <td ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<td>\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869380368
                            __attrs_135756869380368 = _static_135757327983760
                            __backup_type_135757072928400 = get('type', __marker)

                            # <Value u'python:field.getSubfieldType(key)' (93:35)> -> __value
                            __token = 4775
                            try:
                                __zt_tmp = __attrs_135756869380368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'field.getSubfieldType(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['type'] = __value
                            __backup_required_135757109862480 = get('required', __marker)

                            # <Value u"python:key in field.required_subfields and ' required' or ''" (94:38)> -> __value
                            __token = 4848
                            try:
                                __zt_tmp = __attrs_135756869380368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"key in field.required_subfields and ' required' or ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['required'] = __value
                            __backup_maxlength_135756869380944 = get('maxlength', __marker)

                            # <Value u'python:field.getSubfieldMaxlength(key)' (95:38)> -> __value
                            __token = 4949
                            try:
                                __zt_tmp = __attrs_135756869380368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'field.getSubfieldMaxlength(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['maxlength'] = __value
                            __backup_maxlength_135756869381648 = get('maxlength', __marker)

                            # <Value u'python:maxlength>0 and maxlength or None' (96:37)> -> __value
                            __token = 5028
                            try:
                                __zt_tmp = __attrs_135756869380368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'maxlength>0 and maxlength or None', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['maxlength'] = __value
                            __append(u'\n\n                      <!-- string -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869381968
                            __attrs_135756869381968 = _static_135757327983760

                            # <Value u"python: type == 'string' and not field.isSelection(key)" (100:45)> -> __condition
                            __token = 5163
                            try:
                                __zt_tmp = __attrs_135756869381968
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type == 'string' and not field.isSelection(key)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bc767d0> name=None at 7b785bc76050> -> __attrs_135757074901200
                                __attrs_135757074901200 = _static_135756866086864
                                __backup_width_135756869380816 = get('width', __marker)

                                # <Value u'python: field.getSubfieldWidth(key, default=235)' (107:44)> -> __value
                                __token = 5478
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('python', u' field.getSubfieldWidth(key, default=235)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['width'] = __value
                                __backup_width_135756866085648 = get('width', __marker)

                                # <Value u'string: ${width}px' (108:43)> -> __value
                                __token = 5571
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('string', u' ${width}px', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['width'] = __value

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input type="text"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866088912
                                __default_135756866088912 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:records:ignore_empty' (111:45)> -> __attr_name
                                __token = 5804
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866086352
                                __default_135756866086352 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldValue(values, idx, key)' (113:44)> -> __attr_value
                                __token = 5992
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u' size="30"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866085712
                                __default_135756866085712 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (117:41)> -> __attr_tabindex
                                __token = 6424
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866087568
                                __default_135756866087568 = _DEFAULT_MARKER

                                # <Substitution u'string:records_inputstring form-control form-control-sm' (109:48)> -> __attr_class
                                __token = 5641
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('string', u'records_inputstring form-control form-control-sm', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867963408
                                __default_135756867963408 = _DEFAULT_MARKER

                                # <Substitution u'description' (110:47)> -> __attr_title
                                __token = 5745
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867961616
                                __default_135756867961616 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (112:42)> -> __attr_id
                                __token = 5897
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867964112
                                __default_135756867964112 = _DEFAULT_MARKER

                                # <Substitution u"python:'width:%s;min-width:%s;max-width:%s' % (width, width, width)" (114:43)> -> __attr_style
                                __token = 6088
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_style = _static_135757244280656('python', u"'width:%s;min-width:%s;max-width:%s' % (width, width, width)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_style is not None):
                                    __append((u' style="%s"' % __attr_style))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867960912
                                __default_135756867960912 = _DEFAULT_MARKER

                                # <Substitution u'maxlength|nothing' (115:44)> -> __attr_maxlength
                                __token = 6208
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_maxlength = _static_135757244280656('path', u'maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_maxlength is not None):
                                    __append((u' maxlength="%s"' % __attr_maxlength))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867961488
                                __default_135756867961488 = _DEFAULT_MARKER

                                # <Boolean u"python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False" (116:42)> -> __attr_readonly
                                __token = 6277
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_readonly = _static_135757244280656('python', u"hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if (__attr_readonly is _DEFAULT_MARKER):
                                    __attr_readonly = None
                                else:
                                    if __attr_readonly:
                                        __attr_readonly = u'readonly'
                                    else:
                                        __attr_readonly = None
                                if (__attr_readonly is not None):
                                    __append((u' readonly="%s"' % __attr_readonly))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867963152
                                __default_135756867963152 = _DEFAULT_MARKER

                                # <Substitution u"python: widget.jsondumps(combogrid_options.get(key, ''))" (118:49)> -> __attr_combogrid_options
                                __token = 6506
                                try:
                                    __zt_tmp = __attrs_135757074901200
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_combogrid_options = _static_135757244280656('python', u" widget.jsondumps(combogrid_options.get(key, ''))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_combogrid_options = __quote(__attr_combogrid_options, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_combogrid_options is not None):
                                    __append((u' combogrid_options="%s"' % __attr_combogrid_options))
                                __append(u'/>')
                                if (__backup_width_135756866085648 is __marker):
                                    del econtext['width']
                                else:
                                    econtext['width'] = __backup_width_135756866085648
                                if (__backup_width_135756869380816 is __marker):
                                    del econtext['width']
                                else:
                                    econtext['width'] = __backup_width_135756869380816
                                __append(u'\n                      ')
                            __append(u'\n\n                      <!-- selection -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074901264
                            __attrs_135757074901264 = _static_135757327983760

                            # <Value u'python: field.isSelection(key)' (123:48)> -> __condition
                            __token = 6704
                            try:
                                __zt_tmp = __attrs_135757074901264
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u' field.isSelection(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074901136
                                __attrs_135757074901136 = _static_135757327983760
                                __backup_value_135756869379536 = get('value', __marker)

                                # <Value u'python:field.getSubfieldValue(values, idx, key)' (125:44)> -> __value
                                __token = 6816
                                try:
                                    __zt_tmp = __attrs_135757074901136
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['value'] = __value
                                __backup_vocab_135757074901712 = get('vocab', __marker)

                                # <Value u'python:field.getVocabularyFor(key, here)' (126:43)> -> __value
                                __token = 6908
                                try:
                                    __zt_tmp = __attrs_135757074901136
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('python', u'field.getVocabularyFor(key, here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['vocab'] = __value
                                __backup_size_135757074900176 = get('size', __marker)

                                # <Value u'python:field.getSubfieldSize(key)' (127:41)> -> __value
                                __token = 6992
                                try:
                                    __zt_tmp = __attrs_135757074901136
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['size'] = __value
                                __append(u'\n                          ')

                                # <Static value=<_ast.Dict object at 0x7b7868484b50> name=None at 7b7868484f10> -> __attrs_135757075858576
                                __attrs_135757075858576 = _static_135757075860304

                                # <Value u'python:size and size < 2 or False' (130:43)> -> __condition
                                __token = 7173
                                try:
                                    __zt_tmp = __attrs_135757075858576
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('python', u'size and size < 2 or False', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:
                                    __previous_i18n_domain_135756866017872 = __i18n_domain
                                    __i18n_domain = u'python:i18n_domain'

                                    # <select ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<select class="form-control form-control-sm"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075859088
                                    __default_135757075859088 = _DEFAULT_MARKER

                                    # <Substitution u'string:${fieldName}.${key}:records:ignore_empty' (131:49)> -> __attr_name
                                    __token = 7257
                                    try:
                                        __zt_tmp = __attrs_135757075858576
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_name is not None):
                                        __append((u' name="%s"' % __attr_name))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075860432
                                    __default_135757075860432 = _DEFAULT_MARKER

                                    # <Substitution u'description' (132:49)> -> __attr_title
                                    __token = 7355
                                    try:
                                        __zt_tmp = __attrs_135757075858576
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_title is not None):
                                        __append((u' title="%s"' % __attr_title))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075860368
                                    __default_135757075860368 = _DEFAULT_MARKER

                                    # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (133:45)> -> __attr_id
                                    __token = 7414
                                    try:
                                        __zt_tmp = __attrs_135757075858576
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075861072
                                    __default_135757075861072 = _DEFAULT_MARKER

                                    # <Substitution u'tabindex/next|nothing' (134:50)> -> __attr_tabindex
                                    __token = 7514
                                    try:
                                        __zt_tmp = __attrs_135757075858576
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_tabindex is not None):
                                        __append((u' tabindex="%s"' % __attr_tabindex))
                                    __append(u'>\n                            ')

                                    # <Static value=<_ast.Dict object at 0x7b785bc654d0> name=None at 7b785bc65950> -> __attrs_135756866018640
                                    __attrs_135756866018640 = _static_135756866016464
                                    __backup_item_135757074900432 = get('item', __marker)

                                    # <Value u'vocab' (137:47)> -> __iterator
                                    __token = 7686
                                    try:
                                        __zt_tmp = __attrs_135756866018640
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    (__iterator, ____index_135756866017360, ) = getitem('repeat')(u'item', __iterator)
                                    econtext['item'] = None
                                    for __item in __iterator:
                                        econtext['item'] = __item

                                        # <option ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<option')

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866015312
                                        __default_135756866015312 = _DEFAULT_MARKER

                                        # <Substitution u'item' (138:52)> -> __attr_value
                                        __token = 7745
                                        try:
                                            __zt_tmp = __attrs_135756866018640
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_value is not None):
                                            __append((u' value="%s"' % __attr_value))

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866016976
                                        __default_135756866016976 = _DEFAULT_MARKER

                                        # <Boolean u"python:test(here.checkSelected(item, value), 'selected', None)" (139:50)> -> __attr_selected
                                        __token = 7801
                                        try:
                                            __zt_tmp = __attrs_135756866018640
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_selected = _static_135757244280656('python', u"test(here.checkSelected(item, value), 'selected', None)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                        if (__attr_selected is _DEFAULT_MARKER):
                                            __attr_selected = None
                                        else:
                                            if __attr_selected:
                                                __attr_selected = u'selected'
                                            else:
                                                __attr_selected = None
                                        if (__attr_selected is not None):
                                            __append((u' selected="%s"' % __attr_selected))
                                        __append(u'>')

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866016208
                                        __default_135756866016208 = _DEFAULT_MARKER

                                        # <Value u'python: vocab.getValue(item)' (140:43)> -> __cache_135756866017552
                                        __token = 7910
                                        try:
                                            __zt_tmp = __attrs_135756866018640
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __cache_135756866017552 = _static_135757244280656('python', u' vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                        # <BinOp left=<Value u'python: vocab.getValue(item)' (140:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bc65710> -> __condition
                                        __expression = __cache_135756866017552

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                        __value = _DEFAULT_MARKER
                                        __condition = (__expression is __value)
                                        if __condition:
                                            pass
                                        else:
                                            __content = __cache_135756866017552
                                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                            __content = __quote(__content, None, '\xad', None, None)
                                            if (__content is not None):
                                                __append(__content)
                                        __append(u'</option>')
                                        ____index_135756866017360 -= 1
                                        if (____index_135756866017360 > 0):
                                            __append('\n                            ')
                                    if (__backup_item_135757074900432 is __marker):
                                        del econtext['item']
                                    else:
                                        econtext['item'] = __backup_item_135757074900432
                                    __append(u'\n                          </select>')
                                    __i18n_domain = __previous_i18n_domain_135756866017872
                                __append(u'\n\n                          <!-- multi-select selection -->\n\n                          ')

                                # <Static value=<_ast.Dict object at 0x7b785bc65790> name=None at 7b785bc65210> -> __attrs_135756864704848
                                __attrs_135756864704848 = _static_135756866017168

                                # <Value u'python:size and size > 1 or False' (148:43)> -> __condition
                                __token = 8228
                                try:
                                    __zt_tmp = __attrs_135756864704848
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('python', u'size and size > 1 or False', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:
                                    __previous_i18n_domain_135756864706704 = __i18n_domain
                                    __i18n_domain = u'python:i18n_domain'

                                    # <select ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<select class="form-control form-control-sm" multiple="multiple"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864706000
                                    __default_135756864706000 = _DEFAULT_MARKER

                                    # <Substitution u'string:${fieldName}.${key}:records:list' (150:49)> -> __attr_name
                                    __token = 8360
                                    try:
                                        __zt_tmp = __attrs_135756864704848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:list', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_name is not None):
                                        __append((u' name="%s"' % __attr_name))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864707856
                                    __default_135756864707856 = _DEFAULT_MARKER

                                    # <Substitution u'description' (151:49)> -> __attr_title
                                    __token = 8450
                                    try:
                                        __zt_tmp = __attrs_135756864704848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_title is not None):
                                        __append((u' title="%s"' % __attr_title))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864706384
                                    __default_135756864706384 = _DEFAULT_MARKER

                                    # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (152:45)> -> __attr_id
                                    __token = 8509
                                    try:
                                        __zt_tmp = __attrs_135756864704848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864707984
                                    __default_135756864707984 = _DEFAULT_MARKER

                                    # <Substitution u'tabindex/next|nothing' (153:50)> -> __attr_tabindex
                                    __token = 8609
                                    try:
                                        __zt_tmp = __attrs_135756864704848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_tabindex is not None):
                                        __append((u' tabindex="%s"' % __attr_tabindex))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864704784
                                    __default_135756864704784 = _DEFAULT_MARKER

                                    # <Substitution u'size' (154:45)> -> __attr_size
                                    __token = 8680
                                    try:
                                        __zt_tmp = __attrs_135756864704848
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_size = _static_135757244280656('path', u'size', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_size = __quote(__attr_size, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_size is not None):
                                        __append((u' size="%s"' % __attr_size))
                                    __append(u'>\n                            ')

                                    # <Static value=<_ast.Dict object at 0x7b785bb25610> name=None at 7b785bb25e50> -> __attrs_135756864691984
                                    __attrs_135756864691984 = _static_135756864706064
                                    __backup_item_135757074899920 = get('item', __marker)

                                    # <Value u'vocab' (157:47)> -> __iterator
                                    __token = 8836
                                    try:
                                        __zt_tmp = __attrs_135756864691984
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    (__iterator, ____index_135756864690512, ) = getitem('repeat')(u'item', __iterator)
                                    econtext['item'] = None
                                    for __item in __iterator:
                                        econtext['item'] = __item

                                        # <option ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<option')

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864688272
                                        __default_135756864688272 = _DEFAULT_MARKER

                                        # <Substitution u'item' (158:52)> -> __attr_value
                                        __token = 8895
                                        try:
                                            __zt_tmp = __attrs_135756864691984
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_value is not None):
                                            __append((u' value="%s"' % __attr_value))

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864689424
                                        __default_135756864689424 = _DEFAULT_MARKER

                                        # <Boolean u"python:here.checkSelected(item, value) and 'selected' or None" (159:50)> -> __attr_selected
                                        __token = 8951
                                        try:
                                            __zt_tmp = __attrs_135756864691984
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_selected = _static_135757244280656('python', u"here.checkSelected(item, value) and 'selected' or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                        if (__attr_selected is _DEFAULT_MARKER):
                                            __attr_selected = None
                                        else:
                                            if __attr_selected:
                                                __attr_selected = u'selected'
                                            else:
                                                __attr_selected = None
                                        if (__attr_selected is not None):
                                            __append((u' selected="%s"' % __attr_selected))
                                        __append(u'>')

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864706640
                                        __default_135756864706640 = _DEFAULT_MARKER

                                        # <Value u'python: vocab.getValue(item)' (160:43)> -> __cache_135756864705744
                                        __token = 9059
                                        try:
                                            __zt_tmp = __attrs_135756864691984
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __cache_135756864705744 = _static_135757244280656('python', u' vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                        # <BinOp left=<Value u'python: vocab.getValue(item)' (160:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bb251d0> -> __condition
                                        __expression = __cache_135756864705744

                                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                        __value = _DEFAULT_MARKER
                                        __condition = (__expression is __value)
                                        if __condition:
                                            pass
                                        else:
                                            __content = __cache_135756864705744
                                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                            __content = __quote(__content, None, '\xad', None, None)
                                            if (__content is not None):
                                                __append(__content)
                                        __append(u'</option>')
                                        ____index_135756864690512 -= 1
                                        if (____index_135756864690512 > 0):
                                            __append('\n                            ')
                                    if (__backup_item_135757074899920 is __marker):
                                        del econtext['item']
                                    else:
                                        econtext['item'] = __backup_item_135757074899920
                                    __append(u'\n                          </select>')
                                    __i18n_domain = __previous_i18n_domain_135756864706704
                                __append(u'\n                        ')
                                if (__backup_size_135757074900176 is __marker):
                                    del econtext['size']
                                else:
                                    econtext['size'] = __backup_size_135757074900176
                                if (__backup_vocab_135757074901712 is __marker):
                                    del econtext['vocab']
                                else:
                                    econtext['vocab'] = __backup_vocab_135757074901712
                                if (__backup_value_135756869379536 is __marker):
                                    del econtext['value']
                                else:
                                    econtext['value'] = __backup_value_135756869379536
                                __append(u'\n                      ')
                            __append(u'\n\n                      <!-- text -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074901008
                            __attrs_135757074901008 = _static_135757327983760

                            # <Value u"python: type == 'lines'" (168:43)> -> __condition
                            __token = 9332
                            try:
                                __zt_tmp = __attrs_135757074901008
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type == 'lines'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bb21dd0> name=None at 7b785bb21450> -> __attrs_135756865714320
                                __attrs_135756865714320 = _static_135756864691664

                                # <textarea ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<textarea class="form-control form-control-sm"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864688464
                                __default_135756864688464 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:records:ignore_empty:lines' (173:46)> -> __attr_name
                                __token = 9660
                                try:
                                    __zt_tmp = __attrs_135756865714320
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty:lines', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))
                                __append(u' cols="30" rows="5"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865714128
                                __default_135756865714128 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (175:48)> -> __attr_tabindex
                                __token = 9825
                                try:
                                    __zt_tmp = __attrs_135756865714320
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865712720
                                __default_135756865712720 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (172:45)> -> __attr_id
                                __token = 9566
                                try:
                                    __zt_tmp = __attrs_135756865714320
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865714192
                                __default_135756865714192 = _DEFAULT_MARKER

                                # <Substitution u'description' (174:46)> -> __attr_title
                                __token = 9762
                                try:
                                    __zt_tmp = __attrs_135756865714320
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))
                                __append(u' >')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864691856
                                __default_135756864691856 = _DEFAULT_MARKER

                                # <Value u"python:'\\n'.join(field.getSubfieldValue(values, idx, key, []))" (176:39)> -> __cache_135756864690064
                                __token = 9891
                                try:
                                    __zt_tmp = __attrs_135756865714320
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135756864690064 = _static_135757244280656('python', u"'\\n'.join(field.getSubfieldValue(values, idx, key, []))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u"python:'\\n'.join(field.getSubfieldValue(values, idx, key, []))" (176:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bb21f50> -> __condition
                                __expression = __cache_135756864690064

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\n                        ')
                                else:
                                    __content = __cache_135756864690064
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</textarea>\n                      ')
                            __append(u'\n\n                      <!-- boolean -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865715280
                            __attrs_135756865715280 = _static_135757327983760

                            # <Value u"python: type == 'boolean'" (182:46)> -> __condition
                            __token = 10114
                            try:
                                __zt_tmp = __attrs_135756865715280
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type == 'boolean'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bc1bf10> name=None at 7b785bc1be90> -> __attrs_135756865715088
                                __attrs_135756865715088 = _static_135756865715984

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span style="width:100%;border-bottom:1px solid red;"></span>\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bc1bad0> name=None at 7b785bc1bd50> -> __attrs_135756866336208
                                __attrs_135756866336208 = _static_135756865714896

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input type="checkbox"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866335120
                                __default_135756866335120 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:records:ignore_empty' (186:47)> -> __attr_name
                                __token = 10369
                                try:
                                    __zt_tmp = __attrs_135756866336208
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866338384
                                __default_135756866338384 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (189:48)> -> __attr_tabindex
                                __token = 10620
                                try:
                                    __zt_tmp = __attrs_135756866336208
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866338448
                                __default_135756866338448 = _DEFAULT_MARKER

                                # <Substitution u'description' (187:47)> -> __attr_title
                                __token = 10465
                                try:
                                    __zt_tmp = __attrs_135756866336208
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866338064
                                __default_135756866338064 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (188:43)> -> __attr_id
                                __token = 10522
                                try:
                                    __zt_tmp = __attrs_135756866336208
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866336400
                                __default_135756866336400 = _DEFAULT_MARKER

                                # <Boolean u"python:field.getSubfieldValue(values, idx, key) and 'checked' or ''" (190:46)> -> __attr_checked
                                __token = 10692
                                try:
                                    __zt_tmp = __attrs_135756866336208
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_checked = _static_135757244280656('python', u"field.getSubfieldValue(values, idx, key) and 'checked' or ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if (__attr_checked is _DEFAULT_MARKER):
                                    __attr_checked = None
                                else:
                                    if __attr_checked:
                                        __attr_checked = u'checked'
                                    else:
                                        __attr_checked = None
                                if (__attr_checked is not None):
                                    __append((u' checked="%s"' % __attr_checked))
                                __append(u'/>\n                      ')
                            __append(u'\n\n                      <!-- datepicker -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866335888
                            __attrs_135756866335888 = _static_135757327983760

                            # <Value u"python: type == 'datepicker'" (195:45)> -> __condition
                            __token = 10893
                            try:
                                __zt_tmp = __attrs_135756866335888
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type == 'datepicker'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bcb3cd0> name=None at 7b785bcb3f90> -> __attrs_135756866267216
                                __attrs_135756866267216 = _static_135756866338000

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input type="text"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866266384
                                __default_135756866266384 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:records:ignore_empty' (203:46)> -> __attr_name
                                __token = 11279
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866266256
                                __default_135756866266256 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldValue(values, idx, key)' (206:44)> -> __attr_value
                                __token = 11527
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866265680
                                __default_135756866265680 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldSize(key)' (207:42)> -> __attr_size
                                __token = 11622
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_size = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_size = __quote(__attr_size, '"', '&quot;', u'30', _DEFAULT_MARKER)
                                if (__attr_size is not None):
                                    __append((u' size="%s"' % __attr_size))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866265936
                                __default_135756866265936 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (210:43)> -> __attr_tabindex
                                __token = 11924
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866268432
                                __default_135756866268432 = _DEFAULT_MARKER

                                # <Substitution u'string:datepicker form-control form-control-sm' (202:48)> -> __attr_class
                                __token = 11185
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('string', u'datepicker form-control form-control-sm', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866268048
                                __default_135756866268048 = _DEFAULT_MARKER

                                # <Substitution u'description' (204:46)> -> __attr_title
                                __token = 11375
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866268880
                                __default_135756866268880 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (205:42)> -> __attr_id
                                __token = 11432
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866268688
                                __default_135756866268688 = _DEFAULT_MARKER

                                # <Substitution u'maxlength|nothing' (208:46)> -> __attr_maxlength
                                __token = 11708
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_maxlength = _static_135757244280656('path', u'maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_maxlength is not None):
                                    __append((u' maxlength="%s"' % __attr_maxlength))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866266128
                                __default_135756866266128 = _DEFAULT_MARKER

                                # <Boolean u"python:hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False" (209:44)> -> __attr_readonly
                                __token = 11777
                                try:
                                    __zt_tmp = __attrs_135756866267216
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_readonly = _static_135757244280656('python', u"hasattr(field, 'subfield_readonly') and field.subfield_readonly.get(key, False) or False", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if (__attr_readonly is _DEFAULT_MARKER):
                                    __attr_readonly = None
                                else:
                                    if __attr_readonly:
                                        __attr_readonly = u'readonly'
                                    else:
                                        __attr_readonly = None
                                if (__attr_readonly is not None):
                                    __append((u' readonly="%s"' % __attr_readonly))
                                __append(u'/>\n                      ')
                            __append(u'\n\n                      <!-- int -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866265232
                            __attrs_135756866265232 = _static_135757327983760

                            # <Value u"python: type == 'int'" (215:45)> -> __condition
                            __token = 12076
                            try:
                                __zt_tmp = __attrs_135756866265232
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type == 'int'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bcbc950> name=None at 7b785bca2610> -> __attrs_135756866075536
                                __attrs_135756866075536 = _static_135756866373968

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input class="form-control form-control-sm" type="text"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866373072
                                __default_135756866373072 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:${type}:records:ignore_empty:int' (219:47)> -> __attr_name
                                __token = 12319
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:${type}:records:ignore_empty:int', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866375120
                                __default_135756866375120 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldValue(values, idx, key)' (222:45)> -> __attr_value
                                __token = 12577
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866372560
                                __default_135756866372560 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldSize(key)' (223:43)> -> __attr_size
                                __token = 12672
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_size = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_size = __quote(__attr_size, '"', '&quot;', u'10', _DEFAULT_MARKER)
                                if (__attr_size is not None):
                                    __append((u' size="%s"' % __attr_size))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866372688
                                __default_135756866372688 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (225:45)> -> __attr_tabindex
                                __token = 12827
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866374032
                                __default_135756866374032 = _DEFAULT_MARKER

                                # <Substitution u'description' (220:45)> -> __attr_title
                                __token = 12425
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866074512
                                __default_135756866074512 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (221:43)> -> __attr_id
                                __token = 12482
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866073744
                                __default_135756866073744 = _DEFAULT_MARKER

                                # <Substitution u'maxlength|nothing' (224:47)> -> __attr_maxlength
                                __token = 12758
                                try:
                                    __zt_tmp = __attrs_135756866075536
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_maxlength = _static_135757244280656('path', u'maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_maxlength is not None):
                                    __append((u' maxlength="%s"' % __attr_maxlength))
                                __append(u'/>\n                      ')
                            __append(u'\n\n                      <!-- float long -->\n\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866073360
                            __attrs_135756866073360 = _static_135757327983760

                            # <Value u"python: type in ['float', 'long']" (230:45)> -> __condition
                            __token = 12984
                            try:
                                __zt_tmp = __attrs_135756866073360
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u" type in ['float', 'long']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u'\n                        ')

                                # <Static value=<_ast.Dict object at 0x7b785bc73210> name=None at 7b785bc73810> -> __attrs_135756865675024
                                __attrs_135756865675024 = _static_135756866073104

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input class="form-control form-control-sm" type="text"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866076304
                                __default_135756866076304 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}.${key}:${type}:records:ignore_empty' (234:47)> -> __attr_name
                                __token = 13239
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:${type}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_name is not None):
                                    __append((u' name="%s"' % __attr_name))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866076048
                                __default_135756866076048 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldValue(values, idx, key)' (237:45)> -> __attr_value
                                __token = 13495
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865671376
                                __default_135756865671376 = _DEFAULT_MARKER

                                # <Substitution u'python:field.getSubfieldSize(key)' (238:43)> -> __attr_size
                                __token = 13590
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_size = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_size = __quote(__attr_size, '"', '&quot;', u'10', _DEFAULT_MARKER)
                                if (__attr_size is not None):
                                    __append((u' size="%s"' % __attr_size))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865674000
                                __default_135756865674000 = _DEFAULT_MARKER

                                # <Substitution u'tabindex/next|nothing' (240:45)> -> __attr_tabindex
                                __token = 13745
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_tabindex is not None):
                                    __append((u' tabindex="%s"' % __attr_tabindex))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865674256
                                __default_135756865674256 = _DEFAULT_MARKER

                                # <Substitution u'description' (235:47)> -> __attr_title
                                __token = 13343
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865672528
                                __default_135756865672528 = _DEFAULT_MARKER

                                # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (236:43)> -> __attr_id
                                __token = 13400
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865672656
                                __default_135756865672656 = _DEFAULT_MARKER

                                # <Substitution u'maxlength|nothing' (239:47)> -> __attr_maxlength
                                __token = 13676
                                try:
                                    __zt_tmp = __attrs_135756865675024
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_maxlength = _static_135757244280656('path', u'maxlength|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_maxlength is not None):
                                    __append((u' maxlength="%s"' % __attr_maxlength))
                                __append(u'/>\n                      ')
                            __append(u'\n\n                    ')
                            if (__backup_maxlength_135756869381648 is __marker):
                                del econtext['maxlength']
                            else:
                                econtext['maxlength'] = __backup_maxlength_135756869381648
                            if (__backup_maxlength_135756869380944 is __marker):
                                del econtext['maxlength']
                            else:
                                econtext['maxlength'] = __backup_maxlength_135756869380944
                            if (__backup_required_135757109862480 is __marker):
                                del econtext['required']
                            else:
                                econtext['required'] = __backup_required_135757109862480
                            if (__backup_type_135757072928400 is __marker):
                                del econtext['type']
                            else:
                                econtext['type'] = __backup_type_135757072928400
                            __append(u'\n\n                  </td>')
                        if (__backup_description_135756866278800 is __marker):
                            del econtext['description']
                        else:
                            econtext['description'] = __backup_description_135756866278800
                        __append(u'\n\n                ')
                        ____index_135757109865168 -= 1
                        if (____index_135757109865168 > 0):
                            __append('')
                    if (__backup_key_135757072925008 is __marker):
                        del econtext['key']
                    else:
                        econtext['key'] = __backup_key_135757072925008
                    __append(u'\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866267536
                    __attrs_135756866267536 = _static_135757327983760

                    # <td ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<td>\n                  <!-- delete -->\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b785bf9a2d0> name=None at 7b785bf9a850> -> __attrs_135756865672080
                    __attrs_135756865672080 = _static_135756869378768

                    # <Value u'widget/allowDelete' (252:35)> -> __condition
                    __token = 14015
                    try:
                        __zt_tmp = __attrs_135756865672080
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'widget/allowDelete', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img class="rw_deletebtn btn-link" width="16"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865671440
                        __default_135756865671440 = _DEFAULT_MARKER

                        # <Substitution u'string:delete-row-${repeat/idx/index}' (255:39)> -> __attr_id
                        __token = 14155
                        try:
                            __zt_tmp = __attrs_135756865672080
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('string', u'delete-row-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865674512
                        __default_135756865674512 = _DEFAULT_MARKER

                        # <Substitution u'string:${portal/absolute_url}/senaite_theme/icon/delete' (256:39)> -> __attr_src
                        __token = 14233
                        try:
                            __zt_tmp = __attrs_135756865672080
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_135757244280656('string', u'${portal/absolute_url}/senaite_theme/icon/delete', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))
                        __append(u'/>')
                    __append(u'\n\n                  <!-- Hidden fields -->\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865673232
                    __attrs_135756865673232 = _static_135757327983760
                    __backup_key_135756869378512 = get('key', __marker)

                    # <Value u'python:field.getSubfields()' (259:44)> -> __iterator
                    __token = 14379
                    try:
                        __zt_tmp = __attrs_135756865673232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('python', u'field.getSubfields()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135756864573200, ) = getitem('repeat')(u'key', __iterator)
                    econtext['key'] = None
                    for __item in __iterator:
                        econtext['key'] = __item
                        __append(u'\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b785bb04dd0> name=None at 7b785bb045d0> -> __attrs_135756864571664
                        __attrs_135756864571664 = _static_135756864572880

                        # <Value u"python:hasattr(field, 'subfield_hidden')\n                            and field.subfield_hidden.get(key, False) == True" (262:37)> -> __condition
                        __token = 14509
                        try:
                            __zt_tmp = __attrs_135756864571664
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"hasattr(field, 'subfield_hidden')\n                            and field.subfield_hidden.get(key, False) == True", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="hidden"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864569872
                            __default_135756864569872 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}.${key}:records:ignore_empty' (267:32)> -> __attr_name
                            __token = 14811
                            try:
                                __zt_tmp = __attrs_135756864571664
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:records:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864572432
                            __default_135756864572432 = _DEFAULT_MARKER

                            # <Substitution u'python:field.getSubfieldValue(values, idx, key)' (268:32)> -> __attr_value
                            __token = 14893
                            try:
                                __zt_tmp = __attrs_135756864571664
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('python', u'field.getSubfieldValue(values, idx, key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864572368
                            __default_135756864572368 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}-${key}-${repeat/idx/index}' (266:41)> -> __attr_id
                            __token = 14731
                            try:
                                __zt_tmp = __attrs_135756864571664
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('string', u'${fieldName}-${key}-${repeat/idx/index}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))
                            __append(u'/>')
                        __append(u'\n                  ')
                        ____index_135756864573200 -= 1
                        if (____index_135756864573200 > 0):
                            __append('')
                    if (__backup_key_135756869378512 is __marker):
                        del econtext['key']
                    else:
                        econtext['key'] = __backup_key_135756869378512
                    __append(u'\n                </td>\n\n              </tr>')
                    ____index_135757109865744 -= 1
                    if (____index_135757109865744 > 0):
                        __append('\n              ')
                if (__backup_idx_135757074797328 is __marker):
                    del econtext['idx']
                else:
                    econtext['idx'] = __backup_idx_135757074797328
                if (__backup_combogrid_options_135756866280720 is __marker):
                    del econtext['combogrid_options']
                else:
                    econtext['combogrid_options'] = __backup_combogrid_options_135756866280720
                __append(u'\n            </table>\n\n            ')

                # <Static value=<_ast.Dict object at 0x7b786a4f2350> name=None at 7b786a4f2910> -> __attrs_135757072500816
                __attrs_135757072500816 = _static_135757109863248

                # <Value u'python: field.showMore(values) or not field.fixedSize' (279:29)> -> __condition
                __token = 15208
                try:
                    __zt_tmp = __attrs_135757072500816
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u' field.showMore(values) or not field.fixedSize', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="button" class="context btn btn-outline-secondary btn-sm"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864569424
                    __default_135756864569424 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x7b785bb04710> at 7b785bb043d0> -> __attr_value
                    __attr_value = u'More'
                    __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864571408
                    __default_135756864571408 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_more' (280:33)> -> __attr_id
                    __token = 15296
                    try:
                        __zt_tmp = __attrs_135757072500816
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}_more', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072500624
                    __default_135757072500624 = _DEFAULT_MARKER

                    # <Substitution u'tabindex/next|nothing' (280:66)> -> __attr_tabindex
                    __token = 15329
                    try:
                        __zt_tmp = __attrs_135757072500816
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_tabindex is not None):
                        __append((u' tabindex="%s"' % __attr_tabindex))
                    __append(u' />')
                __append(u'\n          </fieldset>')
                if (__backup_i18n_domain_135756866133840 is __marker):
                    del econtext['i18n_domain']
                else:
                    econtext['i18n_domain'] = __backup_i18n_domain_135756866133840
                if (__backup_values_135756866131600 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135756866131600
                if (__backup_cached_values_135756865909840 is __marker):
                    del econtext['cached_values']
                else:
                    econtext['cached_values'] = __backup_cached_values_135756865909840
                if (__backup_session_values_135756865908880 is __marker):
                    del econtext['session_values']
                else:
                    econtext['session_values'] = __backup_session_values_135756865908880
                if (__backup_values_135756865931152 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135756865931152
                __append(u'\n        ')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'here/widgets/field/macros/edit' (44:28)> -> __macro
            __token = 1839
            try:
                __zt_tmp = __attrs_135756866130704
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 1839
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757119365840 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757119365840
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866131984
            __attrs_135756866131984 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109780368
            __attrs_135757109780368 = _static_135757327983760
            __backup_macroname_135757119368960 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bca5490> name=None at 7b7868381e10> -> __value
            __value = _static_135756866278544
            econtext['macroname'] = __value

            # <Value u'here/widgets/string/macros/edit' (288:28)> -> __macro
            __token = 15543
            try:
                __zt_tmp = __attrs_135757109780368
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/widgets/string/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 15543
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757119368960 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757119368960
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_records_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bc50690> name=None at 7b785bc50750> -> __attrs_135756865932880
            __attrs_135756865932880 = _static_135756865930896
            __backup_kss_class_135756865932176 = get('kss_class', __marker)

            # <Value u"python:getKssClasses(fieldName,\n                    templateId='records_widget', macro='records-field-view')" (18:30)> -> __value
            __token = 577
            try:
                __zt_tmp = __attrs_135756865932880
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"getKssClasses(fieldName,\n                    templateId='records_widget', macro='records-field-view')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kss_class'] = __value

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865933264
            __default_135756865933264 = _DEFAULT_MARKER

            # <Substitution u'kss_class' (20:30)> -> __attr_class
            __token = 718
            try:
                __zt_tmp = __attrs_135756865932880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'kss_class', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756865930448
            __default_135756865930448 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName' (21:26)> -> __attr_id
            __token = 755
            try:
                __zt_tmp = __attrs_135756865932880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('string', u'parent-fieldname-$fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n        ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865910608
                __attrs_135756865910608 = _static_135757327983760
                __backup_subfields_135756865932496 = get('subfields', __marker)

                # <Value u'python:field.getSubfields()' (24:41)> -> __value
                __token = 950
                try:
                    __zt_tmp = __attrs_135756865910608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.getSubfields()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['subfields'] = __value
                __backup_hidden_135756865911696 = get('hidden', __marker)

                # <Value u"python:getattr(field, 'subfield_hidden', {})" (25:37)> -> __value
                __token = 1016
                try:
                    __zt_tmp = __attrs_135756865910608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"getattr(field, 'subfield_hidden', {})", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['hidden'] = __value
                __backup_outerJoin_135756865909200 = get('outerJoin', __marker)

                # <Value u'field/outerJoin' (26:39)> -> __value
                __token = 1102
                try:
                    __zt_tmp = __attrs_135756865910608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'field/outerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['outerJoin'] = __value
                __backup_innerJoin_135756865909648 = get('innerJoin', __marker)

                # <Value u'field/innerJoin' (27:38)> -> __value
                __token = 1159
                try:
                    __zt_tmp = __attrs_135756865910608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'field/innerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['innerJoin'] = __value
                __backup_idx_135756865910352 = get('idx', __marker)

                # <Value u'python:range(field.getSize(here))' (23:35)> -> __iterator
                __token = 874
                try:
                    __zt_tmp = __attrs_135756865910608
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u'range(field.getSize(here))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756865910864, ) = getitem('repeat')(u'idx', __iterator)
                econtext['idx'] = None
                for __item in __iterator:
                    econtext['idx'] = __item
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b785bc4be10> name=None at 7b785bc4be90> -> __attrs_135756865910160
                    __attrs_135756865910160 = _static_135756865912336

                    # <ul ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<ul class="list-inline m-0">\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866131792
                    __attrs_135756866131792 = _static_135757327983760
                    __backup_subfield_135756865910736 = get('subfield', __marker)

                    # <Value u'subfields' (29:43)> -> __iterator
                    __token = 1263
                    try:
                        __zt_tmp = __attrs_135756866131792
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'subfields', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135756866131344, ) = getitem('repeat')(u'subfield', __iterator)
                    econtext['subfield'] = None
                    for __item in __iterator:
                        econtext['subfield'] = __item
                        __append(u'\n              ')

                        # <Static value=<_ast.Dict object at 0x7b785bc814d0> name=None at 7b785bc811d0> -> __attrs_135756866132304
                        __attrs_135756866132304 = _static_135756866131152
                        __backup_value_135756865909776 = get('value', __marker)

                        # <Value u'python:field.getViewFor(context, idx, subfield, innerJoin)' (30:36)> -> __value
                        __token = 1311
                        try:
                            __zt_tmp = __attrs_135756866132304
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'field.getViewFor(context, idx, subfield, innerJoin)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['value'] = __value

                        # <Value u'python:value and hidden.get(subfield, False) is False' (31:33)> -> __condition
                        __token = 1404
                        try:
                            __zt_tmp = __attrs_135756866132304
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'value and hidden.get(subfield, False) is False', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <li ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<li class="list-inline-item mr-0 mb-2">\n                ')

                            # <Static value=<_ast.Dict object at 0x7b785bc81c50> name=None at 7b785bc81cd0> -> __attrs_135756866277968
                            __attrs_135756866277968 = _static_135756866133072

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="p-1 bg-light border rounded">\n                  ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866279888
                            __attrs_135756866279888 = _static_135757327983760

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866279760
                            __default_135756866279760 = _DEFAULT_MARKER

                            # <Value u'value' (34:47)> -> __cache_135756866278928
                            __token = 1619
                            try:
                                __zt_tmp = __attrs_135756866279888
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135756866278928 = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'value' (34:47)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bca5850> -> __condition
                            __expression = __cache_135756866278928

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                pass
                            else:
                                __content = __cache_135756866278928
                                __content = __convert(__content)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</span>\n                </span>\n              </li>')
                        if (__backup_value_135756865909776 is __marker):
                            del econtext['value']
                        else:
                            econtext['value'] = __backup_value_135756865909776
                        __append(u'\n            ')
                        ____index_135756866131344 -= 1
                        if (____index_135756866131344 > 0):
                            __append('')
                    if (__backup_subfield_135756865910736 is __marker):
                        del econtext['subfield']
                    else:
                        econtext['subfield'] = __backup_subfield_135756865910736
                    __append(u'\n          </ul>\n        ')
                    ____index_135756865910864 -= 1
                    if (____index_135756865910864 > 0):
                        __append('')
                if (__backup_idx_135756865910352 is __marker):
                    del econtext['idx']
                else:
                    econtext['idx'] = __backup_idx_135756865910352
                if (__backup_innerJoin_135756865909648 is __marker):
                    del econtext['innerJoin']
                else:
                    econtext['innerJoin'] = __backup_innerJoin_135756865909648
                if (__backup_outerJoin_135756865909200 is __marker):
                    del econtext['outerJoin']
                else:
                    econtext['outerJoin'] = __backup_outerJoin_135756865909200
                if (__backup_hidden_135756865911696 is __marker):
                    del econtext['hidden']
                else:
                    econtext['hidden'] = __backup_hidden_135756865911696
                if (__backup_subfields_135756865932496 is __marker):
                    del econtext['subfields']
                else:
                    econtext['subfields'] = __backup_subfields_135756865932496
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n      </span>')
            if (__backup_kss_class_135756865932176 is __marker):
                del econtext['kss_class']
            else:
                econtext['kss_class'] = __backup_kss_class_135756865932176
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865932112
            __attrs_135756865932112 = _static_135757327983760
            __backup_kssClassesView_135756869493392 = get('kssClassesView', __marker)

            # <Value u'context/@@kss_field_decorator_view' (14:33)> -> __value
            __token = 366
            try:
                __zt_tmp = __attrs_135756865932112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kssClassesView'] = __value
            __backup_getKssClasses_135756869495248 = get('getKssClasses', __marker)

            # <Value u'nocall:kssClassesView/getKssClassesInlineEditable' (15:31)> -> __value
            __token = 433
            try:
                __zt_tmp = __attrs_135756865932112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'kssClassesView/getKssClassesInlineEditable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['getKssClasses'] = __value
            __append(u'\n      ')
            __token = None
            render_records_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
            if (__backup_getKssClasses_135756869495248 is __marker):
                del econtext['getKssClasses']
            else:
                econtext['getKssClasses'] = __backup_getKssClasses_135756869495248
            if (__backup_kssClassesView_135756869493392 is __marker):
                del econtext['kssClassesView']
            else:
                econtext['kssClassesView'] = __backup_kssClassesView_135756869493392
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bfb6650> name=None at 7b785bfb6f50> -> __attrs_135756869494416
            __attrs_135756869494416 = _static_135756869494352
            __previous_i18n_domain_135756869493264 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869494992
            __attrs_135756869494992 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072826832
            __attrs_135757072826832 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title>\n  </head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756865930000
            __attrs_135756865930000 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135756869493264
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_records_field_view': render_records_field_view, u'render_view': render_view, 'render': render, }