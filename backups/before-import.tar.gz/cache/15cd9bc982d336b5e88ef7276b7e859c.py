# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.app.listing/src/senaite/app/listing/templates/listing.pt'

__tokens = {428: (u'provider:senaite.listingtabletitle', 10, 67), 632: (u'provider:senaite.listingtabledescription', 14, 73), 828: (u'provider:senaite.abovelistingtable', 18, 67), 942: (u'view/contents_table', 20, 34), 1044: (u'provider:senaite.belowlistingtable', 22, 67), 231: (u'here/main_template/macros/master', 5, 23), 231: (u'here/main_template/macros/master', 5, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757148694416 = {u'id': u'folderlisting-main-table', }
_static_135757075407120 = {u'id': u'viewlet-listing-table-description', }
_static_135757075274192 = {u'id': u'viewlet-below-content-table', }
_static_135757073444688 = u'master'
_static_135757244280656 = __compile_zt_expr
_static_135757150043600 = {u'id': u'viewlet-listing-table-title', }
_static_135757075408720 = {u'id': u'viewlet-above-listing-table', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073103248
            __attrs_135757073103248 = _static_135757327983760
            __previous_i18n_domain_135757073104464 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_135757117832400 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868236f50> name=None at 7b7868236810> -> __value
            __value = _static_135757073444688
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150042384
                __attrs_135757150042384 = _static_135757327983760
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7b786cb43dd0> name=None at 7b786cb43450> -> __attrs_135757075409104
                __attrs_135757075409104 = _static_135757150043600

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="viewlet-listing-table-title">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150040976
                __default_135757150040976 = _DEFAULT_MARKER

                # <Value u'provider:senaite.listingtabletitle' (10:67)> -> __cache_135757150043536
                __token = 428
                try:
                    __zt_tmp = __attrs_135757075409104
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757150043536 = _static_135757244280656('provider', u'senaite.listingtabletitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:senaite.listingtabletitle' (10:67)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cb43e90> -> __condition
                __expression = __cache_135757150043536

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135757150043536
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n    ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_description(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150041232
                __attrs_135757150041232 = _static_135757327983760
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7b7868416110> name=None at 7b78684162d0> -> __attrs_135757075410128
                __attrs_135757075410128 = _static_135757075407120

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="viewlet-listing-table-description">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075409936
                __default_135757075409936 = _DEFAULT_MARKER

                # <Value u'provider:senaite.listingtabledescription' (14:73)> -> __cache_135757075409616
                __token = 632
                try:
                    __zt_tmp = __attrs_135757075410128
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075409616 = _static_135757244280656('provider', u'senaite.listingtabledescription', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:senaite.listingtabledescription' (14:73)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78684165d0> -> __condition
                __expression = __cache_135757075409616

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135757075409616
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n    ')
            _slots = econtext[u'__slot_content_description'] = _deque((__fill_content_description, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075409552
                __attrs_135757075409552 = _static_135757327983760
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7b7868416750> name=None at 7b78684166d0> -> __attrs_135757148694224
                __attrs_135757148694224 = _static_135757075408720

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="viewlet-above-listing-table">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075408464
                __default_135757075408464 = _DEFAULT_MARKER

                # <Value u'provider:senaite.abovelistingtable' (18:67)> -> __cache_135757075410064
                __token = 828
                try:
                    __zt_tmp = __attrs_135757148694224
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075410064 = _static_135757244280656('provider', u'senaite.abovelistingtable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:senaite.abovelistingtable' (18:67)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868416bd0> -> __condition
                __expression = __cache_135757075410064

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135757075410064
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n      ')

                # <Static value=<_ast.Dict object at 0x7b786c9fa790> name=None at 7b786c9fa050> -> __attrs_135757074282704
                __attrs_135757074282704 = _static_135757148694416

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="folderlisting-main-table">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148695312
                __default_135757148695312 = _DEFAULT_MARKER

                # <Value u'view/contents_table' (20:34)> -> __cache_135757148694864
                __token = 942
                try:
                    __zt_tmp = __attrs_135757074282704
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757148694864 = _static_135757244280656('path', u'view/contents_table', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/contents_table' (20:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786c9fa350> -> __condition
                __expression = __cache_135757148694864

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n      ')
                else:
                    __content = __cache_135757148694864
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n      ')

                # <Static value=<_ast.Dict object at 0x7b78683f59d0> name=None at 7b78683f51d0> -> __attrs_135757075273040
                __attrs_135757075273040 = _static_135757075274192

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="viewlet-below-content-table">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075274832
                __default_135757075274832 = _DEFAULT_MARKER

                # <Value u'provider:senaite.belowlistingtable' (22:67)> -> __cache_135757075274064
                __token = 1044
                try:
                    __zt_tmp = __attrs_135757075273040
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075274064 = _static_135757244280656('provider', u'senaite.belowlistingtable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:senaite.belowlistingtable' (22:67)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683f5b10> -> __condition
                __expression = __cache_135757075274064

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_135757075274064
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n    ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (5:23)> -> __macro
            __token = 231
            try:
                __zt_tmp = __attrs_135757073103248
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 231
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757117832400 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757117832400
            __i18n_domain = __previous_i18n_domain_135757073104464
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }