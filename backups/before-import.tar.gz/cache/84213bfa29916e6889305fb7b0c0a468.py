# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/namedimage/display.pt'

__tokens = {51: (u'python:view.value', 2, 24), 98: (u" python:getattr(view.field, '__name__', None", 3, 27), 170: (u't python:view.conte', 4, 24), 216: (u"es python:context.restrictedTraverse('@@images', None)\r\n                          if (value is not None and fieldname and context is not None)\r\n                          else N", 5, 22), 418: (u"ale python:scales.scale(fieldname, scale='mini')\r\n                         if scales is not None else ", 8, 20), 552: (u'view/id', 10, 25), 589: (u' view/klas', 11, 27), 629: (u'e view/sty', 12, 26), 669: (u'le view/ti', 13, 25), 708: (u'ang view/', 14, 23), 753: (u'scale', 15, 28), 797: (u'python:scale.tag()', 16, 36), 846: (u'python:value is None', 17, 25)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402356200592 = {}
_static_140402272508432 = __C2ZContextWrapper
_static_140402101334800 = {u'lang': u'view/lang', u'style': u'view/style', u'title': u'view/title', u'id': u'view/id', u'class': u'view/klass', }
_static_140402272508048 = __compile_zt_expr
_static_140402101134352 = {u'class': u'discreet', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e9603310> name=None at 7fb1e9603110> -> __attrs_140402101474896
            __attrs_140402101474896 = _static_140402101334800
            __backup_value_140402101746640 = get('value', __marker)

            # <Value u'python:view.value' (2:24)> -> __value
            __token = 51
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_fieldname_140402101451280 = get('fieldname', __marker)

            # <Value u"python:getattr(view.field, '__name__', None)" (3:27)> -> __value
            __token = 98
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"getattr(view.field, '__name__', None)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['fieldname'] = __value
            __backup_context_140402101452688 = get('context', __marker)

            # <Value u'python:view.context' (4:24)> -> __value
            __token = 170
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.context', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['context'] = __value
            __backup_scales_140402101816208 = get('scales', __marker)

            # <Value u"python:context.restrictedTraverse('@@images', None)\r\n                          if (value is not None and fieldname and context is not None)\r\n                          else None" (5:22)> -> __value
            __token = 216
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"context.restrictedTraverse('@@images', None)\r\n                          if (value is not None and fieldname and context is not None)\r\n                          else None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['scales'] = __value
            __backup_scale_140402101756752 = get('scale', __marker)

            # <Value u"python:scales.scale(fieldname, scale='mini')\r\n                         if scales is not None else None" (8:20)> -> __value
            __token = 418
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"scales.scale(fieldname, scale='mini')\r\n                         if scales is not None else None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['scale'] = __value
            __previous_i18n_domain_140402101475344 = __i18n_domain
            __i18n_domain = u'plone'

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101474640
            __default_140402101474640 = _DEFAULT_MARKER

            # <Substitution u'view/id' (10:25)> -> __attr_id
            __token = 552
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'view/id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101474256
            __default_140402101474256 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (11:27)> -> __attr_class
            __token = 589
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101476048
            __default_140402101476048 = _DEFAULT_MARKER

            # <Substitution u'view/style' (12:26)> -> __attr_style
            __token = 629
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101476496
            __default_140402101476496 = _DEFAULT_MARKER

            # <Substitution u'view/title' (13:25)> -> __attr_title
            __token = 669
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101475280
            __default_140402101475280 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (14:23)> -> __attr_lang
            __token = 708
            try:
                __zt_tmp = __attrs_140402101474896
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_140402272508048('path', u'view/lang', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u'>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101133712
            __attrs_140402101133712 = _static_140402356200592

            # <Value u'scale' (15:28)> -> __condition
            __token = 753
            try:
                __zt_tmp = __attrs_140402101133712
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'scale', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101134288
                __default_140402101134288 = _DEFAULT_MARKER

                # <Value u'python:scale.tag()' (16:36)> -> __cache_140402101474768
                __token = 797
                try:
                    __zt_tmp = __attrs_140402101133712
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402101474768 = _static_140402272508048('python', u'scale.tag()', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:scale.tag()' (16:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e95d2050> -> __condition
                __expression = __cache_140402101474768

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_140402101474768
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            __append(u'\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e95d2410> name=None at 7fb1e95d2ed0> -> __attrs_140402101137296
            __attrs_140402101137296 = _static_140402101134352

            # <Value u'python:value is None' (17:25)> -> __condition
            __token = 846
            try:
                __zt_tmp = __attrs_140402101137296
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u'value is None', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span           class="discreet">')
                __stream_140402101134096 = []
                __append_140402101134096 = __stream_140402101134096.append
                __append_140402101134096(u'\r\n        No image\r\n    ')
                __msgid_140402101134096 = __re_whitespace(''.join(__stream_140402101134096)).strip()
                if u'no_image':
                    __append(translate(u'no_image', mapping=None, default=__msgid_140402101134096, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>')
            __append(u'\r\n</span>')
            __i18n_domain = __previous_i18n_domain_140402101475344
            if (__backup_scale_140402101756752 is __marker):
                del econtext['scale']
            else:
                econtext['scale'] = __backup_scale_140402101756752
            if (__backup_scales_140402101816208 is __marker):
                del econtext['scales']
            else:
                econtext['scales'] = __backup_scales_140402101816208
            if (__backup_context_140402101452688 is __marker):
                del econtext['context']
            else:
                econtext['context'] = __backup_context_140402101452688
            if (__backup_fieldname_140402101451280 is __marker):
                del econtext['fieldname']
            else:
                econtext['fieldname'] = __backup_fieldname_140402101451280
            if (__backup_value_140402101746640 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_140402101746640
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }