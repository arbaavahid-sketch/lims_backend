# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/install/templates/senaite-overview.pt'

__tokens = {647: (u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', 16, 31), 877: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 19, 31), 996: (u'view/sites', 22, 26), 1262: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', 33, 39), 1541: (u'sites', 39, 40), 1589: (u'python:len(sites) == 1', 40, 40), 1654: (u'sites', 41, 40), 1908: (u'site/absolute_url', 46, 47), 2174: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 51, 50), 2488: (u'python:view.outdated(site)', 56, 41), 2878: (u'python:view.upgrade_url(site)', 63, 53), 2958: (u'not:view/can_manage', 64, 48), 3096: (u'python:view.upgrade_url(site, can_manage=True)', 66, 54), 3570: (u'python:len(sites) &gt', 77, 41), 3803: (u'sites', 80, 65), 3942: (u'site/absolute_url', 83, 48), 3999: (u' site/Titl', 84, 38), 4225: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 88, 51), 4353: (u'site/Title', 89, 45), 4432: (u'string: (${site/getId})', 90, 59), 4617: (u'python:view.outdated(site)', 94, 42), 5032: (u'python:view.upgrade_url(site)', 102, 53), 5112: (u'not:view/can_manage', 103, 48), 5252: (u'python:view.upgrade_url(site, can_manage=True)', 105, 55), 5864: (u'not:sites', 121, 55), 6015: (u'sites', 124, 55), 6255: (u"python: '' if not sites else len(sites) + 1", 130, 46), 6345: (u'string:${context/absolute_url}/@@senaite-addsite', 131, 45), 6457: (u'senaite${site_number}', 132, 61), 6466: (u'site_number', 132, 70), 6900: (u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&amp;advanc', 140, 42)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757154787600 = {u'class': u'list-inline-item', }
_static_135757235500880 = {u'type': u'submit', u'class': u'btn btn-success', u'value': u'Create a new SENAITE site', }
_static_135757159721360 = {u'class': u'list-group', }
_static_135757159727184 = {u'class': u'prominent', }
_static_135757154791312 = {u'class': u'list-inline-item', }
_static_135757154833424 = {u'href': u'https://twitter.com/senaitelims', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Twitter', }
_static_135757226700496 = {u'class': u'list-group-item', }
_static_135757232008592 = {u'href': u'favicon.ico', u'type': u'image/x-icon', u'rel': u'icon', }
_static_135757159741392 = {u'action': u'', u'style': u'display: inline;', u'method': u'get', }
_static_135757235280464 = {u'type': u'hidden', u'name': u'site_id', u'value': u'senaite${site_number}', }
_static_135757226608080 = {u'class': u'container', }
_static_135757232035088 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135757159729872 = {u'href': u'#', u'class': u'btn btn-outline-secondary btn-sm', u'title': u'site/Title', }
_static_135757226771600 = {u'id': u'multiple-sites', }
_static_135757138290128 = {u'id': u'text', }
_static_135757159725904 = {u'class': u'list-group', }
_static_135757226826896 = {u'type': u'submit', u'class': u'plone-btn-secondary', u'value': u'Upgrade&hellip;', }
_static_135757235499088 = {u'type': u'hidden', u'name': u'site_title', u'value': u'SENAITE LIMS', }
_static_135757226698256 = {u'class': u'prominent', }
_static_135757154791760 = {u'href': u'https://community.senaite.com', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'SENAITE community', }
_static_135757327983760 = {}
_static_135757154788560 = {u'class': u'list-inline-item', }
_static_135757154778064 = {u'class': u'list-inline flex-column flex-sm-row', }
_static_135757154797712 = {u'href': u'https://github.com/senaite', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'GitHub', }
_static_135757154791632 = {u'class': u'list-inline-item', }
_static_135757226773008 = {u'action': u'', u'style': u'display: inline;', u'method': u'get', }
_static_135757235502672 = {u'href': u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1', u'class': u'btn btn-outline-secondary', }
_static_135757226767440 = {u'class': u'list-group-item', }
_static_135757244280656 = __compile_zt_expr
_static_135757154776784 = {u'class': u'col-sm-12', }
_static_135757235455440 = {u'type': u'submit', u'class': u'btn btn-secondary', u'value': u'Upgrade&hellip;', }
_static_135757159730064 = {u'class': u'upgrade-warning', }
_static_135757226746256 = {u'class': u'small', }
_static_135757226774224 = {u'type': u'hidden', u'name': u'came_from', u'value': u'python:view.upgrade_url(site, can_manage=True)', }
_static_135757226657616 = {u'src': u'favicon.ico', u'height': u'16', }
_static_135757226657552 = {u'class': u'upgrade-warning', }
_static_135757231987792 = {u'content': u'width=device-width, initial-scale=1', u'name': u'viewport', }
_static_135757154788880 = {u'href': u'https://www.senaite.com', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Website', }
_static_135757231987024 = {u'charset': u'utf-8', }
_static_135757159730512 = {u'src': u'favicon.ico', u'height': u'16', }
_static_135757226609744 = {u'class': u'col-sm-6 offset-sm-3', }
_static_135757159723472 = {u'class': u'list-group-item', }
_static_135757235278224 = {u'action': u'#', u'id': u'add-plone-site', u'method': u'get', }
_static_135757154777040 = {u'class': u'lead', }
_static_135757226608272 = {u'class': u'row', }
_static_135757226700432 = {u'href': u'#', u'class': u'btn btn-outline-secondary btn-sm', u'title': u'Go to your instance', }
_static_135757159722192 = {u'src': u'senaite-logo.png', u'height': u'30', }
_static_135757232006480 = {u'href': u'bootstrap.min.css', u'type': u'text/css', u'rel': u'stylesheet', }
_static_135757154797392 = {u'class': u'list-inline-item', }
_static_135757159740432 = {u'class': u'row', }
_static_135757159742288 = {u'type': u'hidden', u'name': u'came_from', u'value': u'python:view.upgrade_url(site, can_manage=True)', }
_static_135757159720528 = {u'class': u'lead', }
_static_135757154794704 = {u'href': u'https://gitter.im/senaite/Lobby', u'target': u'_blank', u'class': u'btn btn-outline-secondary', u'title': u'Gitter Chat', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n\n')

            # <Static value=<_ast.Dict object at 0x7b7871975510> name=None at 7b7871975590> -> __attrs_135757232036112
            __attrs_135757232036112 = _static_135757232035088
            __previous_i18n_domain_135757232035984 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232037712
            __attrs_135757232037712 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b7871969950> name=None at 7b78719690d0> -> __attrs_135757231988112
            __attrs_135757231988112 = _static_135757231987024

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta charset="utf-8"/>\n    ')

            # <Static value=<_ast.Dict object at 0x7b7871969c50> name=None at 7b7871969c90> -> __attrs_135757231985552
            __attrs_135757231985552 = _static_135757231987792

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport" content="width=device-width, initial-scale=1"/>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232005264
            __attrs_135757232005264 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title>')
            __stream_135757231985360 = []
            __append_135757231985360 = __stream_135757231985360.append
            __append_135757231985360(u'Welcome to SENAITE')
            __msgid_135757231985360 = __re_whitespace(''.join(__stream_135757231985360)).strip()
            if __msgid_135757231985360:
                __append(translate(__msgid_135757231985360, mapping=None, default=__msgid_135757231985360, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</title>\n    ')

            # <Static value=<_ast.Dict object at 0x7b787196e550> name=None at 7b787196e650> -> __attrs_135757232008528
            __attrs_135757232008528 = _static_135757232006480

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet" type="text/css"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232009168
            __default_135757232009168 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css' (16:31)> -> __attr_href
            __token = 647
            try:
                __zt_tmp = __attrs_135757232008528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'bootstrap.min.css', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' />\n    ')

            # <Static value=<_ast.Dict object at 0x7b787196ed90> name=None at 7b787196ecd0> -> __attrs_135757232005200
            __attrs_135757232005200 = _static_135757232008592

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232006224
            __default_135757232006224 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (19:31)> -> __attr_href
            __token = 877
            try:
                __zt_tmp = __attrs_135757232005200
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="icon" type="image/x-icon"/>\n  </head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757236404624
            __attrs_135757236404624 = _static_135757327983760
            __backup_sites_135757232034384 = get('sites', __marker)

            # <Value u'view/sites' (22:26)> -> __value
            __token = 996
            try:
                __zt_tmp = __attrs_135757236404624
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['sites'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78714485d0> name=None at 7b7871448650> -> __attrs_135757226608720
            __attrs_135757226608720 = _static_135757226608080

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container">\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b7871448690> name=None at 7b7871448750> -> __attrs_135757226607312
            __attrs_135757226607312 = _static_135757226608272

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n        ')

            # <Static value=<_ast.Dict object at 0x7b7871448c50> name=None at 7b7871448d10> -> __attrs_135757231993168
            __attrs_135757231993168 = _static_135757226609744

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-6 offset-sm-3">\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786c00e5d0> name=None at 7b786c00e610> -> __attrs_135757138291088
            __attrs_135757138291088 = _static_135757138290128

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="text">\n            ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757132662352
            __attrs_135757132662352 = _static_135757327983760

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1>\n              ')

            # <Static value=<_ast.Dict object at 0x7b786d47ecd0> name=None at 7b786d47ec50> -> __attrs_135757159720016
            __attrs_135757159720016 = _static_135757159722192

            # <img ... (0:0)
            # --------------------------------------------------------
            __append(u'<img')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159719120
            __default_135757159719120 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg' (33:39)> -> __attr_src
            __token = 1262
            try:
                __zt_tmp = __attrs_135757159720016
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'senaite-logo.png', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u' height="30" />\n              ')

            # <Static value=<_ast.Dict object at 0x7b786d47e650> name=None at 7b786d47e610> -> __attrs_135757159720720
            __attrs_135757159720720 = _static_135757159720528

            # <small ... (0:0)
            # --------------------------------------------------------
            __append(u'<small class="lead">Enterprise Open Source Laboratory System</small>\n            </h1>\n            ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159720912
            __attrs_135757159720912 = _static_135757327983760

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\n\n            ')

            # <Static value=<_ast.Dict object at 0x7b786d47e990> name=None at 7b786d47e890> -> __attrs_135757226768592
            __attrs_135757226768592 = _static_135757159721360

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-group">\n              ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226767056
            __attrs_135757226767056 = _static_135757327983760

            # <Value u'sites' (39:40)> -> __condition
            __token = 1541
            try:
                __zt_tmp = __attrs_135757226767056
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226769424
                __attrs_135757226769424 = _static_135757327983760

                # <Value u'python:len(sites) == 1' (40:40)> -> __condition
                __token = 1589
                try:
                    __zt_tmp = __attrs_135757226769424
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'len(sites) == 1', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226770256
                    __attrs_135757226770256 = _static_135757327983760
                    __backup_site_135757138291984 = get('site', __marker)

                    # <Value u'sites' (41:40)> -> __iterator
                    __token = 1654
                    try:
                        __zt_tmp = __attrs_135757226770256
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757226770128, ) = getitem('repeat')(u'site', __iterator)
                    econtext['site'] = None
                    for __item in __iterator:
                        econtext['site'] = __item

                        # <tal ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<tal>\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b787145eed0> name=None at 7b787145ee10> -> __attrs_135757226697552
                        __attrs_135757226697552 = _static_135757226700496

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="list-group-item">\n                      ')

                        # <Static value=<_ast.Dict object at 0x7b787145e610> name=None at 7b787145e750> -> __attrs_135757226700560
                        __attrs_135757226700560 = _static_135757226698256

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="prominent">\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b787145ee90> name=None at 7b787145e990> -> __attrs_135757226656656
                        __attrs_135757226656656 = _static_135757226700432

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757231978128
                        __default_135757231978128 = _DEFAULT_MARKER

                        # <Substitution u'site/absolute_url' (46:47)> -> __attr_href
                        __token = 1908
                        try:
                            __zt_tmp = __attrs_135757226656656
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('path', u'site/absolute_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u' class="btn btn-outline-secondary btn-sm"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226656016
                        __default_135757226656016 = _DEFAULT_MARKER

                        # <Translate msgid=None node=<_ast.Str object at 0x7b7871454950> at 7b78714540d0> -> __attr_title
                        __attr_title = u'Go to your instance'
                        __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>\n                          ')

                        # <Static value=<_ast.Dict object at 0x7b7871454750> name=None at 7b7871454290> -> __attrs_135757226658704
                        __attrs_135757226658704 = _static_135757226657616

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226658896
                        __default_135757226658896 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (51:50)> -> __attr_src
                        __token = 2174
                        try:
                            __zt_tmp = __attrs_135757226658704
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))
                        __append(u' height="16" />\n                          ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226656336
                        __attrs_135757226656336 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                        __stream_135757226659536 = []
                        __append_135757226659536 = __stream_135757226659536.append
                        __append_135757226659536(u'View your SENAITE site')
                        __msgid_135757226659536 = __re_whitespace(''.join(__stream_135757226659536)).strip()
                        if __msgid_135757226659536:
                            __append(translate(__msgid_135757226659536, mapping=None, default=__msgid_135757226659536, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\n                        </a>\n                      </span>\n                      ')

                        # <Static value=<_ast.Dict object at 0x7b7871454710> name=None at 7b7871454fd0> -> __attrs_135757226659280
                        __attrs_135757226659280 = _static_135757226657552

                        # <Value u'python:view.outdated(site)' (56:41)> -> __condition
                        __token = 2488
                        try:
                            __zt_tmp = __attrs_135757226659280
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'view.outdated(site)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="upgrade-warning">\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226770512
                            __attrs_135757226770512 = _static_135757327983760

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_135757226772816 = []
                            __append_135757226772816 = __stream_135757226772816.append
                            __append_135757226772816(u'\n                          This site configuration is outdated and needs to be\n                          upgraded:')
                            __msgid_135757226772816 = __re_whitespace(''.join(__stream_135757226772816)).strip()
                            if __msgid_135757226772816:
                                __append(translate(__msgid_135757226772816, mapping=None, default=__msgid_135757226772816, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b7871470a10> name=None at 7b7871470a50> -> __attrs_135757226772368
                            __attrs_135757226772368 = _static_135757226773008

                            # <form ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<form')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226772176
                            __default_135757226772176 = _DEFAULT_MARKER

                            # <Substitution u'python:view.upgrade_url(site)' (63:53)> -> __attr_action
                            __token = 2878
                            try:
                                __zt_tmp = __attrs_135757226772368
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_action = _static_135757244280656('python', u'view.upgrade_url(site)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_action is not None):
                                __append((u' action="%s"' % __attr_action))
                            __append(u' style="display: inline;" method="get">\n                          ')

                            # <Static value=<_ast.Dict object at 0x7b7871470ed0> name=None at 7b7871470290> -> __attrs_135757226825360
                            __attrs_135757226825360 = _static_135757226774224

                            # <Value u'not:view/can_manage' (64:48)> -> __condition
                            __token = 2958
                            try:
                                __zt_tmp = __attrs_135757226825360
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('not', u'view/can_manage', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input type="hidden" name="came_from"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226824528
                                __default_135757226824528 = _DEFAULT_MARKER

                                # <Substitution u'python:view.upgrade_url(site, can_manage=True)' (66:54)> -> __attr_value
                                __token = 3096
                                try:
                                    __zt_tmp = __attrs_135757226825360
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'view.upgrade_url(site, can_manage=True)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u'/>')
                            __append(u'\n                          ')

                            # <Static value=<_ast.Dict object at 0x7b787147dc90> name=None at 7b787147d750> -> __attrs_135757159726672
                            __attrs_135757159726672 = _static_135757226826896

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="submit" class="plone-btn-secondary"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226826704
                            __default_135757226826704 = _DEFAULT_MARKER

                            # <Translate msgid=u'label_upgrade_hellip' node=<_ast.Str object at 0x7b787147d190> at 7b787147d490> -> __attr_value
                            __attr_value = u'Upgrade&hellip;'
                            __attr_value = translate(u'label_upgrade_hellip', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))
                            __append(u' />\n                        </form>\n                      </div>')
                        __append(u'\n                    </li>\n                  </tal>')
                        ____index_135757226770128 -= 1
                        if (____index_135757226770128 > 0):
                            __append('\n                  ')
                    if (__backup_site_135757138291984 is __marker):
                        del econtext['site']
                    else:
                        econtext['site'] = __backup_site_135757138291984
                    __append(u'\n                ')
                __append(u'\n\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226766864
                __attrs_135757226766864 = _static_135757327983760

                # <Value u'python:len(sites) > 1' (77:41)> -> __condition
                __token = 3570
                try:
                    __zt_tmp = __attrs_135757226766864
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'len(sites) > 1', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b7871470490> name=None at 7b7871470d90> -> __attrs_135757159725392
                    __attrs_135757159725392 = _static_135757226771600

                    # <h2 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h2 id="multiple-sites">')
                    __stream_135757226774288 = []
                    __append_135757226774288 = __stream_135757226774288.append
                    __append_135757226774288(u' You have multiple SENAITE sites:')
                    __msgid_135757226774288 = __re_whitespace(''.join(__stream_135757226774288)).strip()
                    if __msgid_135757226774288:
                        __append(translate(__msgid_135757226774288, mapping=None, default=__msgid_135757226774288, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h2>\n                  ')

                    # <Static value=<_ast.Dict object at 0x7b786d47fb50> name=None at 7b786d47f990> -> __attrs_135757159726736
                    __attrs_135757159726736 = _static_135757159725904

                    # <ul ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<ul class="list-group">\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b786d47f1d0> name=None at 7b786d47f210> -> __attrs_135757159726928
                    __attrs_135757159726928 = _static_135757159723472
                    __backup_site_135757226769168 = get('site', __marker)

                    # <Value u'sites' (80:65)> -> __iterator
                    __token = 3803
                    try:
                        __zt_tmp = __attrs_135757159726928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757159726288, ) = getitem('repeat')(u'site', __iterator)
                    econtext['site'] = None
                    for __item in __iterator:
                        econtext['site'] = __item

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="list-group-item">\n                      ')

                        # <Static value=<_ast.Dict object at 0x7b786d480050> name=None at 7b786d480410> -> __attrs_135757159728464
                        __attrs_135757159728464 = _static_135757159727184

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="prominent">\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b786d480ad0> name=None at 7b786d480b10> -> __attrs_135757159728912
                        __attrs_135757159728912 = _static_135757159729872

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159727248
                        __default_135757159727248 = _DEFAULT_MARKER

                        # <Substitution u'site/absolute_url' (83:48)> -> __attr_href
                        __token = 3942
                        try:
                            __zt_tmp = __attrs_135757159728912
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('path', u'site/absolute_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u' class="btn btn-outline-secondary btn-sm"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159729680
                        __default_135757159729680 = _DEFAULT_MARKER

                        # <Substitution u'site/Title' (84:38)> -> __attr_title
                        __token = 3999
                        try:
                            __zt_tmp = __attrs_135757159728912
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('path', u'site/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>\n                          ')

                        # <Static value=<_ast.Dict object at 0x7b786d480d50> name=None at 7b786d480c50> -> __attrs_135757226746640
                        __attrs_135757226746640 = _static_135757159730512

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226748112
                        __default_135757226748112 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (88:51)> -> __attr_src
                        __token = 4225
                        try:
                            __zt_tmp = __attrs_135757226746640
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_src = __quote(__attr_src, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
                        if (__attr_src is not None):
                            __append((u' src="%s"' % __attr_src))
                        __append(u' height="16" />\n                          ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226746192
                        __attrs_135757226746192 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226747728
                        __default_135757226747728 = _DEFAULT_MARKER

                        # <Value u'site/Title' (89:45)> -> __cache_135757226747536
                        __token = 4353
                        try:
                            __zt_tmp = __attrs_135757226746192
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757226747536 = _static_135757244280656('path', u'site/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'site/Title' (89:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787146a610> -> __condition
                        __expression = __cache_135757226747536

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757226747536
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n                          ')

                        # <Static value=<_ast.Dict object at 0x7b787146a190> name=None at 7b787146ac50> -> __attrs_135757132503824
                        __attrs_135757132503824 = _static_135757226746256

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="small">')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226749840
                        __default_135757226749840 = _DEFAULT_MARKER

                        # <Value u'string: (${site/getId})' (90:59)> -> __cache_135757226748176
                        __token = 4432
                        try:
                            __zt_tmp = __attrs_135757132503824
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757226748176 = _static_135757244280656('string', u' (${site/getId})', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'string: (${site/getId})' (90:59)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b787146ae50> -> __condition
                        __expression = __cache_135757226748176

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757226748176
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n                        </a>\n                      </span>\n                      ')

                        # <Static value=<_ast.Dict object at 0x7b786d480b90> name=None at 7b786d4804d0> -> __attrs_135757132503568
                        __attrs_135757132503568 = _static_135757159730064

                        # <Value u'python:view.outdated(site)' (94:42)> -> __condition
                        __token = 4617
                        try:
                            __zt_tmp = __attrs_135757132503568
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'view.outdated(site)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="upgrade-warning">\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159739792
                            __attrs_135757159739792 = _static_135757327983760

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span>')
                            __stream_135757159742864 = []
                            __append_135757159742864 = __stream_135757159742864.append
                            __append_135757159742864(u'\n                          This site configuration is outdated and\n                          needs to be upgraded:\n                        ')
                            __msgid_135757159742864 = __re_whitespace(''.join(__stream_135757159742864)).strip()
                            if __msgid_135757159742864:
                                __append(translate(__msgid_135757159742864, mapping=None, default=__msgid_135757159742864, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b786d4837d0> name=None at 7b786d483ad0> -> __attrs_135757159739664
                            __attrs_135757159739664 = _static_135757159741392

                            # <form ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<form')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159739472
                            __default_135757159739472 = _DEFAULT_MARKER

                            # <Substitution u'python:view.upgrade_url(site)' (102:53)> -> __attr_action
                            __token = 5032
                            try:
                                __zt_tmp = __attrs_135757159739664
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_action = _static_135757244280656('python', u'view.upgrade_url(site)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_action is not None):
                                __append((u' action="%s"' % __attr_action))
                            __append(u' style="display: inline;" method="get">\n                          ')

                            # <Static value=<_ast.Dict object at 0x7b786d483b50> name=None at 7b786d483150> -> __attrs_135757235454864
                            __attrs_135757235454864 = _static_135757159742288

                            # <Value u'not:view/can_manage' (103:48)> -> __condition
                            __token = 5112
                            try:
                                __zt_tmp = __attrs_135757235454864
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('not', u'view/can_manage', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input type="hidden" name="came_from"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235454608
                                __default_135757235454608 = _DEFAULT_MARKER

                                # <Substitution u'python:view.upgrade_url(site, can_manage=True)' (105:55)> -> __attr_value
                                __token = 5252
                                try:
                                    __zt_tmp = __attrs_135757235454864
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('python', u'view.upgrade_url(site, can_manage=True)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u'/>')
                            __append(u'\n                          ')

                            # <Static value=<_ast.Dict object at 0x7b7871cb85d0> name=None at 7b7871cb8510> -> __attrs_135757235456848
                            __attrs_135757235456848 = _static_135757235455440

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="submit" class="btn btn-secondary"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235456592
                            __default_135757235456592 = _DEFAULT_MARKER

                            # <Translate msgid=u'label_upgrade_hellip' node=<_ast.Str object at 0x7b7871cb8990> at 7b7871cb89d0> -> __attr_value
                            __attr_value = u'Upgrade&hellip;'
                            __attr_value = translate(u'label_upgrade_hellip', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))
                            __append(u' />\n                        </form>\n\n                      </div>')
                        __append(u'\n                    </li>')
                        ____index_135757159726288 -= 1
                        if (____index_135757159726288 > 0):
                            __append('\n                    ')
                    if (__backup_site_135757226769168 is __marker):
                        del econtext['site']
                    else:
                        econtext['site'] = __backup_site_135757226769168
                    __append(u'\n                  </ul>\n                ')
                __append(u'\n\n              ')
            __append(u'\n\n              ')

            # <Static value=<_ast.Dict object at 0x7b787146f450> name=None at 7b787146f710> -> __attrs_135757159724048
            __attrs_135757159724048 = _static_135757226767440

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-group-item">\n                <!-- No SENAITE site added yet -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235457104
            __attrs_135757235457104 = _static_135757327983760

            # <Value u'not:sites' (121:55)> -> __condition
            __token = 5864
            try:
                __zt_tmp = __attrs_135757235457104
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_135757159741008 = []
                __append_135757159741008 = __stream_135757159741008.append
                __append_135757159741008(u'\n                  Your SENAITE site has not been added yet:\n                ')
                __msgid_135757159741008 = __re_whitespace(''.join(__stream_135757159741008)).strip()
                if __msgid_135757159741008:
                    __append(translate(__msgid_135757159741008, mapping=None, default=__msgid_135757159741008, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>')
            __append(u'\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757235457872
            __attrs_135757235457872 = _static_135757327983760

            # <Value u'sites' (124:55)> -> __condition
            __token = 6015
            try:
                __zt_tmp = __attrs_135757235457872
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'sites', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_135757235457488 = []
                __append_135757235457488 = __stream_135757235457488.append
                __append_135757235457488(u'\n                  You can add another SENAITE site:\n                ')
                __msgid_135757235457488 = __re_whitespace(''.join(__stream_135757235457488)).strip()
                if __msgid_135757235457488:
                    __append(translate(__msgid_135757235457488, mapping=None, default=__msgid_135757235457488, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>')
            __append(u'\n                ')

            # <Static value=<_ast.Dict object at 0x7b7871c8d190> name=None at 7b7871c8d1d0> -> __attrs_135757235279696
            __attrs_135757235279696 = _static_135757235278224
            __backup_site_number_135757132664400 = get('site_number', __marker)

            # <Value u"python: '' if not sites else len(sites) + 1" (130:46)> -> __value
            __token = 6255
            try:
                __zt_tmp = __attrs_135757235279696
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u" '' if not sites else len(sites) + 1", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['site_number'] = __value

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form id="add-plone-site" method="get"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235279376
            __default_135757235279376 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/@@senaite-addsite' (131:45)> -> __attr_action
            __token = 6345
            try:
                __zt_tmp = __attrs_135757235279696
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_135757244280656('string', u'${context/absolute_url}/@@senaite-addsite', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u'>\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7871c8da50> name=None at 7b7871c8da90> -> __attrs_135757235281744
            __attrs_135757235281744 = _static_135757235280464

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="site_id"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235281488
            __default_135757235281488 = _DEFAULT_MARKER

            # <Interpolation value=<Substitution u'senaite${site_number}' (132:61)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b7871c8de10> -> __attr_value
            __token = 6457
            __token = 6466
            try:
                __zt_tmp = __attrs_135757235281744
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('path', u'site_number', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            __attr_value = ('%s%s' % (u'senaite', (__attr_value if (__attr_value is not None) else ''), ))
            if (__attr_value is None):
                pass
            else:
                if (__attr_value is _DEFAULT_MARKER):
                    __attr_value = None
                else:
                    __tt = type(__attr_value)
                    if ((__tt is int) or (__tt is float) or (__tt is long)):
                        __attr_value = unicode(__attr_value)
                    else:
                        if (__tt is str):
                            __attr_value = decode(__attr_value)
                        else:
                            if (__tt is not unicode):
                                try:
                                    __attr_value = __attr_value.__html__
                                except get('AttributeError', AttributeError):
                                    __converted = convert(__attr_value)
                                    __attr_value = (unicode(__attr_value) if (__attr_value is __converted) else __converted)
                                else:
                                    __attr_value = __attr_value()
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7871cc3050> name=None at 7b7871cc3110> -> __attrs_135757235500496
            __attrs_135757235500496 = _static_135757235499088

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="site_title" value="SENAITE LIMS" />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7871cc3750> name=None at 7b7871cc3690> -> __attrs_135757235502288
            __attrs_135757235502288 = _static_135757235500880

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="submit" class="btn btn-success"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235502032
            __default_135757235502032 = _DEFAULT_MARKER

            # <Translate msgid=None node=<_ast.Str object at 0x7b7871cc3b10> at 7b7871cc3b50> -> __attr_value
            __attr_value = u'Create a new SENAITE site'
            __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7871cc3e50> name=None at 7b7871cc3e10> -> __attrs_135757154775696
            __attrs_135757154775696 = _static_135757235502672

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154775376
            __default_135757154775376 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1' (140:42)> -> __attr_href
            __token = 6900
            try:
                __zt_tmp = __attrs_135757154775696
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${context/absolute_url}/@@senaite-addsite?site_id=senaite${site_number}&site_title=SENAITE LIMS&advanced=1', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_135757235502480 = []
            __append_135757235502480 = __stream_135757235502480.append
            __append_135757235502480(u'\n                    Advanced\n                  ')
            __msgid_135757235502480 = __re_whitespace(''.join(__stream_135757235502480)).strip()
            if __msgid_135757235502480:
                __append(translate(__msgid_135757235502480, mapping=None, default=__msgid_135757235502480, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\n                </form>')
            if (__backup_site_number_135757132664400 is __marker):
                del econtext['site_number']
            else:
                econtext['site_number'] = __backup_site_number_135757132664400
            __append(u'\n              </li>\n\n            </ul>\n          </div>\n\n          <!-- Community Links -->\n          ')

            # <Static value=<_ast.Dict object at 0x7b786d483410> name=None at 7b786d47f350> -> __attrs_135757154776016
            __attrs_135757154776016 = _static_135757159740432

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cfc76d0> name=None at 7b786cfc7650> -> __attrs_135757226749264
            __attrs_135757226749264 = _static_135757154776784

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138338064
            __attrs_135757138338064 = _static_135757327983760

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\n              ')

            # <Static value=<_ast.Dict object at 0x7b786cfc77d0> name=None at 7b786cfc7790> -> __attrs_135757154777616
            __attrs_135757154777616 = _static_135757154777040

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="lead">')
            __stream_135757226659344 = []
            __append_135757226659344 = __stream_135757226659344.append
            __append_135757226659344(u'\n                Meet the community, browse the code and get support on\n              ')
            __msgid_135757226659344 = __re_whitespace(''.join(__stream_135757226659344)).strip()
            if __msgid_135757226659344:
                __append(translate(__msgid_135757226659344, mapping=None, default=__msgid_135757226659344, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n              ')

            # <Static value=<_ast.Dict object at 0x7b786cfc7bd0> name=None at 7b786cfc7b90> -> __attrs_135757154778704
            __attrs_135757154778704 = _static_135757154778064

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-inline flex-column flex-sm-row">\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfca110> name=None at 7b786cfca0d0> -> __attrs_135757154788240
            __attrs_135757154788240 = _static_135757154787600

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7b786cfca610> name=None at 7b786cfca590> -> __attrs_135757154790416
            __attrs_135757154790416 = _static_135757154788880

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://www.senaite.com" title="Website" target="_blank">Website</a></li>\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfca4d0> name=None at 7b786cfca090> -> __attrs_135757154791120
            __attrs_135757154791120 = _static_135757154788560

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7b786cfcb150> name=None at 7b786cfcb110> -> __attrs_135757154793360
            __attrs_135757154793360 = _static_135757154791760

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://community.senaite.com" title="SENAITE community" target="_blank">Community Site</a></li>\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfcb0d0> name=None at 7b786cfc7fd0> -> __attrs_135757154794128
            __attrs_135757154794128 = _static_135757154791632

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7b786cfcbcd0> name=None at 7b786cfcbc90> -> __attrs_135757154796368
            __attrs_135757154796368 = _static_135757154794704

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://gitter.im/senaite/Lobby" title="Gitter Chat" target="_blank">Gitter Chat</a></li>\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfcaf90> name=None at 7b786cfcafd0> -> __attrs_135757154797072
            __attrs_135757154797072 = _static_135757154791312

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7b786cfcc890> name=None at 7b786cfcc810> -> __attrs_135757154799248
            __attrs_135757154799248 = _static_135757154797712

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://github.com/senaite" title="GitHub" target="_blank">GitHub</a></li>\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfcc750> name=None at 7b786cfcc6d0> -> __attrs_135757154832784
            __attrs_135757154832784 = _static_135757154797392

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li class="list-inline-item">')

            # <Static value=<_ast.Dict object at 0x7b786cfd5410> name=None at 7b786cfd5390> -> __attrs_135757154834960
            __attrs_135757154834960 = _static_135757154833424

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="btn btn-outline-secondary" href="https://twitter.com/senaitelims" title="Twitter" target="_blank">Twitter</a></li>\n              </ul>\n            </div>\n          </div>\n\n        </div>\n      </div>\n\n    </div>\n  </body>')
            if (__backup_sites_135757232034384 is __marker):
                del econtext['sites']
            else:
                econtext['sites'] = __backup_sites_135757232034384
            __append(u'\n</html>')
            __i18n_domain = __previous_i18n_domain_135757232035984
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }