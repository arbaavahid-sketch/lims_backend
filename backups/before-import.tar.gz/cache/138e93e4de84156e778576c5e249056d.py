# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/sections.pt'

__tokens = {197: (u'view/portal_tabs', 5, 26), 233: (u'portal_tabs', 6, 17), 577: (u'python:view.selected_portal_tab', 19, 33), 650: (u'view/portal_tabs', 21, 36), 733: (u"python:action['id'] == selected_tab", 23, 33), 798: (u'action/available|nothing', 24, 27), 900: (u'action/url', 26, 34), 947: (u" python:selected and 'active nav-link' or 'nav-link", 27, 34), 1035: (u'e action/description|action/tit', 28, 33), 1103: (u'action/title', 29, 31)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133838686049744 = {u'href': u'#', u'class': u'nav-link', u'title': u'action/description|action/title', }
_static_133838700751184 = {u'class': u'nav-item', }
_static_133838700751696 = {u'class': u'dropdown-menu dropdown-menu-right', }
_static_133838794967184 = __compile_zt_expr
_static_133838700750800 = {u'class': u'fas fa-th', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838698707600 = {u'data-toggle': u'dropdown', u'href': u'#', u'class': u'nav-link dropdown-toggle', u'aria-expanded': u'false', u'aria-haspopup': u'true', }
_static_133838698708752 = {u'class': u'dropdown', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681268688
            __attrs_133838681268688 = _static_133838878659728
            __backup_portal_tabs_133838698784528 = get('portal_tabs', __marker)

            # <Value u'view/portal_tabs' (5:26)> -> __value
            __token = 197
            try:
                __zt_tmp = __attrs_133838681268688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'view/portal_tabs', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['portal_tabs'] = __value

            # <Value u'portal_tabs' (6:17)> -> __condition
            __token = 233
            try:
                __zt_tmp = __attrs_133838681268688
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'portal_tabs', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_133838681270288 = __i18n_domain
                __i18n_domain = u'plone'
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9c017ff10> name=None at 79b9c017fad0> -> __attrs_133838698705872
                __attrs_133838698705872 = _static_133838698708752

                # <nav ... (0:0)
                # --------------------------------------------------------
                __append(u'<nav class="dropdown">\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9c017fa90> name=None at 79b9c017f290> -> __attrs_133838698707856
                __attrs_133838698707856 = _static_133838698707600

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a href="#"        class="nav-link dropdown-toggle"        data-toggle="dropdown"        aria-haspopup="true"        aria-expanded="false">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9c03727d0> name=None at 79b9c0372350> -> __attrs_133838700751376
                __attrs_133838700751376 = _static_133838700750800

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-th"></i>\r\n    </a>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9c0372b50> name=None at 79b9c0372a50> -> __attrs_133838700751312
                __attrs_133838700751312 = _static_133838700751696
                __backup_selected_tab_133838698711376 = get('selected_tab', __marker)

                # <Value u'python:view.selected_portal_tab' (19:33)> -> __value
                __token = 577
                try:
                    __zt_tmp = __attrs_133838700751312
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u'view.selected_portal_tab', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['selected_tab'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="dropdown-menu dropdown-menu-right">\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838685974864
                __attrs_133838685974864 = _static_133838878659728
                __backup_action_133838698696848 = get('action', __marker)

                # <Value u'view/portal_tabs' (21:36)> -> __iterator
                __token = 650
                try:
                    __zt_tmp = __attrs_133838685974864
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'view/portal_tabs', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838700749840, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item
                    __append(u'\r\n        ')

                    # <Static value=<_ast.Dict object at 0x79b9c0372950> name=None at 79b9c0372510> -> __attrs_133838686052304
                    __attrs_133838686052304 = _static_133838700751184
                    __backup_selected_133838705508752 = get('selected', __marker)

                    # <Value u"python:action['id'] == selected_tab" (23:33)> -> __value
                    __token = 733
                    try:
                        __zt_tmp = __attrs_133838686052304
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u"action['id'] == selected_tab", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['selected'] = __value

                    # <Value u'action/available|nothing' (24:27)> -> __condition
                    __token = 798
                    try:
                        __zt_tmp = __attrs_133838686052304
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('path', u'action/available|nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="nav-item">\r\n          ')

                        # <Static value=<_ast.Dict object at 0x79b9bf56d5d0> name=None at 79b9bf56d950> -> __attrs_133838686051792
                        __attrs_133838686051792 = _static_133838686049744

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686050128
                        __default_133838686050128 = _DEFAULT_MARKER

                        # <Substitution u'action/url' (26:34)> -> __attr_href
                        __token = 900
                        try:
                            __zt_tmp = __attrs_133838686051792
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_133838794967184('path', u'action/url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686050320
                        __default_133838686050320 = _DEFAULT_MARKER

                        # <Substitution u"python:selected and 'active nav-link' or 'nav-link'" (27:34)> -> __attr_class
                        __token = 947
                        try:
                            __zt_tmp = __attrs_133838686051792
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_133838794967184('python', u"selected and 'active nav-link' or 'nav-link'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-link', _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686051024
                        __default_133838686051024 = _DEFAULT_MARKER

                        # <Substitution u'action/description|action/title' (28:33)> -> __attr_title
                        __token = 1035
                        try:
                            __zt_tmp = __attrs_133838686051792
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_133838794967184('path', u'action/description|action/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>\r\n            ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681233104
                        __attrs_133838681233104 = _static_133838878659728

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686051152
                        __default_133838686051152 = _DEFAULT_MARKER

                        # <Value u'action/title' (29:31)> -> __cache_133838686048848
                        __token = 1103
                        try:
                            __zt_tmp = __attrs_133838681233104
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838686048848 = _static_133838794967184('path', u'action/title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'action/title' (29:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf56d650> -> __condition
                        __expression = __cache_133838686048848

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133838686048848
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n          </a>\r\n        </li>')
                    if (__backup_selected_133838705508752 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_133838705508752
                    __append(u'\r\n      ')
                    ____index_133838700749840 -= 1
                    if (____index_133838700749840 > 0):
                        __append('')
                if (__backup_action_133838698696848 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_133838698696848
                __append(u'\r\n    </ul>')
                if (__backup_selected_tab_133838698711376 is __marker):
                    del econtext['selected_tab']
                else:
                    econtext['selected_tab'] = __backup_selected_tab_133838698711376
                __append(u'\r\n  </nav>\r\n\r\n')
                __i18n_domain = __previous_i18n_domain_133838681270288
            if (__backup_portal_tabs_133838698784528 is __marker):
                del econtext['portal_tabs']
            else:
                econtext['portal_tabs'] = __backup_portal_tabs_133838698784528
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }