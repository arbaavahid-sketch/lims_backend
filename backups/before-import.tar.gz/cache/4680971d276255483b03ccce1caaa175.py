# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/content/../browser/setup/templates/email_body_sample_publication.pt'

__tokens = {40: (u'python:context.laboratory', 2, 25), 309: (u'options/client_name|default', 11, 53)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402356200592 = {}
_static_140402272508432 = __C2ZContextWrapper
_static_140402272508048 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099034640
            __attrs_140402099034640 = _static_140402356200592
            __backup_laboratory_140402098940240 = get('laboratory', __marker)

            # <Value u'python:context.laboratory' (2:25)> -> __value
            __token = 40
            try:
                __zt_tmp = __attrs_140402099034640
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'context.laboratory', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['laboratory'] = __value
            __previous_i18n_domain_140402099034832 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099035664
            __attrs_140402099035664 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>')
            __stream_140402099035344 = []
            __append_140402099035344 = __stream_140402099035344.append
            __append_140402099035344(u'\r\n    Thank you for your analysis request.\r\n  ')
            __msgid_140402099035344 = __re_whitespace(''.join(__stream_140402099035344)).strip()
            if __msgid_140402099035344:
                __append(translate(__msgid_140402099035344, mapping=None, default=__msgid_140402099035344, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099093776
            __attrs_140402099093776 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>')
            __stream_140402101216032_client_name = ''
            __stream_140402099036048 = []
            __append_140402099036048 = __stream_140402099036048.append
            __append_140402099036048(u'\r\n    Please find attached the analysis result(s) for\r\n    ')
            __stream_140402101216032_client_name = []
            __append_140402101216032_client_name = __stream_140402101216032_client_name.append

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099094992
            __attrs_140402099094992 = _static_140402356200592

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099094672
            __default_140402099094672 = _DEFAULT_MARKER

            # <Value u'options/client_name|default' (11:53)> -> __cache_140402099094352
            __token = 309
            try:
                __zt_tmp = __attrs_140402099094992
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402099094352 = _static_140402272508048('path', u'options/client_name|default', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

            # <BinOp left=<Value u'options/client_name|default' (11:53)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e93e03d0> -> __condition
            __expression = __cache_140402099094352

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append_140402101216032_client_name(u'$client_name')
            else:
                __content = __cache_140402099094352
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append_140402101216032_client_name(__content)
            __append_140402099036048(u'${client_name}')
            __stream_140402101216032_client_name = ''.join(__stream_140402101216032_client_name)
            __append_140402099036048(u'\r\n  ')
            __msgid_140402099036048 = __re_whitespace(''.join(__stream_140402099036048)).strip()
            if __msgid_140402099036048:
                __append(translate(__msgid_140402099036048, mapping={u'client_name': __stream_140402101216032_client_name, }, default=__msgid_140402099036048, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099095504
            __attrs_140402099095504 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>')
            __stream_140402099094096 = []
            __append_140402099094096 = __stream_140402099094096.append
            __append_140402099094096(u'\r\n    This report was sent to the following contacts:\r\n  ')
            __msgid_140402099094096 = __re_whitespace(''.join(__stream_140402099094096)).strip()
            if __msgid_140402099094096:
                __append(translate(__msgid_140402099094096, mapping=None, default=__msgid_140402099094096, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099096080
            __attrs_140402099096080 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>$recipients</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099096720
            __attrs_140402099096720 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>')
            __stream_140402099096400 = []
            __append_140402099096400 = __stream_140402099096400.append
            __append_140402099096400(u'\r\n    With best regards\r\n  ')
            __msgid_140402099096400 = __re_whitespace(''.join(__stream_140402099096400)).strip()
            if __msgid_140402099096400:
                __append(translate(__msgid_140402099096400, mapping=None, default=__msgid_140402099096400, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099097296
            __attrs_140402099097296 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>$lab_name</p>\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099102096
            __attrs_140402099102096 = _static_140402356200592

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p>')
            __stream_140402099101776 = []
            __append_140402099101776 = __stream_140402099101776.append
            __append_140402099101776(u'\r\n    *** This is an automatically generated email, please do not reply to this message. ***\r\n  ')
            __msgid_140402099101776 = __re_whitespace(''.join(__stream_140402099101776)).strip()
            if __msgid_140402099101776:
                __append(translate(__msgid_140402099101776, mapping=None, default=__msgid_140402099101776, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</p>\r\n\r\n')
            __i18n_domain = __previous_i18n_domain_140402099034832
            if (__backup_laboratory_140402098940240 is __marker):
                del econtext['laboratory']
            else:
                econtext['laboratory'] = __backup_laboratory_140402098940240
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }