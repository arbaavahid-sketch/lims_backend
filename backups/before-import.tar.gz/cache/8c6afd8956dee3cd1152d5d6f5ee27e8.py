# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.Archetypes-1.16.6-py2.7.egg/Products/Archetypes/skins/archetypes/widgets/selection.pt'

__tokens = {1509: (u'python:field.Vocabulary(context)', 38, 42), 1583: (u' python:len(vocab', 39, 40), 1651: (u'w context/@@at_selection_widg', 40, 48), 1727: (u'on python:selectionview.getSelected(vocab, val', 41, 43), 1817: (u'mat python:widget.fo', 42, 39), 1882: (u"python:(vlen &lt; 4 and format == 'flex') or (format == 'radi", 44, 37), 1989: (u'fieldName', 45, 41), 2163: (u'python:widget.Label(here)', 50, 43), 2334: (u'field/required', 53, 45), 2581: (u'python:widget.Description(here)', 57, 53), 2727: (u'string:${fieldName}_help', 59, 48), 2666: (u'description', 58, 52), 2937: (u'vocab', 65, 45), 3100: (u'fieldName', 69, 52), 3160: (u' string:${fieldName}_${repeat/item/number', 70, 49), 3257: (u"d python:item in selection and 'checked' or No", 71, 53), 3357: (u'ue i', 72, 50), 3575: (u'string:${fieldName}_${repeat/item/number}', 77, 51), 3446: (u'python:vocab.getValue(item)', 75, 44), 3756: (u"python:(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))", 85, 42), 3983: (u'python:fieldName', 90, 47), 4045: (u'python:widget.Label(here)', 91, 43), 4216: (u'field/required', 94, 45), 4463: (u'python:widget.Description(here)', 98, 53), 4609: (u'string:${fieldName}_help', 100, 48), 4548: (u'description', 99, 52), 4825: (u'fieldName', 106, 49), 4882: (u' fieldNam', 107, 46), 4946: (u'vocab', 109, 49), 5007: (u'item', 110, 54), 5069: (u" python:item in selection and 'selected' or (not selection and not value and 'selected') or  Non", 111, 56), 5213: (u'python:vocab.getValue(item)', 112, 45), 1370: (u'field_macro|context/widgets/field/macros/edit', 35, 30), 1370: (u'field_macro|context/widgets/field/macros/edit', 35, 30), 5531: (u'context/widgets/selection/macros/edit', 127, 30), 5531: (u'context/widgets/selection/macros/edit', 127, 30), 610: (u"python:getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')", 19, 34), 768: (u' context/UID|nothin', 21, 33), 825: (u'kss_class', 22, 34), 866: (u' string:parent-fieldname-$fieldName-$ui', 23, 30), 988: (u'python:field.Vocabulary(context)', 25, 34), 1055: (u' python:accessor(', 26, 33), 1109: (u'y python:context.displayValue(vocab, value, widge', 27, 34), 1247: (u'display', 29, 39), 393: (u'context/@@kss_field_decorator_view', 16, 39), 466: (u' nocall:kssClassesView/getKssClassesInlineEditabl', 17, 37)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756869378576 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757109839888 = u'edit'
_static_135757075221648 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_135757150233168 = {u'checked': u"python:item in selection and 'checked' or None", u'name': u'fieldName', u'value': u'item', u'class': u'noborder blurrable', u'type': u'radio', u'id': u'string:${fieldName}_${repeat/item/number}', }
_static_135757109841296 = {u'id': u'fieldName', }
_static_135757075214480 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_135757071595088 = {u'name': u'fieldName', u'id': u'fieldName', }
_static_135757244280656 = __compile_zt_expr
_static_135756869422352 = {u'class': u'kss_class', u'id': u'string:parent-fieldname-$fieldName-$uid', }
_static_135757071593808 = {u'class': u'formQuestion', u'for': u'python:fieldName', }
_static_135757109875152 = u'edit'
_static_135757244301584 = __C2ZContextWrapper
_static_135756869623440 = {u'class': u'required', u'title': u'Required', }
_static_135757071595984 = {u'for': u'string:${fieldName}_${repeat/item/number}', }
_static_135757327983760 = {}
_static_135757154260752 = {u'selected': u"python:item in selection and 'selected' or (not selection and not value and 'selected') or  None", u'value': u'item', }
_static_135757109841424 = {u'class': u'formQuestion label', }
_static_135757074834640 = {u'class': u'required', u'title': u'Required', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109878736
            __attrs_135757109878736 = _static_135757327983760
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109875024
            __attrs_135757109875024 = _static_135757327983760
            __backup_macroname_135757130356208 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786a4f51d0> name=None at 7b786a4f5a90> -> __value
            __value = _static_135757109875152
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109876560
                __attrs_135757109876560 = _static_135757327983760
                __backup_vocab_135757075872080 = get('vocab', __marker)

                # <Value u'python:field.Vocabulary(context)' (38:42)> -> __value
                __token = 1509
                try:
                    __zt_tmp = __attrs_135757109876560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.Vocabulary(context)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['vocab'] = __value
                __backup_vlen_135757151773136 = get('vlen', __marker)

                # <Value u'python:len(vocab)' (39:40)> -> __value
                __token = 1583
                try:
                    __zt_tmp = __attrs_135757109876560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'len(vocab)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['vlen'] = __value
                __backup_selectionview_135757075201808 = get('selectionview', __marker)

                # <Value u'context/@@at_selection_widget' (40:48)> -> __value
                __token = 1651
                try:
                    __zt_tmp = __attrs_135757109876560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/@@at_selection_widget', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['selectionview'] = __value
                __backup_selection_135757074196560 = get('selection', __marker)

                # <Value u'python:selectionview.getSelected(vocab, value)' (41:43)> -> __value
                __token = 1727
                try:
                    __zt_tmp = __attrs_135757109876560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'selectionview.getSelected(vocab, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['selection'] = __value
                __backup_format_135757075180496 = get('format', __marker)

                # <Value u'python:widget.format' (42:39)> -> __value
                __token = 1817
                try:
                    __zt_tmp = __attrs_135757109876560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.format', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['format'] = __value
                __append(u'\n\n                ')

                # <Static value=<_ast.Dict object at 0x7b786a4ecd90> name=None at 7b786a4ec8d0> -> __attrs_135757109840400
                __attrs_135757109840400 = _static_135757109841296

                # <Value u"python:(vlen < 4 and format == 'flex') or (format == 'radio')" (44:37)> -> __condition
                __token = 1882
                try:
                    __zt_tmp = __attrs_135757109840400
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u"(vlen < 4 and format == 'flex') or (format == 'radio')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109838416
                    __default_135757109838416 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (45:41)> -> __attr_id
                    __token = 1989
                    try:
                        __zt_tmp = __attrs_135757109840400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n\n                    <!-- Radio when the vocab is short < 4 -->\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b786a4ece10> name=None at 7b786a4ec0d0> -> __attrs_135757074836432
                    __attrs_135757074836432 = _static_135757109841424

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="formQuestion label">\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074834320
                    __attrs_135757074834320 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074836240
                    __default_135757074836240 = _DEFAULT_MARKER

                    # <Value u'python:widget.Label(here)' (50:43)> -> __cache_135757074834256
                    __token = 2163
                    try:
                        __zt_tmp = __attrs_135757074834320
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757074834256 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:widget.Label(here)' (50:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786838a950> -> __condition
                    __expression = __cache_135757074834256

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span />')
                    else:
                        __content = __cache_135757074834256
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786838a4d0> name=None at 7b786838a410> -> __attrs_135757075217104
                    __attrs_135757075217104 = _static_135757074834640

                    # <Value u'field/required' (53:45)> -> __condition
                    __token = 2334
                    try:
                        __zt_tmp = __attrs_135757075217104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'field/required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074835984
                        __default_135757074835984 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7b786838aa50> at 7b786838af90> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78683e7090> name=None at 7b78683e7610> -> __attrs_135757075218320
                    __attrs_135757075218320 = _static_135757075214480
                    __backup_description_135757072798352 = get('description', __marker)

                    # <Value u'python:widget.Description(here)' (57:53)> -> __value
                    __token = 2581
                    try:
                        __zt_tmp = __attrs_135757075218320
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'widget.Description(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075215248
                    __default_135757075215248 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_help' (59:48)> -> __attr_id
                    __token = 2727
                    try:
                        __zt_tmp = __attrs_135757075218320
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}_help', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075215184
                    __default_135757075215184 = _DEFAULT_MARKER

                    # <Value u'description' (58:52)> -> __cache_135757075217808
                    __token = 2666
                    try:
                        __zt_tmp = __attrs_135757075218320
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075217808 = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description' (58:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683e7910> -> __condition
                    __expression = __cache_135757075217808

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                          Help\n                        ')
                    else:
                        __content = __cache_135757075217808
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                    if (__backup_description_135757072798352 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_135757072798352
                    __append(u'\n                    </div>\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075218192
                    __attrs_135757075218192 = _static_135757327983760
                    __backup_item_135757109739472 = get('item', __marker)

                    # <Value u'vocab' (65:45)> -> __iterator
                    __token = 2937
                    try:
                        __zt_tmp = __attrs_135757075218192
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757075218064, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item
                        __append(u'\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b786cb72250> name=None at 7b786cb72810> -> __attrs_135757150232848
                        __attrs_135757150232848 = _static_135757150233168

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input class="noborder blurrable" type="radio"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150235792
                        __default_135757150235792 = _DEFAULT_MARKER

                        # <Substitution u'fieldName' (69:52)> -> __attr_name
                        __token = 3100
                        try:
                            __zt_tmp = __attrs_135757150232848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150234576
                        __default_135757150234576 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_${repeat/item/number}' (70:49)> -> __attr_id
                        __token = 3160
                        try:
                            __zt_tmp = __attrs_135757150232848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('string', u'${fieldName}_${repeat/item/number}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150235408
                        __default_135757150235408 = _DEFAULT_MARKER

                        # <Boolean u"python:item in selection and 'checked' or None" (71:53)> -> __attr_checked
                        __token = 3257
                        try:
                            __zt_tmp = __attrs_135757150232848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_checked = _static_135757244280656('python', u"item in selection and 'checked' or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_checked is _DEFAULT_MARKER):
                            __attr_checked = None
                        else:
                            if __attr_checked:
                                __attr_checked = u'checked'
                            else:
                                __attr_checked = None
                        if (__attr_checked is not None):
                            __append((u' checked="%s"' % __attr_checked))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150234000
                        __default_135757150234000 = _DEFAULT_MARKER

                        # <Substitution u'item' (72:50)> -> __attr_value
                        __token = 3357
                        try:
                            __zt_tmp = __attrs_135757150232848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u' />\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78680739d0> name=None at 7b786cb72c10> -> __attrs_135757071595216
                        __attrs_135757071595216 = _static_135757071595984

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071595920
                        __default_135757071595920 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_${repeat/item/number}' (77:51)> -> __attr_for
                        __token = 3575
                        try:
                            __zt_tmp = __attrs_135757071595216
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_135757244280656('string', u'${fieldName}_${repeat/item/number}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150234768
                        __default_135757150234768 = _DEFAULT_MARKER

                        # <Value u'python:vocab.getValue(item)' (75:44)> -> __cache_135757150232720
                        __token = 3446
                        try:
                            __zt_tmp = __attrs_135757071595216
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757150232720 = _static_135757244280656('python', u'vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:vocab.getValue(item)' (75:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cb72490> -> __condition
                        __expression = __cache_135757150232720

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757150232720
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</label>\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071593936
                        __attrs_135757071593936 = _static_135757327983760

                        # <br ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<br />\n\n                    ')
                        ____index_135757075218064 -= 1
                        if (____index_135757075218064 > 0):
                            __append('')
                    if (__backup_item_135757109739472 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_135757109739472
                    __append(u'\n\n                </span>')
                __append(u'\n\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074834064
                __attrs_135757074834064 = _static_135757327983760

                # <Value u"python:(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))" (85:42)> -> __condition
                __token = 3756
                try:
                    __zt_tmp = __attrs_135757074834064
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u"(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n\n                    <!-- Pulldown when longer -->\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b7868073150> name=None at 7b7868073b90> -> __attrs_135757071596816
                    __attrs_135757071596816 = _static_135757071593808

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label class="formQuestion"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071597392
                    __default_135757071597392 = _DEFAULT_MARKER

                    # <Substitution u'python:fieldName' (90:47)> -> __attr_for
                    __token = 3983
                    try:
                        __zt_tmp = __attrs_135757071596816
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869622480
                    __attrs_135756869622480 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869621008
                    __default_135756869621008 = _DEFAULT_MARKER

                    # <Value u'python:widget.Label(here)' (91:43)> -> __cache_135756869622352
                    __token = 4045
                    try:
                        __zt_tmp = __attrs_135756869622480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756869622352 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:widget.Label(here)' (91:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfd5590> -> __condition
                    __expression = __cache_135756869622352

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span />')
                    else:
                        __content = __cache_135756869622352
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b785bfd5e90> name=None at 7b785bfd53d0> -> __attrs_135756869620752
                    __attrs_135756869620752 = _static_135756869623440

                    # <Value u'field/required' (94:45)> -> __condition
                    __token = 4216
                    try:
                        __zt_tmp = __attrs_135756869620752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'field/required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869621584
                        __default_135756869621584 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7b785bfd5b10> at 7b785bfd5990> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78683e8c90> name=None at 7b78683e82d0> -> __attrs_135757075219536
                    __attrs_135757075219536 = _static_135757075221648
                    __backup_description_135757109783376 = get('description', __marker)

                    # <Value u'python:widget.Description(here)' (98:53)> -> __value
                    __token = 4463
                    try:
                        __zt_tmp = __attrs_135757075219536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'widget.Description(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075219024
                    __default_135757075219024 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}_help' (100:48)> -> __attr_id
                    __token = 4609
                    try:
                        __zt_tmp = __attrs_135757075219536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('string', u'${fieldName}_help', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869621776
                    __default_135756869621776 = _DEFAULT_MARKER

                    # <Value u'description' (99:52)> -> __cache_135756869621392
                    __token = 4548
                    try:
                        __zt_tmp = __attrs_135757075219536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756869621392 = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description' (99:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfd5150> -> __condition
                    __expression = __cache_135756869621392

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                          Help\n                        ')
                    else:
                        __content = __cache_135756869621392
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                    if (__backup_description_135757109783376 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_135757109783376
                    __append(u'\n                    </label>\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b7868073650> name=None at 7b7868073710> -> __attrs_135757075219664
                    __attrs_135757075219664 = _static_135757071595088

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075221200
                    __default_135757075221200 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (106:49)> -> __attr_name
                    __token = 4825
                    try:
                        __zt_tmp = __attrs_135757075219664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075222480
                    __default_135757075222480 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (107:46)> -> __attr_id
                    __token = 4882
                    try:
                        __zt_tmp = __attrs_135757075219664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786cf49710> name=None at 7b786cf49f10> -> __attrs_135757154259856
                    __attrs_135757154259856 = _static_135757154260752
                    __backup_item_135757074506960 = get('item', __marker)

                    # <Value u'vocab' (109:49)> -> __iterator
                    __token = 4946
                    try:
                        __zt_tmp = __attrs_135757154259856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757154260560, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154261840
                        __default_135757154261840 = _DEFAULT_MARKER

                        # <Substitution u'item' (110:54)> -> __attr_value
                        __token = 5007
                        try:
                            __zt_tmp = __attrs_135757154259856
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154259664
                        __default_135757154259664 = _DEFAULT_MARKER

                        # <Boolean u"python:item in selection and 'selected' or (not selection and not value and 'selected') or  None" (111:56)> -> __attr_selected
                        __token = 5069
                        try:
                            __zt_tmp = __attrs_135757154259856
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_selected = _static_135757244280656('python', u"item in selection and 'selected' or (not selection and not value and 'selected') or  None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_selected is _DEFAULT_MARKER):
                            __attr_selected = None
                        else:
                            if __attr_selected:
                                __attr_selected = u'selected'
                            else:
                                __attr_selected = None
                        if (__attr_selected is not None):
                            __append((u' selected="%s"' % __attr_selected))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154262544
                        __default_135757154262544 = _DEFAULT_MARKER

                        # <Value u'python:vocab.getValue(item)' (112:45)> -> __cache_135757154260304
                        __token = 5213
                        try:
                            __zt_tmp = __attrs_135757154259856
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757154260304 = _static_135757244280656('python', u'vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:vocab.getValue(item)' (112:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cf49210> -> __condition
                        __expression = __cache_135757154260304

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757154260304
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>')
                        ____index_135757154260560 -= 1
                        if (____index_135757154260560 > 0):
                            __append('\n                        ')
                    if (__backup_item_135757074506960 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_135757074506960
                    __append(u'\n\n                    </select>\n\n                ')
                __append(u'\n\n            ')
                if (__backup_format_135757075180496 is __marker):
                    del econtext['format']
                else:
                    econtext['format'] = __backup_format_135757075180496
                if (__backup_selection_135757074196560 is __marker):
                    del econtext['selection']
                else:
                    econtext['selection'] = __backup_selection_135757074196560
                if (__backup_selectionview_135757075201808 is __marker):
                    del econtext['selectionview']
                else:
                    econtext['selectionview'] = __backup_selectionview_135757075201808
                if (__backup_vlen_135757151773136 is __marker):
                    del econtext['vlen']
                else:
                    econtext['vlen'] = __backup_vlen_135757151773136
                if (__backup_vocab_135757075872080 is __marker):
                    del econtext['vocab']
                else:
                    econtext['vocab'] = __backup_vocab_135757075872080
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro|context/widgets/field/macros/edit' (35:30)> -> __macro
            __token = 1370
            try:
                __zt_tmp = __attrs_135757109875024
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'field_macro|context/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 1370
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757130356208 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757130356208
            __append(u'\n\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109876624
            __attrs_135757109876624 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075217616
            __attrs_135757075217616 = _static_135757327983760
            __backup_macroname_135757149414896 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786a4ec810> name=None at 7b786838ab50> -> __value
            __value = _static_135757109839888
            econtext['macroname'] = __value

            # <Value u'context/widgets/selection/macros/edit' (127:30)> -> __macro
            __token = 5531
            try:
                __zt_tmp = __attrs_135757075217616
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/selection/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 5531
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757149414896 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757149414896
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_selection_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bfa4d10> name=None at 7b785bfa4fd0> -> __attrs_135757109874832
            __attrs_135757109874832 = _static_135756869422352
            __backup_kss_class_135757072799056 = get('kss_class', __marker)

            # <Value u"python:getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')" (19:34)> -> __value
            __token = 610
            try:
                __zt_tmp = __attrs_135757109874832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kss_class'] = __value
            __backup_uid_135757153178000 = get('uid', __marker)

            # <Value u'context/UID|nothing' (21:33)> -> __value
            __token = 768
            try:
                __zt_tmp = __attrs_135757109874832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/UID|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['uid'] = __value

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869422480
            __default_135756869422480 = _DEFAULT_MARKER

            # <Substitution u'kss_class' (22:34)> -> __attr_class
            __token = 825
            try:
                __zt_tmp = __attrs_135757109874832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'kss_class', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869422736
            __default_135756869422736 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName-$uid' (23:30)> -> __attr_id
            __token = 866
            try:
                __zt_tmp = __attrs_135757109874832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('string', u'parent-fieldname-$fieldName-$uid', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n            ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109877840
                __attrs_135757109877840 = _static_135757327983760
                __backup_vocab_135757109780176 = get('vocab', __marker)

                # <Value u'python:field.Vocabulary(context)' (25:34)> -> __value
                __token = 988
                try:
                    __zt_tmp = __attrs_135757109877840
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.Vocabulary(context)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['vocab'] = __value
                __backup_value_135757150217104 = get('value', __marker)

                # <Value u'python:accessor()' (26:33)> -> __value
                __token = 1055
                try:
                    __zt_tmp = __attrs_135757109877840
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['value'] = __value
                __backup_display_135757075193936 = get('display', __marker)

                # <Value u'python:context.displayValue(vocab, value, widget)' (27:34)> -> __value
                __token = 1109
                try:
                    __zt_tmp = __attrs_135757109877840
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'context.displayValue(vocab, value, widget)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['display'] = __value

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109877520
                __default_135757109877520 = _DEFAULT_MARKER

                # <Value u'display' (29:39)> -> __cache_135757109877648
                __token = 1247
                try:
                    __zt_tmp = __attrs_135757109877840
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757109877648 = _static_135757244280656('path', u'display', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'display' (29:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786a4f5850> -> __condition
                __expression = __cache_135757109877648

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_135757109877648
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                if (__backup_display_135757075193936 is __marker):
                    del econtext['display']
                else:
                    econtext['display'] = __backup_display_135757075193936
                if (__backup_value_135757150217104 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_135757150217104
                if (__backup_vocab_135757109780176 is __marker):
                    del econtext['vocab']
                else:
                    econtext['vocab'] = __backup_vocab_135757109780176
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n        </span>')
            if (__backup_uid_135757153178000 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_135757153178000
            if (__backup_kss_class_135757072799056 is __marker):
                del econtext['kss_class']
            else:
                econtext['kss_class'] = __backup_kss_class_135757072799056
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869420688
            __attrs_135756869420688 = _static_135757327983760
            __backup_kssClassesView_135757151776272 = get('kssClassesView', __marker)

            # <Value u'context/@@kss_field_decorator_view' (16:39)> -> __value
            __token = 393
            try:
                __zt_tmp = __attrs_135756869420688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kssClassesView'] = __value
            __backup_getKssClasses_135757166255952 = get('getKssClasses', __marker)

            # <Value u'nocall:kssClassesView/getKssClassesInlineEditable' (17:37)> -> __value
            __token = 466
            try:
                __zt_tmp = __attrs_135756869420688
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'kssClassesView/getKssClassesInlineEditable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['getKssClasses'] = __value
            __append(u'\n        ')
            __token = None
            render_selection_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
            if (__backup_getKssClasses_135757166255952 is __marker):
                del econtext['getKssClasses']
            else:
                econtext['getKssClasses'] = __backup_getKssClasses_135757166255952
            if (__backup_kssClassesView_135757151776272 is __marker):
                del econtext['kssClassesView']
            else:
                econtext['kssClassesView'] = __backup_kssClassesView_135757151776272
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bf9a210> name=None at 7b785bf9a990> -> __attrs_135757075409744
            __attrs_135757075409744 = _static_135756869378576
            __previous_i18n_domain_135757075408464 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869419792
            __attrs_135756869419792 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869421584
            __attrs_135756869421584 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title>\n</head>\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869422160
            __attrs_135756869422160 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Selection Widgets -->\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n</body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_135757075408464
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_selection_field_view': render_selection_field_view, u'render_view': render_view, 'render': render, }