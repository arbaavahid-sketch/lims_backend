# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dashboard/templates/dashboard.pt'

__tokens = {301: (u'python:view.get_user_fullname()', 8, 25), 524: (u'python:view.get_current_date()', 14, 25), 626: (u'python:view.get_current_time()', 16, 25), 828: (u'string:${portal_url}/++resource++senaite.core.dashboard.css', 23, 31), 1042: (u'string:${view/portal_url}/senaite-dashboard-data', 28, 39), 1134: (u' view/periodicit', 29, 41), 1197: (u"s python:'true' if view.can_view_statistics() else 'fals", 30, 43), 1296: (u'rl view/portal_', 31, 38), 1353: (u'rom python:plone_view.toLocalizedTime(view.date_f', 32, 36), 1442: (u'e-to python:plone_view.toLocalizedTime(view.dat', 33, 33), 1864: (u'python:view.can_view_statistics()', 45, 31), 1935: (u"python:['analysisrequests', 'analyses', 'worksheets']", 46, 34), 2024: (u'string:dashboard-section-${section_id}', 47, 32), 2364: (u'string:${portal_url}/++resource++senaite.core.dashboard.js', 57, 32), 2471: (u'context/@@authenticator/authenticator', 59, 34), 67: (u'here/main_template/macros/master', 2, 23), 67: (u'here/main_template/macros/master', 2, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133987184232400 = {u'src': u'string:${portal_url}/++resource++senaite.core.dashboard.js', }
_static_133987184233552 = {u'class': u'dashboard-section', u'id': u'string:dashboard-section-${section_id}', }
_static_133987276028048 = __compile_zt_expr
_static_133987184241360 = {u'class': u'text-muted', }
_static_133987184239696 = {u'id': u'dashboard-overview', u'class': u'mt-4', }
_static_133987183704272 = u'master'
_static_133987184247824 = {u'class': u'text-muted py-3', }
_static_133987184235728 = {u'data-can-view-stats': u"python:'true' if view.can_view_statistics() else 'false'", u'style': u'display:none', u'data-periodicity': u'view/periodicity', u'data-date-from': u'python:plone_view.toLocalizedTime(view.date_from)', u'data-date-to': u'python:plone_view.toLocalizedTime(view.date_to)', u'data-portal-url': u'view/portal_url', u'id': u'dashboard-config', u'data-base-url': u'string:${view/portal_url}/senaite-dashboard-data', }
_static_133987184242576 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_133987276028432 = __C2ZContextWrapper
_static_133987165528912 = {u'class': u'documentDescription text-muted', }
_static_133987184225616 = {u'href': u'string:${portal_url}/++resource++senaite.core.dashboard.css', u'rel': u'stylesheet', }
_static_133987359720592 = {}
_static_133987184249296 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_133987166732816 = {u'class': u'documentFirstHeading', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987165733584
            __attrs_133987165733584 = _static_133987359720592
            __previous_i18n_domain_133987165762192 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_133987158533296 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79dc527d38d0> name=None at 79dc516b0850> -> __value
            __value = _static_133987183704272
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987167422800
                __attrs_133987167422800 = _static_133987359720592
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc517a4210> name=None at 79dc516b0a90> -> __attrs_133987185252816
                __attrs_133987185252816 = _static_133987166732816

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987423783824
                __attrs_133987423783824 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_133987423783184 = []
                __append_133987423783184 = __stream_133987423783184.append
                __append_133987423783184(u'Welcome')
                __msgid_133987423783184 = __re_whitespace(''.join(__stream_133987423783184)).strip()
                if __msgid_133987423783184:
                    __append(translate(__msgid_133987423783184, mapping=None, default=__msgid_133987423783184, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>,\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987165528528
                __attrs_133987165528528 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987422399376
                __default_133987422399376 = _DEFAULT_MARKER

                # <Value u'python:view.get_user_fullname()' (8:25)> -> __cache_133987422398928
                __token = 301
                try:
                    __zt_tmp = __attrs_133987165528528
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987422398928 = _static_133987276028048('python', u'view.get_user_fullname()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_user_fullname()' (8:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc60b76710> -> __condition
                __expression = __cache_133987422398928

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'User')
                else:
                    __content = __cache_133987422398928
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n    </h1>\r\n  ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_description(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987165778896
                __attrs_133987165778896 = _static_133987359720592
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc5167e350> name=None at 79dc5167e3d0> -> __attrs_133987184222736
                __attrs_133987184222736 = _static_133987165528912

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="documentDescription text-muted">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184223952
                __attrs_133987184223952 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184223568
                __default_133987184223568 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_date()' (14:25)> -> __cache_133987184223248
                __token = 524
                try:
                    __zt_tmp = __attrs_133987184223952
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987184223248 = _static_133987276028048('python', u'view.get_current_date()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_date()' (14:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52852490> -> __condition
                __expression = __cache_133987184223248

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Monday, 22 April 2026')
                else:
                    __content = __cache_133987184223248
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n      &mdash;\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184224976
                __attrs_133987184224976 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184224592
                __default_133987184224592 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_time()' (16:25)> -> __cache_133987184224272
                __token = 626
                try:
                    __zt_tmp = __attrs_133987184224976
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987184224272 = _static_133987276028048('python', u'view.get_current_time()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_time()' (16:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52852890> -> __condition
                __expression = __cache_133987184224272

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'14:30')
                else:
                    __content = __cache_133987184224272
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n    </div>\r\n  ')
            _slots = econtext[u'__slot_content_description'] = _deque((__fill_content_description, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184222800
                __attrs_133987184222800 = _static_133987359720592
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52852d50> name=None at 79dc52852d10> -> __attrs_133987184234704
                __attrs_133987184234704 = _static_133987184225616

                # <link ... (0:0)
                # --------------------------------------------------------
                __append(u'<link rel="stylesheet"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987167398672
                __default_133987167398672 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.css' (23:31)> -> __attr_href
                __token = 828
                try:
                    __zt_tmp = __attrs_133987184234704
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133987276028048('string', u'${portal_url}/++resource++senaite.core.dashboard.css', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' />\r\n\r\n    <!-- Configuration for dashboard.js -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc528554d0> name=None at 79dc528552d0> -> __attrs_133987184239312
                __attrs_133987184239312 = _static_133987184235728

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-config"          style="display:none"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184237584
                __default_133987184237584 = _DEFAULT_MARKER

                # <Substitution u'string:${view/portal_url}/senaite-dashboard-data' (28:39)> -> __attr_data_base_url
                __token = 1042
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_base_url = _static_133987276028048('string', u'${view/portal_url}/senaite-dashboard-data', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_base_url = __quote(__attr_data_base_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_base_url is not None):
                    __append((u' data-base-url="%s"' % __attr_data_base_url))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184237840
                __default_133987184237840 = _DEFAULT_MARKER

                # <Substitution u'view/periodicity' (29:41)> -> __attr_data_periodicity
                __token = 1134
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_periodicity = _static_133987276028048('path', u'view/periodicity', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_periodicity = __quote(__attr_data_periodicity, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_periodicity is not None):
                    __append((u' data-periodicity="%s"' % __attr_data_periodicity))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184238096
                __default_133987184238096 = _DEFAULT_MARKER

                # <Substitution u"python:'true' if view.can_view_statistics() else 'false'" (30:43)> -> __attr_data_can_view_stats
                __token = 1197
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_can_view_stats = _static_133987276028048('python', u"'true' if view.can_view_statistics() else 'false'", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_can_view_stats = __quote(__attr_data_can_view_stats, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_can_view_stats is not None):
                    __append((u' data-can-view-stats="%s"' % __attr_data_can_view_stats))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184238416
                __default_133987184238416 = _DEFAULT_MARKER

                # <Substitution u'view/portal_url' (31:38)> -> __attr_data_portal_url
                __token = 1296
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_portal_url = _static_133987276028048('path', u'view/portal_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_portal_url = __quote(__attr_data_portal_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_portal_url is not None):
                    __append((u' data-portal-url="%s"' % __attr_data_portal_url))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184238736
                __default_133987184238736 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_from)' (32:36)> -> __attr_data_date_from
                __token = 1353
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_from = _static_133987276028048('python', u'plone_view.toLocalizedTime(view.date_from)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_date_from = __quote(__attr_data_date_from, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_from is not None):
                    __append((u' data-date-from="%s"' % __attr_data_date_from))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184238992
                __default_133987184238992 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_to)' (33:33)> -> __attr_data_date_to
                __token = 1442
                try:
                    __zt_tmp = __attrs_133987184239312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_to = _static_133987276028048('python', u'plone_view.toLocalizedTime(view.date_to)', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_date_to = __quote(__attr_data_date_to, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_to is not None):
                    __append((u' data-date-to="%s"' % __attr_data_date_to))
                __append(u'>\r\n    </div>\r\n\r\n    <!-- Status Cards + Quick Links (async) -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52856450> name=None at 79dc52856490> -> __attrs_133987184240720
                __attrs_133987184240720 = _static_133987184239696

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-overview" class="mt-4">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52856ad0> name=None at 79dc52856a50> -> __attrs_133987184241936
                __attrs_133987184241936 = _static_133987184241360

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="text-muted">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc52856f90> name=None at 79dc52856f50> -> __attrs_133987184230992
                __attrs_133987184230992 = _static_133987184242576

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184231568
                __attrs_133987184231568 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_133987184231248 = []
                __append_133987184231248 = __stream_133987184231248.append
                __append_133987184231248(u'Loading...')
                __msgid_133987184231248 = __re_whitespace(''.join(__stream_133987184231248)).strip()
                if __msgid_133987184231248:
                    __append(translate(__msgid_133987184231248, mapping=None, default=__msgid_133987184231248, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Statistics Sections (async, permission-gated) -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184231888
                __attrs_133987184231888 = _static_133987359720592

                # <Value u'python:view.can_view_statistics()' (45:31)> -> __condition
                __token = 1864
                try:
                    __zt_tmp = __attrs_133987184231888
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('python', u'view.can_view_statistics()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n      ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184232784
                    __attrs_133987184232784 = _static_133987359720592
                    __backup_section_id_133987165886544 = get('section_id', __marker)

                    # <Value u"python:['analysisrequests', 'analyses', 'worksheets']" (46:34)> -> __iterator
                    __token = 1935
                    try:
                        __zt_tmp = __attrs_133987184232784
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_133987276028048('python', u"['analysisrequests', 'analyses', 'worksheets']", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    (__iterator, ____index_133987184232976, ) = getitem('repeat')(u'section_id', __iterator)
                    econtext['section_id'] = None
                    for __item in __iterator:
                        econtext['section_id'] = __item

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>\r\n        ')

                        # <Static value=<_ast.Dict object at 0x79dc52854c50> name=None at 79dc52854c10> -> __attrs_133987184246992
                        __attrs_133987184246992 = _static_133987184233552

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div              class="dashboard-section"')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184234320
                        __default_133987184234320 = _DEFAULT_MARKER

                        # <Substitution u'string:dashboard-section-${section_id}' (47:32)> -> __attr_id
                        __token = 2024
                        try:
                            __zt_tmp = __attrs_133987184246992
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_133987276028048('string', u'dashboard-section-${section_id}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>\r\n          ')

                        # <Static value=<_ast.Dict object at 0x79dc52858410> name=None at 79dc528583d0> -> __attrs_133987184248464
                        __attrs_133987184248464 = _static_133987184247824

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-muted py-3">\r\n            ')

                        # <Static value=<_ast.Dict object at 0x79dc528589d0> name=None at 79dc52858990> -> __attrs_133987184249936
                        __attrs_133987184249936 = _static_133987184249296

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\r\n            ')

                        # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184250576
                        __attrs_133987184250576 = _static_133987359720592

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                        __stream_133987184250256 = []
                        __append_133987184250256 = __stream_133987184250256.append
                        __append_133987184250256(u'Loading...')
                        __msgid_133987184250256 = __re_whitespace(''.join(__stream_133987184250256)).strip()
                        if __msgid_133987184250256:
                            __append(translate(__msgid_133987184250256, mapping=None, default=__msgid_133987184250256, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\r\n          </div>\r\n        </div>\r\n      </div>')
                        ____index_133987184232976 -= 1
                        if (____index_133987184232976 > 0):
                            __append('\n      ')
                    if (__backup_section_id_133987165886544 is __marker):
                        del econtext['section_id']
                    else:
                        econtext['section_id'] = __backup_section_id_133987165886544
                    __append(u'\r\n    ')
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc528547d0> name=None at 79dc52854650> -> __attrs_133987184248848
                __attrs_133987184248848 = _static_133987184232400

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184247376
                __default_133987184247376 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.js' (57:32)> -> __attr_src
                __token = 2364
                try:
                    __zt_tmp = __attrs_133987184248848
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_133987276028048('string', u'${portal_url}/++resource++senaite.core.dashboard.js', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'></script>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987184251728
                __attrs_133987184251728 = _static_133987359720592

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184251600
                __default_133987184251600 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (59:34)> -> __cache_133987184251280
                __token = 2471
                try:
                    __zt_tmp = __attrs_133987184251728
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987184251280 = _static_133987276028048('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (59:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52859210> -> __condition
                __expression = __cache_133987184251280

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input/>')
                else:
                    __content = __cache_133987184251280
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (2:23)> -> __macro
            __token = 67
            try:
                __zt_tmp = __attrs_133987165733584
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133987276028048('path', u'here/main_template/macros/master', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __token = 67
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133987158533296 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133987158533296
            __i18n_domain = __previous_i18n_domain_133987165762192
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }