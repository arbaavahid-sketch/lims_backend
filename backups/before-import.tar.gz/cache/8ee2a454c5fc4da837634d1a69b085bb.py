# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/sections.pt'

__tokens = {193: (u'view/portal_tabs', 5, 26), 228: (u'portal_tabs', 6, 17), 559: (u'python:view.selected_portal_tab', 19, 33), 630: (u'view/portal_tabs', 21, 36), 711: (u"python:action['id'] == selected_tab", 23, 33), 775: (u'action/available|nothing', 24, 27), 875: (u'action/url', 26, 34), 921: (u" python:selected and 'active nav-link' or 'nav-link", 27, 34), 1008: (u'e action/description|action/tit', 28, 33), 1075: (u'action/title', 29, 31)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757075231824 = {u'class': u'fas fa-th', }
_static_135757148696400 = {u'href': u'#', u'class': u'nav-link', u'title': u'action/description|action/title', }
_static_135757075232656 = {u'class': u'dropdown-menu dropdown-menu-right', }
_static_135757244280656 = __compile_zt_expr
_static_135757150465936 = {u'class': u'dropdown', }
_static_135757136196176 = {u'data-toggle': u'dropdown', u'href': u'#', u'class': u'nav-link dropdown-toggle', u'aria-expanded': u'false', u'aria-haspopup': u'true', }
_static_135757327983760 = {}
_static_135757148640592 = {u'class': u'nav-item', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150462224
            __attrs_135757150462224 = _static_135757327983760
            __backup_portal_tabs_135757148736144 = get('portal_tabs', __marker)

            # <Value u'view/portal_tabs' (5:26)> -> __value
            __token = 193
            try:
                __zt_tmp = __attrs_135757150462224
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/portal_tabs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_tabs'] = __value

            # <Value u'portal_tabs' (6:17)> -> __condition
            __token = 228
            try:
                __zt_tmp = __attrs_135757150462224
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'portal_tabs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757150464464 = __i18n_domain
                __i18n_domain = u'plone'
                __append(u'\n\n  ')

                # <Static value=<_ast.Dict object at 0x7b786cbaaf90> name=None at 7b786cbaaa90> -> __attrs_135757136198480
                __attrs_135757136198480 = _static_135757150465936

                # <nav ... (0:0)
                # --------------------------------------------------------
                __append(u'<nav class="dropdown">\n    ')

                # <Static value=<_ast.Dict object at 0x7b786be0f250> name=None at 7b786be0f290> -> __attrs_135757075996432
                __attrs_135757075996432 = _static_135757136196176

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\n      ')

                # <Static value=<_ast.Dict object at 0x7b78683eb450> name=None at 7b78683ebf50> -> __attrs_135757075232912
                __attrs_135757075232912 = _static_135757075231824

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-th"></i>\n    </a>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b78683eb790> name=None at 7b78683eb410> -> __attrs_135757075233360
                __attrs_135757075233360 = _static_135757075232656
                __backup_selected_tab_135757163481552 = get('selected_tab', __marker)

                # <Value u'python:view.selected_portal_tab' (19:33)> -> __value
                __token = 559
                try:
                    __zt_tmp = __attrs_135757075233360
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'view.selected_portal_tab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['selected_tab'] = __value

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="dropdown-menu dropdown-menu-right">\n\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075234256
                __attrs_135757075234256 = _static_135757327983760
                __backup_action_135757163045648 = get('action', __marker)

                # <Value u'view/portal_tabs' (21:36)> -> __iterator
                __token = 630
                try:
                    __zt_tmp = __attrs_135757075234256
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'view/portal_tabs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757075232272, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item
                    __append(u'\n        ')

                    # <Static value=<_ast.Dict object at 0x7b786c9ed550> name=None at 7b786c9ed110> -> __attrs_135757148692560
                    __attrs_135757148692560 = _static_135757148640592
                    __backup_selected_135757074251152 = get('selected', __marker)

                    # <Value u"python:action['id'] == selected_tab" (23:33)> -> __value
                    __token = 711
                    try:
                        __zt_tmp = __attrs_135757148692560
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u"action['id'] == selected_tab", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['selected'] = __value

                    # <Value u'action/available|nothing' (24:27)> -> __condition
                    __token = 775
                    try:
                        __zt_tmp = __attrs_135757148692560
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'action/available|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="nav-item">\n          ')

                        # <Static value=<_ast.Dict object at 0x7b786c9faf50> name=None at 7b786c9fa450> -> __attrs_135757148693328
                        __attrs_135757148693328 = _static_135757148696400

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148693968
                        __default_135757148693968 = _DEFAULT_MARKER

                        # <Substitution u'action/url' (26:34)> -> __attr_href
                        __token = 875
                        try:
                            __zt_tmp = __attrs_135757148693328
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('path', u'action/url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148692816
                        __default_135757148692816 = _DEFAULT_MARKER

                        # <Substitution u"python:selected and 'active nav-link' or 'nav-link'" (27:34)> -> __attr_class
                        __token = 921
                        try:
                            __zt_tmp = __attrs_135757148693328
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_135757244280656('python', u"selected and 'active nav-link' or 'nav-link'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-link', _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148694416
                        __default_135757148694416 = _DEFAULT_MARKER

                        # <Substitution u'action/description|action/title' (28:33)> -> __attr_title
                        __token = 1008
                        try:
                            __zt_tmp = __attrs_135757148693328
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('path', u'action/description|action/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073556880
                        __attrs_135757073556880 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073558352
                        __default_135757073558352 = _DEFAULT_MARKER

                        # <Value u'action/title' (29:31)> -> __cache_135757073555920
                        __token = 1075
                        try:
                            __zt_tmp = __attrs_135757073556880
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757073555920 = _static_135757244280656('path', u'action/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'action/title' (29:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868252710> -> __condition
                        __expression = __cache_135757073555920

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757073555920
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n          </a>\n        </li>')
                    if (__backup_selected_135757074251152 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_135757074251152
                    __append(u'\n      ')
                    ____index_135757075232272 -= 1
                    if (____index_135757075232272 > 0):
                        __append('')
                if (__backup_action_135757163045648 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_135757163045648
                __append(u'\n    </ul>')
                if (__backup_selected_tab_135757163481552 is __marker):
                    del econtext['selected_tab']
                else:
                    econtext['selected_tab'] = __backup_selected_tab_135757163481552
                __append(u'\n  </nav>\n\n')
                __i18n_domain = __previous_i18n_domain_135757150464464
            if (__backup_portal_tabs_135757148736144 is __marker):
                del econtext['portal_tabs']
            else:
                econtext['portal_tabs'] = __backup_portal_tabs_135757148736144
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }