# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.app.spotlight/src/senaite/app/spotlight/templates/spotlight_viewlet.pt'

__tokens = {172: (u'view/get_config_json', 4, 35), 354: (u'context/@@plone_portal_state/portal', 10, 25), 417: (u'string:${portal/absolute_url}/++resource++senaite.app.spotlight.static/js/senaite.app.spotlight.js', 11, 26)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757075354640 = {u'src': u'#', u'type': u'text/javascript', }
_static_135757327983760 = {}
_static_135757074403408 = {u'data-config': u'view/get_config_json', u'id': u'spotlight-root', }
_static_135757244280656 = __compile_zt_expr
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074406992
            __attrs_135757074406992 = _static_135757327983760
            __previous_i18n_domain_135757074405840 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __append(u'\n  <!-- React mount node, the configuration is provided as JSON -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b7868321050> name=None at 7b7868321850> -> __attrs_135757075355216
            __attrs_135757075355216 = _static_135757074403408

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="spotlight-root"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152172368
            __default_135757152172368 = _DEFAULT_MARKER

            # <Substitution u'view/get_config_json' (4:35)> -> __attr_data_config
            __token = 172
            try:
                __zt_tmp = __attrs_135757075355216
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_config = _static_135757244280656('path', u'view/get_config_json', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_data_config = __quote(__attr_data_config, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_config is not None):
                __append((u' data-config="%s"' % __attr_data_config))
            __append(u'></div>\n\n  <!-- Spotlight bundle (consumes the shared React from senaite.core) -->\n  ')

            # <Static value=<_ast.Dict object at 0x7b7868409410> name=None at 7b78684091d0> -> __attrs_135757075356560
            __attrs_135757075356560 = _static_135757075354640
            __backup_portal_135757075283024 = get('portal', __marker)

            # <Value u'context/@@plone_portal_state/portal' (10:25)> -> __value
            __token = 354
            try:
                __zt_tmp = __attrs_135757075356560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@plone_portal_state/portal', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal'] = __value

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075354448
            __default_135757075354448 = _DEFAULT_MARKER

            # <Substitution u'string:${portal/absolute_url}/++resource++senaite.app.spotlight.static/js/senaite.app.spotlight.js' (11:26)> -> __attr_src
            __token = 417
            try:
                __zt_tmp = __attrs_135757075356560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${portal/absolute_url}/++resource++senaite.app.spotlight.static/js/senaite.app.spotlight.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u' type="text/javascript">\n  </script>')
            if (__backup_portal_135757075283024 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_135757075283024
            __append(u'\n')
            __i18n_domain = __previous_i18n_domain_135757074405840
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }