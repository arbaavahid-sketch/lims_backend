# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/path_bar.pt'

__tokens = {87: (u'view/breadcrumbs', 3, 30), 130: (u' view/is_rt', 4, 24), 171: (u"python:is_rtl and 'rtl' or 'ltr'", 5, 26), 353: (u'view/navigation_root_url', 9, 61), 435: (u'breadcrumbs', 12, 33), 486: (u'repeat/crumb/end', 13, 36), 536: (u' crumb/absolute_ur', 14, 31), 590: (u'e crumb/Tit', 15, 32), 641: (u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'", 16, 34), 739: (u' string:breadcrumbs-${repeat/crumb/number', 17, 30), 836: (u'not: url', 19, 27), 881: (u'url', 20, 34), 921: (u" python:is_last and 'text-secondary", 21, 34), 986: (u'title', 22, 26)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525521558992 = {u'class': u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'", u'id': u'string:breadcrumbs-${repeat/crumb/number}', }
_static_124525979686032 = {}
_static_124525521611536 = {u'aria-label': u'breadcrumb', }
_static_124525732132560 = {u'href': u'#', u'class': u"python:is_last and 'text-secondary'", }
_static_124525521476624 = {u'href': u'#', }
_static_124525521612688 = {u'class': u'breadcrumb', u'dir': u"python:is_rtl and 'rtl' or 'ltr'", }
_static_124525896002064 = __C2ZContextWrapper
_static_124525896001680 = __compile_zt_expr
_static_124525521476176 = {u'id': u'breadcrumbs-home', u'class': u'breadcrumb-item', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7b2b10> name=None at 714168361810> -> __attrs_124525521609744
            __attrs_124525521609744 = _static_124525521611536

            # <nav ... (0:0)
            # --------------------------------------------------------
            __append(u'<nav aria-label="breadcrumb">\r\n  ')

            # <Static value=<_ast.Dict object at 0x71415b7b2f90> name=None at 71415b7b2ad0> -> __attrs_124525732037712
            __attrs_124525732037712 = _static_124525521612688
            __backup_breadcrumbs_124525521410256 = get('breadcrumbs', __marker)

            # <Value u'view/breadcrumbs' (3:30)> -> __value
            __token = 87
            try:
                __zt_tmp = __attrs_124525732037712
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/breadcrumbs', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['breadcrumbs'] = __value
            __backup_is_rtl_124525521550928 = get('is_rtl', __marker)

            # <Value u'view/is_rtl' (4:24)> -> __value
            __token = 130
            try:
                __zt_tmp = __attrs_124525732037712
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/is_rtl', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['is_rtl'] = __value
            __previous_i18n_domain_124525521609616 = __i18n_domain
            __i18n_domain = u'plone'

            # <ol ... (0:0)
            # --------------------------------------------------------
            __append(u'<ol class="breadcrumb"')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521609040
            __default_124525521609040 = _DEFAULT_MARKER

            # <Substitution u"python:is_rtl and 'rtl' or 'ltr'" (5:26)> -> __attr_dir
            __token = 171
            try:
                __zt_tmp = __attrs_124525732037712
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_124525896001680('python', u"is_rtl and 'rtl' or 'ltr'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_dir is not None):
                __append((u' dir="%s"' % __attr_dir))
            __append(u'>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x71415b791a50> name=None at 71415b791310> -> __attrs_124525521476112
            __attrs_124525521476112 = _static_124525521476176

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li id="breadcrumbs-home" class="breadcrumb-item">\r\n      ')

            # <Static value=<_ast.Dict object at 0x71415b791c10> name=None at 71415b791150> -> __attrs_124525520881552
            __attrs_124525520881552 = _static_124525521476624

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520882128
            __default_124525520882128 = _DEFAULT_MARKER

            # <Substitution u'view/navigation_root_url' (9:61)> -> __attr_href
            __token = 353
            try:
                __zt_tmp = __attrs_124525520881552
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_124525896001680('path', u'view/navigation_root_url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_124525521475728 = []
            __append_124525521475728 = __stream_124525521475728.append
            __append_124525521475728(u'Home')
            __msgid_124525521475728 = __re_whitespace(''.join(__stream_124525521475728)).strip()
            if u'Home':
                __append(translate(u'Home', mapping=None, default=__msgid_124525521475728, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\r\n    </li>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525520879888
            __attrs_124525520879888 = _static_124525979686032
            __backup_crumb_124525521713040 = get('crumb', __marker)

            # <Value u'breadcrumbs' (12:33)> -> __iterator
            __token = 435
            try:
                __zt_tmp = __attrs_124525520879888
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_124525896001680('path', u'breadcrumbs', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            (__iterator, ____index_124525520880400, ) = getitem('repeat')(u'crumb', __iterator)
            econtext['crumb'] = None
            for __item in __iterator:
                econtext['crumb'] = __item
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732044048
                __attrs_124525732044048 = _static_124525979686032
                __backup_is_last_124525732041040 = get('is_last', __marker)

                # <Value u'repeat/crumb/end' (13:36)> -> __value
                __token = 486
                try:
                    __zt_tmp = __attrs_124525732044048
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'repeat/crumb/end', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['is_last'] = __value
                __backup_url_124525521408592 = get('url', __marker)

                # <Value u'crumb/absolute_url' (14:31)> -> __value
                __token = 536
                try:
                    __zt_tmp = __attrs_124525732044048
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'crumb/absolute_url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['url'] = __value
                __backup_title_124525782462800 = get('title', __marker)

                # <Value u'crumb/Title' (15:32)> -> __value
                __token = 590
                try:
                    __zt_tmp = __attrs_124525732044048
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'crumb/Title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['title'] = __value
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x71415b7a5dd0> name=None at 71415b7a5a50> -> __attrs_124525520879824
                __attrs_124525520879824 = _static_124525521558992

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520881104
                __default_124525520881104 = _DEFAULT_MARKER

                # <Substitution u"python: is_last and 'active breadcrumb-item' or 'breadcrumb-item'" (16:34)> -> __attr_class
                __token = 641
                try:
                    __zt_tmp = __attrs_124525520879824
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_124525896001680('python', u" is_last and 'active breadcrumb-item' or 'breadcrumb-item'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520882768
                __default_124525520882768 = _DEFAULT_MARKER

                # <Substitution u'string:breadcrumbs-${repeat/crumb/number}' (17:30)> -> __attr_id
                __token = 739
                try:
                    __zt_tmp = __attrs_124525520879824
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_124525896001680('string', u'breadcrumbs-${repeat/crumb/number}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\r\n          ')

                # <Static value=<_ast.Dict object at 0x7141680776d0> name=None at 714168077f10> -> __attrs_124525732132688
                __attrs_124525732132688 = _static_124525732132560

                # <Negate value=<Value u'not: url' (19:27)> at 714168077090> -> __cache_124525732130960

                # <Value u'not: url' (19:27)> -> __cache_124525732130960
                __token = 836
                try:
                    __zt_tmp = __attrs_124525732132688
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525732130960 = _static_124525896001680('not', u' url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __cache_124525732130960 = not __cache_124525732130960
                __condition = __cache_124525732130960
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732133584
                    __default_124525732133584 = _DEFAULT_MARKER

                    # <Substitution u'url' (20:34)> -> __attr_href
                    __token = 881
                    try:
                        __zt_tmp = __attrs_124525732132688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('path', u'url', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732133072
                    __default_124525732133072 = _DEFAULT_MARKER

                    # <Substitution u"python:is_last and 'text-secondary'" (21:34)> -> __attr_class
                    __token = 921
                    try:
                        __zt_tmp = __attrs_124525732132688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_124525896001680('python', u"is_last and 'text-secondary'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525520881488
                __default_124525520881488 = _DEFAULT_MARKER

                # <Value u'title' (22:26)> -> __cache_124525520880016
                __token = 986
                try:
                    __zt_tmp = __attrs_124525732132688
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525520880016 = _static_124525896001680('path', u'title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'title' (22:26)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b700850> -> __condition
                __expression = __cache_124525520880016

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\r\n            crumb\r\n          ')
                else:
                    __content = __cache_124525520880016
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __condition = __cache_124525732130960
                if __condition:
                    __append(u'</a>')
                __append(u'\r\n        </li>\r\n      ')
                if (__backup_title_124525782462800 is __marker):
                    del econtext['title']
                else:
                    econtext['title'] = __backup_title_124525782462800
                if (__backup_url_124525521408592 is __marker):
                    del econtext['url']
                else:
                    econtext['url'] = __backup_url_124525521408592
                if (__backup_is_last_124525732041040 is __marker):
                    del econtext['is_last']
                else:
                    econtext['is_last'] = __backup_is_last_124525732041040
                __append(u'\r\n    ')
                ____index_124525520880400 -= 1
                if (____index_124525520880400 > 0):
                    __append('')
            if (__backup_crumb_124525521713040 is __marker):
                del econtext['crumb']
            else:
                econtext['crumb'] = __backup_crumb_124525521713040
            __append(u'\r\n\r\n  </ol>')
            __i18n_domain = __previous_i18n_domain_124525521609616
            if (__backup_is_rtl_124525521550928 is __marker):
                del econtext['is_rtl']
            else:
                econtext['is_rtl'] = __backup_is_rtl_124525521550928
            if (__backup_breadcrumbs_124525521410256 is __marker):
                del econtext['breadcrumbs']
            else:
                econtext['breadcrumbs'] = __backup_breadcrumbs_124525521410256
            __append(u'\r\n</nav>\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }