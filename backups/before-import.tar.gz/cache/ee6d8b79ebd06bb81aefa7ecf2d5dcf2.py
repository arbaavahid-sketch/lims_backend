# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dashboard/templates/dashboard.pt'

__tokens = {301: (u'python:view.get_user_fullname()', 8, 25), 524: (u'python:view.get_current_date()', 14, 25), 626: (u'python:view.get_current_time()', 16, 25), 828: (u'string:${portal_url}/++resource++senaite.core.dashboard.css', 23, 31), 1274: (u'string:${view/portal_url}/senaite-dashboard-data', 32, 39), 1366: (u' view/periodicit', 33, 41), 1429: (u"s python:'true' if view.can_view_statistics() else 'fals", 34, 43), 1528: (u'rl view/portal_', 35, 38), 1585: (u'rom python:plone_view.toLocalizedTime(view.date_f', 36, 36), 1674: (u'e-to python:plone_view.toLocalizedTime(view.dat', 37, 33), 2096: (u'python:view.can_view_statistics()', 49, 31), 2167: (u"python:['analysisrequests', 'analyses', 'worksheets']", 50, 34), 2256: (u'string:dashboard-section-${section_id}', 51, 32), 2596: (u'string:${portal_url}/++resource++senaite.core.dashboard.js', 61, 32), 2703: (u'context/@@authenticator/authenticator', 63, 34), 67: (u'here/main_template/macros/master', 2, 23), 67: (u'here/main_template/macros/master', 2, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_131357902596752 = {u'data-can-view-stats': u"python:'true' if view.can_view_statistics() else 'false'", u'data-label-status': u'Status', u'style': u'display:none', u'data-label-timeline': u'Show/hide timeline', u'data-periodicity': u'view/periodicity', u'data-date-from': u'python:plone_view.toLocalizedTime(view.date_from)', u'data-label-quick-actions': u'Quick Actions', u'data-date-to': u'python:plone_view.toLocalizedTime(view.date_to)', u'data-portal-url': u'view/portal_url', u'id': u'dashboard-config', u'data-base-url': u'string:${view/portal_url}/senaite-dashboard-data', }
_static_131357902614224 = {u'class': u'text-muted py-3', }
_static_131357902591184 = {u'class': u'documentDescription text-muted', }
_static_131357902525008 = u'master'
_static_131357902612432 = {u'class': u'dashboard-section', u'id': u'string:dashboard-section-${section_id}', }
_static_131357902594768 = {u'href': u'string:${portal_url}/++resource++senaite.core.dashboard.css', u'rel': u'stylesheet', }
_static_131357902526672 = {u'class': u'documentFirstHeading', }
_static_131357902623824 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_131357902611344 = {u'src': u'string:${portal_url}/++resource++senaite.core.dashboard.js', }
_static_131357902609296 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_131358013585936 = __C2ZContextWrapper
_static_131358013585552 = __compile_zt_expr
_static_131357902608144 = {u'class': u'text-muted', }
_static_131357902606480 = {u'id': u'dashboard-overview', u'class': u'mt-4', }
_static_131358097278096 = {}

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902525264
            __attrs_131357902525264 = _static_131358097278096
            __previous_i18n_domain_131357902525392 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_131357893909952 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7778251e5250> name=None at 7778251e5290> -> __value
            __value = _static_131357902525008
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902526032
                __attrs_131357902526032 = _static_131358097278096
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251e58d0> name=None at 7778251e5890> -> __attrs_131357902527312
                __attrs_131357902527312 = _static_131357902526672

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">\r\n      ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902528080
                __attrs_131357902528080 = _static_131358097278096

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_131357902527824 = []
                __append_131357902527824 = __stream_131357902527824.append
                __append_131357902527824(u'Welcome')
                __msgid_131357902527824 = __re_whitespace(''.join(__stream_131357902527824)).strip()
                if __msgid_131357902527824:
                    __append(translate(__msgid_131357902527824, mapping=None, default=__msgid_131357902527824, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>,\r\n      ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902590608
                __attrs_131357902590608 = _static_131358097278096

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902590224
                __default_131357902590224 = _DEFAULT_MARKER

                # <Value u'python:view.get_user_fullname()' (8:25)> -> __cache_131357902528400
                __token = 301
                try:
                    __zt_tmp = __attrs_131357902590608
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357902528400 = _static_131358013585552('python', u'view.get_user_fullname()', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_user_fullname()' (8:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778251f5050> -> __condition
                __expression = __cache_131357902528400

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'User')
                else:
                    __content = __cache_131357902528400
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n    </h1>\r\n  ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_description(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902525584
                __attrs_131357902525584 = _static_131358097278096
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251f54d0> name=None at 7778251f5490> -> __attrs_131357902591824
                __attrs_131357902591824 = _static_131357902591184

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="documentDescription text-muted">\r\n      ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902593040
                __attrs_131357902593040 = _static_131358097278096

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902592656
                __default_131357902592656 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_date()' (14:25)> -> __cache_131357902592336
                __token = 524
                try:
                    __zt_tmp = __attrs_131357902593040
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357902592336 = _static_131358013585552('python', u'view.get_current_date()', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_date()' (14:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778251f59d0> -> __condition
                __expression = __cache_131357902592336

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Monday, 22 April 2026')
                else:
                    __content = __cache_131357902592336
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n      &mdash;\r\n      ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902594128
                __attrs_131357902594128 = _static_131358097278096

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902593680
                __default_131357902593680 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_time()' (16:25)> -> __cache_131357902593360
                __token = 626
                try:
                    __zt_tmp = __attrs_131357902594128
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357902593360 = _static_131358013585552('python', u'view.get_current_time()', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_time()' (16:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778251f5dd0> -> __condition
                __expression = __cache_131357902593360

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'14:30')
                else:
                    __content = __cache_131357902593360
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n    </div>\r\n  ')
            _slots = econtext[u'__slot_content_description'] = _deque((__fill_content_description, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902591888
                __attrs_131357902591888 = _static_131358097278096
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251f62d0> name=None at 7778251f6290> -> __attrs_131357902595728
                __attrs_131357902595728 = _static_131357902594768

                # <link ... (0:0)
                # --------------------------------------------------------
                __append(u'<link rel="stylesheet"')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902595472
                __default_131357902595472 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.css' (23:31)> -> __attr_href
                __token = 828
                try:
                    __zt_tmp = __attrs_131357902595728
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_131358013585552('string', u'${portal_url}/++resource++senaite.core.dashboard.css', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' />\r\n\r\n    <!-- Configuration for dashboard.js -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251f6a90> name=None at 7778251f6950> -> __attrs_131357902601936
                __attrs_131357902601936 = _static_131357902596752

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-config"          style="display:none"')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902599248
                __default_131357902599248 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7778251f7390> at 7778251f73d0> -> __attr_data_label_status
                __attr_data_label_status = u'Status'
                __attr_data_label_status = translate(__attr_data_label_status, default=__attr_data_label_status, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_data_label_status is not None):
                    __append((u'          data-label-status="%s"' % __attr_data_label_status))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902599632
                __default_131357902599632 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7778251f7510> at 7778251f7550> -> __attr_data_label_quick_actions
                __attr_data_label_quick_actions = u'Quick Actions'
                __attr_data_label_quick_actions = translate(__attr_data_label_quick_actions, default=__attr_data_label_quick_actions, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_data_label_quick_actions is not None):
                    __append((u'          data-label-quick-actions="%s"' % __attr_data_label_quick_actions))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902600016
                __default_131357902600016 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7778251f7690> at 7778251f76d0> -> __attr_data_label_timeline
                __attr_data_label_timeline = u'Show/hide timeline'
                __attr_data_label_timeline = translate(__attr_data_label_timeline, default=__attr_data_label_timeline, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_data_label_timeline is not None):
                    __append((u'          data-label-timeline="%s"' % __attr_data_label_timeline))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902600272
                __default_131357902600272 = _DEFAULT_MARKER

                # <Substitution u'string:${view/portal_url}/senaite-dashboard-data' (32:39)> -> __attr_data_base_url
                __token = 1274
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_base_url = _static_131358013585552('string', u'${view/portal_url}/senaite-dashboard-data', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_base_url = __quote(__attr_data_base_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_base_url is not None):
                    __append((u' data-base-url="%s"' % __attr_data_base_url))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902600528
                __default_131357902600528 = _DEFAULT_MARKER

                # <Substitution u'view/periodicity' (33:41)> -> __attr_data_periodicity
                __token = 1366
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_periodicity = _static_131358013585552('path', u'view/periodicity', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_periodicity = __quote(__attr_data_periodicity, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_periodicity is not None):
                    __append((u' data-periodicity="%s"' % __attr_data_periodicity))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902600784
                __default_131357902600784 = _DEFAULT_MARKER

                # <Substitution u"python:'true' if view.can_view_statistics() else 'false'" (34:43)> -> __attr_data_can_view_stats
                __token = 1429
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_can_view_stats = _static_131358013585552('python', u"'true' if view.can_view_statistics() else 'false'", econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_can_view_stats = __quote(__attr_data_can_view_stats, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_can_view_stats is not None):
                    __append((u' data-can-view-stats="%s"' % __attr_data_can_view_stats))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902601104
                __default_131357902601104 = _DEFAULT_MARKER

                # <Substitution u'view/portal_url' (35:38)> -> __attr_data_portal_url
                __token = 1528
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_portal_url = _static_131358013585552('path', u'view/portal_url', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_portal_url = __quote(__attr_data_portal_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_portal_url is not None):
                    __append((u' data-portal-url="%s"' % __attr_data_portal_url))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902601360
                __default_131357902601360 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_from)' (36:36)> -> __attr_data_date_from
                __token = 1585
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_from = _static_131358013585552('python', u'plone_view.toLocalizedTime(view.date_from)', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_date_from = __quote(__attr_data_date_from, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_from is not None):
                    __append((u' data-date-from="%s"' % __attr_data_date_from))

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902601616
                __default_131357902601616 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_to)' (37:33)> -> __attr_data_date_to
                __token = 1674
                try:
                    __zt_tmp = __attrs_131357902601936
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_to = _static_131358013585552('python', u'plone_view.toLocalizedTime(view.date_to)', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_date_to = __quote(__attr_data_date_to, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_to is not None):
                    __append((u' data-date-to="%s"' % __attr_data_date_to))
                __append(u'>\r\n    </div>\r\n\r\n    <!-- Status Cards + Quick Links (async) -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251f9090> name=None at 7778251f90d0> -> __attrs_131357902607504
                __attrs_131357902607504 = _static_131357902606480

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-overview" class="mt-4">\r\n      ')

                # <Static value=<_ast.Dict object at 0x7778251f9710> name=None at 7778251f9690> -> __attrs_131357902608720
                __attrs_131357902608720 = _static_131357902608144

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="text-muted">\r\n        ')

                # <Static value=<_ast.Dict object at 0x7778251f9b90> name=None at 7778251f9b50> -> __attrs_131357902609936
                __attrs_131357902609936 = _static_131357902609296

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\r\n        ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902610576
                __attrs_131357902610576 = _static_131358097278096

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_131357902610192 = []
                __append_131357902610192 = __stream_131357902610192.append
                __append_131357902610192(u'Loading...')
                __msgid_131357902610192 = __re_whitespace(''.join(__stream_131357902610192)).strip()
                if __msgid_131357902610192:
                    __append(translate(__msgid_131357902610192, mapping=None, default=__msgid_131357902610192, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Statistics Sections (async, permission-gated) -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902610832
                __attrs_131357902610832 = _static_131358097278096

                # <Value u'python:view.can_view_statistics()' (49:31)> -> __condition
                __token = 2096
                try:
                    __zt_tmp = __attrs_131357902610832
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_131358013585552('python', u'view.can_view_statistics()', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n      ')

                    # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902611728
                    __attrs_131357902611728 = _static_131358097278096
                    __backup_section_id_131357921771920 = get('section_id', __marker)

                    # <Value u"python:['analysisrequests', 'analyses', 'worksheets']" (50:34)> -> __iterator
                    __token = 2167
                    try:
                        __zt_tmp = __attrs_131357902611728
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_131358013585552('python', u"['analysisrequests', 'analyses', 'worksheets']", econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                    (__iterator, ____index_131357902611920, ) = getitem('repeat')(u'section_id', __iterator)
                    econtext['section_id'] = None
                    for __item in __iterator:
                        econtext['section_id'] = __item

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>\r\n        ')

                        # <Static value=<_ast.Dict object at 0x7778251fa7d0> name=None at 7778251fa790> -> __attrs_131357902613520
                        __attrs_131357902613520 = _static_131357902612432

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div              class="dashboard-section"')

                        # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902613200
                        __default_131357902613200 = _DEFAULT_MARKER

                        # <Substitution u'string:dashboard-section-${section_id}' (51:32)> -> __attr_id
                        __token = 2256
                        try:
                            __zt_tmp = __attrs_131357902613520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_131358013585552('string', u'dashboard-section-${section_id}', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>\r\n          ')

                        # <Static value=<_ast.Dict object at 0x7778251faed0> name=None at 7778251fae90> -> __attrs_131357902623120
                        __attrs_131357902623120 = _static_131357902614224

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-muted py-3">\r\n            ')

                        # <Static value=<_ast.Dict object at 0x7778251fd450> name=None at 7778251fd410> -> __attrs_131357902624464
                        __attrs_131357902624464 = _static_131357902623824

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\r\n            ')

                        # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902625104
                        __attrs_131357902625104 = _static_131358097278096

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                        __stream_131357902624784 = []
                        __append_131357902624784 = __stream_131357902624784.append
                        __append_131357902624784(u'Loading...')
                        __msgid_131357902624784 = __re_whitespace(''.join(__stream_131357902624784)).strip()
                        if __msgid_131357902624784:
                            __append(translate(__msgid_131357902624784, mapping=None, default=__msgid_131357902624784, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\r\n          </div>\r\n        </div>\r\n      </div>')
                        ____index_131357902611920 -= 1
                        if (____index_131357902611920 > 0):
                            __append('\n      ')
                    if (__backup_section_id_131357921771920 is __marker):
                        del econtext['section_id']
                    else:
                        econtext['section_id'] = __backup_section_id_131357921771920
                    __append(u'\r\n    ')
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7778251fa390> name=None at 7778251fa210> -> __attrs_131357902623440
                __attrs_131357902623440 = _static_131357902611344

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902613904
                __default_131357902613904 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.js' (61:32)> -> __attr_src
                __token = 2596
                try:
                    __zt_tmp = __attrs_131357902623440
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_131358013585552('string', u'${portal_url}/++resource++senaite.core.dashboard.js', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'></script>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357902626128
                __attrs_131357902626128 = _static_131358097278096

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357902626000
                __default_131357902626000 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (63:34)> -> __cache_131357902625680
                __token = 2703
                try:
                    __zt_tmp = __attrs_131357902626128
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357902625680 = _static_131358013585552('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (63:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778251fdc10> -> __condition
                __expression = __cache_131357902625680

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input/>')
                else:
                    __content = __cache_131357902625680
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (2:23)> -> __macro
            __token = 67
            try:
                __zt_tmp = __attrs_131357902525264
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_131358013585552('path', u'here/main_template/macros/master', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
            __token = 67
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_131357893909952 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_131357893909952
            __i18n_domain = __previous_i18n_domain_131357902525392
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }