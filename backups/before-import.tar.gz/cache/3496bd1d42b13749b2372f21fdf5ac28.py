# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/phone_display.pt'

__tokens = {173: (u'view/id', 5, 27), 200: (u' view/klas', 6, 17), 230: (u'e view/sty', 7, 16), 260: (u'le view/ti', 8, 15), 304: (u'view/value', 9, 26), 325: (u'view/value', 9, 47)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402356200592 = {}
_static_140402272508432 = __C2ZContextWrapper
_static_140402272508048 = __compile_zt_expr
_static_140402101717264 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402101815376 = {u'style': u'view/style', u'title': u'view/title', u'id': u'', u'class': u'', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e9660910> name=None at 7fb1e9660c10> -> __attrs_140402101863312
            __attrs_140402101863312 = _static_140402101717264
            __append(u'\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9678850> name=None at 7fb1e96789d0> -> __attrs_140402101813456
            __attrs_140402101813456 = _static_140402101815376

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101816016
            __default_140402101816016 = _DEFAULT_MARKER

            # <Substitution u'view/id' (5:27)> -> __attr_id
            __token = 173
            try:
                __zt_tmp = __attrs_140402101813456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'view/id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101816080
            __default_140402101816080 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (6:17)> -> __attr_class
            __token = 200
            try:
                __zt_tmp = __attrs_140402101813456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101814544
            __default_140402101814544 = _DEFAULT_MARKER

            # <Substitution u'view/style' (7:16)> -> __attr_style
            __token = 230
            try:
                __zt_tmp = __attrs_140402101813456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101814096
            __default_140402101814096 = _DEFAULT_MARKER

            # <Substitution u'view/title' (8:15)> -> __attr_title
            __token = 260
            try:
                __zt_tmp = __attrs_140402101813456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))
            __append(u'>\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101355728
            __attrs_140402101355728 = _static_140402356200592

            # <Value u'view/value' (9:26)> -> __condition
            __token = 304
            try:
                __zt_tmp = __attrs_140402101355728
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101355792
                __default_140402101355792 = _DEFAULT_MARKER

                # <Value u'view/value' (9:47)> -> __cache_140402101815696
                __token = 325
                try:
                    __zt_tmp = __attrs_140402101355728
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402101815696 = _static_140402272508048('path', u'view/value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/value' (9:47)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9678890> -> __condition
                __expression = __cache_140402101815696

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_140402101815696
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
            __append(u'\r\n  </span>\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }