# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/tabs.pt'

__tokens = {24: (u'view/groups | nothing', 1, 24), 84: (u' view/enable_form_tabbing | python:Tru', 2, 36), 164: (u"l view/default_fieldset_label | string:'Genera", 3, 38), 240: (u'ps python:bool(grou', 4, 25), 294: (u"ets python:[w for w in view.widgets.values() if w.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'descriptio", 5, 29), 458: (u'gets python:bool(default_wid', 6, 32), 588: (u'has_groups', 10, 22), 686: (u'python:enable_form_tabbing', 13, 22), 743: (u'string:${context/absolute_url}?enable_form_tabbing=0', 14, 28), 940: (u'python:not enable_form_tabbing', 20, 22), 1001: (u'string:${context/absolute_url}?enable_form_tabbing=1', 21, 28), 1233: (u'python: has_groups and enable_form_tabbing', 29, 21), 1376: (u'has_default_widgets', 33, 23), 1477: (u"python:'nav-link active'", 35, 31), 1421: (u'default_fieldset_label', 34, 22), 1700: (u'groups', 44, 26), 1784: (u'nocall:context/@@plone/normalizeString', 45, 37), 1860: (u' group/labe', 46, 35), 1908: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 47, 33), 2045: (u'me python:normalizeString(fieldset_na', 48, 32), 2116: (u'ors group/widgets/errors|not', 49, 28), 2176: (u"irst python:repeat['group'].", 50, 25), 2244: (u'ctive python:is_first and not has_default_w', 51, 32), 2324: (u'string:${fieldset_name}-tab', 52, 28), 2383: (u' string:#${fieldset_name', 53, 29), 2440: (u"s python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link", 54, 29), 2569: (u'fieldset_label', 55, 22), 2857: (u'has_default_widgets', 67, 24), 2912: (u'view/widgets/values|nothing', 68, 32), 2977: (u"python:widget.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'description',)", 69, 34), 3119: (u'widget/@@ploneform-render-widget', 70, 45), 3296: (u'has_groups', 75, 52), 3277: (u'groups', 75, 33), 3394: (u'nocall:context/@@plone/normalizeString', 77, 39), 3472: (u' group/labe', 78, 37), 3522: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 79, 35), 3661: (u'me python:normalizeString(fieldset_na', 80, 34), 3732: (u"rst python:repeat['group'].s", 81, 28), 3802: (u'tive python:is_first and not has_default_wi', 82, 35), 3881: (u"class python:('tab-pane active' if should_be_active else 'tab-pane') if enable_form_tabbing else 'd-", 83, 28), 4079: (u' pane_clas', 85, 32), 4021: (u'string:${fieldset_name}', 84, 30), 4132: (u't fieldset_na', 86, 39), 4190: (u'group/widgets/values', 87, 38), 4259: (u'widget/@@ploneform-render-widget', 88, 45)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402101736016 = {u'href': u'#', u'title': u'', }
_static_140402101776336 = {u'data-toggle': u'tab', u'href': u'string:#${fieldset_name}', u'role': u'tab', u'id': u'string:${fieldset_name}-tab', u'class': u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", }
_static_140402101718608 = {u'role': u'tablist', u'class': u'nav nav-tabs mb-2', }
_static_140402356200592 = {}
_static_140402272508048 = __compile_zt_expr
_static_140402101706384 = {u'data-toggle': u'tab', u'href': u'#default', u'role': u'tab', u'id': u'default-tab', u'class': u"python:'nav-link active'", }
_static_140402101720784 = {u'data-fieldset': u'fieldset_name', u'role': u'tabpanel', u'class': u'tab-pane', u'id': u'string:${fieldset_name}', }
_static_140402101737872 = {u'class': u'fas fa-expand', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402101718096 = {u'href': u'#', u'title': u'', }
_static_140402101736208 = {u'class': u'fas fa-compress', }
_static_140402101758160 = {u'role': u'presentation', u'class': u'nav-item', }
_static_140402101723280 = {u'role': u'tabpanel', u'class': u'tab-pane active', u'id': u'default', }
_static_140402101703760 = {u'role': u'presentation', u'class': u'nav-item', }
_static_140402102598928 = {u'class': u'd-flex flex-row-reverse', }
_static_140402101754192 = {u'class': u'tab-content', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101750288
            __attrs_140402101750288 = _static_140402356200592
            __backup_groups_140402101826832 = get('groups', __marker)

            # <Value u'view/groups | nothing' (1:24)> -> __value
            __token = 24
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/groups | nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['groups'] = __value
            __backup_enable_form_tabbing_140402101718416 = get('enable_form_tabbing', __marker)

            # <Value u'view/enable_form_tabbing | python:True' (2:36)> -> __value
            __token = 84
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/enable_form_tabbing | python:True', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['enable_form_tabbing'] = __value
            __backup_default_fieldset_label_140402102600848 = get('default_fieldset_label', __marker)

            # <Value u"view/default_fieldset_label | string:'General'" (3:38)> -> __value
            __token = 164
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u"view/default_fieldset_label | string:'General'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['default_fieldset_label'] = __value
            __backup_has_groups_140402101815824 = get('has_groups', __marker)

            # <Value u'python:bool(groups)' (4:25)> -> __value
            __token = 240
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'bool(groups)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['has_groups'] = __value
            __backup_default_widgets_140402101814352 = get('default_widgets', __marker)

            # <Value u"python:[w for w in view.widgets.values() if w.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'description')]" (5:29)> -> __value
            __token = 294
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"[w for w in view.widgets.values() if w.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'description')]", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['default_widgets'] = __value
            __backup_has_default_widgets_140402101814480 = get('has_default_widgets', __marker)

            # <Value u'python:bool(default_widgets)' (6:32)> -> __value
            __token = 458
            try:
                __zt_tmp = __attrs_140402101750288
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'bool(default_widgets)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['has_default_widgets'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\r\n\r\n  <!-- Tab view toggle -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9737d10> name=None at 7fb1e97370d0> -> __attrs_140402101715600
            __attrs_140402101715600 = _static_140402102598928

            # <Value u'has_groups' (10:22)> -> __condition
            __token = 588
            try:
                __zt_tmp = __attrs_140402101715600
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'has_groups', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="d-flex flex-row-reverse">\r\n    <!-- shows all contents on one page -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e9660c50> name=None at 7fb1e96608d0> -> __attrs_140402101718736
                __attrs_140402101718736 = _static_140402101718096

                # <Value u'python:enable_form_tabbing' (13:22)> -> __condition
                __token = 686
                try:
                    __zt_tmp = __attrs_140402101718736
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('python', u'enable_form_tabbing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101718288
                    __default_140402101718288 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}?enable_form_tabbing=0' (14:28)> -> __attr_href
                    __token = 743
                    try:
                        __zt_tmp = __attrs_140402101718736
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_140402272508048('string', u'${context/absolute_url}?enable_form_tabbing=0', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'        title="">\r\n      ')

                    # <Static value=<_ast.Dict object at 0x7fb1e9665990> name=None at 7fb1e9665b10> -> __attrs_140402101735888
                    __attrs_140402101735888 = _static_140402101737872

                    # <i ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<i class="fas fa-expand"></i>\r\n    </a>')
                __append(u'\r\n    <!-- shows contents in tabs -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e9665250> name=None at 7fb1e9665510> -> __attrs_140402101737424
                __attrs_140402101737424 = _static_140402101736016

                # <Value u'python:not enable_form_tabbing' (20:22)> -> __condition
                __token = 940
                try:
                    __zt_tmp = __attrs_140402101737424
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('python', u'not enable_form_tabbing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101738192
                    __default_140402101738192 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}?enable_form_tabbing=1' (21:28)> -> __attr_href
                    __token = 1001
                    try:
                        __zt_tmp = __attrs_140402101737424
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_140402272508048('string', u'${context/absolute_url}?enable_form_tabbing=1', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'        title="">\r\n      ')

                    # <Static value=<_ast.Dict object at 0x7fb1e9665310> name=None at 7fb1e9665f90> -> __attrs_140402101901136
                    __attrs_140402101901136 = _static_140402101736208

                    # <i ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<i class="fas fa-compress"></i>\r\n    </a>')
                __append(u'\r\n  </div>')
            __append(u'\r\n\r\n  <!-- navigation tabs -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9660e50> name=None at 7fb1e9660110> -> __attrs_140402101758736
            __attrs_140402101758736 = _static_140402101718608

            # <Value u'python: has_groups and enable_form_tabbing' (29:21)> -> __condition
            __token = 1233
            try:
                __zt_tmp = __attrs_140402101758736
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u' has_groups and enable_form_tabbing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-tabs mb-2" role="tablist">\r\n\r\n    <!-- primary tab -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e966a8d0> name=None at 7fb1e966a910> -> __attrs_140402101759568
                __attrs_140402101759568 = _static_140402101758160

                # <Value u'has_default_widgets' (33:23)> -> __condition
                __token = 1376
                try:
                    __zt_tmp = __attrs_140402101759568
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'has_default_widgets', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\r\n      ')

                    # <Static value=<_ast.Dict object at 0x7fb1e965de90> name=None at 7fb1e965d550> -> __attrs_140402101706512
                    __attrs_140402101706512 = _static_140402101706384

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a          id="default-tab"          href="#default"          data-toggle="tab"          role="tab"')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101703248
                    __default_140402101703248 = _DEFAULT_MARKER

                    # <Substitution u"python:'nav-link active'" (35:31)> -> __attr_class
                    __token = 1477
                    try:
                        __zt_tmp = __attrs_140402101706512
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_140402272508048('python', u"'nav-link active'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101755984
                    __default_140402101755984 = _DEFAULT_MARKER

                    # <Value u'default_fieldset_label' (34:22)> -> __cache_140402101757968
                    __token = 1421
                    try:
                        __zt_tmp = __attrs_140402101706512
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101757968 = _static_140402272508048('path', u'default_fieldset_label', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'default_fieldset_label' (34:22)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e966a690> -> __condition
                    __expression = __cache_140402101757968

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n        Label\r\n      ')
                    else:
                        __content = __cache_140402101757968
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>\r\n    </li>')
                __append(u'\r\n    <!-- secondary tabs -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e965d450> name=None at 7fb1e965d990> -> __attrs_140402101772688
                __attrs_140402101772688 = _static_140402101703760
                __backup_group_140402101744912 = get('group', __marker)

                # <Value u'groups' (44:26)> -> __iterator
                __token = 1700
                try:
                    __zt_tmp = __attrs_140402101772688
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_140402272508048('path', u'groups', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                (__iterator, ____index_140402101775568, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\r\n      ')

                    # <Static value=<_ast.Dict object at 0x7fb1e966efd0> name=None at 7fb1e966eed0> -> __attrs_140402101755088
                    __attrs_140402101755088 = _static_140402101776336
                    __backup_normalizeString_140402101742992 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (45:37)> -> __value
                    __token = 1784
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_140402101717328 = get('fieldset_label', __marker)

                    # <Value u'group/label' (46:35)> -> __value
                    __token = 1860
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('path', u'group/label', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_140402101738896 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (47:33)> -> __value
                    __token = 1908
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_140402101704976 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (48:32)> -> __value
                    __token = 2045
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_has_errors_140402101753936 = get('has_errors', __marker)

                    # <Value u'group/widgets/errors|nothing' (49:28)> -> __value
                    __token = 2116
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('path', u'group/widgets/errors|nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['has_errors'] = __value
                    __backup_is_first_140402101755472 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (50:25)> -> __value
                    __token = 2176
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u"repeat['group'].start", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_140402101754768 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (51:32)> -> __value
                    __token = 2244
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a          data-toggle="tab"          role="tab"')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101774736
                    __default_140402101774736 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}-tab' (52:28)> -> __attr_id
                    __token = 2324
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_140402272508048('string', u'${fieldset_name}-tab', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101775312
                    __default_140402101775312 = _DEFAULT_MARKER

                    # <Substitution u'string:#${fieldset_name}' (53:29)> -> __attr_href
                    __token = 2383
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_140402272508048('string', u'#${fieldset_name}', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101772880
                    __default_140402101772880 = _DEFAULT_MARKER

                    # <Substitution u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')" (54:29)> -> __attr_class
                    __token = 2440
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_140402272508048('python', u"has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101775760
                    __default_140402101775760 = _DEFAULT_MARKER

                    # <Value u'fieldset_label' (55:22)> -> __cache_140402101773328
                    __token = 2569
                    try:
                        __zt_tmp = __attrs_140402101755088
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101773328 = _static_140402272508048('path', u'fieldset_label', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'fieldset_label' (55:22)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e966e790> -> __condition
                    __expression = __cache_140402101773328

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n        Label\r\n      ')
                    else:
                        __content = __cache_140402101773328
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>')
                    if (__backup_should_be_active_140402101754768 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_140402101754768
                    if (__backup_is_first_140402101755472 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_140402101755472
                    if (__backup_has_errors_140402101753936 is __marker):
                        del econtext['has_errors']
                    else:
                        econtext['has_errors'] = __backup_has_errors_140402101753936
                    if (__backup_fieldset_name_140402101704976 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_140402101704976
                    if (__backup_fieldset_name_140402101738896 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_140402101738896
                    if (__backup_fieldset_label_140402101717328 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_140402101717328
                    if (__backup_normalizeString_140402101742992 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_140402101742992
                    __append(u'\r\n    </li>')
                    ____index_140402101775568 -= 1
                    if (____index_140402101775568 > 0):
                        __append('\n    ')
                if (__backup_group_140402101744912 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_140402101744912
                __append(u'\r\n  </ul>')
            __append(u'\r\n\r\n  <!-- tab content -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9669950> name=None at 7fb1e966a2d0> -> __attrs_140402101754896
            __attrs_140402101754896 = _static_140402101754192

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="tab-content">\r\n    <!-- Primary fieldsets -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e9662090> name=None at 7fb1e9662310> -> __attrs_140402101725328
            __attrs_140402101725328 = _static_140402101723280

            # <Value u'has_default_widgets' (67:24)> -> __condition
            __token = 2857
            try:
                __zt_tmp = __attrs_140402101725328
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'has_default_widgets', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="tab-pane active" id="default" role="tabpanel">\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101724944
                __attrs_140402101724944 = _static_140402356200592
                __backup_widget_140402101814864 = get('widget', __marker)

                # <Value u'view/widgets/values|nothing' (68:32)> -> __iterator
                __token = 2912
                try:
                    __zt_tmp = __attrs_140402101724944
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_140402272508048('path', u'view/widgets/values|nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                (__iterator, ____index_140402101726416, ) = getitem('repeat')(u'widget', __iterator)
                econtext['widget'] = None
                for __item in __iterator:
                    econtext['widget'] = __item
                    __append(u'\r\n        ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101720144
                    __attrs_140402101720144 = _static_140402356200592

                    # <Value u"python:widget.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'description',)" (69:34)> -> __condition
                    __token = 2977
                    try:
                        __zt_tmp = __attrs_140402101720144
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_140402272508048('python', u"widget.__name__ not in ('IBasic.title', 'IBasic.description', 'title', 'description',)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\r\n          ')

                        # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101719760
                        __attrs_140402101719760 = _static_140402356200592

                        # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101719504
                        __default_140402101719504 = _DEFAULT_MARKER

                        # <Value u'widget/@@ploneform-render-widget' (70:45)> -> __cache_140402101722640
                        __token = 3119
                        try:
                            __zt_tmp = __attrs_140402101719760
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_140402101722640 = _static_140402272508048('path', u'widget/@@ploneform-render-widget', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                        # <BinOp left=<Value u'widget/@@ploneform-render-widget' (70:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9661410> -> __condition
                        __expression = __cache_140402101722640

                        # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_140402101722640
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n        ')
                    __append(u'\r\n      ')
                    ____index_140402101726416 -= 1
                    if (____index_140402101726416 > 0):
                        __append('')
                if (__backup_widget_140402101814864 is __marker):
                    del econtext['widget']
                else:
                    econtext['widget'] = __backup_widget_140402101814864
                __append(u'\r\n    </div>')
            __append(u'\r\n    <!-- Secondary fieldsets -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101727120
            __attrs_140402101727120 = _static_140402356200592

            # <Value u'has_groups' (75:52)> -> __condition
            __token = 3296
            try:
                __zt_tmp = __attrs_140402101727120
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'has_groups', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:
                __backup_group_140402101742096 = get('group', __marker)

                # <Value u'groups' (75:33)> -> __iterator
                __token = 3277
                try:
                    __zt_tmp = __attrs_140402101727120
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_140402272508048('path', u'groups', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                (__iterator, ____index_140402101722256, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item
                    __append(u'\r\n      ')

                    # <Static value=<_ast.Dict object at 0x7fb1e96616d0> name=None at 7fb1e9661590> -> __attrs_140402101815248
                    __attrs_140402101815248 = _static_140402101720784
                    __backup_normalizeString_140402101755728 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (77:39)> -> __value
                    __token = 3394
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_140402101755664 = get('fieldset_label', __marker)

                    # <Value u'group/label' (78:37)> -> __value
                    __token = 3472
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('path', u'group/label', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_140402101726992 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (79:35)> -> __value
                    __token = 3522
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_140402101722896 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (80:34)> -> __value
                    __token = 3661
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_is_first_140402101719952 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (81:28)> -> __value
                    __token = 3732
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u"repeat['group'].start", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_140402101754960 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (82:35)> -> __value
                    __token = 3802
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value
                    __backup_pane_class_140402101723024 = get('pane_class', __marker)

                    # <Value u"python:('tab-pane active' if should_be_active else 'tab-pane') if enable_form_tabbing else 'd-block'" (83:28)> -> __value
                    __token = 3881
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_140402272508048('python', u"('tab-pane active' if should_be_active else 'tab-pane') if enable_form_tabbing else 'd-block'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    econtext['pane_class'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101719888
                    __default_140402101719888 = _DEFAULT_MARKER

                    # <Substitution u'pane_class' (85:32)> -> __attr_class
                    __token = 4079
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_140402272508048('path', u'pane_class', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'tab-pane', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u' role="tabpanel"')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101816912
                    __default_140402101816912 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}' (84:30)> -> __attr_id
                    __token = 4021
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_140402272508048('string', u'${fieldset_name}', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101816208
                    __default_140402101816208 = _DEFAULT_MARKER

                    # <Substitution u'fieldset_name' (86:39)> -> __attr_data_fieldset
                    __token = 4132
                    try:
                        __zt_tmp = __attrs_140402101815248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_fieldset = _static_140402272508048('path', u'fieldset_name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_data_fieldset = __quote(__attr_data_fieldset, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_fieldset is not None):
                        __append((u' data-fieldset="%s"' % __attr_data_fieldset))
                    __append(u'>\r\n        ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101969232
                    __attrs_140402101969232 = _static_140402356200592
                    __backup_widget_140402101815120 = get('widget', __marker)

                    # <Value u'group/widgets/values' (87:38)> -> __iterator
                    __token = 4190
                    try:
                        __zt_tmp = __attrs_140402101969232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_140402272508048('path', u'group/widgets/values', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    (__iterator, ____index_140402101972432, ) = getitem('repeat')(u'widget', __iterator)
                    econtext['widget'] = None
                    for __item in __iterator:
                        econtext['widget'] = __item
                        __append(u'\r\n          ')

                        # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101968976
                        __attrs_140402101968976 = _static_140402356200592

                        # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101972176
                        __default_140402101972176 = _DEFAULT_MARKER

                        # <Value u'widget/@@ploneform-render-widget' (88:45)> -> __cache_140402101971664
                        __token = 4259
                        try:
                            __zt_tmp = __attrs_140402101968976
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_140402101971664 = _static_140402272508048('path', u'widget/@@ploneform-render-widget', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                        # <BinOp left=<Value u'widget/@@ploneform-render-widget' (88:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e969ef10> -> __condition
                        __expression = __cache_140402101971664

                        # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_140402101971664
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n        ')
                        ____index_140402101972432 -= 1
                        if (____index_140402101972432 > 0):
                            __append('')
                    if (__backup_widget_140402101815120 is __marker):
                        del econtext['widget']
                    else:
                        econtext['widget'] = __backup_widget_140402101815120
                    __append(u'\r\n      </div>')
                    if (__backup_pane_class_140402101723024 is __marker):
                        del econtext['pane_class']
                    else:
                        econtext['pane_class'] = __backup_pane_class_140402101723024
                    if (__backup_should_be_active_140402101754960 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_140402101754960
                    if (__backup_is_first_140402101719952 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_140402101719952
                    if (__backup_fieldset_name_140402101722896 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_140402101722896
                    if (__backup_fieldset_name_140402101726992 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_140402101726992
                    if (__backup_fieldset_label_140402101755664 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_140402101755664
                    if (__backup_normalizeString_140402101755728 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_140402101755728
                    __append(u'\r\n    ')
                    ____index_140402101722256 -= 1
                    if (____index_140402101722256 > 0):
                        __append('')
                if (__backup_group_140402101742096 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_140402101742096
            __append(u'\r\n  </div>\r\n</div>')
            if (__backup_has_default_widgets_140402101814480 is __marker):
                del econtext['has_default_widgets']
            else:
                econtext['has_default_widgets'] = __backup_has_default_widgets_140402101814480
            if (__backup_default_widgets_140402101814352 is __marker):
                del econtext['default_widgets']
            else:
                econtext['default_widgets'] = __backup_default_widgets_140402101814352
            if (__backup_has_groups_140402101815824 is __marker):
                del econtext['has_groups']
            else:
                econtext['has_groups'] = __backup_has_groups_140402101815824
            if (__backup_default_fieldset_label_140402102600848 is __marker):
                del econtext['default_fieldset_label']
            else:
                econtext['default_fieldset_label'] = __backup_default_fieldset_label_140402102600848
            if (__backup_enable_form_tabbing_140402101718416 is __marker):
                del econtext['enable_form_tabbing']
            else:
                econtext['enable_form_tabbing'] = __backup_enable_form_tabbing_140402101718416
            if (__backup_groups_140402101826832 is __marker):
                del econtext['groups']
            else:
                econtext['groups'] = __backup_groups_140402101826832
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }