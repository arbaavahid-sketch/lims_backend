# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/portlets/templates/edit-manager-macros.pt'

__tokens = {146: (u'view/addable_portlets', 4, 29), 193: (u'portlets', 5, 23), 235: (u'view/context_url', 6, 31), 319: (u'view/referer', 8, 62), 580: (u'python: view.context_url()', 16, 45), 646: (u"python:request['ACTUAL_URL'].replace(view.context_url(), '')", 17, 36), 850: (u'portlets', 21, 35), 900: (u'string:${portlet/addview}', 22, 38), 957: (u'portlet/title', 23, 29), 1378: (u'view/portlets', 38, 26), 1466: (u'portlets', 40, 69), 1557: (u'portlets', 45, 31), 1611: (u"python:not portlet['visible'] and 'blockedPortlet' or ''", 46, 42), 1703: (u'string:managedPortlet portlet ${hiddenPortletClass}', 47, 33), 1800: (u' portlet/has', 48, 43), 1855: (u'e view/view_na', 49, 39), 1944: (u'context/@@authenticator/authenticator', 51, 66), 2014: (u'not:portlet/editview', 53, 27), 2071: (u'string:${portlet/editview}?referer=${view/url_quote_referer}', 54, 34), 2183: (u'portlet/title', 56, 26), 2402: (u'not:repeat/portlet/start', 61, 33), 2352: (u'portlet/up_url', 60, 86), 2502: (u'view/url_quote_referer', 62, 72), 2598: (u'view/key', 63, 68), 2681: (u'portlet/name', 64, 69), 2772: (u'view/view_name', 65, 73), 2835: (u'authenticator', 66, 43), 3037: (u'string:${portlet/name}-up', 69, 43), 3245: (u'not:repeat/portlet/end', 73, 33), 3193: (u'portlet/down_url', 72, 88), 3343: (u'view/url_quote_referer', 74, 72), 3439: (u'view/key', 75, 68), 3522: (u'portlet/name', 76, 69), 3613: (u'view/view_name', 77, 73), 3676: (u'authenticator', 78, 43), 3880: (u'string:${portlet/name}-down', 81, 43), 4085: (u'not: portlet/visible', 85, 33), 4033: (u'portlet/show_url', 84, 83), 4181: (u'view/url_quote_referer', 86, 72), 4277: (u'view/key', 87, 68), 4360: (u'portlet/name', 88, 69), 4451: (u'view/view_name', 89, 73), 4514: (u'authenticator', 90, 43), 4707: (u'string:${portlet/name}-show', 93, 43), 4909: (u'portlet/visible', 97, 33), 4857: (u'portlet/hide_url', 96, 83), 5000: (u'view/url_quote_referer', 98, 72), 5096: (u'view/key', 99, 68), 5179: (u'portlet/name', 100, 69), 5270: (u'view/view_name', 101, 73), 5333: (u'authenticator', 102, 43), 5528: (u'string:${portlet/name}-hide', 105, 43), 5685: (u'portlet/delete_url', 108, 90), 5779: (u'view/url_quote_referer', 109, 72), 5875: (u'view/key', 110, 68), 5958: (u'portlet/name', 111, 69), 6049: (u'view/view_name', 112, 73), 6112: (u'authenticator', 113, 43), 6310: (u'string:${portlet/name}-remove', 116, 43)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133987186683536 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/referer', }
_static_133987186637328 = {u'type': u'submit', u'class': u'standalone btn btn-sm btn-primary my-3', u'value': u'Add portlet', }
_static_133987186635984 = {u'value': u'string:${portlet/addview}', }
_static_133987276028048 = __compile_zt_expr
_static_133987184240976 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/url_quote_referer', }
_static_133987186869904 = {u'name': u':action', u'data-context-url': u'python: view.context_url()', u'class': u'add-portlet form-control form-control-sm', }
_static_133987186738768 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/url_quote_referer', }
_static_133987186666704 = {u'type': u'hidden', u'name': u'viewname', u'value': u'view/view_name', }
_static_133987185502224 = {u'action': u'portlet/delete_url', u'class': u'portlet-action delete mr-1', u'method': u'POST', }
_static_133987105725520 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/url_quote_referer', }
_static_133987180615504 = {u'href': u'string:${portlet/editview}?referer=${view/url_quote_referer}', u'class': u'', }
_static_133987186680528 = {u'action': u'#', u'method': u'post', }
_static_133987180597712 = {u'type': u'hidden', u'name': u'key', u'value': u'view/key', }
_static_133987185565456 = {u'action': u'portlet/show_url', u'class': u'portlet-action mr-1', u'method': u'POST', }
_static_133987180599056 = {u'type': u'hidden', u'name': u'name', u'value': u'portlet/name', }
_static_133987105763280 = {u'type': u'hidden', u'name': u'name', u'value': u'portlet/name', }
_static_133987186638800 = {u'value': u"python:request['ACTUAL_URL'].replace(view.context_url(), '')", }
_static_133987186811280 = {u'class': u'section', }
_static_133987185480976 = {u'type': u'submit', u'class': u'btn btn-sm btn-outline-primary', u'name': u'string:${portlet/name}-show', }
_static_133987105744976 = {u'type': u'hidden', u'name': u'name', u'value': u'portlet/name', }
_static_133987186667280 = {u'type': u'submit', u'class': u'btn btn-sm btn-outline-secondary', u'name': u'string:${portlet/name}-up', u'title': u'Move up', }
_static_133987184241872 = {u'action': u'portlet/down_url', u'class': u'portlet-action down mr-1', u'method': u'POST', }
_static_133987276028432 = __C2ZContextWrapper
_static_133987186841360 = {u'type': u'submit', u'class': u'btn btn-sm btn-outline-secondary', u'name': u'string:${portlet/name}-hide', }
_static_133987185563088 = {u'type': u'submit', u'class': u'btn btn-sm btn-outline-secondary', u'name': u'string:${portlet/name}-down', u'title': u'Move down', }
_static_133987185460560 = {u'type': u'hidden', u'name': u'viewname', u'value': u'view/view_name', }
_static_133987185482000 = {u'action': u'portlet/hide_url', u'class': u'portlet-action mr-1', u'method': u'POST', }
_static_133987185546256 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/url_quote_referer', }
_static_133987185540496 = {u'type': u'submit', u'class': u'btn btn-sm btn-outline-danger', u'name': u'string:${portlet/name}-remove', u'title': u'Remove', }
_static_133987185474128 = {u'action': u'portlet/up_url', u'class': u'portlet-action up mr-1', u'method': u'POST', }
_static_133987185377360 = {u'type': u'hidden', u'name': u'key', u'value': u'view/key', }
_static_133987185500432 = {u'type': u'hidden', u'name': u'referer', u'value': u'view/url_quote_referer', }
_static_133987105759312 = {u'type': u'hidden', u'name': u'key', u'value': u'view/key', }
_static_133987180614544 = {u'class': u'portletHeader mb-3', }
_static_133987359720592 = {}
_static_133987180772752 = {u'type': u'hidden', u'name': u'name', u'value': u'portlet/name', }
_static_133987105827152 = {u'type': u'hidden', u'name': u'viewname', u'value': u'view/view_name', }
_static_133987186869456 = {u'class': u'hiddenStructure', }
_static_133987186681168 = {u'class': u'portletAssignments', }
_static_133987180770896 = {u'type': u'hidden', u'name': u'viewname', u'value': u'view/view_name', }
_static_133987180734352 = {u'data-portlethash': u'portlet/hash', u'class': u'string:managedPortlet portlet ${hiddenPortletClass}', u'data-viewname': u'view/view_name', }
_static_133987185475472 = {u'class': u'managedPortletActions input-group', }
_static_133987105723920 = {u'type': u'hidden', u'name': u'key', u'value': u'view/key', }
_static_133987186866448 = {u'type': u'hidden', u'name': u'name', u'value': u'portlet/name', }
_static_133987186866832 = {u'type': u'hidden', u'name': u'viewname', u'value': u'view/view_name', }
_static_133987186737424 = {u'type': u'hidden', u'name': u'key', u'value': u'view/key', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_portlet_add_form(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc52aca190> name=None at 79dc52aca3d0> -> __attrs_133987186683600
            __attrs_133987186683600 = _static_133987186811280
            __previous_i18n_domain_133987186681424 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="section">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79dc52aaa2d0> name=None at 79dc52aaa510> -> __attrs_133987186683664
            __attrs_133987186683664 = _static_133987186680528
            __backup_portlets_133987180804880 = get('portlets', __marker)

            # <Value u'view/addable_portlets' (4:29)> -> __value
            __token = 146
            try:
                __zt_tmp = __attrs_133987186683664
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/addable_portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['portlets'] = __value

            # <Value u'portlets' (5:23)> -> __condition
            __token = 193
            try:
                __zt_tmp = __attrs_133987186683664
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if __condition:

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form method="post"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186680144
                __default_133987186680144 = _DEFAULT_MARKER

                # <Substitution u'view/context_url' (6:31)> -> __attr_action
                __token = 235
                try:
                    __zt_tmp = __attrs_133987186683664
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_action = _static_133987276028048('path', u'view/context_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_action = __quote(__attr_action, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_action is not None):
                    __append((u' action="%s"' % __attr_action))
                __append(u'>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52aaae90> name=None at 79dc52aaa9d0> -> __attrs_133987186868432
                __attrs_133987186868432 = _static_133987186683536

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="referer"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186871952
                __default_133987186871952 = _DEFAULT_MARKER

                # <Substitution u'view/referer' (8:62)> -> __attr_value
                __token = 319
                try:
                    __zt_tmp = __attrs_133987186868432
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('path', u'view/referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52ad84d0> name=None at 79dc52ad8650> -> __attrs_133987186869584
                __attrs_133987186869584 = _static_133987186869456

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="hiddenStructure">')
                __stream_133987186869136 = []
                __append_133987186869136 = __stream_133987186869136.append
                __append_133987186869136(u'\r\n      Add portlet\r\n    ')
                __msgid_133987186869136 = __re_whitespace(''.join(__stream_133987186869136)).strip()
                if u'label_add_portlet':
                    __append(translate(u'label_add_portlet', mapping=None, default=__msgid_133987186869136, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52ad8690> name=None at 79dc52ad8450> -> __attrs_133987186871504
                __attrs_133987186871504 = _static_133987186869904

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select name=":action" class="add-portlet form-control form-control-sm"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186871120
                __default_133987186871120 = _DEFAULT_MARKER

                # <Substitution u'python: view.context_url()' (16:45)> -> __attr_data_context_url
                __token = 580
                try:
                    __zt_tmp = __attrs_133987186871504
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_context_url = _static_133987276028048('python', u' view.context_url()', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_context_url = __quote(__attr_data_context_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_context_url is not None):
                    __append((u' data-context-url="%s"' % __attr_data_context_url))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52a9ffd0> name=None at 79dc52a9fc10> -> __attrs_133987186638736
                __attrs_133987186638736 = _static_133987186638800

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186638352
                __default_133987186638352 = _DEFAULT_MARKER

                # <Substitution u"python:request['ACTUAL_URL'].replace(view.context_url(), '')" (17:36)> -> __attr_value
                __token = 646
                try:
                    __zt_tmp = __attrs_133987186638736
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('python', u"request['ACTUAL_URL'].replace(view.context_url(), '')", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'>')
                __stream_133987186636816 = []
                __append_133987186636816 = __stream_133987186636816.append
                __append_133987186636816(u'\r\n        Add portlet&hellip;\r\n      ')
                __msgid_133987186636816 = __re_whitespace(''.join(__stream_133987186636816)).strip()
                if u'label_add_portlet_ellipsis':
                    __append(translate(u'label_add_portlet_ellipsis', mapping=None, default=__msgid_133987186636816, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</option>\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186637584
                __attrs_133987186637584 = _static_133987359720592
                __backup_portlet_133987140596688 = get('portlet', __marker)

                # <Value u'portlets' (21:35)> -> __iterator
                __token = 850
                try:
                    __zt_tmp = __attrs_133987186637584
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                (__iterator, ____index_133987186636112, ) = getitem('repeat')(u'portlet', __iterator)
                econtext['portlet'] = None
                for __item in __iterator:
                    econtext['portlet'] = __item
                    __append(u'\r\n        ')

                    # <Static value=<_ast.Dict object at 0x79dc52a9f4d0> name=None at 79dc52a9fc90> -> __attrs_133987186634896
                    __attrs_133987186634896 = _static_133987186635984

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186636624
                    __default_133987186636624 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/addview}' (22:38)> -> __attr_value
                    __token = 900
                    try:
                        __zt_tmp = __attrs_133987186634896
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('string', u'${portlet/addview}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186636688
                    __default_133987186636688 = _DEFAULT_MARKER

                    # <Value u'portlet/title' (23:29)> -> __cache_133987186635728
                    __token = 957
                    try:
                        __zt_tmp = __attrs_133987186634896
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987186635728 = _static_133987276028048('path', u'portlet/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'portlet/title' (23:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52a9fdd0> -> __condition
                    __expression = __cache_133987186635728

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133987186635728
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>\r\n      ')
                    ____index_133987186636112 -= 1
                    if (____index_133987186636112 > 0):
                        __append('')
                if (__backup_portlet_133987140596688 is __marker):
                    del econtext['portlet']
                else:
                    econtext['portlet'] = __backup_portlet_133987140596688
                __append(u'\r\n    </select>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79dc52a9fa10> name=None at 79dc52a9f9d0> -> __attrs_133987180594192
                __attrs_133987180594192 = _static_133987186637328

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input class="standalone btn btn-sm btn-primary my-3"             type="submit"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180597136
                __default_133987180597136 = _DEFAULT_MARKER

                # <Translate msgid=u'label_add_portlet' node=<_ast.Str object at 0x79dc5172c590> at 79dc52864150> -> __attr_value
                __attr_value = u'Add portlet'
                __attr_value = translate(u'label_add_portlet', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_value is not None):
                    __append((u'             value="%s"' % __attr_value))
                __append(u'/>\r\n\r\n  </form>')
            if (__backup_portlets_133987180804880 is __marker):
                del econtext['portlets']
            else:
                econtext['portlets'] = __backup_portlets_133987180804880
            __append(u'\r\n</div>')
            __i18n_domain = __previous_i18n_domain_133987186681424
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_current_portlets_list(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc52aaa550> name=None at 79dc52aaaad0> -> __attrs_133987180597200
            __attrs_133987180597200 = _static_133987186681168
            __backup_portlets_133987185485136 = get('portlets', __marker)

            # <Value u'view/portlets' (38:26)> -> __value
            __token = 1378
            try:
                __zt_tmp = __attrs_133987180597200
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133987276028048('path', u'view/portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            econtext['portlets'] = __value
            __previous_i18n_domain_133987180595472 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portletAssignments">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987180596816
            __attrs_133987180596816 = _static_133987359720592

            # <Value u'portlets' (40:69)> -> __condition
            __token = 1466
            try:
                __zt_tmp = __attrs_133987180596816
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            if __condition:

                # <h4 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h4>')
                __stream_133987180593360 = []
                __append_133987180593360 = __stream_133987180593360.append
                __append_133987180593360(u'\r\n    Portlets assigned here\r\n  ')
                __msgid_133987180593360 = __re_whitespace(''.join(__stream_133987180593360)).strip()
                if u'heading_portlets_assigned_here':
                    __append(translate(u'heading_portlets_assigned_here', mapping=None, default=__msgid_133987180593360, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h4>')
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987180594128
            __attrs_133987180594128 = _static_133987359720592

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\r\n    ')

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987180594640
            __attrs_133987180594640 = _static_133987359720592
            __backup_portlet_133987184223952 = get('portlet', __marker)

            # <Value u'portlets' (45:31)> -> __iterator
            __token = 1557
            try:
                __zt_tmp = __attrs_133987180594640
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_133987276028048('path', u'portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            (__iterator, ____index_133987185475792, ) = getitem('repeat')(u'portlet', __iterator)
            econtext['portlet'] = None
            for __item in __iterator:
                econtext['portlet'] = __item
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc524fe790> name=None at 79dc52984b10> -> __attrs_133987186778896
                __attrs_133987186778896 = _static_133987180734352
                __backup_hiddenPortletClass_133987140590416 = get('hiddenPortletClass', __marker)

                # <Value u"python:not portlet['visible'] and 'blockedPortlet' or ''" (46:42)> -> __value
                __token = 1611
                try:
                    __zt_tmp = __attrs_133987186778896
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133987276028048('python', u"not portlet['visible'] and 'blockedPortlet' or ''", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                econtext['hiddenPortletClass'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180735952
                __default_133987180735952 = _DEFAULT_MARKER

                # <Substitution u'string:managedPortlet portlet ${hiddenPortletClass}' (47:33)> -> __attr_class
                __token = 1703
                try:
                    __zt_tmp = __attrs_133987186778896
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_133987276028048('string', u'managedPortlet portlet ${hiddenPortletClass}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180732752
                __default_133987180732752 = _DEFAULT_MARKER

                # <Substitution u'portlet/hash' (48:43)> -> __attr_data_portlethash
                __token = 1800
                try:
                    __zt_tmp = __attrs_133987186778896
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_portlethash = _static_133987276028048('path', u'portlet/hash', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_portlethash = __quote(__attr_data_portlethash, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_portlethash is not None):
                    __append((u' data-portlethash="%s"' % __attr_data_portlethash))

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186781904
                __default_133987186781904 = _DEFAULT_MARKER

                # <Substitution u'view/view_name' (49:39)> -> __attr_data_viewname
                __token = 1855
                try:
                    __zt_tmp = __attrs_133987186778896
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_viewname = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_data_viewname = __quote(__attr_data_viewname, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_viewname is not None):
                    __append((u' data-viewname="%s"' % __attr_data_viewname))
                __append(u'>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc524e1390> name=None at 79dc524e1810> -> __attrs_133987180614608
                __attrs_133987180614608 = _static_133987180614544
                __backup_authenticator_133987180772816 = get('authenticator', __marker)

                # <Value u'context/@@authenticator/authenticator' (51:66)> -> __value
                __token = 1944
                try:
                    __zt_tmp = __attrs_133987180614608
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133987276028048('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                econtext['authenticator'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="portletHeader mb-3">\r\n\r\n          ')

                # <Static value=<_ast.Dict object at 0x79dc524e1750> name=None at 79dc524e1410> -> __attrs_133987185474960
                __attrs_133987185474960 = _static_133987180615504

                # <Negate value=<Value u'not:portlet/editview' (53:27)> at 79dc52983510> -> __cache_133987185472784

                # <Value u'not:portlet/editview' (53:27)> -> __cache_133987185472784
                __token = 2014
                try:
                    __zt_tmp = __attrs_133987185474960
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987185472784 = _static_133987276028048('not', u'portlet/editview', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __cache_133987185472784 = not __cache_133987185472784
                __condition = __cache_133987185472784
                if __condition:

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a              class=""')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185472336
                    __default_133987185472336 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/editview}?referer=${view/url_quote_referer}' (54:34)> -> __attr_href
                    __token = 2071
                    try:
                        __zt_tmp = __attrs_133987185474960
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133987276028048('string', u'${portlet/editview}?referer=${view/url_quote_referer}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))
                    __append(u'>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180614992
                __default_133987180614992 = _DEFAULT_MARKER

                # <Value u'portlet/title' (56:26)> -> __cache_133987180616080
                __token = 2183
                try:
                    __zt_tmp = __attrs_133987185474960
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987180616080 = _static_133987276028048('path', u'portlet/title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'portlet/title' (56:26)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc524e1590> -> __condition
                __expression = __cache_133987180616080

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_133987180616080
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __condition = __cache_133987185472784
                if __condition:
                    __append(u'</a>')
                __append(u'\r\n\r\n          ')

                # <Static value=<_ast.Dict object at 0x79dc52983f90> name=None at 79dc52983f10> -> __attrs_133987185473552
                __attrs_133987185473552 = _static_133987185475472

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="managedPortletActions input-group">\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x79dc52983a50> name=None at 79dc52983090> -> __attrs_133987184238992
                __attrs_133987184238992 = _static_133987185474128

                # <Value u'not:repeat/portlet/start' (61:33)> -> __condition
                __token = 2402
                try:
                    __zt_tmp = __attrs_133987184238992
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('not', u'repeat/portlet/start', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form class="portlet-action up mr-1" method="POST"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184240592
                    __default_133987184240592 = _DEFAULT_MARKER

                    # <Substitution u'portlet/up_url' (60:86)> -> __attr_action
                    __token = 2352
                    try:
                        __zt_tmp = __attrs_133987184238992
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('path', u'portlet/up_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52856950> name=None at 79dc52856fd0> -> __attrs_133987184239760
                    __attrs_133987184239760 = _static_133987184240976

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="referer"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184239440
                    __default_133987184239440 = _DEFAULT_MARKER

                    # <Substitution u'view/url_quote_referer' (62:72)> -> __attr_value
                    __token = 2502
                    try:
                        __zt_tmp = __attrs_133987184239760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/url_quote_referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5296c050> name=None at 79dc52856790> -> __attrs_133987105745680
                    __attrs_133987105745680 = _static_133987185377360

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="key"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105743504
                    __default_133987105743504 = _DEFAULT_MARKER

                    # <Substitution u'view/key' (63:68)> -> __attr_value
                    __token = 2598
                    try:
                        __zt_tmp = __attrs_133987105745680
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/key', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd7a850> name=None at 79dc4dd7a650> -> __attrs_133987105743888
                    __attrs_133987105743888 = _static_133987105744976

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="name"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105746064
                    __default_133987105746064 = _DEFAULT_MARKER

                    # <Substitution u'portlet/name' (64:69)> -> __attr_value
                    __token = 2681
                    try:
                        __zt_tmp = __attrs_133987105743888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'portlet/name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52aa6cd0> name=None at 79dc52aa67d0> -> __attrs_133987186666448
                    __attrs_133987186666448 = _static_133987186666704

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="viewname"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186664848
                    __default_133987186664848 = _DEFAULT_MARKER

                    # <Substitution u'view/view_name' (65:73)> -> __attr_value
                    __token = 2772
                    try:
                        __zt_tmp = __attrs_133987186666448
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186663760
                    __attrs_133987186663760 = _static_133987359720592

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186667408
                    __default_133987186667408 = _DEFAULT_MARKER

                    # <Value u'authenticator' (66:43)> -> __cache_133987186665616
                    __token = 2835
                    try:
                        __zt_tmp = __attrs_133987186663760
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987186665616 = _static_133987276028048('path', u'authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'authenticator' (66:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52aa6b90> -> __condition
                    __expression = __cache_133987186665616

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_133987186665616
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52aa6f10> name=None at 79dc52aa61d0> -> __attrs_133987185547344
                    __attrs_133987185547344 = _static_133987186667280

                    # <button ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<button')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185545744
                    __default_133987185545744 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x79dc52aa6550> at 79dc52aa6790> -> __attr_title
                    __attr_title = u'Move up'
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u' type="submit"                       class="btn btn-sm btn-outline-secondary"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185548112
                    __default_133987185548112 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/name}-up' (69:43)> -> __attr_name
                    __token = 3037
                    try:
                        __zt_tmp = __attrs_133987185547344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_133987276028048('string', u'${portlet/name}-up', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))
                    __append(u'>&#9650;</button>\r\n            </form>')
                __append(u'\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x79dc52856cd0> name=None at 79dc4dd7a0d0> -> __attrs_133987185549264
                __attrs_133987185549264 = _static_133987184241872

                # <Value u'not:repeat/portlet/end' (73:33)> -> __condition
                __token = 3245
                try:
                    __zt_tmp = __attrs_133987185549264
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('not', u'repeat/portlet/end', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form class="portlet-action down mr-1" method="POST"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185549072
                    __default_133987185549072 = _DEFAULT_MARKER

                    # <Substitution u'portlet/down_url' (72:88)> -> __attr_action
                    __token = 3193
                    try:
                        __zt_tmp = __attrs_133987185549264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('path', u'portlet/down_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52995410> name=None at 79dc52995650> -> __attrs_133987105762704
                    __attrs_133987105762704 = _static_133987185546256

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="referer"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105760080
                    __default_133987105760080 = _DEFAULT_MARKER

                    # <Substitution u'view/url_quote_referer' (74:72)> -> __attr_value
                    __token = 3343
                    try:
                        __zt_tmp = __attrs_133987105762704
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/url_quote_referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd7e050> name=None at 79dc4dd7ed10> -> __attrs_133987105762448
                    __attrs_133987105762448 = _static_133987105759312

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="key"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105761488
                    __default_133987105761488 = _DEFAULT_MARKER

                    # <Substitution u'view/key' (75:68)> -> __attr_value
                    __token = 3439
                    try:
                        __zt_tmp = __attrs_133987105762448
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/key', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd7efd0> name=None at 79dc4dd7e2d0> -> __attrs_133987105825040
                    __attrs_133987105825040 = _static_133987105763280

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="name"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105828368
                    __default_133987105828368 = _DEFAULT_MARKER

                    # <Substitution u'portlet/name' (76:69)> -> __attr_value
                    __token = 3522
                    try:
                        __zt_tmp = __attrs_133987105825040
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'portlet/name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd8e950> name=None at 79dc4dd8e750> -> __attrs_133987105826128
                    __attrs_133987105826128 = _static_133987105827152

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="viewname"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105825680
                    __default_133987105825680 = _DEFAULT_MARKER

                    # <Substitution u'view/view_name' (77:73)> -> __attr_value
                    __token = 3613
                    try:
                        __zt_tmp = __attrs_133987105826128
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185563856
                    __attrs_133987185563856 = _static_133987359720592

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185565328
                    __default_133987185565328 = _DEFAULT_MARKER

                    # <Value u'authenticator' (78:43)> -> __cache_133987105825232
                    __token = 3676
                    try:
                        __zt_tmp = __attrs_133987185563856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987105825232 = _static_133987276028048('path', u'authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'authenticator' (78:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc4dd8e5d0> -> __condition
                    __expression = __cache_133987105825232

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_133987105825232
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc529995d0> name=None at 79dc529992d0> -> __attrs_133987185563536
                    __attrs_133987185563536 = _static_133987185563088

                    # <button ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<button')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185564560
                    __default_133987185564560 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x79dc52999950> at 79dc52999c90> -> __attr_title
                    __attr_title = u'Move down'
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u' type="submit"                       class="btn btn-sm btn-outline-secondary"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185564624
                    __default_133987185564624 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/name}-down' (81:43)> -> __attr_name
                    __token = 3880
                    try:
                        __zt_tmp = __attrs_133987185563536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_133987276028048('string', u'${portlet/name}-down', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))
                    __append(u'>&#9660;</button>\r\n            </form>')
                __append(u'\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x79dc52999f10> name=None at 79dc52999b50> -> __attrs_133987423784592
                __attrs_133987423784592 = _static_133987185565456

                # <Value u'not: portlet/visible' (85:33)> -> __condition
                __token = 4085
                try:
                    __zt_tmp = __attrs_133987423784592
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('not', u' portlet/visible', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form class="portlet-action mr-1" method="POST"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186799376
                    __default_133987186799376 = _DEFAULT_MARKER

                    # <Substitution u'portlet/show_url' (84:83)> -> __attr_action
                    __token = 4033
                    try:
                        __zt_tmp = __attrs_133987423784592
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('path', u'portlet/show_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd75c50> name=None at 79dc4dd75ad0> -> __attrs_133987105724496
                    __attrs_133987105724496 = _static_133987105725520

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="referer"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105723088
                    __default_133987105723088 = _DEFAULT_MARKER

                    # <Substitution u'view/url_quote_referer' (86:72)> -> __attr_value
                    __token = 4181
                    try:
                        __zt_tmp = __attrs_133987105724496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/url_quote_referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc4dd75610> name=None at 79dc4dd757d0> -> __attrs_133987105723024
                    __attrs_133987105723024 = _static_133987105723920

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="key"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987105726288
                    __default_133987105726288 = _DEFAULT_MARKER

                    # <Substitution u'view/key' (87:68)> -> __attr_value
                    __token = 4277
                    try:
                        __zt_tmp = __attrs_133987105723024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/key', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52507d90> name=None at 79dc52507ed0> -> __attrs_133987180771280
                    __attrs_133987180771280 = _static_133987180772752

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="name"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180771216
                    __default_133987180771216 = _DEFAULT_MARKER

                    # <Substitution u'portlet/name' (88:69)> -> __attr_value
                    __token = 4360
                    try:
                        __zt_tmp = __attrs_133987180771280
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'portlet/name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52507650> name=None at 79dc52507410> -> __attrs_133987180772432
                    __attrs_133987180772432 = _static_133987180770896

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="viewname"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180772240
                    __default_133987180772240 = _DEFAULT_MARKER

                    # <Substitution u'view/view_name' (89:73)> -> __attr_value
                    __token = 4451
                    try:
                        __zt_tmp = __attrs_133987180772432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185482960
                    __attrs_133987185482960 = _static_133987359720592

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185481744
                    __default_133987185481744 = _DEFAULT_MARKER

                    # <Value u'authenticator' (90:43)> -> __cache_133987185481616
                    __token = 4514
                    try:
                        __zt_tmp = __attrs_133987185482960
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987185481616 = _static_133987276028048('path', u'authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'authenticator' (90:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52985850> -> __condition
                    __expression = __cache_133987185481616

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_133987185481616
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52985510> name=None at 79dc52985410> -> __attrs_133987185481104
                    __attrs_133987185481104 = _static_133987185480976

                    # <button ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<button type="submit"                       class="btn btn-sm btn-outline-primary"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185480848
                    __default_133987185480848 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/name}-show' (93:43)> -> __attr_name
                    __token = 4707
                    try:
                        __zt_tmp = __attrs_133987185481104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_133987276028048('string', u'${portlet/name}-show', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))
                    __append(u'>')
                    __stream_133987185481424 = []
                    __append_133987185481424 = __stream_133987185481424.append
                    __append_133987185481424(u'Show')
                    __msgid_133987185481424 = __re_whitespace(''.join(__stream_133987185481424)).strip()
                    if u'label_show_item':
                        __append(translate(u'label_show_item', mapping=None, default=__msgid_133987185481424, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</button>\r\n            </form>')
                __append(u'\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x79dc52985910> name=None at 79dc52985c90> -> __attrs_133987185480464
                __attrs_133987185480464 = _static_133987185482000

                # <Value u'portlet/visible' (97:33)> -> __condition
                __token = 4909
                try:
                    __zt_tmp = __attrs_133987185480464
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'portlet/visible', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form class="portlet-action mr-1" method="POST"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185480400
                    __default_133987185480400 = _DEFAULT_MARKER

                    # <Substitution u'portlet/hide_url' (96:83)> -> __attr_action
                    __token = 4857
                    try:
                        __zt_tmp = __attrs_133987185480464
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('path', u'portlet/hide_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab8650> name=None at 79dc52ab8b10> -> __attrs_133987186739856
                    __attrs_133987186739856 = _static_133987186738768

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="referer"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186739664
                    __default_133987186739664 = _DEFAULT_MARKER

                    # <Substitution u'view/url_quote_referer' (98:72)> -> __attr_value
                    __token = 5000
                    try:
                        __zt_tmp = __attrs_133987186739856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/url_quote_referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ab8110> name=None at 79dc52ab82d0> -> __attrs_133987186866576
                    __attrs_133987186866576 = _static_133987186737424

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="key"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186867472
                    __default_133987186867472 = _DEFAULT_MARKER

                    # <Substitution u'view/key' (99:68)> -> __attr_value
                    __token = 5096
                    try:
                        __zt_tmp = __attrs_133987186866576
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/key', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ad7910> name=None at 79dc52ad7e90> -> __attrs_133987186868048
                    __attrs_133987186868048 = _static_133987186866448

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="name"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186868112
                    __default_133987186868112 = _DEFAULT_MARKER

                    # <Substitution u'portlet/name' (100:69)> -> __attr_value
                    __token = 5179
                    try:
                        __zt_tmp = __attrs_133987186868048
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'portlet/name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ad7a90> name=None at 79dc52ad74d0> -> __attrs_133987186840144
                    __attrs_133987186840144 = _static_133987186866832

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="viewname"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186841872
                    __default_133987186841872 = _DEFAULT_MARKER

                    # <Substitution u'view/view_name' (101:73)> -> __attr_value
                    __token = 5270
                    try:
                        __zt_tmp = __attrs_133987186840144
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186843216
                    __attrs_133987186843216 = _static_133987359720592

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186841104
                    __default_133987186841104 = _DEFAULT_MARKER

                    # <Value u'authenticator' (102:43)> -> __cache_133987186842576
                    __token = 5333
                    try:
                        __zt_tmp = __attrs_133987186843216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133987186842576 = _static_133987276028048('path', u'authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'authenticator' (102:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52ad1790> -> __condition
                    __expression = __cache_133987186842576

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_133987186842576
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79dc52ad1710> name=None at 79dc52ad1fd0> -> __attrs_133987185500240
                    __attrs_133987185500240 = _static_133987186841360

                    # <button ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<button type="submit"                       class="btn btn-sm btn-outline-secondary"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185502864
                    __default_133987185502864 = _DEFAULT_MARKER

                    # <Substitution u'string:${portlet/name}-hide' (105:43)> -> __attr_name
                    __token = 5528
                    try:
                        __zt_tmp = __attrs_133987185500240
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_133987276028048('string', u'${portlet/name}-hide', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))
                    __append(u'>')
                    __stream_133987186843280 = []
                    __append_133987186843280 = __stream_133987186843280.append
                    __append_133987186843280(u'Hide')
                    __msgid_133987186843280 = __re_whitespace(''.join(__stream_133987186843280)).strip()
                    if u'label_hide_item':
                        __append(translate(u'label_hide_item', mapping=None, default=__msgid_133987186843280, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</button>\r\n            </form>')
                __append(u'\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x79dc5298a810> name=None at 79dc52ad7250> -> __attrs_133987185500816
                __attrs_133987185500816 = _static_133987185502224

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form class="portlet-action delete mr-1" method="POST"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185501712
                __default_133987185501712 = _DEFAULT_MARKER

                # <Substitution u'portlet/delete_url' (108:90)> -> __attr_action
                __token = 5685
                try:
                    __zt_tmp = __attrs_133987185500816
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_action = _static_133987276028048('path', u'portlet/delete_url', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_action is not None):
                    __append((u' action="%s"' % __attr_action))
                __append(u'>\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc5298a110> name=None at 79dc5298a590> -> __attrs_133987180600272
                __attrs_133987180600272 = _static_133987185500432

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="referer"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180599312
                __default_133987180599312 = _DEFAULT_MARKER

                # <Substitution u'view/url_quote_referer' (109:72)> -> __attr_value
                __token = 5779
                try:
                    __zt_tmp = __attrs_133987180600272
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('path', u'view/url_quote_referer', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc524dd1d0> name=None at 79dc524dd5d0> -> __attrs_133987180598224
                __attrs_133987180598224 = _static_133987180597712

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="key"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987180597392
                __default_133987180597392 = _DEFAULT_MARKER

                # <Substitution u'view/key' (110:68)> -> __attr_value
                __token = 5875
                try:
                    __zt_tmp = __attrs_133987180598224
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('path', u'view/key', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc524dd710> name=None at 79dc524dd390> -> __attrs_133987185461136
                __attrs_133987185461136 = _static_133987180599056

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="name"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185461264
                __default_133987185461264 = _DEFAULT_MARKER

                # <Substitution u'portlet/name' (111:69)> -> __attr_value
                __token = 5958
                try:
                    __zt_tmp = __attrs_133987185461136
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('path', u'portlet/name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52980550> name=None at 79dc52980710> -> __attrs_133987185463120
                __attrs_133987185463120 = _static_133987185460560

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="viewname"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185460624
                __default_133987185460624 = _DEFAULT_MARKER

                # <Substitution u'view/view_name' (112:73)> -> __attr_value
                __token = 6049
                try:
                    __zt_tmp = __attrs_133987185463120
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_133987276028048('path', u'view/view_name', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185462544
                __attrs_133987185462544 = _static_133987359720592

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185459280
                __default_133987185459280 = _DEFAULT_MARKER

                # <Value u'authenticator' (113:43)> -> __cache_133987185462736
                __token = 6112
                try:
                    __zt_tmp = __attrs_133987185462544
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987185462736 = _static_133987276028048('path', u'authenticator', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'authenticator' (113:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52980990> -> __condition
                __expression = __cache_133987185462736

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span/>')
                else:
                    __content = __cache_133987185462736
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n              ')

                # <Static value=<_ast.Dict object at 0x79dc52993d90> name=None at 79dc52993110> -> __attrs_133987185541072
                __attrs_133987185541072 = _static_133987185540496

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185538448
                __default_133987185538448 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x79dc52993ad0> at 79dc52993b10> -> __attr_title
                __attr_title = u'Remove'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u' type="submit"                       class="btn btn-sm btn-outline-danger"')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185538704
                __default_133987185538704 = _DEFAULT_MARKER

                # <Substitution u'string:${portlet/name}-remove' (116:43)> -> __attr_name
                __token = 6310
                try:
                    __zt_tmp = __attrs_133987185541072
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_133987276028048('string', u'${portlet/name}-remove', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))
                __append(u'>&times;</button>\r\n            </form>\r\n          </span>\r\n        </div>')
                if (__backup_authenticator_133987180772816 is __marker):
                    del econtext['authenticator']
                else:
                    econtext['authenticator'] = __backup_authenticator_133987180772816
                __append(u'\r\n      </div>')
                if (__backup_hiddenPortletClass_133987140590416 is __marker):
                    del econtext['hiddenPortletClass']
                else:
                    econtext['hiddenPortletClass'] = __backup_hiddenPortletClass_133987140590416
                __append(u'\r\n    ')
                ____index_133987185475792 -= 1
                if (____index_133987185475792 > 0):
                    __append('')
            if (__backup_portlet_133987184223952 is __marker):
                del econtext['portlet']
            else:
                econtext['portlet'] = __backup_portlet_133987184223952
            __append(u'\r\n  </div>\r\n\r\n</div>')
            __i18n_domain = __previous_i18n_domain_133987180595472
            if (__backup_portlets_133987185485136 is __marker):
                del econtext['portlets']
            else:
                econtext['portlets'] = __backup_portlets_133987185485136
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_portlet_add_form(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n\r\n')
            __token = None
            render_current_portlets_list(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_portlet_add_form': render_portlet_add_form, u'render_current_portlets_list': render_current_portlets_list, 'render': render, }