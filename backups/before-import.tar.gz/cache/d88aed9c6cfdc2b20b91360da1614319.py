# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.textfield-1.3.7-py2.7.egg/plone/app/textfield/widget_textarea_display.pt'

__tokens = {151: (u"python:getattr(view.field, 'output_mime_type', None) == 'text/x-html-safe'", 4, 33), 282: (u'view/id', 6, 29), 322: (u' view/klas', 7, 31), 365: (u'e view/sty', 8, 30), 408: (u'le view/ti', 9, 29), 450: (u'ang view/', 10, 27), 494: (u'lick view/on', 11, 29), 544: (u'click view/ondb', 12, 31), 598: (u'sedown view/onmo', 13, 31), 651: (u'mouseup view/o', 14, 28), 704: (u'ouseover view/on', 15, 29), 759: (u'mousemove view/o', 16, 28), 813: (u'onmouseout view', 17, 26), 866: (u' onkeypress vie', 18, 25), 918: (u'   onkeydown v', 19, 23), 967: (u'      onkeyu', 20, 20), 1027: (u'view/value', 21, 21), 1077: (u'safe_structure', 22, 27), 1124: (u'view/value', 23, 31), 1193: (u'not: safe_structure', 25, 23), 1235: (u'view/value', 26, 21)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402356200592 = {}
_static_140402272508432 = __C2ZContextWrapper
_static_140402272508048 = __compile_zt_expr
_static_140402101357712 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402101356560 = {u'lang': u'view/lang', u'style': u'view/style', u'onmousedown': u'view/onmousedown', u'onmouseup': u'view/onmouseup', u'onmouseout': u'view/onmouseout', u'title': u'view/title', u'onkeypress': u'view/onkeypress', u'onkeydown': u'view/onkeydown', u'class': u'', u'onmousemove': u'view/onmousemove', u'onmouseover': u'view/onmouseover', u'onclick': u'view/onclick', u'onkeyup': u'view/onkeyup', u'ondblclick': u'view/ondblclick', u'id': u'', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e9608c90> name=None at 7fb1e9608950> -> __attrs_140402101356304
            __attrs_140402101356304 = _static_140402101357712
            __backup_safe_structure_140402101075088 = get('safe_structure', __marker)

            # <Value u"python:getattr(view.field, 'output_mime_type', None) == 'text/x-html-safe'" (4:33)> -> __value
            __token = 151
            try:
                __zt_tmp = __attrs_140402101356304
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"getattr(view.field, 'output_mime_type', None) == 'text/x-html-safe'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['safe_structure'] = __value
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e9608810> name=None at 7fb1e9608d10> -> __attrs_140402101457808
            __attrs_140402101457808 = _static_140402101356560

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101365200
            __default_140402101365200 = _DEFAULT_MARKER

            # <Substitution u'view/id' (6:29)> -> __attr_id
            __token = 282
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'view/id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101366480
            __default_140402101366480 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (7:31)> -> __attr_class
            __token = 322
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101366416
            __default_140402101366416 = _DEFAULT_MARKER

            # <Substitution u'view/style' (8:30)> -> __attr_style
            __token = 365
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101363472
            __default_140402101363472 = _DEFAULT_MARKER

            # <Substitution u'view/title' (9:29)> -> __attr_title
            __token = 408
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101362768
            __default_140402101362768 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (10:27)> -> __attr_lang
            __token = 450
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_140402272508048('path', u'view/lang', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101365136
            __default_140402101365136 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (11:29)> -> __attr_onclick
            __token = 494
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_140402272508048('path', u'view/onclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101458832
            __default_140402101458832 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (12:31)> -> __attr_ondblclick
            __token = 544
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_140402272508048('path', u'view/ondblclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101458512
            __default_140402101458512 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (13:31)> -> __attr_onmousedown
            __token = 598
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_140402272508048('path', u'view/onmousedown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101459472
            __default_140402101459472 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (14:28)> -> __attr_onmouseup
            __token = 651
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_140402272508048('path', u'view/onmouseup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101458000
            __default_140402101458000 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (15:29)> -> __attr_onmouseover
            __token = 704
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_140402272508048('path', u'view/onmouseover', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101460816
            __default_140402101460816 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (16:28)> -> __attr_onmousemove
            __token = 759
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_140402272508048('path', u'view/onmousemove', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101458640
            __default_140402101458640 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (17:26)> -> __attr_onmouseout
            __token = 813
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_140402272508048('path', u'view/onmouseout', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101458192
            __default_140402101458192 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (18:25)> -> __attr_onkeypress
            __token = 866
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_140402272508048('path', u'view/onkeypress', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101459216
            __default_140402101459216 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (19:23)> -> __attr_onkeydown
            __token = 918
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_140402272508048('path', u'view/onkeydown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101459024
            __default_140402101459024 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (20:20)> -> __attr_onkeyup
            __token = 967
            try:
                __zt_tmp = __attrs_140402101457808
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_140402272508048('path', u'view/onkeyup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))
            __append(u'>')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101135568
            __attrs_140402101135568 = _static_140402356200592

            # <Value u'view/value' (21:21)> -> __condition
            __token = 1027
            try:
                __zt_tmp = __attrs_140402101135568
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101135376
                __attrs_140402101135376 = _static_140402356200592

                # <Value u'safe_structure' (22:27)> -> __condition
                __token = 1077
                try:
                    __zt_tmp = __attrs_140402101135376
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'safe_structure', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101136848
                    __default_140402101136848 = _DEFAULT_MARKER

                    # <Value u'view/value' (23:31)> -> __cache_140402101137168
                    __token = 1124
                    try:
                        __zt_tmp = __attrs_140402101135376
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101137168 = _static_140402272508048('path', u'view/value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/value' (23:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e95d2bd0> -> __condition
                    __expression = __cache_140402101137168

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_140402101137168
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101133520
                __attrs_140402101133520 = _static_140402356200592

                # <Value u'not: safe_structure' (25:23)> -> __condition
                __token = 1193
                try:
                    __zt_tmp = __attrs_140402101133520
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('not', u' safe_structure', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101134736
                    __default_140402101134736 = _DEFAULT_MARKER

                    # <Value u'view/value' (26:21)> -> __cache_140402101136528
                    __token = 1235
                    try:
                        __zt_tmp = __attrs_140402101133520
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101136528 = _static_140402272508048('path', u'view/value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/value' (26:21)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e95d2e90> -> __condition
                    __expression = __cache_140402101136528

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_140402101136528
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
            __append(u'</span>\n')
            if (__backup_safe_structure_140402101075088 is __marker):
                del econtext['safe_structure']
            else:
                econtext['safe_structure'] = __backup_safe_structure_140402101075088
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }