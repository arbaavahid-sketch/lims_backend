# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/user/templates/account-panel.pt'

__tokens = {371: (u'${view/label}', 9, 37), 373: (u'view/label', 9, 39), 505: (u'view/prepareObjectTabs', 14, 34), 577: (u'view_actions', 15, 46), 697: (u'action/selected|nothing', 18, 32), 607: (u'contentview-${action/id}', 16, 15), 621: (u'action/id', 16, 29), 650: (u'${action/url}', 17, 17), 652: (u'action/url', 17, 19), 756: (u"python:'nav-link' + (' active' if selected else '')", 19, 33), 838: (u'${action/title}', 20, 29), 840: (u'action/title', 20, 31), 906: (u'context/@@ploneform-macros/titlelessform', 24, 24), 906: (u'context/@@ploneform-macros/titlelessform', 24, 24), 257: (u'context/main_template/macros/master', 6, 23), 257: (u'context/main_template/macros/master', 6, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948418207568 = __compile_zt_expr
_static_136948327644688 = u'master'
_static_136948501914768 = {}
_static_136948309603408 = {u'href': u'${action/url}', u'id': u'contentview-${action/id}', u'class': u"python:'nav-link' + (' active' if selected else '')", }
_static_136948309603088 = u'titlelessform'
_static_136948418228496 = __C2ZContextWrapper
_static_136948309585488 = {u'class': u'nav-item', }
_static_136948309582480 = {u'class': u'documentFirstHeading', }
_static_136948309584080 = {u'class': u'nav nav-tabs', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948409535248
            __attrs_136948409535248 = _static_136948501914768
            __previous_i18n_domain_136948309792976 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_136948305507664 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7c8dc46bfe10> name=None at 7c8dc3632150> -> __value
            __value = _static_136948327644688
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309794768
                __attrs_136948309794768 = _static_136948501914768
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3586290> name=None at 7c8dc3586250> -> __attrs_136948309583120
                __attrs_136948309583120 = _static_136948309582480

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')

                # <Interpolation value=<Substitution u'${view/label}' (9:37)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc35b9390> -> __content_136948571129056
                __token = 371
                __token = 373
                try:
                    __zt_tmp = __attrs_136948309583120
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_136948571129056 = _static_136948418207568('path', u'view/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __content_136948571129056 = __quote(__content_136948571129056, '\x00', '&#0;', None, None)
                __content_136948571129056 = __content_136948571129056
                if (__content_136948571129056 is None):
                    pass
                else:
                    if (__content_136948571129056 is None):
                        __content_136948571129056 = None
                    else:
                        __tt = type(__content_136948571129056)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_136948571129056 = unicode(__content_136948571129056)
                        else:
                            if (__tt is str):
                                __content_136948571129056 = decode(__content_136948571129056)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_136948571129056 = __content_136948571129056.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_136948571129056)
                                        __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                    else:
                                        __content_136948571129056 = __content_136948571129056()
                if (__content_136948571129056 is not None):
                    __append(__content_136948571129056)
                __append(u'</h1>\n  ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309583184
                __attrs_136948309583184 = _static_136948501914768
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc35868d0> name=None at 7c8dc3586890> -> __attrs_136948309584656
                __attrs_136948309584656 = _static_136948309584080
                __backup_view_actions_136948310996432 = get('view_actions', __marker)

                # <Value u'view/prepareObjectTabs' (14:34)> -> __value
                __token = 505
                try:
                    __zt_tmp = __attrs_136948309584656
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'view/prepareObjectTabs', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['view_actions'] = __value

                # <nav ... (0:0)
                # --------------------------------------------------------
                __append(u'<nav class="nav nav-tabs">\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc3586e50> name=None at 7c8dc3586e10> -> __attrs_136948309602512
                __attrs_136948309602512 = _static_136948309585488
                __backup_action_136948400577680 = get('action', __marker)

                # <Value u'view_actions' (15:46)> -> __iterator
                __token = 577
                try:
                    __zt_tmp = __attrs_136948309602512
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'view_actions', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948309602704, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dc358b450> name=None at 7c8dc358b3d0> -> __attrs_136948309605008
                    __attrs_136948309605008 = _static_136948309603408
                    __backup_selected_136948329070480 = get('selected', __marker)

                    # <Value u'action/selected|nothing' (18:32)> -> __value
                    __token = 697
                    try:
                        __zt_tmp = __attrs_136948309605008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'action/selected|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['selected'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309604112
                    __default_136948309604112 = _DEFAULT_MARKER

                    # <Interpolation value=<Substitution u'contentview-${action/id}' (16:15)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc358b690> -> __attr_id
                    __token = 607
                    __token = 621
                    try:
                        __zt_tmp = __attrs_136948309605008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_136948418207568('path', u'action/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    __attr_id = ('%s%s' % (u'contentview-', (__attr_id if (__attr_id is not None) else ''), ))
                    if (__attr_id is None):
                        pass
                    else:
                        if (__attr_id is _DEFAULT_MARKER):
                            __attr_id = None
                        else:
                            __tt = type(__attr_id)
                            if ((__tt is int) or (__tt is float) or (__tt is long)):
                                __attr_id = unicode(__attr_id)
                            else:
                                if (__tt is str):
                                    __attr_id = decode(__attr_id)
                                else:
                                    if (__tt is not unicode):
                                        try:
                                            __attr_id = __attr_id.__html__
                                        except get('AttributeError', AttributeError):
                                            __converted = convert(__attr_id)
                                            __attr_id = (unicode(__attr_id) if (__attr_id is __converted) else __converted)
                                        else:
                                            __attr_id = __attr_id()
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309604432
                    __default_136948309604432 = _DEFAULT_MARKER

                    # <Interpolation value=<Substitution u'${action/url}' (17:17)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc358b7d0> -> __attr_href
                    __token = 650
                    __token = 652
                    try:
                        __zt_tmp = __attrs_136948309605008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_136948418207568('path', u'action/url', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    __attr_href = __attr_href
                    if (__attr_href is None):
                        pass
                    else:
                        if (__attr_href is _DEFAULT_MARKER):
                            __attr_href = None
                        else:
                            __tt = type(__attr_href)
                            if ((__tt is int) or (__tt is float) or (__tt is long)):
                                __attr_href = unicode(__attr_href)
                            else:
                                if (__tt is str):
                                    __attr_href = decode(__attr_href)
                                else:
                                    if (__tt is not unicode):
                                        try:
                                            __attr_href = __attr_href.__html__
                                        except get('AttributeError', AttributeError):
                                            __converted = convert(__attr_href)
                                            __attr_href = (unicode(__attr_href) if (__attr_href is __converted) else __converted)
                                        else:
                                            __attr_href = __attr_href()
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309604688
                    __default_136948309604688 = _DEFAULT_MARKER

                    # <Substitution u"python:'nav-link' + (' active' if selected else '')" (19:33)> -> __attr_class
                    __token = 756
                    try:
                        __zt_tmp = __attrs_136948309605008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136948418207568('python', u"'nav-link' + (' active' if selected else '')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')
                    __stream_136948309603216 = []
                    __append_136948309603216 = __stream_136948309603216.append

                    # <Interpolation value=<Substitution u'${action/title}' (20:29)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc358bc10> -> __content_136948571129056
                    __token = 838
                    __token = 840
                    try:
                        __zt_tmp = __attrs_136948309605008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __content_136948571129056 = _static_136948418207568('path', u'action/title', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __content_136948571129056 = __quote(__content_136948571129056, '\x00', '&#0;', None, None)
                    __content_136948571129056 = __content_136948571129056
                    if (__content_136948571129056 is None):
                        pass
                    else:
                        if (__content_136948571129056 is None):
                            __content_136948571129056 = None
                        else:
                            __tt = type(__content_136948571129056)
                            if ((__tt is int) or (__tt is float) or (__tt is long)):
                                __content_136948571129056 = unicode(__content_136948571129056)
                            else:
                                if (__tt is str):
                                    __content_136948571129056 = decode(__content_136948571129056)
                                else:
                                    if (__tt is not unicode):
                                        try:
                                            __content_136948571129056 = __content_136948571129056.__html__
                                        except get('AttributeError', AttributeError):
                                            __converted = convert(__content_136948571129056)
                                            __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                        else:
                                            __content_136948571129056 = __content_136948571129056()
                    if (__content_136948571129056 is not None):
                        __append_136948309603216(__content_136948571129056)
                    __msgid_136948309603216 = __re_whitespace(''.join(__stream_136948309603216)).strip()
                    if __msgid_136948309603216:
                        __append(translate(__msgid_136948309603216, mapping=None, default=__msgid_136948309603216, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</a>')
                    if (__backup_selected_136948329070480 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_136948329070480
                    __append(u'\n      </li>')
                    ____index_136948309602704 -= 1
                    if (____index_136948309602704 > 0):
                        __append('\n      ')
                if (__backup_action_136948400577680 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_136948400577680
                __append(u'\n    </nav>')
                if (__backup_view_actions_136948310996432 is __marker):
                    del econtext['view_actions']
                else:
                    econtext['view_actions'] = __backup_view_actions_136948310996432
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309605520
                __attrs_136948309605520 = _static_136948501914768
                __backup_macroname_136948305471520 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x7c8dc358b310> name=None at 7c8dc358b2d0> -> __value
                __value = _static_136948309603088
                econtext['macroname'] = __value

                # <Value u'context/@@ploneform-macros/titlelessform' (24:24)> -> __macro
                __token = 906
                try:
                    __zt_tmp = __attrs_136948309605520
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_136948418207568('path', u'context/@@ploneform-macros/titlelessform', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __token = 906
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_136948305471520 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_136948305471520
                __append(u'\n  ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'context/main_template/macros/master' (6:23)> -> __macro
            __token = 257
            try:
                __zt_tmp = __attrs_136948409535248
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_136948418207568('path', u'context/main_template/macros/master', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __token = 257
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_136948305507664 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_136948305507664
            __i18n_domain = __previous_i18n_domain_136948309792976
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }