# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/macros.pt'

__tokens = {7470: (u'view/widgets/values', 152, 48), 377: (u'view/label | nothing', 11, 27), 412: (u'view/label', 11, 62), 7009: (u'show_default_label|nothing', 142, 45), 7074: (u' has_groups|nothin', 143, 36), 7333: (u'has_default_widgets', 150, 36), 8003: (u'has_groups', 163, 64), 7984: (u'groups', 163, 45), 8149: (u'nocall:context/@@plone/normalizeString', 166, 51), 8239: (u' group/labe', 167, 49), 8301: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 168, 47), 8452: (u'me python:normalizeString(fieldset_na', 169, 46), 8535: (u"rst python:repeat['group'].s", 170, 40), 8617: (u'tive python:is_first and not has_default_wi', 171, 47), 8708: (u"class python:'tab-pane active' if should_be_active else 'tab", 172, 40), 8890: (u' pane_clas', 174, 44), 8820: (u'string:${fieldset_name}', 173, 42), 8955: (u't fieldset_na', 175, 51), 9070: (u'group/description|nothing', 178, 52), 9135: (u'group_description', 179, 37), 9200: (u'group_description', 180, 45), 9370: (u'group/widgets/errors', 185, 50), 9439: (u'python:False', 186, 46), 9503: (u'errors', 187, 49), 9617: (u'not:nocall:error/widget', 189, 42), 9693: (u'error/render', 190, 50), 9827: (u'nocall:group', 194, 44), 9890: (u'context/@@ploneform-macros/widget_rendering', 195, 46), 9890: (u'context/@@ploneform-macros/widget_rendering', 195, 46), 10333: (u'view/actions/values|nothing', 209, 55), 10406: (u'view/actions/values', 210, 42), 10491: (u'action/render', 211, 62), 7676: (u'widget/@@ploneform-render-widget', 155, 61), 578: (u'view/status', 17, 35), 629: (u" python:view.widgets.errors or status == getattr(view, 'formErrorsMessage', None", 18, 37), 723: (u'status', 18, 131), 796: (u'has_error', 19, 63), 947: (u'status', 23, 29), 1032: (u'not:has_error', 25, 56), 1187: (u'status', 29, 29), 1315: (u'view/widgets/errors', 34, 35), 1347: (u'errors', 34, 67), 1392: (u'errors', 35, 35), 1492: (u'not:nocall:error/widget', 37, 32), 1558: (u'error/render', 38, 40), 1740: (u'view/groups|nothing', 45, 35), 1793: (u'python:bool(groups)', 46, 31), 1849: (u'groups', 47, 34), 1899: (u'group/widgets/errors', 48, 40), 1957: (u'errors', 49, 35), 2004: (u'errors', 50, 38), 2103: (u'not:nocall:error/widget', 52, 31), 2168: (u'error/render', 53, 39), 2407: (u'view/description | nothing', 60, 37), 2464: (u'description', 61, 28), 2514: (u'description|default', 62, 36), 2856: (u'view/groups | nothing', 70, 33), 2915: (u' view/form_name | nothin', 71, 35), 2978: (u's view/css_class | strin', 72, 35), 3053: (u'el view/default_fieldset_label | form_n', 73, 46), 3140: (u'ing view/enable_form_tabbing | python:', 74, 42), 3231: (u'tion view/enable_unload_protection|python', 75, 46), 3318: (u"ction python:enable_unload_protection and 'pat-formunload", 76, 38), 3414: (u'groups python:bool(', 77, 30), 3474: (u"tabbing python:(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autoto", 78, 31), 3603: (u'_widgets python:view.widgets', 79, 33), 3679: (u't_widgets python:bool(defaul', 80, 36), 3754: (u'ault_label python:has_groups and default_fieldset_label and len(vi', 81, 34), 3867: (u'ew_name_raw python:view.__name__ or request.getURL().sp', 82, 33), 3965: (u"rm_view_name python:'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split", 83, 28), 4247: (u"s python:'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_nam", 87, 34), 4131: (u'view/action|request/getURL', 85, 37), 4469: (u'hod view/method|string:', 89, 33), 4197: (u' view/enctyp', 86, 37), 4423: (u'id view', 88, 30), 4669: (u'python: has_groups and enable_form_tabbing', 95, 29), 4897: (u'view/widgets/errors', 100, 39), 4836: (u'has_default_widgets', 99, 31), 5014: (u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'", 102, 39), 4950: (u'default_fieldset_label', 101, 30), 5359: (u'groups', 112, 34), 5451: (u'nocall:context/@@plone/normalizeString', 113, 45), 5535: (u' group/labe', 114, 43), 5591: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 115, 41), 5736: (u'me python:normalizeString(fieldset_na', 116, 40), 5815: (u'ors group/widgets/errors|not', 117, 36), 5883: (u"irst python:repeat['group'].", 118, 33), 5959: (u'ctive python:is_first and not has_default_w', 119, 40), 6047: (u'string:${fieldset_name}-tab', 120, 36), 6114: (u' string:#${fieldset_name', 121, 37), 6179: (u"s python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link", 122, 37), 6316: (u'fieldset_label', 123, 30), 6652: (u'request/fieldset | python:None', 135, 48), 6719: (u'python:has_groups and enable_form_tabbing and current_fieldset is not None', 136, 34), 6837: (u'current_fieldset', 137, 41), 10662: (u'view/enableCSRFProtection|nothing', 217, 36), 10742: (u'context/@@authenticator/authenticator', 218, 44)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525731872848 = {u'class': u'formControls', }
_static_124525979686032 = {}
_static_124525731919504 = {u'class': u'field error fieldErrorBox', }
_static_124525732570064 = {u'role': u'alert', u'class': u'portalMessage alert error', }
_static_124525732566096 = {u'role': u'presentation', u'class': u'nav-item', }
_static_124525521692368 = {u'role': u'tablist', u'class': u'nav nav-tabs', }
_static_124525521692112 = {u'role': u'presentation', u'class': u'nav-item', }
_static_124525731921296 = u'widget_rendering'
_static_124525521676752 = {u'class': u'field error alert alert-warning', }
_static_124525521703440 = {u'role': u'tabpanel', u'class': u'tab-pane active', u'id': u'default', }
_static_124525732899536 = {u'name': u'edit_form', u'id': u'view/id', u'data-pat-autotoc': u'levels: legend; section: fieldset; className: autotabs', u'method': u'post', u'action': u'.', u'class': u'rowlike enableUnloadProtection', u'enctype': u'view/enctype', }
_static_124525521822992 = {u'class': u'form', }
_static_124525732653200 = {u'role': u'status', u'class': u'portalMessage info', }
_static_124525521695824 = {u'class': u'field error alert alert-warning', }
_static_124525812517264 = {u'class': u'discreet text-secondary', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525731875088 = {u'type': u'submit', }
_static_124525896001680 = __compile_zt_expr
_static_124525521826192 = {u'data-fieldset': u'fieldset_name', u'role': u'tabpanel', u'class': u'tab-pane', u'id': u'string:${fieldset_name}', }
_static_124525732521424 = {u'data-toggle': u'tab', u'href': u'#default', u'role': u'tab', u'id': u'default-tab', u'class': u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'", }
_static_124525521684880 = {u'type': u'hidden', u'name': u'fieldset', u'value': u'current_fieldset', }
_static_124525732568144 = {u'data-toggle': u'tab', u'href': u'string:#${fieldset_name}', u'role': u'tab', u'id': u'string:${fieldset_name}-tab', u'class': u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", }
_static_124525521784592 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_124525521685008 = {u'class': u'tab-content', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_rendering(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_field = econtext[u'__slot_field'].pop()
        except:
            __slot_field = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521706000
            __attrs_124525521706000 = _static_124525979686032
            __append(u'\r\n                    ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521826064
            __attrs_124525521826064 = _static_124525979686032
            __backup_widget_124525521676304 = get('widget', __marker)

            # <Value u'view/widgets/values' (152:48)> -> __iterator
            __token = 7470
            try:
                __zt_tmp = __attrs_124525521826064
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_124525896001680('path', u'view/widgets/values', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            (__iterator, ____index_124525521827216, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\r\n                      ')
                if (__slot_field is None):

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521825872
                    __attrs_124525521825872 = _static_124525979686032
                    __append(u'\r\n                        ')
                    __token = None
                    render_field(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    __append(u'\r\n                      ')
                else:
                    __slot_field(__stream, econtext.copy(), rcontext)
                __append(u'\r\n                    ')
                ____index_124525521827216 -= 1
                if (____index_124525521827216 > 0):
                    __append('')
            if (__backup_widget_124525521676304 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_124525521676304
            __append(u'\r\n                  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_form(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_title = econtext[u'__slot_title'].pop()
        except:
            __slot_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7e6510> name=None at 71415b7e63d0> -> __attrs_124525521821840
            __attrs_124525521821840 = _static_124525521822992

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form">\r\n\r\n      ')
            if (__slot_title is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732514320
                __attrs_124525732514320 = _static_124525979686032
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732512720
                __attrs_124525732512720 = _static_124525979686032

                # <Value u'view/label | nothing' (11:27)> -> __condition
                __token = 377
                try:
                    __zt_tmp = __attrs_124525732512720
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'view/label | nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <h3 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h3>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732514448
                    __default_124525732514448 = _DEFAULT_MARKER

                    # <Value u'view/label' (11:62)> -> __cache_124525732513936
                    __token = 412
                    try:
                        __zt_tmp = __attrs_124525732512720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732513936 = _static_124525896001680('path', u'view/label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/label' (11:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680d47d0> -> __condition
                    __expression = __cache_124525732513936

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_124525732513936
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</h3>')
                __append(u'\r\n      ')
            else:
                __slot_title(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n      ')
            __token = None
            render_titlelessform(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_fields(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521685520
            __attrs_124525521685520 = _static_124525979686032
            __backup_show_default_label_124525732497488 = get('show_default_label', __marker)

            # <Value u'show_default_label|nothing' (142:45)> -> __value
            __token = 7009
            try:
                __zt_tmp = __attrs_124525521685520
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'show_default_label|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['show_default_label'] = __value
            __backup_has_groups_124525734888400 = get('has_groups', __marker)

            # <Value u'has_groups|nothing' (143:36)> -> __value
            __token = 7074
            try:
                __zt_tmp = __attrs_124525521685520
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'has_groups|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['has_groups'] = __value
            __append(u'\r\n\r\n              <!-- tab content -->\r\n              ')

            # <Static value=<_ast.Dict object at 0x71415b7c4a10> name=None at 71415b7c46d0> -> __attrs_124525521703312
            __attrs_124525521703312 = _static_124525521685008

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="tab-content">\r\n\r\n                <!-- Primary fieldsets -->\r\n                ')

            # <Static value=<_ast.Dict object at 0x71415b7c9210> name=None at 71415b7c9390> -> __attrs_124525521703568
            __attrs_124525521703568 = _static_124525521703440

            # <Value u'has_default_widgets' (150:36)> -> __condition
            __token = 7333
            try:
                __zt_tmp = __attrs_124525521703568
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'has_default_widgets', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="tab-pane active" id="default" role="tabpanel">\r\n                  ')
                __token = None
                render_widget_rendering(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n                </div>')
            __append(u'\r\n\r\n                <!-- Secondary fieldsets -->\r\n                ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521705232
            __attrs_124525521705232 = _static_124525979686032

            # <Value u'has_groups' (163:64)> -> __condition
            __token = 8003
            try:
                __zt_tmp = __attrs_124525521705232
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'has_groups', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __backup_group_124525733997136 = get('group', __marker)

                # <Value u'groups' (163:45)> -> __iterator
                __token = 7984
                try:
                    __zt_tmp = __attrs_124525521705232
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'groups', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525521826000, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item
                    __append(u'\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x71415b7e7190> name=None at 71415b7e7450> -> __attrs_124525731963664
                    __attrs_124525731963664 = _static_124525521826192
                    __backup_normalizeString_124525521823696 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (166:51)> -> __value
                    __token = 8149
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_124525881099024 = get('fieldset_label', __marker)

                    # <Value u'group/label' (167:49)> -> __value
                    __token = 8239
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_124525735318608 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (168:47)> -> __value
                    __token = 8301
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_124525734612368 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (169:46)> -> __value
                    __token = 8452
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_is_first_124525785355920 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (170:40)> -> __value
                    __token = 8535
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"repeat['group'].start", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_124525785117840 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (171:47)> -> __value
                    __token = 8617
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value
                    __backup_pane_class_124525732649296 = get('pane_class', __marker)

                    # <Value u"python:'tab-pane active' if should_be_active else 'tab-pane'" (172:40)> -> __value
                    __token = 8708
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"'tab-pane active' if should_be_active else 'tab-pane'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['pane_class'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521829520
                    __default_124525521829520 = _DEFAULT_MARKER

                    # <Substitution u'pane_class' (174:44)> -> __attr_class
                    __token = 8890
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_124525896001680('path', u'pane_class', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'tab-pane', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'                        role="tabpanel"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731963024
                    __default_124525731963024 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}' (173:42)> -> __attr_id
                    __token = 8820
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_124525896001680('string', u'${fieldset_name}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731963344
                    __default_124525731963344 = _DEFAULT_MARKER

                    # <Substitution u'fieldset_name' (175:51)> -> __attr_data_fieldset
                    __token = 8955
                    try:
                        __zt_tmp = __attrs_124525731963664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_fieldset = _static_124525896001680('path', u'fieldset_name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_data_fieldset = __quote(__attr_data_fieldset, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_fieldset is not None):
                        __append((u' data-fieldset="%s"' % __attr_data_fieldset))
                    __append(u'>\r\n\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731966096
                    __attrs_124525731966096 = _static_124525979686032
                    __backup_group_description_124525734831376 = get('group_description', __marker)

                    # <Value u'group/description|nothing' (178:52)> -> __value
                    __token = 9070
                    try:
                        __zt_tmp = __attrs_124525731966096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/description|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['group_description'] = __value

                    # <Value u'group_description' (179:37)> -> __condition
                    __token = 9135
                    try:
                        __zt_tmp = __attrs_124525731966096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('path', u'group_description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <p ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<p>')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731965712
                        __default_124525731965712 = _DEFAULT_MARKER

                        # <Value u'group_description' (180:45)> -> __cache_124525731965392
                        __token = 9200
                        try:
                            __zt_tmp = __attrs_124525731966096
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_124525731965392 = _static_124525896001680('path', u'group_description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                        # <BinOp left=<Value u'group_description' (180:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71416804ea50> -> __condition
                        __expression = __cache_124525731965392

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n                      Description\r\n                    ')
                        else:
                            __content = __cache_124525731965392
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</p>')
                    if (__backup_group_description_124525734831376 is __marker):
                        del econtext['group_description']
                    else:
                        econtext['group_description'] = __backup_group_description_124525734831376
                    __append(u'\r\n\r\n                    <!-- Error -->\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731918032
                    __attrs_124525731918032 = _static_124525979686032
                    __backup_errors_124525818359696 = get('errors', __marker)

                    # <Value u'group/widgets/errors' (185:50)> -> __value
                    __token = 9370
                    try:
                        __zt_tmp = __attrs_124525731918032
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/widgets/errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['errors'] = __value

                    # <Value u'python:False' (186:46)> -> __condition
                    __token = 9439
                    try:
                        __zt_tmp = __attrs_124525731918032
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('python', u'False', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:
                        __backup_error_124525734927248 = get('error', __marker)

                        # <Value u'errors' (187:49)> -> __iterator
                        __token = 9503
                        try:
                            __zt_tmp = __attrs_124525731918032
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_124525896001680('path', u'errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        (__iterator, ____index_124525731918224, ) = getitem('repeat')(u'error', __iterator)
                        econtext['error'] = None
                        for __item in __iterator:
                            econtext['error'] = __item
                            __append(u'\r\n                      ')

                            # <Static value=<_ast.Dict object at 0x714168043690> name=None at 714168043650> -> __attrs_124525731920144
                            __attrs_124525731920144 = _static_124525731919504

                            # <Value u'not:nocall:error/widget' (189:42)> -> __condition
                            __token = 9617
                            try:
                                __zt_tmp = __attrs_124525731920144
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_124525896001680('not', u'nocall:error/widget', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div class="field error fieldErrorBox">')

                                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731919312
                                __default_124525731919312 = _DEFAULT_MARKER

                                # <Value u'error/render' (190:50)> -> __cache_124525731918864
                                __token = 9693
                                try:
                                    __zt_tmp = __attrs_124525731920144
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_124525731918864 = _static_124525896001680('path', u'error/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                                # <BinOp left=<Value u'error/render' (190:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168043510> -> __condition
                                __expression = __cache_124525731918864

                                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    pass
                                else:
                                    __content = __cache_124525731918864
                                    __content = __convert(__content)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            __append(u'\r\n                    ')
                            ____index_124525731918224 -= 1
                            if (____index_124525731918224 > 0):
                                __append('')
                        if (__backup_error_124525734927248 is __marker):
                            del econtext['error']
                        else:
                            econtext['error'] = __backup_error_124525734927248
                    if (__backup_errors_124525818359696 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_124525818359696
                    __append(u'\r\n\r\n                    <!-- Widget -->\r\n                    ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731920464
                    __attrs_124525731920464 = _static_124525979686032
                    __backup_view_124525734888784 = get('view', __marker)

                    # <Value u'nocall:group' (194:44)> -> __value
                    __token = 9827
                    try:
                        __zt_tmp = __attrs_124525731920464
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('nocall', u'group', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['view'] = __value
                    __append(u'\r\n                      ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731921552
                    __attrs_124525731921552 = _static_124525979686032
                    __backup_macroname_124525767574304 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x714168043d90> name=None at 714168043dd0> -> __value
                    __value = _static_124525731921296
                    econtext['macroname'] = __value

                    # <Value u'context/@@ploneform-macros/widget_rendering' (195:46)> -> __macro
                    __token = 9890
                    try:
                        __zt_tmp = __attrs_124525731921552
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_124525896001680('path', u'context/@@ploneform-macros/widget_rendering', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __token = 9890
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_124525767574304 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_124525767574304
                    __append(u'\r\n                    ')
                    if (__backup_view_124525734888784 is __marker):
                        del econtext['view']
                    else:
                        econtext['view'] = __backup_view_124525734888784
                    __append(u'\r\n\r\n                  </div>')
                    if (__backup_pane_class_124525732649296 is __marker):
                        del econtext['pane_class']
                    else:
                        econtext['pane_class'] = __backup_pane_class_124525732649296
                    if (__backup_should_be_active_124525785117840 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_124525785117840
                    if (__backup_is_first_124525785355920 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_124525785355920
                    if (__backup_fieldset_name_124525734612368 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_124525734612368
                    if (__backup_fieldset_name_124525735318608 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_124525735318608
                    if (__backup_fieldset_label_124525881099024 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_124525881099024
                    if (__backup_normalizeString_124525521823696 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_124525521823696
                    __append(u'\r\n                ')
                    ____index_124525521826000 -= 1
                    if (____index_124525521826000 > 0):
                        __append('')
                if (__backup_group_124525733997136 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_124525733997136
            __append(u'\r\n              </div>\r\n\r\n            ')
            if (__backup_has_groups_124525734888400 is __marker):
                del econtext['has_groups']
            else:
                econtext['has_groups'] = __backup_has_groups_124525734888400
            if (__backup_show_default_label_124525732497488 is __marker):
                del econtext['show_default_label']
            else:
                econtext['show_default_label'] = __backup_show_default_label_124525732497488
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_actions(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731917968
            __attrs_124525731917968 = _static_124525979686032
            __append(u'\r\n              ')

            # <Static value=<_ast.Dict object at 0x714168038050> name=None at 714168043fd0> -> __attrs_124525731873424
            __attrs_124525731873424 = _static_124525731872848

            # <Value u'view/actions/values|nothing' (209:55)> -> __condition
            __token = 10333
            try:
                __zt_tmp = __attrs_124525731873424
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'view/actions/values|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="formControls">\r\n                ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731874320
                __attrs_124525731874320 = _static_124525979686032
                __backup_action_124525734654480 = get('action', __marker)

                # <Value u'view/actions/values' (210:42)> -> __iterator
                __token = 10406
                try:
                    __zt_tmp = __attrs_124525731874320
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'view/actions/values', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525731874512, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item
                    __append(u'\r\n                  ')

                    # <Static value=<_ast.Dict object at 0x714168038910> name=None at 7141680388d0> -> __attrs_124525731876112
                    __attrs_124525731876112 = _static_124525731875088

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731875984
                    __default_124525731875984 = _DEFAULT_MARKER

                    # <Value u'action/render' (211:62)> -> __cache_124525731875600
                    __token = 10491
                    try:
                        __zt_tmp = __attrs_124525731876112
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525731875600 = _static_124525896001680('path', u'action/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/render' (211:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168038bd0> -> __condition
                    __expression = __cache_124525731875600

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="submit" />')
                    else:
                        __content = __cache_124525731875600
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n                ')
                    ____index_124525731874512 -= 1
                    if (____index_124525731874512 > 0):
                        __append('')
                if (__backup_action_124525734654480 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_124525734654480
                __append(u'\r\n              </div>')
            __append(u'\r\n            ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_field(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521826384
            __attrs_124525521826384 = _static_124525979686032
            __append(u'\r\n                          ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521829072
            __attrs_124525521829072 = _static_124525979686032

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521828880
            __default_124525521828880 = _DEFAULT_MARKER

            # <Value u'widget/@@ploneform-render-widget' (155:61)> -> __cache_124525521827024
            __token = 7676
            try:
                __zt_tmp = __attrs_124525521829072
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_124525521827024 = _static_124525896001680('path', u'widget/@@ploneform-render-widget', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

            # <BinOp left=<Value u'widget/@@ploneform-render-widget' (155:61)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7e7350> -> __condition
            __expression = __cache_124525521827024

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_124525521827024
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n                        ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_titlelessform(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_formtop = econtext[u'__slot_formtop'].pop()
        except:
            __slot_formtop = None

        try:
            __slot_fields = econtext[u'__slot_fields'].pop()
        except:
            __slot_fields = None

        try:
            __slot_belowfields = econtext[u'__slot_belowfields'].pop()
        except:
            __slot_belowfields = None

        try:
            __slot_description = econtext[u'__slot_description'].pop()
        except:
            __slot_description = None

        try:
            __slot_actions = econtext[u'__slot_actions'].pop()
        except:
            __slot_actions = None

        try:
            __slot_formbottom = econtext[u'__slot_formbottom'].pop()
        except:
            __slot_formbottom = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732512080
            __attrs_124525732512080 = _static_124525979686032
            __append(u'\r\n\r\n        <!-- Status Message -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525733167952
            __attrs_124525733167952 = _static_124525979686032
            __backup_status_124525732514768 = get('status', __marker)

            # <Value u'view/status' (17:35)> -> __value
            __token = 578
            try:
                __zt_tmp = __attrs_124525733167952
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/status', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['status'] = __value
            __backup_has_error_124525732515344 = get('has_error', __marker)

            # <Value u"python:view.widgets.errors or status == getattr(view, 'formErrorsMessage', None)" (18:37)> -> __value
            __token = 629
            try:
                __zt_tmp = __attrs_124525733167952
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"view.widgets.errors or status == getattr(view, 'formErrorsMessage', None)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['has_error'] = __value

            # <Value u'status' (18:131)> -> __condition
            __token = 723
            try:
                __zt_tmp = __attrs_124525733167952
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'status', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x7141680e23d0> name=None at 7141680e2410> -> __attrs_124525732571408
                __attrs_124525732571408 = _static_124525732570064

                # <Value u'has_error' (19:63)> -> __condition
                __token = 796
                try:
                    __zt_tmp = __attrs_124525732571408
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'has_error', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <dl ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dl class="portalMessage alert error" role="alert">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732572880
                    __attrs_124525732572880 = _static_124525979686032
                    __previous_i18n_domain_124525732572304 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <dt ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dt>')
                    __stream_124525732572688 = []
                    __append_124525732572688 = __stream_124525732572688.append
                    __append_124525732572688(u'\r\n              Error\r\n            ')
                    __msgid_124525732572688 = __re_whitespace(''.join(__stream_124525732572688)).strip()
                    if __msgid_124525732572688:
                        __append(translate(__msgid_124525732572688, mapping=None, default=__msgid_124525732572688, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</dt>')
                    __i18n_domain = __previous_i18n_domain_124525732572304
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732652944
                    __attrs_124525732652944 = _static_124525979686032

                    # <dd ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dd>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525782268368
                    __default_124525782268368 = _DEFAULT_MARKER

                    # <Value u'status' (23:29)> -> __cache_124525732569872
                    __token = 947
                    try:
                        __zt_tmp = __attrs_124525732652944
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732569872 = _static_124525896001680('path', u'status', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'status' (23:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680e2690> -> __condition
                    __expression = __cache_124525732569872

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_124525732569872
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</dd>\r\n          </dl>')
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x7141680f6890> name=None at 7141680f6a50> -> __attrs_124525732651472
                __attrs_124525732651472 = _static_124525732653200

                # <Value u'not:has_error' (25:56)> -> __condition
                __token = 1032
                try:
                    __zt_tmp = __attrs_124525732651472
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('not', u'has_error', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <dl ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dl class="portalMessage info" role="status">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732653776
                    __attrs_124525732653776 = _static_124525979686032
                    __previous_i18n_domain_124525732654800 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <dt ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dt>')
                    __stream_124525732653840 = []
                    __append_124525732653840 = __stream_124525732653840.append
                    __append_124525732653840(u'\r\n              Info\r\n            ')
                    __msgid_124525732653840 = __re_whitespace(''.join(__stream_124525732653840)).strip()
                    if __msgid_124525732653840:
                        __append(translate(__msgid_124525732653840, mapping=None, default=__msgid_124525732653840, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</dt>')
                    __i18n_domain = __previous_i18n_domain_124525732654800
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732654608
                    __attrs_124525732654608 = _static_124525979686032

                    # <dd ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dd>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732652368
                    __default_124525732652368 = _DEFAULT_MARKER

                    # <Value u'status' (29:29)> -> __cache_124525732652880
                    __token = 1187
                    try:
                        __zt_tmp = __attrs_124525732654608
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732652880 = _static_124525896001680('path', u'status', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'status' (29:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680f6a90> -> __condition
                    __expression = __cache_124525732652880

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_124525732652880
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</dd>\r\n          </dl>')
                __append(u'\r\n        ')
            if (__backup_has_error_124525732515344 is __marker):
                del econtext['has_error']
            else:
                econtext['has_error'] = __backup_has_error_124525732515344
            if (__backup_status_124525732514768 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_124525732514768
            __append(u'\r\n\r\n        <!-- Primary Field Errors -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732651600
            __attrs_124525732651600 = _static_124525979686032
            __backup_errors_124525732513808 = get('errors', __marker)

            # <Value u'view/widgets/errors' (34:35)> -> __value
            __token = 1315
            try:
                __zt_tmp = __attrs_124525732651600
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/widgets/errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['errors'] = __value

            # <Value u'errors' (34:67)> -> __condition
            __token = 1347
            try:
                __zt_tmp = __attrs_124525732651600
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521678224
                __attrs_124525521678224 = _static_124525979686032
                __backup_error_124525732572752 = get('error', __marker)

                # <Value u'errors' (35:35)> -> __iterator
                __token = 1392
                try:
                    __zt_tmp = __attrs_124525521678224
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525521675408, ) = getitem('repeat')(u'error', __iterator)
                econtext['error'] = None
                for __item in __iterator:
                    econtext['error'] = __item
                    __append(u'\r\n            ')

                    # <Static value=<_ast.Dict object at 0x71415b7c29d0> name=None at 71415b7c24d0> -> __attrs_124525521678032
                    __attrs_124525521678032 = _static_124525521676752

                    # <Value u'not:nocall:error/widget' (37:32)> -> __condition
                    __token = 1492
                    try:
                        __zt_tmp = __attrs_124525521678032
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('not', u'nocall:error/widget', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="field error alert alert-warning">')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521674512
                        __default_124525521674512 = _DEFAULT_MARKER

                        # <Value u'error/render' (38:40)> -> __cache_124525521674768
                        __token = 1558
                        try:
                            __zt_tmp = __attrs_124525521678032
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_124525521674768 = _static_124525896001680('path', u'error/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                        # <BinOp left=<Value u'error/render' (38:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c2350> -> __condition
                        __expression = __cache_124525521674768

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n              Error\r\n            ')
                        else:
                            __content = __cache_124525521674768
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    __append(u'\r\n          ')
                    ____index_124525521675408 -= 1
                    if (____index_124525521675408 > 0):
                        __append('')
                if (__backup_error_124525732572752 is __marker):
                    del econtext['error']
                else:
                    econtext['error'] = __backup_error_124525732572752
                __append(u'\r\n        ')
            if (__backup_errors_124525732513808 is __marker):
                del econtext['errors']
            else:
                econtext['errors'] = __backup_errors_124525732513808
            __append(u'\r\n\r\n        <!-- Secondary Field Errors -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521677904
            __attrs_124525521677904 = _static_124525979686032
            __backup_groups_124525732513616 = get('groups', __marker)

            # <Value u'view/groups|nothing' (45:35)> -> __value
            __token = 1740
            try:
                __zt_tmp = __attrs_124525521677904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/groups|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['groups'] = __value

            # <Value u'python:bool(groups)' (46:31)> -> __condition
            __token = 1793
            try:
                __zt_tmp = __attrs_124525521677904
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u'bool(groups)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __backup_group_124525732569296 = get('group', __marker)

                # <Value u'groups' (47:34)> -> __iterator
                __token = 1849
                try:
                    __zt_tmp = __attrs_124525521677904
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'groups', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525521676496, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521695184
                    __attrs_124525521695184 = _static_124525979686032
                    __backup_errors_124525732512592 = get('errors', __marker)

                    # <Value u'group/widgets/errors' (48:40)> -> __value
                    __token = 1899
                    try:
                        __zt_tmp = __attrs_124525521695184
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/widgets/errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['errors'] = __value

                    # <Value u'errors' (49:35)> -> __condition
                    __token = 1957
                    try:
                        __zt_tmp = __attrs_124525521695184
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('path', u'errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:
                        __backup_error_124525732571472 = get('error', __marker)

                        # <Value u'errors' (50:38)> -> __iterator
                        __token = 2004
                        try:
                            __zt_tmp = __attrs_124525521695184
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_124525896001680('path', u'errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                        (__iterator, ____index_124525521695376, ) = getitem('repeat')(u'error', __iterator)
                        econtext['error'] = None
                        for __item in __iterator:
                            econtext['error'] = __item
                            __append(u'\r\n            ')

                            # <Static value=<_ast.Dict object at 0x71415b7c7450> name=None at 71415b7c7590> -> __attrs_124525521697296
                            __attrs_124525521697296 = _static_124525521695824

                            # <Value u'not:nocall:error/widget' (52:31)> -> __condition
                            __token = 2103
                            try:
                                __zt_tmp = __attrs_124525521697296
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_124525896001680('not', u'nocall:error/widget', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div class="field error alert alert-warning">')

                                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521694992
                                __default_124525521694992 = _DEFAULT_MARKER

                                # <Value u'error/render' (53:39)> -> __cache_124525521698576
                                __token = 2168
                                try:
                                    __zt_tmp = __attrs_124525521697296
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_124525521698576 = _static_124525896001680('path', u'error/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                                # <BinOp left=<Value u'error/render' (53:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c77d0> -> __condition
                                __expression = __cache_124525521698576

                                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    pass
                                else:
                                    __content = __cache_124525521698576
                                    __content = __convert(__content)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            __append(u'\r\n          ')
                            ____index_124525521695376 -= 1
                            if (____index_124525521695376 > 0):
                                __append('')
                        if (__backup_error_124525732571472 is __marker):
                            del econtext['error']
                        else:
                            econtext['error'] = __backup_error_124525732571472
                    if (__backup_errors_124525732512592 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_124525732512592
                    __append(u'\r\n        ')
                    ____index_124525521676496 -= 1
                    if (____index_124525521676496 > 0):
                        __append('')
                if (__backup_group_124525732569296 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_124525732569296
            if (__backup_groups_124525732513616 is __marker):
                del econtext['groups']
            else:
                econtext['groups'] = __backup_groups_124525732513616
            __append(u'\r\n\r\n        <!-- Description -->\r\n        ')
            if (__slot_description is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521695504
                __attrs_124525521695504 = _static_124525979686032
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x71416cd20990> name=None at 71416cd20c90> -> __attrs_124525733312272
                __attrs_124525733312272 = _static_124525812517264
                __backup_description_124525734953424 = get('description', __marker)

                # <Value u'view/description | nothing' (60:37)> -> __value
                __token = 2407
                try:
                    __zt_tmp = __attrs_124525733312272
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'view/description | nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['description'] = __value

                # <Value u'description' (61:28)> -> __condition
                __token = 2464
                try:
                    __zt_tmp = __attrs_124525733312272
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="discreet text-secondary">')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521695312
                    __default_124525521695312 = _DEFAULT_MARKER

                    # <Value u'description|default' (62:36)> -> __cache_124525521698768
                    __token = 2514
                    try:
                        __zt_tmp = __attrs_124525733312272
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525521698768 = _static_124525896001680('path', u'description|default', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description|default' (62:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c7210> -> __condition
                    __expression = __cache_124525521698768

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n            Description\r\n          ')
                    else:
                        __content = __cache_124525521698768
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</p>')
                if (__backup_description_124525734953424 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_124525734953424
                __append(u'\r\n        ')
            else:
                __slot_description(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n        <!-- Form -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x714168132ad0> name=None at 71416c7d31d0> -> __attrs_124525734610832
            __attrs_124525734610832 = _static_124525732899536
            __backup_groups_124525521823056 = get('groups', __marker)

            # <Value u'view/groups | nothing' (70:33)> -> __value
            __token = 2856
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/groups | nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['groups'] = __value
            __backup_form_name_124525732571664 = get('form_name', __marker)

            # <Value u'view/form_name | nothing' (71:35)> -> __value
            __token = 2915
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/form_name | nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['form_name'] = __value
            __backup_form_class_124525734953616 = get('form_class', __marker)

            # <Value u'view/css_class | string:' (72:35)> -> __value
            __token = 2978
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/css_class | string:', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['form_class'] = __value
            __backup_default_fieldset_label_124525732573072 = get('default_fieldset_label', __marker)

            # <Value u'view/default_fieldset_label | form_name' (73:46)> -> __value
            __token = 3053
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/default_fieldset_label | form_name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['default_fieldset_label'] = __value
            __backup_enable_form_tabbing_124525734986384 = get('enable_form_tabbing', __marker)

            # <Value u'view/enable_form_tabbing | python:True' (74:42)> -> __value
            __token = 3140
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/enable_form_tabbing | python:True', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['enable_form_tabbing'] = __value
            __backup_enable_unload_protection_124525734986128 = get('enable_unload_protection', __marker)

            # <Value u'view/enable_unload_protection|python:True' (75:46)> -> __value
            __token = 3231
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/enable_unload_protection|python:True', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['enable_unload_protection'] = __value
            __backup_unload_protection_124525521693584 = get('unload_protection', __marker)

            # <Value u"python:enable_unload_protection and 'pat-formunloadalert'" (76:38)> -> __value
            __token = 3318
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"enable_unload_protection and 'pat-formunloadalert'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['unload_protection'] = __value
            __backup_has_groups_124525734987600 = get('has_groups', __marker)

            # <Value u'python:bool(groups)' (77:30)> -> __value
            __token = 3414
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u'bool(groups)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['has_groups'] = __value
            __backup_form_tabbing_124525732648784 = get('form_tabbing', __marker)

            # <Value u"python:(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autotoc' or ''" (78:31)> -> __value
            __token = 3474
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autotoc' or ''", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['form_tabbing'] = __value
            __backup_default_widgets_124525735236048 = get('default_widgets', __marker)

            # <Value u'python:view.widgets.values()' (79:33)> -> __value
            __token = 3603
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u'view.widgets.values()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['default_widgets'] = __value
            __backup_has_default_widgets_124525732655056 = get('has_default_widgets', __marker)

            # <Value u'python:bool(default_widgets)' (80:36)> -> __value
            __token = 3679
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u'bool(default_widgets)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['has_default_widgets'] = __value
            __backup_show_default_label_124525734856400 = get('show_default_label', __marker)

            # <Value u'python:has_groups and default_fieldset_label and len(view.widgets)' (81:34)> -> __value
            __token = 3754
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u'has_groups and default_fieldset_label and len(view.widgets)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['show_default_label'] = __value
            __backup_form_view_name_raw_124525521714896 = get('form_view_name_raw', __marker)

            # <Value u"python:view.__name__ or request.getURL().split('/')[-1]" (82:33)> -> __value
            __token = 3867
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"view.__name__ or request.getURL().split('/')[-1]", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['form_view_name_raw'] = __value
            __backup_form_view_name_124525734914320 = get('form_view_name', __marker)

            # <Value u"python:'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split('++') if x])" (83:28)> -> __value
            __token = 3965
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split('++') if x])", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['form_view_name'] = __value

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form data-pat-autotoc="levels: legend; section: fieldset; className: autotabs"')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732470224
            __default_124525732470224 = _DEFAULT_MARKER

            # <Substitution u"python:'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_name)" (87:34)> -> __attr_class
            __token = 4247
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_124525896001680('python', u"'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_name)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'rowlike enableUnloadProtection', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u'               class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525735187664
            __default_124525735187664 = _DEFAULT_MARKER

            # <Substitution u'view/action|request/getURL' (85:37)> -> __attr_action
            __token = 4131
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_124525896001680('path', u'view/action|request/getURL', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'.', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525735188176
            __default_124525735188176 = _DEFAULT_MARKER

            # <Substitution u'view/method|string:post' (89:33)> -> __attr_method
            __token = 4469
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_method = _static_124525896001680('path', u'view/method|string:post', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_method = __quote(__attr_method, '"', '&quot;', u'post', _DEFAULT_MARKER)
            if (__attr_method is not None):
                __append((u' method="%s"' % __attr_method))
            __append(u' name="edit_form"')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525735013776
            __default_124525735013776 = _DEFAULT_MARKER

            # <Substitution u'view/enctype' (86:37)> -> __attr_enctype
            __token = 4197
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_enctype = _static_124525896001680('path', u'view/enctype', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_enctype = __quote(__attr_enctype, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_enctype is not None):
                __append((u' enctype="%s"' % __attr_enctype))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734627024
            __default_124525734627024 = _DEFAULT_MARKER

            # <Substitution u'view/id' (88:30)> -> __attr_id
            __token = 4423
            try:
                __zt_tmp = __attrs_124525734610832
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_124525896001680('path', u'view/id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\r\n\r\n          ')
            if (__slot_formtop is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521693264
                __attrs_124525521693264 = _static_124525979686032
            else:
                __slot_formtop(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          <!-- navigation tabs -->\r\n          ')

            # <Static value=<_ast.Dict object at 0x71415b7c66d0> name=None at 71415b7c6c50> -> __attrs_124525521692880
            __attrs_124525521692880 = _static_124525521692368

            # <Value u'python: has_groups and enable_form_tabbing' (95:29)> -> __condition
            __token = 4669
            try:
                __zt_tmp = __attrs_124525521692880
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u' has_groups and enable_form_tabbing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-tabs" role="tablist">\r\n\r\n            <!-- primary tab -->\r\n            ')

                # <Static value=<_ast.Dict object at 0x71415b7c65d0> name=None at 71415b7c6ed0> -> __attrs_124525732523024
                __attrs_124525732523024 = _static_124525521692112
                __backup_has_errors_124525733990160 = get('has_errors', __marker)

                # <Value u'view/widgets/errors' (100:39)> -> __value
                __token = 4897
                try:
                    __zt_tmp = __attrs_124525732523024
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'view/widgets/errors', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['has_errors'] = __value

                # <Value u'has_default_widgets' (99:31)> -> __condition
                __token = 4836
                try:
                    __zt_tmp = __attrs_124525732523024
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('path', u'has_default_widgets', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x7141680d65d0> name=None at 7141680d6690> -> __attrs_124525732521360
                    __attrs_124525732521360 = _static_124525732521424

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a                  id="default-tab"                  href="#default"                  data-toggle="tab"                  role="tab"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732523280
                    __default_124525732523280 = _DEFAULT_MARKER

                    # <Substitution u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'" (102:39)> -> __attr_class
                    __token = 5014
                    try:
                        __zt_tmp = __attrs_124525732521360
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_124525896001680('python', u"has_errors and 'nav-link active text-danger' or 'nav-link active'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732521168
                    __default_124525732521168 = _DEFAULT_MARKER

                    # <Value u'default_fieldset_label' (101:30)> -> __cache_124525732520400
                    __token = 4950
                    try:
                        __zt_tmp = __attrs_124525732521360
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732520400 = _static_124525896001680('path', u'default_fieldset_label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'default_fieldset_label' (101:30)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680d6710> -> __condition
                    __expression = __cache_124525732520400

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n                Label\r\n              ')
                    else:
                        __content = __cache_124525732520400
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>\r\n            </li>')
                if (__backup_has_errors_124525733990160 is __marker):
                    del econtext['has_errors']
                else:
                    econtext['has_errors'] = __backup_has_errors_124525733990160
                __append(u'\r\n\r\n            <!-- secondary tabs -->\r\n            ')

                # <Static value=<_ast.Dict object at 0x7141680e1450> name=None at 7141680e1690> -> __attrs_124525732567056
                __attrs_124525732567056 = _static_124525732566096
                __backup_group_124525732473424 = get('group', __marker)

                # <Value u'groups' (112:34)> -> __iterator
                __token = 5359
                try:
                    __zt_tmp = __attrs_124525732567056
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_124525896001680('path', u'groups', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                (__iterator, ____index_124525732565776, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\r\n              ')

                    # <Static value=<_ast.Dict object at 0x7141680e1c50> name=None at 7141680e1cd0> -> __attrs_124525521712912
                    __attrs_124525521712912 = _static_124525732568144
                    __backup_normalizeString_124525732650896 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (113:45)> -> __value
                    __token = 5451
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_124525732648976 = get('fieldset_label', __marker)

                    # <Value u'group/label' (114:43)> -> __value
                    __token = 5535
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_124525785168272 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (115:41)> -> __value
                    __token = 5591
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_124525732495440 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (116:40)> -> __value
                    __token = 5736
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_has_errors_124525732572560 = get('has_errors', __marker)

                    # <Value u'group/widgets/errors|nothing' (117:36)> -> __value
                    __token = 5815
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('path', u'group/widgets/errors|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['has_errors'] = __value
                    __backup_is_first_124525734889552 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (118:33)> -> __value
                    __token = 5883
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u"repeat['group'].start", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_124525734913360 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (119:40)> -> __value
                    __token = 5959
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a                  data-toggle="tab"                  role="tab"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732567632
                    __default_124525732567632 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}-tab' (120:36)> -> __attr_id
                    __token = 6047
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_124525896001680('string', u'${fieldset_name}-tab', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521712720
                    __default_124525521712720 = _DEFAULT_MARKER

                    # <Substitution u'string:#${fieldset_name}' (121:37)> -> __attr_href
                    __token = 6114
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_124525896001680('string', u'#${fieldset_name}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521714192
                    __default_124525521714192 = _DEFAULT_MARKER

                    # <Substitution u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')" (122:37)> -> __attr_class
                    __token = 6179
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_124525896001680('python', u"has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732567760
                    __default_124525732567760 = _DEFAULT_MARKER

                    # <Value u'fieldset_label' (123:30)> -> __cache_124525732566864
                    __token = 6316
                    try:
                        __zt_tmp = __attrs_124525521712912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732566864 = _static_124525896001680('path', u'fieldset_label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'fieldset_label' (123:30)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680e1a10> -> __condition
                    __expression = __cache_124525732566864

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n                Label\r\n              ')
                    else:
                        __content = __cache_124525732566864
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>')
                    if (__backup_should_be_active_124525734913360 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_124525734913360
                    if (__backup_is_first_124525734889552 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_124525734889552
                    if (__backup_has_errors_124525732572560 is __marker):
                        del econtext['has_errors']
                    else:
                        econtext['has_errors'] = __backup_has_errors_124525732572560
                    if (__backup_fieldset_name_124525732495440 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_124525732495440
                    if (__backup_fieldset_name_124525785168272 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_124525785168272
                    if (__backup_fieldset_label_124525732648976 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_124525732648976
                    if (__backup_normalizeString_124525732650896 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_124525732650896
                    __append(u'\r\n            </li>')
                    ____index_124525732565776 -= 1
                    if (____index_124525732565776 > 0):
                        __append('\n            ')
                if (__backup_group_124525732473424 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_124525732473424
                __append(u'\r\n          </ul>')
            __append(u'\r\n\r\n          ')
            if (__slot_fields is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521713616
                __attrs_124525521713616 = _static_124525979686032
                __append(u'\r\n\r\n            ')

                # <Static value=<_ast.Dict object at 0x71415b7c4990> name=None at 71415b7cb6d0> -> __attrs_124525521683856
                __attrs_124525521683856 = _static_124525521684880
                __backup_current_fieldset_124525521719760 = get('current_fieldset', __marker)

                # <Value u'request/fieldset | python:None' (135:48)> -> __value
                __token = 6652
                try:
                    __zt_tmp = __attrs_124525521683856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('path', u'request/fieldset | python:None', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['current_fieldset'] = __value

                # <Value u'python:has_groups and enable_form_tabbing and current_fieldset is not None' (136:34)> -> __condition
                __token = 6719
                try:
                    __zt_tmp = __attrs_124525521683856
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u'has_groups and enable_form_tabbing and current_fieldset is not None', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden"                    name="fieldset"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521682576
                    __default_124525521682576 = _DEFAULT_MARKER

                    # <Substitution u'current_fieldset' (137:41)> -> __attr_value
                    __token = 6837
                    try:
                        __zt_tmp = __attrs_124525521683856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_124525896001680('path', u'current_fieldset', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />')
                if (__backup_current_fieldset_124525521719760 is __marker):
                    del econtext['current_fieldset']
                else:
                    econtext['current_fieldset'] = __backup_current_fieldset_124525521719760
                __append(u'\r\n\r\n            <!-- Default fieldset -->\r\n            ')
                __token = None
                render_fields(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n          ')
            else:
                __slot_fields(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          ')
            if (__slot_belowfields is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521686352
                __attrs_124525521686352 = _static_124525979686032
            else:
                __slot_belowfields(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          ')
            if (__slot_actions is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521706512
                __attrs_124525521706512 = _static_124525979686032
                __append(u'\r\n            ')
                __token = None
                render_actions(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n          ')
            else:
                __slot_actions(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731874704
            __attrs_124525731874704 = _static_124525979686032

            # <Value u'view/enableCSRFProtection|nothing' (217:36)> -> __condition
            __token = 10662
            try:
                __zt_tmp = __attrs_124525731874704
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'view/enableCSRFProtection|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731921616
                __default_124525731921616 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (218:44)> -> __cache_124525521826448
                __token = 10742
                try:
                    __zt_tmp = __attrs_124525731874704
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521826448 = _static_124525896001680('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (218:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168043d10> -> __condition
                __expression = __cache_124525521826448

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_124525521826448
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            __append(u'\r\n          ')
            if (__slot_formbottom is None):

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731874064
                __attrs_124525731874064 = _static_124525979686032
            else:
                __slot_formbottom(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n        </form>')
            if (__backup_form_view_name_124525734914320 is __marker):
                del econtext['form_view_name']
            else:
                econtext['form_view_name'] = __backup_form_view_name_124525734914320
            if (__backup_form_view_name_raw_124525521714896 is __marker):
                del econtext['form_view_name_raw']
            else:
                econtext['form_view_name_raw'] = __backup_form_view_name_raw_124525521714896
            if (__backup_show_default_label_124525734856400 is __marker):
                del econtext['show_default_label']
            else:
                econtext['show_default_label'] = __backup_show_default_label_124525734856400
            if (__backup_has_default_widgets_124525732655056 is __marker):
                del econtext['has_default_widgets']
            else:
                econtext['has_default_widgets'] = __backup_has_default_widgets_124525732655056
            if (__backup_default_widgets_124525735236048 is __marker):
                del econtext['default_widgets']
            else:
                econtext['default_widgets'] = __backup_default_widgets_124525735236048
            if (__backup_form_tabbing_124525732648784 is __marker):
                del econtext['form_tabbing']
            else:
                econtext['form_tabbing'] = __backup_form_tabbing_124525732648784
            if (__backup_has_groups_124525734987600 is __marker):
                del econtext['has_groups']
            else:
                econtext['has_groups'] = __backup_has_groups_124525734987600
            if (__backup_unload_protection_124525521693584 is __marker):
                del econtext['unload_protection']
            else:
                econtext['unload_protection'] = __backup_unload_protection_124525521693584
            if (__backup_enable_unload_protection_124525734986128 is __marker):
                del econtext['enable_unload_protection']
            else:
                econtext['enable_unload_protection'] = __backup_enable_unload_protection_124525734986128
            if (__backup_enable_form_tabbing_124525734986384 is __marker):
                del econtext['enable_form_tabbing']
            else:
                econtext['enable_form_tabbing'] = __backup_enable_form_tabbing_124525734986384
            if (__backup_default_fieldset_label_124525732573072 is __marker):
                del econtext['default_fieldset_label']
            else:
                econtext['default_fieldset_label'] = __backup_default_fieldset_label_124525732573072
            if (__backup_form_class_124525734953616 is __marker):
                del econtext['form_class']
            else:
                econtext['form_class'] = __backup_form_class_124525734953616
            if (__backup_form_name_124525732571664 is __marker):
                del econtext['form_name']
            else:
                econtext['form_name'] = __backup_form_name_124525732571664
            if (__backup_groups_124525521823056 is __marker):
                del econtext['groups']
            else:
                econtext['groups'] = __backup_groups_124525521823056
            __append(u'\r\n      ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7dcf10> name=None at 71415b7dcd90> -> __attrs_124525521823760
            __attrs_124525521823760 = _static_124525521784592
            __previous_i18n_domain_124525521824144 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\r\n  ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521822480
            __attrs_124525521822480 = _static_124525979686032

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\r\n\r\n    ')
            __token = None
            render_form(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n  </body>\r\n</html>')
            __i18n_domain = __previous_i18n_domain_124525521824144
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_rendering': render_widget_rendering, u'render_form': render_form, u'render_fields': render_fields, u'render_actions': render_actions, u'render_field': render_field, u'render_titlelessform': render_titlelessform, 'render': render, }