# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/listingdescription.pt'

__tokens = {47: (u'view/description', 2, 29), 86: (u'description', 3, 20), 199: (u'description', 6, 32)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525521438160 = {u'class': u'row', }
_static_124525521439184 = {u'class': u'col-sm-12', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525521822608 = {u'class': u'text-secondary small', }
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7885d0> name=None at 71415b788dd0> -> __attrs_124525521437712
            __attrs_124525521437712 = _static_124525521438160
            __backup_description_124525732132176 = get('description', __marker)

            # <Value u'view/description' (2:29)> -> __value
            __token = 47
            try:
                __zt_tmp = __attrs_124525521437712
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'view/description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['description'] = __value

            # <Value u'description' (3:20)> -> __condition
            __token = 86
            try:
                __zt_tmp = __attrs_124525521437712
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('path', u'description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="row">\r\n  ')

                # <Static value=<_ast.Dict object at 0x71415b7889d0> name=None at 71415b788f10> -> __attrs_124525521437904
                __attrs_124525521437904 = _static_124525521439184

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="col-sm-12">\r\n    ')

                # <Static value=<_ast.Dict object at 0x71415b7e6390> name=None at 7141682d0650> -> __attrs_124525521823440
                __attrs_124525521823440 = _static_124525521822608

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="text-secondary small">')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734593680
                __default_124525734593680 = _DEFAULT_MARKER

                # <Value u'description' (6:32)> -> __cache_124525734667792
                __token = 199
                try:
                    __zt_tmp = __attrs_124525521823440
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525734667792 = _static_124525896001680('path', u'description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'description' (6:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141682e2390> -> __condition
                __expression = __cache_124525734667792

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_124525734667792
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\r\n  </div>\r\n</div>')
            if (__backup_description_124525732132176 is __marker):
                del econtext['description']
            else:
                econtext['description'] = __backup_description_124525732132176
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }