# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.locking-2.3.0-py2.7.egg/plone/locking/browser/info.pt'

__tokens = {77: (u'view/info/is_locked_for_current_user', 3, 24), 141: (u' view/lock_is_stealabl', 4, 26), 194: (u's view/lock_in', 5, 28), 238: (u'locked', 6, 24), 398: (u'lock_details/author_page', 11, 27), 647: (u'lock_details/author_page', 16, 34), 590: (u'lock_details/fullname', 15, 26), 738: (u'lock_details/time_difference', 18, 29), 858: (u'not:lock_details/author_page', 21, 27), 1060: (u'lock_details/fullname', 25, 29), 1148: (u'lock_details/time_difference', 27, 29), 1245: (u'stealable', 29, 29), 1293: (u'string:${context/absolute_url}/@@plone_lock_operations/force_unlock', 30, 37)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757244280656 = __compile_zt_expr
_static_135757150040144 = {u'class': u'portalMessage info', }
_static_135756868961680 = {u'action': u'string:${context/absolute_url}/@@plone_lock_operations/force_unlock', u'method': u'POST', }
_static_135757154866128 = {u'id': u'plone-lock-status', }
_static_135757150055888 = {u'type': u'submit', u'value': u'Unlock', }
_static_135757327983760 = {}
_static_135757244301584 = __C2ZContextWrapper
_static_135757075141776 = {u'href': u'lock_details/author_page', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786cfdd3d0> name=None at 7b786be0fed0> -> __attrs_135757075272144
            __attrs_135757075272144 = _static_135757154866128
            __backup_locked_135757075706256 = get('locked', __marker)

            # <Value u'view/info/is_locked_for_current_user' (3:24)> -> __value
            __token = 77
            try:
                __zt_tmp = __attrs_135757075272144
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/info/is_locked_for_current_user', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['locked'] = __value
            __backup_stealable_135757071572560 = get('stealable', __marker)

            # <Value u'view/lock_is_stealable' (4:26)> -> __value
            __token = 141
            try:
                __zt_tmp = __attrs_135757075272144
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/lock_is_stealable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['stealable'] = __value
            __backup_lock_details_135757071403472 = get('lock_details', __marker)

            # <Value u'view/lock_info' (5:28)> -> __value
            __token = 194
            try:
                __zt_tmp = __attrs_135757075272144
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/lock_info', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['lock_details'] = __value
            __previous_i18n_domain_135757075272656 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="plone-lock-status">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150041360
            __attrs_135757150041360 = _static_135757327983760

            # <Value u'locked' (6:24)> -> __condition
            __token = 238
            try:
                __zt_tmp = __attrs_135757150041360
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'locked', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b786cb43050> name=None at 7b786cb43b10> -> __attrs_135757074273232
                __attrs_135757074273232 = _static_135757150040144

                # <dl ... (0:0)
                # --------------------------------------------------------
                __append(u'<dl class="portalMessage info">\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073441168
                __attrs_135757073441168 = _static_135757327983760

                # <dt ... (0:0)
                # --------------------------------------------------------
                __append(u'<dt>')
                __stream_135757149893264 = []
                __append_135757149893264 = __stream_135757149893264.append
                __append_135757149893264(u'Locked')
                __msgid_135757149893264 = __re_whitespace(''.join(__stream_135757149893264)).strip()
                if u'label_locked':
                    __append(translate(u'label_locked', mapping=None, default=__msgid_135757149893264, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</dt>\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073441936
                __attrs_135757073441936 = _static_135757327983760

                # <dd ... (0:0)
                # --------------------------------------------------------
                __append(u'<dd>\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074212944
                __attrs_135757074212944 = _static_135757327983760

                # <Value u'lock_details/author_page' (11:27)> -> __condition
                __token = 398
                try:
                    __zt_tmp = __attrs_135757074212944
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'lock_details/author_page', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __stream_135757075745920_author = ''
                    __stream_135757075745920_time = ''
                    __stream_135757075534800 = []
                    __append_135757075534800 = __stream_135757075534800.append
                    __append_135757075534800(u'\n          This item was locked by\n          ')
                    __stream_135757075745920_author = []
                    __append_135757075745920_author = __stream_135757075745920_author.append

                    # <Static value=<_ast.Dict object at 0x7b78683d5490> name=None at 7b786833a790> -> __attrs_135757073176016
                    __attrs_135757073176016 = _static_135757075141776

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075745920_author(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075142672
                    __default_135757075142672 = _DEFAULT_MARKER

                    # <Substitution u'lock_details/author_page' (16:34)> -> __attr_href
                    __token = 647
                    try:
                        __zt_tmp = __attrs_135757073176016
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('path', u'lock_details/author_page', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_135757075745920_author((u' href="%s"' % __attr_href))
                    __append_135757075745920_author(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075143184
                    __default_135757075143184 = _DEFAULT_MARKER

                    # <Value u'lock_details/fullname' (15:26)> -> __cache_135757075141008
                    __token = 590
                    try:
                        __zt_tmp = __attrs_135757073176016
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075141008 = _static_135757244280656('path', u'lock_details/fullname', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'lock_details/fullname' (15:26)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683d5990> -> __condition
                    __expression = __cache_135757075141008

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757075141008
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757075745920_author(__content)
                    __append_135757075745920_author(u'</a>')
                    __append_135757075534800(u'${author}')
                    __stream_135757075745920_author = ''.join(__stream_135757075745920_author)
                    __append_135757075534800(u'\n          ')
                    __stream_135757075745920_time = []
                    __append_135757075745920_time = __stream_135757075745920_time.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073105104
                    __attrs_135757073105104 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075745920_time(u'<span>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073105616
                    __default_135757073105616 = _DEFAULT_MARKER

                    # <Value u'lock_details/time_difference' (18:29)> -> __cache_135757073177680
                    __token = 738
                    try:
                        __zt_tmp = __attrs_135757073105104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757073177680 = _static_135757244280656('path', u'lock_details/time_difference', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'lock_details/time_difference' (18:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78680ae0d0> -> __condition
                    __expression = __cache_135757073177680

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135757073177680
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757075745920_time(__content)
                    __append_135757075745920_time(u'</span>')
                    __append_135757075534800(u'${time}')
                    __stream_135757075745920_time = ''.join(__stream_135757075745920_time)
                    __append_135757075534800(u' ago.\n        ')
                    __msgid_135757075534800 = __re_whitespace(''.join(__stream_135757075534800)).strip()
                    if u'description_webdav_locked_by_author_on_time':
                        __append(translate(u'description_webdav_locked_by_author_on_time', mapping={u'time': __stream_135757075745920_time, u'author': __stream_135757075745920_author, }, default=__msgid_135757075534800, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073105872
                __attrs_135757073105872 = _static_135757327983760

                # <Value u'not:lock_details/author_page' (21:27)> -> __condition
                __token = 858
                try:
                    __zt_tmp = __attrs_135757073105872
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('not', u'lock_details/author_page', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __stream_135757075745920_author = ''
                    __stream_135757075745920_time = ''
                    __stream_135757075536272 = []
                    __append_135757075536272 = __stream_135757075536272.append
                    __append_135757075536272(u'\n          This item was locked by\n          ')
                    __stream_135757075745920_author = []
                    __append_135757075745920_author = __stream_135757075745920_author.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868960528
                    __attrs_135756868960528 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075745920_author(u'<span>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868962128
                    __default_135756868962128 = _DEFAULT_MARKER

                    # <Value u'lock_details/fullname' (25:29)> -> __cache_135756868963536
                    __token = 1060
                    try:
                        __zt_tmp = __attrs_135756868960528
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756868963536 = _static_135757244280656('path', u'lock_details/fullname', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'lock_details/fullname' (25:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf34310> -> __condition
                    __expression = __cache_135756868963536

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135756868963536
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757075745920_author(__content)
                    __append_135757075745920_author(u'</span>')
                    __append_135757075536272(u'${author}')
                    __stream_135757075745920_author = ''.join(__stream_135757075745920_author)
                    __append_135757075536272(u'\n          ')
                    __stream_135757075745920_time = []
                    __append_135757075745920_time = __stream_135757075745920_time.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868962000
                    __attrs_135756868962000 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075745920_time(u'<span>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868961168
                    __default_135756868961168 = _DEFAULT_MARKER

                    # <Value u'lock_details/time_difference' (27:29)> -> __cache_135756868962512
                    __token = 1148
                    try:
                        __zt_tmp = __attrs_135756868962000
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756868962512 = _static_135757244280656('path', u'lock_details/time_difference', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'lock_details/time_difference' (27:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf34f90> -> __condition
                    __expression = __cache_135756868962512

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_135756868962512
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757075745920_time(__content)
                    __append_135757075745920_time(u'</span>')
                    __append_135757075536272(u'${time}')
                    __stream_135757075745920_time = ''.join(__stream_135757075745920_time)
                    __append_135757075536272(u' ago.\n        ')
                    __msgid_135757075536272 = __re_whitespace(''.join(__stream_135757075536272)).strip()
                    if u'description_webdav_locked_by_author_on_time':
                        __append(translate(u'description_webdav_locked_by_author_on_time', mapping={u'time': __stream_135757075745920_time, u'author': __stream_135757075745920_author, }, default=__msgid_135757075536272, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b785bf34590> name=None at 7b786bcbf850> -> __attrs_135757150055056
                __attrs_135757150055056 = _static_135756868961680

                # <Value u'stealable' (29:29)> -> __condition
                __token = 1245
                try:
                    __zt_tmp = __attrs_135757150055056
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'stealable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form method="POST"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150054608
                    __default_135757150054608 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}/@@plone_lock_operations/force_unlock' (30:37)> -> __attr_action
                    __token = 1293
                    try:
                        __zt_tmp = __attrs_135757150055056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_135757244280656('string', u'${context/absolute_url}/@@plone_lock_operations/force_unlock', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150054544
                    __attrs_135757150054544 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_135757075745680_unlock_button = ''
                    __stream_135757150056400 = []
                    __append_135757150056400 = __stream_135757150056400.append
                    __append_135757150056400(u'\n            If you are certain this user has abandoned the object,\n            you may\n            ')
                    __stream_135757075745680_unlock_button = []
                    __append_135757075745680_unlock_button = __stream_135757075745680_unlock_button.append

                    # <Static value=<_ast.Dict object at 0x7b786cb46dd0> name=None at 7b786cb467d0> -> __attrs_135757074251536
                    __attrs_135757074251536 = _static_135757150055888

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append_135757075745680_unlock_button(u'<input type="submit"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074251280
                    __default_135757074251280 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x7b786cb46a50> at 7b786cb46990> -> __attr_value
                    __attr_value = u'Unlock'
                    __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append_135757075745680_unlock_button((u' value="%s"' % __attr_value))
                    __append_135757075745680_unlock_button(u' />')
                    __append_135757150056400(u'${unlock_button}')
                    __stream_135757075745680_unlock_button = ''.join(__stream_135757075745680_unlock_button)
                    __append_135757150056400(u'\n            the object. You will then be able to edit it.\n          ')
                    __msgid_135757150056400 = __re_whitespace(''.join(__stream_135757150056400)).strip()
                    if u'description_webdav_locked_steal':
                        __append(translate(u'description_webdav_locked_steal', mapping={u'unlock_button': __stream_135757075745680_unlock_button, }, default=__msgid_135757150056400, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\n        </form>')
                __append(u'\n      </dd>\n    </dl>\n  ')
            __append(u'\n</div>')
            __i18n_domain = __previous_i18n_domain_135757075272656
            if (__backup_lock_details_135757071403472 is __marker):
                del econtext['lock_details']
            else:
                econtext['lock_details'] = __backup_lock_details_135757071403472
            if (__backup_stealable_135757071572560 is __marker):
                del econtext['stealable']
            else:
                econtext['stealable'] = __backup_stealable_135757071572560
            if (__backup_locked_135757075706256 is __marker):
                del econtext['locked']
            else:
                econtext['locked'] = __backup_locked_135757075706256
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }