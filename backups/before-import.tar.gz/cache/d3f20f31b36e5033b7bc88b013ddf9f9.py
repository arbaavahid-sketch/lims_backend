# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/selection.pt'

__tokens = {1613: (u'python:field.Vocabulary(context)', 38, 42), 1687: (u' python:len(vocab', 39, 40), 1755: (u'w context/@@at_selection_widg', 40, 48), 1831: (u'on python:selectionview.getSelected(vocab, val', 41, 43), 1921: (u'mat python:widget.fo', 42, 39), 1986: (u"python:(vlen &lt; 4 and format == 'flex') or (format == 'radi", 44, 37), 2093: (u'fieldName', 45, 41), 2211: (u'not: widget/render_own_label | nothing', 49, 40), 2322: (u'python:widget.Label(here)', 50, 43), 2493: (u'field/required', 53, 45), 2740: (u'python:widget.Description(here)', 57, 53), 2886: (u'string:${fieldName}_help', 59, 48), 2825: (u'description', 58, 52), 3096: (u'vocab', 65, 45), 3259: (u'fieldName', 69, 52), 3319: (u' string:${fieldName}_${repeat/item/number', 70, 49), 3416: (u"d python:item in selection and 'checked' or No", 71, 53), 3516: (u'ue i', 72, 50), 3734: (u'string:${fieldName}_${repeat/item/number}', 77, 51), 3605: (u'python:vocab.getValue(item)', 75, 44), 3915: (u"python:(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))", 85, 42), 4089: (u'not: widget/render_own_label | nothing', 89, 42), 4197: (u'python:fieldName', 90, 47), 4259: (u'python:widget.Label(here)', 91, 43), 4430: (u'field/required', 94, 45), 4677: (u'python:widget.Description(here)', 98, 53), 4823: (u'string:${fieldName}_help', 100, 48), 4762: (u'description', 99, 52), 5039: (u'fieldName', 106, 49), 5096: (u' fieldNam', 107, 46), 5160: (u'vocab', 109, 49), 5221: (u'item', 110, 54), 5283: (u" python:item in selection and 'selected' or Non", 111, 56), 5378: (u'python:vocab.getValue(item)', 112, 45), 1474: (u'field_macro|context/widgets/field/macros/edit', 35, 30), 1474: (u'field_macro|context/widgets/field/macros/edit', 35, 30), 5696: (u'context/widgets/selection/macros/edit', 127, 30), 5696: (u'context/widgets/selection/macros/edit', 127, 30), 714: (u"python:getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')", 19, 34), 872: (u' context/UID|nothin', 21, 33), 929: (u'kss_class', 22, 34), 970: (u' string:parent-fieldname-$fieldName-$ui', 23, 30), 1092: (u'python:field.Vocabulary(context)', 25, 34), 1159: (u' python:accessor(', 26, 33), 1213: (u'y python:context.displayValue(vocab, value, widge', 27, 34), 1351: (u'display', 29, 39), 497: (u'context/@@kss_field_decorator_view', 16, 39), 570: (u' nocall:kssClassesView/getKssClassesInlineEditabl', 17, 37)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_127045740876752 = u'edit'
_static_127045642474320 = {u'class': u'required', u'title': u'Required', }
_static_127045886978576 = __C2ZContextWrapper
_static_127045642477072 = {u'name': u'fieldName', u'id': u'fieldName', }
_static_127045642547152 = {u'id': u'fieldName', }
_static_127045642546640 = {u'class': u'formQuestion label', }
_static_127045642544528 = u'edit'
_static_127045970670736 = {}
_static_127045739281296 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_127045740344464 = {u'checked': u"python:item in selection and 'checked' or None", u'name': u'fieldName', u'value': u'item', u'class': u'noborder blurrable', u'type': u'radio', u'id': u'string:${fieldName}_${repeat/item/number}', }
_static_127045740222864 = {u'class': u'formQuestion', u'for': u'python:fieldName', }
_static_127045742077328 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_127045740316368 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_127045739312592 = {u'for': u'string:${fieldName}_${repeat/item/number}', }
_static_127045886978192 = __compile_zt_expr
_static_127045642585360 = {u'selected': u"python:item in selection and 'selected' or None", u'value': u'item', }
_static_127045739685840 = {u'class': u'kss_class', u'id': u'string:parent-fieldname-$fieldName-$uid', }
_static_127045643097936 = {u'class': u'required', u'title': u'Required', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045741896592
            __attrs_127045741896592 = _static_127045970670736
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045740878416
            __attrs_127045740878416 = _static_127045970670736
            __backup_macroname_127045887681712 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c244153d0> name=None at 738c244154d0> -> __value
            __value = _static_127045740876752
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045775309136
                __attrs_127045775309136 = _static_127045970670736
                __backup_vocab_127045741917712 = get('vocab', __marker)

                # <Value u'python:field.Vocabulary(context)' (38:42)> -> __value
                __token = 1613
                try:
                    __zt_tmp = __attrs_127045775309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'field.Vocabulary(context)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['vocab'] = __value
                __backup_vlen_127045741899472 = get('vlen', __marker)

                # <Value u'python:len(vocab)' (39:40)> -> __value
                __token = 1687
                try:
                    __zt_tmp = __attrs_127045775309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'len(vocab)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['vlen'] = __value
                __backup_selectionview_127045872051600 = get('selectionview', __marker)

                # <Value u'context/@@at_selection_widget' (40:48)> -> __value
                __token = 1755
                try:
                    __zt_tmp = __attrs_127045775309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'context/@@at_selection_widget', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['selectionview'] = __value
                __backup_selection_127045872051024 = get('selection', __marker)

                # <Value u'python:selectionview.getSelected(vocab, value)' (41:43)> -> __value
                __token = 1831
                try:
                    __zt_tmp = __attrs_127045775309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'selectionview.getSelected(vocab, value)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['selection'] = __value
                __backup_format_127045775310160 = get('format', __marker)

                # <Value u'python:widget.format' (42:39)> -> __value
                __token = 1921
                try:
                    __zt_tmp = __attrs_127045775309136
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'widget.format', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['format'] = __value
                __append(u'\n\n                ')

                # <Static value=<_ast.Dict object at 0x738c1e64efd0> name=None at 738c1e64ef90> -> __attrs_127045642547024
                __attrs_127045642547024 = _static_127045642547152

                # <Value u"python:(vlen < 4 and format == 'flex') or (format == 'radio')" (44:37)> -> __condition
                __token = 1986
                try:
                    __zt_tmp = __attrs_127045642547024
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u"(vlen < 4 and format == 'flex') or (format == 'radio')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642544080
                    __default_127045642544080 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (45:41)> -> __attr_id
                    __token = 2093
                    try:
                        __zt_tmp = __attrs_127045642547024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n\n                    <!-- Radio when the vocab is short < 4 -->\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c1e64edd0> name=None at 738c1e64eed0> -> __attrs_127045643096144
                    __attrs_127045643096144 = _static_127045642546640

                    # <Value u'not: widget/render_own_label | nothing' (49:40)> -> __condition
                    __token = 2211
                    try:
                        __zt_tmp = __attrs_127045643096144
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('not', u' widget/render_own_label | nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="formQuestion label">\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643099088
                        __attrs_127045643099088 = _static_127045970670736

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045643098960
                        __default_127045643098960 = _DEFAULT_MARKER

                        # <Value u'python:widget.Label(here)' (50:43)> -> __cache_127045643098256
                        __token = 2322
                        try:
                            __zt_tmp = __attrs_127045643099088
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045643098256 = _static_127045886978192('python', u'widget.Label(here)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:widget.Label(here)' (50:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e6d53d0> -> __condition
                        __expression = __cache_127045643098256

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span />')
                        else:
                            __content = __cache_127045643098256
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c1e6d5750> name=None at 738c1e6d5b10> -> __attrs_127045643098768
                        __attrs_127045643098768 = _static_127045643097936

                        # <Value u'field/required' (53:45)> -> __condition
                        __token = 2493
                        try:
                            __zt_tmp = __attrs_127045643098768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_127045886978192('path', u'field/required', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="required"')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045643099920
                            __default_127045643099920 = _DEFAULT_MARKER

                            # <Translate msgid=u'title_required' node=<_ast.Str object at 0x738c1e6d5790> at 738c1e6d58d0> -> __attr_title
                            __attr_title = u'Required'
                            __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u' title="%s"' % __attr_title))
                            __append(u'>&nbsp;</span>')
                        __append(u'\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c2438c6d0> name=None at 738c24286090> -> __attrs_127045740316176
                        __attrs_127045740316176 = _static_127045740316368
                        __backup_description_127045642545488 = get('description', __marker)

                        # <Value u'python:widget.Description(here)' (57:53)> -> __value
                        __token = 2740
                        try:
                            __zt_tmp = __attrs_127045740316176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u'widget.Description(here)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['description'] = __value

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="formHelp"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045740316112
                        __default_127045740316112 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_help' (59:48)> -> __attr_id
                        __token = 2886
                        try:
                            __zt_tmp = __attrs_127045740316176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('string', u'${fieldName}_help', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739244880
                        __default_127045739244880 = _DEFAULT_MARKER

                        # <Value u'description' (58:52)> -> __cache_127045740371280
                        __token = 2825
                        try:
                            __zt_tmp = __attrs_127045740316176
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045740371280 = _static_127045886978192('path', u'description', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'description' (58:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24399250> -> __condition
                        __expression = __cache_127045740371280

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                          Help\n                        ')
                        else:
                            __content = __cache_127045740371280
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>')
                        if (__backup_description_127045642545488 is __marker):
                            del econtext['description']
                        else:
                            econtext['description'] = __backup_description_127045642545488
                        __append(u'\n                    </div>')
                    __append(u'\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045740300240
                    __attrs_127045740300240 = _static_127045970670736
                    __backup_item_127045642543312 = get('item', __marker)

                    # <Value u'vocab' (65:45)> -> __iterator
                    __token = 3096
                    try:
                        __zt_tmp = __attrs_127045740300240
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('path', u'vocab', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045740344272, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item
                        __append(u'\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c24393490> name=None at 738c24393690> -> __attrs_127045739313552
                        __attrs_127045739313552 = _static_127045740344464

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input class="noborder blurrable" type="radio"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045741424720
                        __default_127045741424720 = _DEFAULT_MARKER

                        # <Substitution u'fieldName' (69:52)> -> __attr_name
                        __token = 3259
                        try:
                            __zt_tmp = __attrs_127045739313552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045740175952
                        __default_127045740175952 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_${repeat/item/number}' (70:49)> -> __attr_id
                        __token = 3319
                        try:
                            __zt_tmp = __attrs_127045739313552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('string', u'${fieldName}_${repeat/item/number}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739312464
                        __default_127045739312464 = _DEFAULT_MARKER

                        # <Boolean u"python:item in selection and 'checked' or None" (71:53)> -> __attr_checked
                        __token = 3416
                        try:
                            __zt_tmp = __attrs_127045739313552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_checked = _static_127045886978192('python', u"item in selection and 'checked' or None", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if (__attr_checked is _DEFAULT_MARKER):
                            __attr_checked = None
                        else:
                            if __attr_checked:
                                __attr_checked = u'checked'
                            else:
                                __attr_checked = None
                        if (__attr_checked is not None):
                            __append((u' checked="%s"' % __attr_checked))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739314512
                        __default_127045739314512 = _DEFAULT_MARKER

                        # <Substitution u'item' (72:50)> -> __attr_value
                        __token = 3516
                        try:
                            __zt_tmp = __attrs_127045739313552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_127045886978192('path', u'item', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u' />\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c242975d0> name=None at 738c24297790> -> __attrs_127045739313808
                        __attrs_127045739313808 = _static_127045739312592

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739313936
                        __default_127045739313936 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_${repeat/item/number}' (77:51)> -> __attr_for
                        __token = 3734
                        try:
                            __zt_tmp = __attrs_127045739313808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_127045886978192('string', u'${fieldName}_${repeat/item/number}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739313168
                        __default_127045739313168 = _DEFAULT_MARKER

                        # <Value u'python:vocab.getValue(item)' (75:44)> -> __cache_127045739312336
                        __token = 3605
                        try:
                            __zt_tmp = __attrs_127045739313808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045739312336 = _static_127045886978192('python', u'vocab.getValue(item)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:vocab.getValue(item)' (75:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24297510> -> __condition
                        __expression = __cache_127045739312336

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_127045739312336
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</label>\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045740379408
                        __attrs_127045740379408 = _static_127045970670736

                        # <br ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<br />\n\n                    ')
                        ____index_127045740344272 -= 1
                        if (____index_127045740344272 > 0):
                            __append('')
                    if (__backup_item_127045642543312 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_127045642543312
                    __append(u'\n\n                </span>')
                __append(u'\n\n                ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643096784
                __attrs_127045643096784 = _static_127045970670736

                # <Value u"python:(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))" (85:42)> -> __condition
                __token = 3915
                try:
                    __zt_tmp = __attrs_127045643096784
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u"(vlen >= 4 and format == 'flex') or (format in ('select', 'pulldown'))", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n\n                    <!-- Pulldown when longer -->\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c24375990> name=None at 738c24375c50> -> __attrs_127045642473872
                    __attrs_127045642473872 = _static_127045740222864

                    # <Value u'not: widget/render_own_label | nothing' (89:42)> -> __condition
                    __token = 4089
                    try:
                        __zt_tmp = __attrs_127045642473872
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_127045886978192('not', u' widget/render_own_label | nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if __condition:

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label class="formQuestion"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127046034733584
                        __default_127046034733584 = _DEFAULT_MARKER

                        # <Substitution u'python:fieldName' (90:47)> -> __attr_for
                        __token = 4197
                        try:
                            __zt_tmp = __attrs_127045642473872
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_127045886978192('python', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642474704
                        __attrs_127045642474704 = _static_127045970670736

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642474192
                        __default_127045642474192 = _DEFAULT_MARKER

                        # <Value u'python:widget.Label(here)' (91:43)> -> __cache_127045642474000
                        __token = 4259
                        try:
                            __zt_tmp = __attrs_127045642474704
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045642474000 = _static_127045886978192('python', u'widget.Label(here)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:widget.Label(here)' (91:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e63d510> -> __condition
                        __expression = __cache_127045642474000

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span />')
                        else:
                            __content = __cache_127045642474000
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c1e63d350> name=None at 738c1e63d3d0> -> __attrs_127045642476688
                        __attrs_127045642476688 = _static_127045642474320

                        # <Value u'field/required' (94:45)> -> __condition
                        __token = 4430
                        try:
                            __zt_tmp = __attrs_127045642476688
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_127045886978192('path', u'field/required', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="required"')

                            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642477264
                            __default_127045642477264 = _DEFAULT_MARKER

                            # <Translate msgid=u'title_required' node=<_ast.Str object at 0x738c1e63df10> at 738c1e63d790> -> __attr_title
                            __attr_title = u'Required'
                            __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u' title="%s"' % __attr_title))
                            __append(u'>&nbsp;</span>')
                        __append(u'\n                        ')

                        # <Static value=<_ast.Dict object at 0x738c2453a590> name=None at 738c2453a690> -> __attrs_127045642586768
                        __attrs_127045642586768 = _static_127045742077328
                        __backup_description_127045642546512 = get('description', __marker)

                        # <Value u'python:widget.Description(here)' (98:53)> -> __value
                        __token = 4677
                        try:
                            __zt_tmp = __attrs_127045642586768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_127045886978192('python', u'widget.Description(here)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        econtext['description'] = __value

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="formHelp"')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642586256
                        __default_127045642586256 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_help' (100:48)> -> __attr_id
                        __token = 4823
                        try:
                            __zt_tmp = __attrs_127045642586768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_127045886978192('string', u'${fieldName}_help', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045742079440
                        __default_127045742079440 = _DEFAULT_MARKER

                        # <Value u'description' (99:52)> -> __cache_127045642475216
                        __token = 4762
                        try:
                            __zt_tmp = __attrs_127045642586768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045642475216 = _static_127045886978192('path', u'description', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'description' (99:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c2453ac90> -> __condition
                        __expression = __cache_127045642475216

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                          Help\n                        ')
                        else:
                            __content = __cache_127045642475216
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>')
                        if (__backup_description_127045642546512 is __marker):
                            del econtext['description']
                        else:
                            econtext['description'] = __backup_description_127045642546512
                        __append(u'\n                    </label>')
                    __append(u'\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x738c1e63de10> name=None at 738c1e63db90> -> __attrs_127045642585616
                    __attrs_127045642585616 = _static_127045642477072

                    # <select ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<select')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642588112
                    __default_127045642588112 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (106:49)> -> __attr_name
                    __token = 5039
                    try:
                        __zt_tmp = __attrs_127045642585616
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642587024
                    __default_127045642587024 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (107:46)> -> __attr_id
                    __token = 5096
                    try:
                        __zt_tmp = __attrs_127045642585616
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'>\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x738c1e658510> name=None at 738c1e658dd0> -> __attrs_127045643491152
                    __attrs_127045643491152 = _static_127045642585360
                    __backup_item_127045740371664 = get('item', __marker)

                    # <Value u'vocab' (109:49)> -> __iterator
                    __token = 5160
                    try:
                        __zt_tmp = __attrs_127045643491152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_127045886978192('path', u'vocab', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    (__iterator, ____index_127045643492752, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642587344
                        __default_127045642587344 = _DEFAULT_MARKER

                        # <Substitution u'item' (110:54)> -> __attr_value
                        __token = 5221
                        try:
                            __zt_tmp = __attrs_127045643491152
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_127045886978192('path', u'item', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642585040
                        __default_127045642585040 = _DEFAULT_MARKER

                        # <Boolean u"python:item in selection and 'selected' or None" (111:56)> -> __attr_selected
                        __token = 5283
                        try:
                            __zt_tmp = __attrs_127045643491152
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_selected = _static_127045886978192('python', u"item in selection and 'selected' or None", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                        if (__attr_selected is _DEFAULT_MARKER):
                            __attr_selected = None
                        else:
                            if __attr_selected:
                                __attr_selected = u'selected'
                            else:
                                __attr_selected = None
                        if (__attr_selected is not None):
                            __append((u' selected="%s"' % __attr_selected))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045642584400
                        __default_127045642584400 = _DEFAULT_MARKER

                        # <Value u'python:vocab.getValue(item)' (112:45)> -> __cache_127045642584592
                        __token = 5378
                        try:
                            __zt_tmp = __attrs_127045643491152
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_127045642584592 = _static_127045886978192('python', u'vocab.getValue(item)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:vocab.getValue(item)' (112:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c1e658250> -> __condition
                        __expression = __cache_127045642584592

                        # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_127045642584592
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</option>')
                        ____index_127045643492752 -= 1
                        if (____index_127045643492752 > 0):
                            __append('\n                        ')
                    if (__backup_item_127045740371664 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_127045740371664
                    __append(u'\n\n                    </select>\n\n                ')
                __append(u'\n\n            ')
                if (__backup_format_127045775310160 is __marker):
                    del econtext['format']
                else:
                    econtext['format'] = __backup_format_127045775310160
                if (__backup_selection_127045872051024 is __marker):
                    del econtext['selection']
                else:
                    econtext['selection'] = __backup_selection_127045872051024
                if (__backup_selectionview_127045872051600 is __marker):
                    del econtext['selectionview']
                else:
                    econtext['selectionview'] = __backup_selectionview_127045872051600
                if (__backup_vlen_127045741899472 is __marker):
                    del econtext['vlen']
                else:
                    econtext['vlen'] = __backup_vlen_127045741899472
                if (__backup_vocab_127045741917712 is __marker):
                    del econtext['vocab']
                else:
                    econtext['vocab'] = __backup_vocab_127045741917712
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro|context/widgets/field/macros/edit' (35:30)> -> __macro
            __token = 1474
            try:
                __zt_tmp = __attrs_127045740878416
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'field_macro|context/widgets/field/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 1474
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045887681712 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045887681712
            __append(u'\n\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045740936720
            __attrs_127045740936720 = _static_127045970670736

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n        ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045642544208
            __attrs_127045642544208 = _static_127045970670736
            __backup_macroname_127045756441776 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e64e590> name=None at 738c1e64e890> -> __value
            __value = _static_127045642544528
            econtext['macroname'] = __value

            # <Value u'context/widgets/selection/macros/edit' (127:30)> -> __macro
            __token = 5696
            try:
                __zt_tmp = __attrs_127045642544208
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'context/widgets/selection/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 5696
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756441776 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756441776
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_selection_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c242f27d0> name=None at 738c242f2110> -> __attrs_127045741920016
            __attrs_127045741920016 = _static_127045739685840
            __backup_kss_class_127045789979856 = get('kss_class', __marker)

            # <Value u"python:getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')" (19:34)> -> __value
            __token = 714
            try:
                __zt_tmp = __attrs_127045741920016
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('python', u"getKssClasses(fieldName,\n                              templateId='widgets/selection', macro='selection-field-view')", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['kss_class'] = __value
            __backup_uid_127045741630160 = get('uid', __marker)

            # <Value u'context/UID|nothing' (21:33)> -> __value
            __token = 872
            try:
                __zt_tmp = __attrs_127045741920016
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'context/UID|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['uid'] = __value

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045741506256
            __default_127045741506256 = _DEFAULT_MARKER

            # <Substitution u'kss_class' (22:34)> -> __attr_class
            __token = 929
            try:
                __zt_tmp = __attrs_127045741920016
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_127045886978192('path', u'kss_class', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045741517200
            __default_127045741517200 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName-$uid' (23:30)> -> __attr_id
            __token = 970
            try:
                __zt_tmp = __attrs_127045741920016
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_127045886978192('string', u'parent-fieldname-$fieldName-$uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n            ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045872052304
                __attrs_127045872052304 = _static_127045970670736
                __backup_vocab_127045742214608 = get('vocab', __marker)

                # <Value u'python:field.Vocabulary(context)' (25:34)> -> __value
                __token = 1092
                try:
                    __zt_tmp = __attrs_127045872052304
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'field.Vocabulary(context)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['vocab'] = __value
                __backup_value_127045742324496 = get('value', __marker)

                # <Value u'python:accessor()' (26:33)> -> __value
                __token = 1159
                try:
                    __zt_tmp = __attrs_127045872052304
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'accessor()', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['value'] = __value
                __backup_display_127045872051088 = get('display', __marker)

                # <Value u'python:context.displayValue(vocab, value, widget)' (27:34)> -> __value
                __token = 1213
                try:
                    __zt_tmp = __attrs_127045872052304
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'context.displayValue(vocab, value, widget)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['display'] = __value

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045740702864
                __default_127045740702864 = _DEFAULT_MARKER

                # <Value u'display' (29:39)> -> __cache_127045741670480
                __token = 1351
                try:
                    __zt_tmp = __attrs_127045872052304
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_127045741670480 = _static_127045886978192('path', u'display', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                # <BinOp left=<Value u'display' (29:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c243eae50> -> __condition
                __expression = __cache_127045741670480

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_127045741670480
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                if (__backup_display_127045872051088 is __marker):
                    del econtext['display']
                else:
                    econtext['display'] = __backup_display_127045872051088
                if (__backup_value_127045742324496 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_127045742324496
                if (__backup_vocab_127045742214608 is __marker):
                    del econtext['vocab']
                else:
                    econtext['vocab'] = __backup_vocab_127045742214608
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n        </span>')
            if (__backup_uid_127045741630160 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_127045741630160
            if (__backup_kss_class_127045789979856 is __marker):
                del econtext['kss_class']
            else:
                econtext['kss_class'] = __backup_kss_class_127045789979856
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045741926352
            __attrs_127045741926352 = _static_127045970670736
            __backup_kssClassesView_127045739282064 = get('kssClassesView', __marker)

            # <Value u'context/@@kss_field_decorator_view' (16:39)> -> __value
            __token = 497
            try:
                __zt_tmp = __attrs_127045741926352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['kssClassesView'] = __value
            __backup_getKssClasses_127045741563728 = get('getKssClasses', __marker)

            # <Value u'nocall:kssClassesView/getKssClassesInlineEditable' (17:37)> -> __value
            __token = 570
            try:
                __zt_tmp = __attrs_127045741926352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('nocall', u'kssClassesView/getKssClassesInlineEditable', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['getKssClasses'] = __value
            __append(u'\n        ')
            __token = None
            render_selection_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
            if (__backup_getKssClasses_127045741563728 is __marker):
                del econtext['getKssClasses']
            else:
                econtext['getKssClasses'] = __backup_getKssClasses_127045741563728
            if (__backup_kssClassesView_127045739282064 is __marker):
                del econtext['kssClassesView']
            else:
                econtext['kssClassesView'] = __backup_kssClassesView_127045739282064
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c2428fb90> name=None at 738c366b9050> -> __attrs_127045739281680
            __attrs_127045739281680 = _static_127045739281296
            __previous_i18n_domain_127045739280016 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n/home/campbell/Plone/zeocluster/parts/omelette/Products/Archetypes/skins/archetypes/widgets/selection.pt\n')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739281936
            __attrs_127045739281936 = _static_127045970670736

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739280720
            __attrs_127045739280720 = _static_127045970670736

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title>\n</head>\n\n')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739278928
            __attrs_127045739278928 = _static_127045970670736

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Selection Widgets -->\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n</body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_127045739280016
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_selection_field_view': render_selection_field_view, u'render_view': render_view, 'render': render, }