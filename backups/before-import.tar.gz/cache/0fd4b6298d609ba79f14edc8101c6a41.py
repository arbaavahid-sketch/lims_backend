# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/contentviews.pt'

__tokens = {40: (u'context/@@plone', 1, 40), 92: (u'ploneview/showToolbar', 2, 33), 187: (u'view/tabSet1', 5, 29), 236: (u'python: view.menu_template(actions=actions)', 6, 32), 332: (u'view/tabSet2', 9, 29), 381: (u'python: view.menu_template(actions=actions)', 10, 32), 544: (u'provider:plone.contentmenu', 15, 32)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838794967184 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681238160
            __attrs_133838681238160 = _static_133838878659728
            __backup_ploneview_133838681210960 = get('ploneview', __marker)

            # <Value u'context/@@plone' (1:40)> -> __value
            __token = 40
            try:
                __zt_tmp = __attrs_133838681238160
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'context/@@plone', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['ploneview'] = __value

            # <Value u'ploneview/showToolbar' (2:33)> -> __condition
            __token = 92
            try:
                __zt_tmp = __attrs_133838681238160
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_133838794967184('path', u'ploneview/showToolbar', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_133838681236560 = __i18n_domain
                __i18n_domain = u'plone'
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681238224
                __attrs_133838681238224 = _static_133838878659728
                __backup_actions_133838681238800 = get('actions', __marker)

                # <Value u'view/tabSet1' (5:29)> -> __value
                __token = 187
                try:
                    __zt_tmp = __attrs_133838681238224
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'view/tabSet1', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['actions'] = __value
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681237840
                __attrs_133838681237840 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681235536
                __default_133838681235536 = _DEFAULT_MARKER

                # <Value u'python: view.menu_template(actions=actions)' (6:32)> -> __cache_133838681239504
                __token = 236
                try:
                    __zt_tmp = __attrs_133838681237840
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838681239504 = _static_133838794967184('python', u' view.menu_template(actions=actions)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'python: view.menu_template(actions=actions)' (6:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf0d6150> -> __condition
                __expression = __cache_133838681239504

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_133838681239504
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  ')
                if (__backup_actions_133838681238800 is __marker):
                    del econtext['actions']
                else:
                    econtext['actions'] = __backup_actions_133838681238800
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681238928
                __attrs_133838681238928 = _static_133838878659728
                __backup_actions_133838681237072 = get('actions', __marker)

                # <Value u'view/tabSet2' (9:29)> -> __value
                __token = 332
                try:
                    __zt_tmp = __attrs_133838681238928
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'view/tabSet2', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['actions'] = __value
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698699216
                __attrs_133838698699216 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698698896
                __default_133838698698896 = _DEFAULT_MARKER

                # <Value u'python: view.menu_template(actions=actions)' (10:32)> -> __cache_133838698699280
                __token = 381
                try:
                    __zt_tmp = __attrs_133838698699216
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838698699280 = _static_133838794967184('python', u' view.menu_template(actions=actions)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'python: view.menu_template(actions=actions)' (10:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c017dd50> -> __condition
                __expression = __cache_133838698699280

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_133838698699280
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  ')
                if (__backup_actions_133838681237072 is __marker):
                    del econtext['actions']
                else:
                    econtext['actions'] = __backup_actions_133838681237072
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698699984
                __attrs_133838698699984 = _static_133838878659728
                __append(u'\r\n    <!-- Workflow, Display, Portlets -->\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698699024
                __attrs_133838698699024 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698699088
                __default_133838698699088 = _DEFAULT_MARKER

                # <Value u'provider:plone.contentmenu' (15:32)> -> __cache_133838698698192
                __token = 544
                try:
                    __zt_tmp = __attrs_133838698699024
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838698698192 = _static_133838794967184('provider', u'plone.contentmenu', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:plone.contentmenu' (15:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c017d650> -> __condition
                __expression = __cache_133838698698192

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_133838698698192
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  \r\n\r\n')
                __i18n_domain = __previous_i18n_domain_133838681236560
            if (__backup_ploneview_133838681210960 is __marker):
                del econtext['ploneview']
            else:
                econtext['ploneview'] = __backup_ploneview_133838681210960
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }