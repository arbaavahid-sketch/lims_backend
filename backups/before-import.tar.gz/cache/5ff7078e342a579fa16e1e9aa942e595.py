# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/../static/resources.pt'

__tokens = {28: (u'string:${view/site_url}/++plone++senaite.core.static/modules/react/vendor-react.js', 1, 28), 149: (u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery/jquery.min.js', 1, 149), 269: (u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-form/jquery.form.min.js', 1, 269), 399: (u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/jquery-ui.min.js', 1, 399), 525: (u'string:${view/site_url}/++plone++senaite.core.static/modules/handlebars/handlebars.min.js', 1, 525), 653: (u'string:${view/site_url}/++plone++senaite.core.static/modules/popperjs/popper.min.js', 1, 653), 775: (u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap/js/bootstrap.min.js', 1, 775), 904: (u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-confirmation2/bootstrap-confirmation.min.js', 1, 904), 1057: (u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/js/bootstrap-select.min.js', 1, 1057), 1200: (u'string:${view/site_url}/++plone++senaite.core.static/modules/tinymce/tinymce.min.js', 1, 1200), 1322: (u'string:${view/site_url}/++plone++senaite.core.static/modules/d3/d3.min.js', 1, 1322), 1459: (u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/css/bootstrap-select.min.css', 1, 1459), 1621: (u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/themes/smoothness/jquery-ui.min.css', 1, 1621), 1758: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.064ec022f1f85e4c78be.js', 1, 1758), 1894: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.0e4fea660acd4521a98f.js', 1, 1894), 2063: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.css', 1, 2063), 2196: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.css', 1, 2196), 2312: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.js', 1, 2312), 2450: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.css', 1, 2450), 2556: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/legacy.js', 1, 2556), 2690: (u'string:${view/site_url}/++plone++senaite.core.static/bundles/legacy.css', 1, 2690)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757152278416 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/bundles/legacy.js', }
_static_135757163481744 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.064ec022f1f85e4c78be.js', }
_static_135757159532880 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-form/jquery.form.min.js', }
_static_135757166283664 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/react/vendor-react.js', }
_static_135757152275920 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/handlebars/handlebars.min.js', }
_static_135757226787920 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757226788560 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/d3/d3.min.js', }
_static_135757148780240 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757163481232 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757152273936 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/popperjs/popper.min.js', }
_static_135757148736016 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/js/bootstrap-select.min.js', }
_static_135757148782416 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757163480464 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.0e4fea660acd4521a98f.js', }
_static_135757244280656 = __compile_zt_expr
_static_135757154041552 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/jquery-ui.min.js', }
_static_135757152278544 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757148736592 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/tinymce/tinymce.min.js', }
_static_135757166284048 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery/jquery.min.js', }
_static_135757154667856 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap/js/bootstrap.min.js', }
_static_135757148779472 = {u'href': u'#', u'rel': u'stylesheet', }
_static_135757148780880 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.js', }
_static_135757154666704 = {u'src': u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-confirmation2/bootstrap-confirmation.min.js', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786dac0b90> name=None at 7b786dac00d0> -> __attrs_135757166282640
            __attrs_135757166282640 = _static_135757166283664

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166283536
            __default_135757166283536 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/react/vendor-react.js' (1:28)> -> __attr_src
            __token = 28
            try:
                __zt_tmp = __attrs_135757166282640
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/react/vendor-react.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786dac0d10> name=None at 7b786dac0110> -> __attrs_135757226772688
            __attrs_135757226772688 = _static_135757166284048

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226773776
            __default_135757226773776 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery/jquery.min.js' (1:149)> -> __attr_src
            __token = 149
            try:
                __zt_tmp = __attrs_135757226772688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/jquery/jquery.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786d450950> name=None at 7b786d4507d0> -> __attrs_135757159534288
            __attrs_135757159534288 = _static_135757159532880

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159531984
            __default_135757159531984 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-form/jquery.form.min.js' (1:269)> -> __attr_src
            __token = 269
            try:
                __zt_tmp = __attrs_135757159534288
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/jquery-form/jquery.form.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cf13ed0> name=None at 7b786cf13990> -> __attrs_135757152274960
            __attrs_135757152274960 = _static_135757154041552

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152274896
            __default_135757152274896 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/jquery-ui.min.js' (1:399)> -> __attr_src
            __token = 399
            try:
                __zt_tmp = __attrs_135757152274960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/jquery-ui.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cd64dd0> name=None at 7b786cd64e50> -> __attrs_135757152276112
            __attrs_135757152276112 = _static_135757152275920

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152272912
            __default_135757152272912 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/handlebars/handlebars.min.js' (1:525)> -> __attr_src
            __token = 525
            try:
                __zt_tmp = __attrs_135757152276112
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/handlebars/handlebars.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cd64610> name=None at 7b786cd64a50> -> __attrs_135757154667984
            __attrs_135757154667984 = _static_135757152273936

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154666448
            __default_135757154666448 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/popperjs/popper.min.js' (1:653)> -> __attr_src
            __token = 653
            try:
                __zt_tmp = __attrs_135757154667984
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/popperjs/popper.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cfacd50> name=None at 7b786cfac290> -> __attrs_135757154664848
            __attrs_135757154664848 = _static_135757154667856

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154667152
            __default_135757154667152 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap/js/bootstrap.min.js' (1:775)> -> __attr_src
            __token = 775
            try:
                __zt_tmp = __attrs_135757154664848
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/bootstrap/js/bootstrap.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cfac8d0> name=None at 7b786cfaced0> -> __attrs_135757148737040
            __attrs_135757148737040 = _static_135757154666704

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154666000
            __default_135757154666000 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-confirmation2/bootstrap-confirmation.min.js' (1:904)> -> __attr_src
            __token = 904
            try:
                __zt_tmp = __attrs_135757148737040
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/bootstrap-confirmation2/bootstrap-confirmation.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786ca04a10> name=None at 7b786ca04dd0> -> __attrs_135757148736912
            __attrs_135757148736912 = _static_135757148736016

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148733520
            __default_135757148733520 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/js/bootstrap-select.min.js' (1:1057)> -> __attr_src
            __token = 1057
            try:
                __zt_tmp = __attrs_135757148736912
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/js/bootstrap-select.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786ca04c50> name=None at 7b786ca04cd0> -> __attrs_135757135285648
            __attrs_135757135285648 = _static_135757148736592

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148737296
            __default_135757148737296 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/tinymce/tinymce.min.js' (1:1200)> -> __attr_src
            __token = 1200
            try:
                __zt_tmp = __attrs_135757135285648
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/tinymce/tinymce.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b78714746d0> name=None at 7b7871474350> -> __attrs_135757226788304
            __attrs_135757226788304 = _static_135757226788560

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226787088
            __default_135757226787088 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/d3/d3.min.js' (1:1322)> -> __attr_src
            __token = 1322
            try:
                __zt_tmp = __attrs_135757226788304
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/d3/d3.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b7871474450> name=None at 7b7871474690> -> __attrs_135757163479888
            __attrs_135757163479888 = _static_135757226787920

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163482832
            __default_135757163482832 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/css/bootstrap-select.min.css' (1:1459)> -> __attr_href
            __token = 1459
            try:
                __zt_tmp = __attrs_135757163479888
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/bootstrap-select/css/bootstrap-select.min.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')

            # <Static value=<_ast.Dict object at 0x7b786d814890> name=None at 7b786d814190> -> __attrs_135757163482768
            __attrs_135757163482768 = _static_135757163481232

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163479376
            __default_135757163479376 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/themes/smoothness/jquery-ui.min.css' (1:1621)> -> __attr_href
            __token = 1621
            try:
                __zt_tmp = __attrs_135757163482768
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/modules/jquery-ui/themes/smoothness/jquery-ui.min.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')

            # <Static value=<_ast.Dict object at 0x7b786d814a90> name=None at 7b786d814f50> -> __attrs_135757163482704
            __attrs_135757163482704 = _static_135757163481744

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163479632
            __default_135757163479632 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.064ec022f1f85e4c78be.js' (1:1758)> -> __attr_src
            __token = 1758
            try:
                __zt_tmp = __attrs_135757163482704
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.064ec022f1f85e4c78be.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786d814590> name=None at 7b786d814d90> -> __attrs_135757163482128
            __attrs_135757163482128 = _static_135757163480464

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163482576
            __default_135757163482576 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.0e4fea660acd4521a98f.js' (1:1894)> -> __attr_src
            __token = 1894
            try:
                __zt_tmp = __attrs_135757163482128
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.0e4fea660acd4521a98f.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786ca0ff50> name=None at 7b786ca0f7d0> -> __attrs_135757148780816
            __attrs_135757148780816 = _static_135757148782416

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148780944
            __default_135757148780944 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.css' (1:2063)> -> __attr_href
            __token = 2063
            try:
                __zt_tmp = __attrs_135757148780816
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')

            # <Static value=<_ast.Dict object at 0x7b786ca0f6d0> name=None at 7b786ca0f650> -> __attrs_135757148781648
            __attrs_135757148781648 = _static_135757148780240

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148779536
            __default_135757148779536 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.css' (1:2196)> -> __attr_href
            __token = 2196
            try:
                __zt_tmp = __attrs_135757148781648
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/senaite.core.widgets.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')

            # <Static value=<_ast.Dict object at 0x7b786ca0f950> name=None at 7b786ca0f810> -> __attrs_135757148778704
            __attrs_135757148778704 = _static_135757148780880

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148781968
            __default_135757148781968 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.js' (1:2312)> -> __attr_src
            __token = 2312
            try:
                __zt_tmp = __attrs_135757148778704
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786ca0f3d0> name=None at 7b786ca0fc10> -> __attrs_135757152280336
            __attrs_135757152280336 = _static_135757148779472

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152277584
            __default_135757152277584 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.css' (1:2450)> -> __attr_href
            __token = 2450
            try:
                __zt_tmp = __attrs_135757152280336
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/thirdparty.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')

            # <Static value=<_ast.Dict object at 0x7b786cd65790> name=None at 7b786cd65c50> -> __attrs_135757152279440
            __attrs_135757152279440 = _static_135757152278416

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152279824
            __default_135757152279824 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/legacy.js' (1:2556)> -> __attr_src
            __token = 2556
            try:
                __zt_tmp = __attrs_135757152279440
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/legacy.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>')

            # <Static value=<_ast.Dict object at 0x7b786cd65810> name=None at 7b786cd65690> -> __attrs_135757152276816
            __attrs_135757152276816 = _static_135757152278544

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152278288
            __default_135757152278288 = _DEFAULT_MARKER

            # <Substitution u'string:${view/site_url}/++plone++senaite.core.static/bundles/legacy.css' (1:2690)> -> __attr_href
            __token = 2690
            try:
                __zt_tmp = __attrs_135757152276816
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${view/site_url}/++plone++senaite.core.static/bundles/legacy.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="stylesheet"/>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }