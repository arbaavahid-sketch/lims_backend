# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.discussion-3.4.9-py2.7.egg/plone/app/discussion/browser/comments.pt'

__tokens = {46: (u'view/can_reply', 1, 46), 104: (u' view/is_discussion_allowe', 2, 42), 183: (u'd view/anonymous_discussion_allow', 3, 50), 261: (u'ed view/edit_comment_allo', 4, 41), 336: (u'wed view/delete_own_comment_all', 5, 45), 398: (u'Anon view/is_anon', 6, 25), 449: (u'eview view/can_', 7, 27), 496: (u'eplies python:view.get_replies(can', 8, 24), 566: (u'replies python:view.has_replies(ca', 9, 27), 643: (u'terImage view/show_commen', 10, 33), 699: (u'   errors options/state/getErro', 11, 20), 760: (u'     wtool context/@@plone_too', 12, 18), 825: (u' auth_token context/@@authenticator/t', 13, 22), 902: (u'python:isDiscussionAllowed or has_replies', 14, 26), 1025: (u'python:isAnon and not isAnonymousDiscussionAllowed', 18, 24), 1115: (u'view/login_action', 19, 37), 1554: (u'has_replies', 30, 24), 1449: (u"python: showCommenterImage and 'discussion showCommenterImage' or 'discussion'", 29, 31), 1611: (u'replies', 31, 43), 1690: (u'reply_dict/comment', 34, 35), 1749: (u' reply/getI', 35, 39), 1796: (u'h reply_dict/depth|python', 36, 33), 1857: (u"th python: depth > 10 and '10' or de", 37, 32), 1939: (u'url python:view.get_commenter_home_url(username=reply.author_usern', 38, 41), 2051: (u'link python:author_home_url and not i', 39, 40), 2131: (u't_url python:view.get_commenter_portrait(reply.author_use', 40, 36), 2231: (u"_state python:wtool.getInfoFor(reply, 'review_state', ", 41, 35), 2323: (u'canEdit python:view.can_edi', 42, 29), 2390: (u'anDelete python:view.can_dele', 43, 30), 2460: (u"olorclass python:lambda x: 'state-private' if x=='rejected' else ('state-internal' if x=='spam' else '", 44, 30), 2795: (u"python:canReview or review_state == 'published'", 47, 32), 2614: (u"python:'comment replyTreeLevel{depth} {state}'.format(depth= depth, state=colorclass(review_state))", 45, 39), 2750: (u' comment_i', 46, 35), 2903: (u'showCommenterImage', 49, 57), 2970: (u'has_author_link', 50, 46), 3039: (u'author_home_url', 51, 52), 3291: (u'portrait_url', 56, 50), 3354: (u' reply/author_nam', 57, 49), 3606: (u'not: has_author_link', 63, 40), 3673: (u'portrait_url', 64, 45), 3731: (u' reply/author_nam', 65, 44), 3931: (u'has_author_link', 71, 42), 4055: (u'author_home_url', 73, 48), 3988: (u'reply/author_name', 72, 40), 4187: (u'not: has_author_link', 76, 45), 4252: (u'reply/author_name', 77, 43), 4319: (u'not: reply/author_name', 78, 45), 4617: (u'python:view.format_time(reply.modification_date)', 83, 38), 4858: (u'reply/getText', 90, 49), 5156: (u'python:not canDelete and isDeleteOwnCommentAllowed and view.could_delete_own(reply)', 97, 45), 5294: (u'string:${reply/absolute_url}/@@delete-own-comment', 98, 53), 5396: (u" python:view.can_delete_own(reply) and 'display: inline' or 'display: none", 99, 51), 5520: (u'd string:delete-${comment_i', 100, 47), 6147: (u'python:canDelete', 112, 45), 6218: (u'string:${reply/absolute_url}/@@moderate-delete-comment', 113, 53), 6322: (u' string:delete-${comment_id', 114, 48), 6768: (u'python:isEditCommentAllowed and canEdit', 123, 49), 7066: (u'auth_token', 127, 44), 7128: (u'string:${reply/absolute_url}/@@edit-comment?_authenticator=${auth_token}', 128, 50), 7499: (u'not: auth_token', 134, 47), 7571: (u'string:${reply/absolute_url}/@@edit-comment', 135, 55), 7666: (u' string:edit-${comment_id', 136, 50), 8392: (u'canReview', 152, 45), 8452: (u'reply_dict/actions|nothing', 153, 49), 8632: (u' action/i', 155, 50), 8533: (u'string:${reply/absolute_url}/@@transmit-comment', 154, 53), 8691: (u'd string:${action/id}-${comment_i', 156, 47), 8823: (u'action/id', 157, 94), 9064: (u'action/title', 161, 57), 9384: (u'python:isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)', 170, 39), 9665: (u'python: has_replies and not isDiscussionAllowed', 178, 28), 9918: (u'python:has_replies and (isAnon and not isAnonymousDiscussionAllowed)', 187, 24), 10026: (u'view/login_action', 188, 37), 10355: (u'python:isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)', 197, 54), 10581: (u'view/comment_transform_message', 202, 28), 10780: (u'view/form/render', 207, 40)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757074673936 = {u'style': u"python:view.can_delete_own(reply) and 'display: inline' or 'display: none'", u'name': u'delete', u'id': u'string:delete-${comment_id}', u'method': u'post', u'action': u'', u'class': u'commentactionsform', }
_static_135757153015888 = {u'href': u'', }
_static_135757075666000 = {u'class': u'reply', }
_static_135756868961680 = {u'href': u'', }
_static_135756868961360 = {u'class': u'commentImage', }
_static_135757153084816 = {u'href': u'string:${reply/absolute_url}/@@edit-comment?_authenticator=${auth_token}', u'class': u'pat-plone-modal context commentactionsform', }
_static_135757075909392 = {u'class': u'discussion', }
_static_135757071457360 = {u'class': u'commentDate', }
_static_135757075681360 = {u'class': u'context reply-to-comment-button hide allowMultiSubmit', }
_static_135757071550096 = {u'type': u'submit', u'name': u'form.button.TransmitComment', u'value': u'action/title', u'class': u'context', }
_static_135757071548880 = {u'type': u'hidden', u'name': u'workflow_action', u'value': u'action/id', }
_static_135757074622224 = {u'class': u'comment', u'id': u'comment_id', }
_static_135757071456336 = {u'class': u'commentBody', }
_static_135757074622160 = {u'class': u'discreet', }
_static_135757075909264 = {u'type': u'submit', u'class': u'standalone loginbutton', u'value': u'Log in to add comments', }
_static_135757327983760 = {}
_static_135757071388368 = {u'src': u'defaultUser.png', u'alt': u'', u'class': u'defaultuserimg', u'height': u'32', }
_static_135757071570192 = {u'class': u'reply', }
_static_135757244280656 = __compile_zt_expr
_static_135757075407312 = {u'src': u'defaultUser.png', u'alt': u'', u'class': u'defaultuserimg', u'height': u'32', }
_static_135757075684112 = {u'action': u'', u'class': u'commentactionsform', u'id': u'string:edit-${comment_id}', u'name': u'edit', u'method': u'get', }
_static_135757075665040 = {u'type': u'submit', u'class': u'standalone loginbutton', u'value': u'Log in to add comments', }
_static_135757075828624 = {u'type': u'submit', u'name': u'form.button.EditComment', u'value': u'Edit', u'class': u'context', }
_static_135757075407952 = {u'class': u'documentByLine', }
_static_135757153087440 = {u'type': u'submit', u'name': u'form.button.DeleteComment', u'value': u'Delete', u'class': u'destructive', }
_static_135757153083920 = {u'action': u'', u'class': u'commentactionsform', u'id': u'string:${action/id}-${comment_id}', u'name': u'', u'method': u'get', }
_static_135757075922064 = {u'action': u'', u'class': u'commentactionsform', u'id': u'string:delete-${comment_id}', u'name': u'delete', u'method': u'post', }
_static_135757075668112 = {u'action': u'view/login_action', }
_static_135757075907984 = {u'action': u'view/login_action', }
_static_135757074677520 = {u'class': u'commentActions', }
_static_135757075667152 = {u'id': u'commenting', u'class': u'reply', }
_static_135757075846544 = {u'type': u'submit', u'name': u'form.button.DeleteComment', u'value': u'Delete', u'class': u'destructive', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071475216
            __attrs_135757071475216 = _static_135757327983760
            __backup_userHasReplyPermission_135757071477200 = get('userHasReplyPermission', __marker)

            # <Value u'view/can_reply' (1:46)> -> __value
            __token = 46
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/can_reply', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['userHasReplyPermission'] = __value
            __backup_isDiscussionAllowed_135757152967056 = get('isDiscussionAllowed', __marker)

            # <Value u'view/is_discussion_allowed' (2:42)> -> __value
            __token = 104
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/is_discussion_allowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isDiscussionAllowed'] = __value
            __backup_isAnonymousDiscussionAllowed_135757071550736 = get('isAnonymousDiscussionAllowed', __marker)

            # <Value u'view/anonymous_discussion_allowed' (3:50)> -> __value
            __token = 183
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/anonymous_discussion_allowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isAnonymousDiscussionAllowed'] = __value
            __backup_isEditCommentAllowed_135757071551952 = get('isEditCommentAllowed', __marker)

            # <Value u'view/edit_comment_allowed' (4:41)> -> __value
            __token = 261
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/edit_comment_allowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isEditCommentAllowed'] = __value
            __backup_isDeleteOwnCommentAllowed_135757075906704 = get('isDeleteOwnCommentAllowed', __marker)

            # <Value u'view/delete_own_comment_allowed' (5:45)> -> __value
            __token = 336
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/delete_own_comment_allowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isDeleteOwnCommentAllowed'] = __value
            __backup_isAnon_135757075683664 = get('isAnon', __marker)

            # <Value u'view/is_anonymous' (6:25)> -> __value
            __token = 398
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/is_anonymous', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isAnon'] = __value
            __backup_canReview_135757153083856 = get('canReview', __marker)

            # <Value u'view/can_review' (7:27)> -> __value
            __token = 449
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/can_review', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['canReview'] = __value
            __backup_replies_135757075899664 = get('replies', __marker)

            # <Value u'python:view.get_replies(canReview)' (8:24)> -> __value
            __token = 496
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.get_replies(canReview)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['replies'] = __value
            __backup_has_replies_135756868936400 = get('has_replies', __marker)

            # <Value u'python:view.has_replies(canReview)' (9:27)> -> __value
            __token = 566
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.has_replies(canReview)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['has_replies'] = __value
            __backup_showCommenterImage_135757152966736 = get('showCommenterImage', __marker)

            # <Value u'view/show_commenter_image' (10:33)> -> __value
            __token = 643
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/show_commenter_image', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['showCommenterImage'] = __value
            __backup_errors_135757152968336 = get('errors', __marker)

            # <Value u'options/state/getErrors|nothing' (11:20)> -> __value
            __token = 699
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'options/state/getErrors|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['errors'] = __value
            __backup_wtool_135757152965648 = get('wtool', __marker)

            # <Value u'context/@@plone_tools/workflow' (12:18)> -> __value
            __token = 760
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@plone_tools/workflow', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['wtool'] = __value
            __backup_auth_token_135757075900752 = get('auth_token', __marker)

            # <Value u'context/@@authenticator/token|nothing' (13:22)> -> __value
            __token = 825
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@authenticator/token|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['auth_token'] = __value

            # <Value u'python:isDiscussionAllowed or has_replies' (14:26)> -> __condition
            __token = 902
            try:
                __zt_tmp = __attrs_135757071475216
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u'isDiscussionAllowed or has_replies', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757071572752 = __i18n_domain
                __i18n_domain = u'plone'
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b786806d510> name=None at 7b786806ddd0> -> __attrs_135757071572688
                __attrs_135757071572688 = _static_135757071570192

                # <Value u'python:isAnon and not isAnonymousDiscussionAllowed' (18:24)> -> __condition
                __token = 1025
                try:
                    __zt_tmp = __attrs_135757071572688
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'isAnon and not isAnonymousDiscussionAllowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="reply">\n        ')

                    # <Static value=<_ast.Dict object at 0x7b7868490590> name=None at 7b7868490690> -> __attrs_135757075908688
                    __attrs_135757075908688 = _static_135757075907984

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075907152
                    __default_135757075907152 = _DEFAULT_MARKER

                    # <Substitution u'view/login_action' (19:37)> -> __attr_action
                    __token = 1115
                    try:
                        __zt_tmp = __attrs_135757075908688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_135757244280656('path', u'view/login_action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b7868490a90> name=None at 7b7868490bd0> -> __attrs_135757074621904
                    __attrs_135757074621904 = _static_135757075909264

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="standalone loginbutton" type="submit"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075910096
                    __default_135757075910096 = _DEFAULT_MARKER

                    # <Translate msgid=u'label_login_to_add_comments' node=<_ast.Str object at 0x7b7868490350> at 7b7868490b90> -> __attr_value
                    __attr_value = u'Log in to add comments'
                    __attr_value = translate(u'label_login_to_add_comments', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\n        </form>\n    </div>')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b7868490b10> name=None at 7b7868490cd0> -> __attrs_135757074622608
                __attrs_135757074622608 = _static_135757075909392

                # <Value u'has_replies' (30:24)> -> __condition
                __token = 1554
                try:
                    __zt_tmp = __attrs_135757074622608
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'has_replies', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074622544
                    __default_135757074622544 = _DEFAULT_MARKER

                    # <Substitution u"python: showCommenterImage and 'discussion showCommenterImage' or 'discussion'" (29:31)> -> __attr_class
                    __token = 1449
                    try:
                        __zt_tmp = __attrs_135757074622608
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('python', u" showCommenterImage and 'discussion showCommenterImage' or 'discussion'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'discussion', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074621392
                    __attrs_135757074621392 = _static_135757327983760
                    __backup_reply_dict_135757075900048 = get('reply_dict', __marker)

                    # <Value u'replies' (31:43)> -> __iterator
                    __token = 1611
                    try:
                        __zt_tmp = __attrs_135757074621392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'replies', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757074621264, ) = getitem('repeat')(u'reply_dict', __iterator)
                    econtext['reply_dict'] = None
                    for __item in __iterator:
                        econtext['reply_dict'] = __item
                        __append(u'\n\n            ')

                        # <Static value=<_ast.Dict object at 0x7b7868356710> name=None at 7b7868356510> -> __attrs_135757073376144
                        __attrs_135757073376144 = _static_135757074622224
                        __backup_reply_135757071571088 = get('reply', __marker)

                        # <Value u'reply_dict/comment' (34:35)> -> __value
                        __token = 1690
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'reply_dict/comment', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['reply'] = __value
                        __backup_comment_id_135757149893264 = get('comment_id', __marker)

                        # <Value u'reply/getId' (35:39)> -> __value
                        __token = 1749
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'reply/getId', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['comment_id'] = __value
                        __backup_depth_135757073441936 = get('depth', __marker)

                        # <Value u'reply_dict/depth|python:0' (36:33)> -> __value
                        __token = 1796
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'reply_dict/depth|python:0', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['depth'] = __value
                        __backup_depth_135757075749776 = get('depth', __marker)

                        # <Value u"python: depth > 10 and '10' or depth" (37:32)> -> __value
                        __token = 1857
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u" depth > 10 and '10' or depth", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['depth'] = __value
                        __backup_author_home_url_135757071549328 = get('author_home_url', __marker)

                        # <Value u'python:view.get_commenter_home_url(username=reply.author_username)' (38:41)> -> __value
                        __token = 1939
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'view.get_commenter_home_url(username=reply.author_username)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['author_home_url'] = __value
                        __backup_has_author_link_135757152986320 = get('has_author_link', __marker)

                        # <Value u'python:author_home_url and not isAnon' (39:40)> -> __value
                        __token = 2051
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'author_home_url and not isAnon', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['has_author_link'] = __value
                        __backup_portrait_url_135757071402256 = get('portrait_url', __marker)

                        # <Value u'python:view.get_commenter_portrait(reply.author_username)' (40:36)> -> __value
                        __token = 2131
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'view.get_commenter_portrait(reply.author_username)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['portrait_url'] = __value
                        __backup_review_state_135757153155920 = get('review_state', __marker)

                        # <Value u"python:wtool.getInfoFor(reply, 'review_state', 'none')" (41:35)> -> __value
                        __token = 2231
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u"wtool.getInfoFor(reply, 'review_state', 'none')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['review_state'] = __value
                        __backup_canEdit_135757075749712 = get('canEdit', __marker)

                        # <Value u'python:view.can_edit(reply)' (42:29)> -> __value
                        __token = 2323
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'view.can_edit(reply)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['canEdit'] = __value
                        __backup_canDelete_135757075867856 = get('canDelete', __marker)

                        # <Value u'python:view.can_delete(reply)' (43:30)> -> __value
                        __token = 2390
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'view.can_delete(reply)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['canDelete'] = __value
                        __backup_colorclass_135756868872464 = get('colorclass', __marker)

                        # <Value u"python:lambda x: 'state-private' if x=='rejected' else ('state-internal' if x=='spam' else 'state-'+x)" (44:30)> -> __value
                        __token = 2460
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u"lambda x: 'state-private' if x=='rejected' else ('state-internal' if x=='spam' else 'state-'+x)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['colorclass'] = __value

                        # <Value u"python:canReview or review_state == 'published'" (47:32)> -> __condition
                        __token = 2795
                        try:
                            __zt_tmp = __attrs_135757073376144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"canReview or review_state == 'published'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074623568
                            __default_135757074623568 = _DEFAULT_MARKER

                            # <Substitution u"python:'comment replyTreeLevel{depth} {state}'.format(depth= depth, state=colorclass(review_state))" (45:39)> -> __attr_class
                            __token = 2614
                            try:
                                __zt_tmp = __attrs_135757073376144
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_class = _static_135757244280656('python', u"'comment replyTreeLevel{depth} {state}'.format(depth= depth, state=colorclass(review_state))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_class = __quote(__attr_class, '"', '&quot;', u'comment', _DEFAULT_MARKER)
                            if (__attr_class is not None):
                                __append((u' class="%s"' % __attr_class))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074623440
                            __default_135757074623440 = _DEFAULT_MARKER

                            # <Substitution u'comment_id' (46:35)> -> __attr_id
                            __token = 2750
                            try:
                                __zt_tmp = __attrs_135757073376144
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('path', u'comment_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))
                            __append(u'>\n\n                ')

                            # <Static value=<_ast.Dict object at 0x7b785bf34450> name=None at 7b78682261d0> -> __attrs_135756868963088
                            __attrs_135756868963088 = _static_135756868961360

                            # <Value u'showCommenterImage' (49:57)> -> __condition
                            __token = 2903
                            try:
                                __zt_tmp = __attrs_135756868963088
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'showCommenterImage', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div class="commentImage">\n                    ')

                                # <Static value=<_ast.Dict object at 0x7b785bf34590> name=None at 7b785bf34690> -> __attrs_135757075406992
                                __attrs_135757075406992 = _static_135756868961680

                                # <Value u'has_author_link' (50:46)> -> __condition
                                __token = 2970
                                try:
                                    __zt_tmp = __attrs_135757075406992
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('path', u'has_author_link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <a ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<a')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075408208
                                    __default_135757075408208 = _DEFAULT_MARKER

                                    # <Substitution u'author_home_url' (51:52)> -> __attr_href
                                    __token = 3039
                                    try:
                                        __zt_tmp = __attrs_135757075406992
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_href = _static_135757244280656('path', u'author_home_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_href is not None):
                                        __append((u' href="%s"' % __attr_href))
                                    __append(u'>\n                         ')

                                    # <Static value=<_ast.Dict object at 0x7b78684161d0> name=None at 7b7868416410> -> __attrs_135757071387792
                                    __attrs_135757071387792 = _static_135757075407312

                                    # <img ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<img')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071386320
                                    __default_135757071386320 = _DEFAULT_MARKER

                                    # <Substitution u'portrait_url' (56:50)> -> __attr_src
                                    __token = 3291
                                    try:
                                        __zt_tmp = __attrs_135757071387792
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_src = _static_135757244280656('path', u'portrait_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_src = __quote(__attr_src, '"', '&quot;', u'defaultUser.png', _DEFAULT_MARKER)
                                    if (__attr_src is not None):
                                        __append((u' src="%s"' % __attr_src))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071386896
                                    __default_135757071386896 = _DEFAULT_MARKER

                                    # <Substitution u'reply/author_name' (57:49)> -> __attr_alt
                                    __token = 3354
                                    try:
                                        __zt_tmp = __attrs_135757071387792
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_alt = _static_135757244280656('path', u'reply/author_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_alt is not None):
                                        __append((u' alt="%s"' % __attr_alt))
                                    __append(u' class="defaultuserimg" height="32" />\n                    </a>')
                                __append(u'\n                    ')

                                # <Static value=<_ast.Dict object at 0x7b7868040ed0> name=None at 7b7868416bd0> -> __attrs_135756868870672
                                __attrs_135756868870672 = _static_135757071388368

                                # <Value u'not: has_author_link' (63:40)> -> __condition
                                __token = 3606
                                try:
                                    __zt_tmp = __attrs_135756868870672
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('not', u' has_author_link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <img ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<img')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868871184
                                    __default_135756868871184 = _DEFAULT_MARKER

                                    # <Substitution u'portrait_url' (64:45)> -> __attr_src
                                    __token = 3673
                                    try:
                                        __zt_tmp = __attrs_135756868870672
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_src = _static_135757244280656('path', u'portrait_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_src = __quote(__attr_src, '"', '&quot;', u'defaultUser.png', _DEFAULT_MARKER)
                                    if (__attr_src is not None):
                                        __append((u' src="%s"' % __attr_src))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868871696
                                    __default_135756868871696 = _DEFAULT_MARKER

                                    # <Substitution u'reply/author_name' (65:44)> -> __attr_alt
                                    __token = 3731
                                    try:
                                        __zt_tmp = __attrs_135756868870672
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_alt = _static_135757244280656('path', u'reply/author_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_alt is not None):
                                        __append((u' alt="%s"' % __attr_alt))
                                    __append(u' class="defaultuserimg" height="32" />')
                                __append(u'\n                </div>')
                            __append(u'\n\n                ')

                            # <Static value=<_ast.Dict object at 0x7b7868416450> name=None at 7b7868416750> -> __attrs_135757071433168
                            __attrs_135757071433168 = _static_135757075407952

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="documentByLine">\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071430864
                            __attrs_135757071430864 = _static_135757327983760
                            __append(u'\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b786ce19850> name=None at 7b786804bf10> -> __attrs_135757153015760
                            __attrs_135757153015760 = _static_135757153015888

                            # <Value u'has_author_link' (71:42)> -> __condition
                            __token = 3931
                            try:
                                __zt_tmp = __attrs_135757153015760
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'has_author_link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <a ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<a')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153016400
                                __default_135757153016400 = _DEFAULT_MARKER

                                # <Substitution u'author_home_url' (73:48)> -> __attr_href
                                __token = 4055
                                try:
                                    __zt_tmp = __attrs_135757153015760
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_href = _static_135757244280656('path', u'author_home_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_href is not None):
                                    __append((u' href="%s"' % __attr_href))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071431824
                                __default_135757071431824 = _DEFAULT_MARKER

                                # <Value u'reply/author_name' (72:40)> -> __cache_135757071430544
                                __token = 3988
                                try:
                                    __zt_tmp = __attrs_135757153015760
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757071430544 = _static_135757244280656('path', u'reply/author_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'reply/author_name' (72:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786804b790> -> __condition
                                __expression = __cache_135757071430544

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\n                            Poster Name\n                        ')
                                else:
                                    __content = __cache_135757071430544
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</a>')
                            __append(u'\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149930000
                            __attrs_135757149930000 = _static_135757327983760

                            # <Value u'not: has_author_link' (76:45)> -> __condition
                            __token = 4187
                            try:
                                __zt_tmp = __attrs_135757149930000
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('not', u' has_author_link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757149932432
                                __default_135757149932432 = _DEFAULT_MARKER

                                # <Value u'reply/author_name' (77:43)> -> __cache_135757153014800
                                __token = 4252
                                try:
                                    __zt_tmp = __attrs_135757149930000
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757153014800 = _static_135757244280656('path', u'reply/author_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'reply/author_name' (77:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cb282d0> -> __condition
                                __expression = __cache_135757153014800

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:

                                    # <span ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<span />')
                                else:
                                    __content = __cache_135757153014800
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                            __append(u'\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071457424
                            __attrs_135757071457424 = _static_135757327983760

                            # <Value u'not: reply/author_name' (78:45)> -> __condition
                            __token = 4319
                            try:
                                __zt_tmp = __attrs_135757071457424
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('not', u' reply/author_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span>')
                                __stream_135757149929680 = []
                                __append_135757149929680 = __stream_135757149929680.append
                                __append_135757149929680(u'Anonymous')
                                __msgid_135757149929680 = __re_whitespace(''.join(__stream_135757149929680)).strip()
                                if u'label_anonymous':
                                    __append(translate(u'label_anonymous', mapping=None, default=__msgid_135757149929680, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                                __append(u'</span>')
                            __append(u'\n                    \n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071431888
                            __attrs_135757071431888 = _static_135757327983760
                            __stream_135757071432848 = []
                            __append_135757071432848 = __stream_135757071432848.append
                            __append_135757071432848(u'says:')
                            __msgid_135757071432848 = __re_whitespace(''.join(__stream_135757071432848)).strip()
                            if u'label_says':
                                __append(translate(u'label_says', mapping=None, default=__msgid_135757071432848, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b7868051c50> name=None at 7b7868051510> -> __attrs_135757071455632
                            __attrs_135757071455632 = _static_135757071457360

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="commentDate">')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071455312
                            __default_135757071455312 = _DEFAULT_MARKER

                            # <Value u'python:view.format_time(reply.modification_date)' (83:38)> -> __cache_135757071433232
                            __token = 4617
                            try:
                                __zt_tmp = __attrs_135757071455632
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757071433232 = _static_135757244280656('python', u'view.format_time(reply.modification_date)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'python:view.format_time(reply.modification_date)' (83:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868051bd0> -> __condition
                            __expression = __cache_135757071433232

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'\n                         8/23/2001 12:40:44 PM\n                    ')
                            else:
                                __content = __cache_135757071433232
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</div>\n                </div>\n\n                ')

                            # <Static value=<_ast.Dict object at 0x7b7868051850> name=None at 7b786804b7d0> -> __attrs_135757071456400
                            __attrs_135757071456400 = _static_135757071456336

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="commentBody">\n\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074677392
                            __attrs_135757074677392 = _static_135757327983760

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074673872
                            __default_135757074673872 = _DEFAULT_MARKER

                            # <Value u'reply/getText' (90:49)> -> __cache_135757074676304
                            __token = 4858
                            try:
                                __zt_tmp = __attrs_135757074677392
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757074676304 = _static_135757244280656('path', u'reply/getText', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'reply/getText' (90:49)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868363bd0> -> __condition
                            __expression = __cache_135757074676304

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span />')
                            else:
                                __content = __cache_135757074676304
                                __content = __convert(__content)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'\n\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b7868363f10> name=None at 7b7868363e50> -> __attrs_135757074675600
                            __attrs_135757074675600 = _static_135757074677520

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="commentActions">\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b7868363110> name=None at 7b78683637d0> -> __attrs_135757075849168
                            __attrs_135757075849168 = _static_135757074673936

                            # <Value u'python:not canDelete and isDeleteOwnCommentAllowed and view.could_delete_own(reply)' (97:45)> -> __condition
                            __token = 5156
                            try:
                                __zt_tmp = __attrs_135757075849168
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u'not canDelete and isDeleteOwnCommentAllowed and view.could_delete_own(reply)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <form ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<form name="delete"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074675856
                                __default_135757074675856 = _DEFAULT_MARKER

                                # <Substitution u'string:${reply/absolute_url}/@@delete-own-comment' (98:53)> -> __attr_action
                                __token = 5294
                                try:
                                    __zt_tmp = __attrs_135757075849168
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_action = _static_135757244280656('string', u'${reply/absolute_url}/@@delete-own-comment', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_action is not None):
                                    __append((u' action="%s"' % __attr_action))
                                __append(u' method="post" class="commentactionsform"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075847888
                                __default_135757075847888 = _DEFAULT_MARKER

                                # <Substitution u"python:view.can_delete_own(reply) and 'display: inline' or 'display: none'" (99:51)> -> __attr_style
                                __token = 5396
                                try:
                                    __zt_tmp = __attrs_135757075849168
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_style = _static_135757244280656('python', u"view.can_delete_own(reply) and 'display: inline' or 'display: none'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_style is not None):
                                    __append((u' style="%s"' % __attr_style))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075845456
                                __default_135757075845456 = _DEFAULT_MARKER

                                # <Substitution u'string:delete-${comment_id}' (100:47)> -> __attr_id
                                __token = 5520
                                try:
                                    __zt_tmp = __attrs_135757075849168
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'delete-${comment_id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))
                                __append(u'>\n                            ')

                                # <Static value=<_ast.Dict object at 0x7b7868481590> name=None at 7b7868481910> -> __attrs_135757075920912
                                __attrs_135757075920912 = _static_135757075846544

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input name="form.button.DeleteComment" class="destructive" type="submit"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075920144
                                __default_135757075920144 = _DEFAULT_MARKER

                                # <Translate msgid=u'label_delete' node=<_ast.Str object at 0x7b78684933d0> at 7b7868493410> -> __attr_value
                                __attr_value = u'Delete'
                                __attr_value = translate(u'label_delete', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u' />\n                        </form>')
                            __append(u'\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b7868493c90> name=None at 7b78683632d0> -> __attrs_135757075922128
                            __attrs_135757075922128 = _static_135757075922064

                            # <Value u'python:canDelete' (112:45)> -> __condition
                            __token = 6147
                            try:
                                __zt_tmp = __attrs_135757075922128
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u'canDelete', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <form ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<form name="delete"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075919760
                                __default_135757075919760 = _DEFAULT_MARKER

                                # <Substitution u'string:${reply/absolute_url}/@@moderate-delete-comment' (113:53)> -> __attr_action
                                __token = 6218
                                try:
                                    __zt_tmp = __attrs_135757075922128
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_action = _static_135757244280656('string', u'${reply/absolute_url}/@@moderate-delete-comment', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_action is not None):
                                    __append((u' action="%s"' % __attr_action))
                                __append(u' method="post" class="commentactionsform"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075920592
                                __default_135757075920592 = _DEFAULT_MARKER

                                # <Substitution u'string:delete-${comment_id}' (114:48)> -> __attr_id
                                __token = 6322
                                try:
                                    __zt_tmp = __attrs_135757075922128
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_id = _static_135757244280656('string', u'delete-${comment_id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_id is not None):
                                    __append((u' id="%s"' % __attr_id))
                                __append(u'>\n                            ')

                                # <Static value=<_ast.Dict object at 0x7b786ce2afd0> name=None at 7b786ce2a9d0> -> __attrs_135757153085264
                                __attrs_135757153085264 = _static_135757153087440

                                # <input ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<input name="form.button.DeleteComment" class="destructive" type="submit"')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153087312
                                __default_135757153087312 = _DEFAULT_MARKER

                                # <Translate msgid=u'label_delete' node=<_ast.Str object at 0x7b786ce2ac90> at 7b786ce2a690> -> __attr_value
                                __attr_value = u'Delete'
                                __attr_value = translate(u'label_delete', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))
                                __append(u' />\n                        </form>')
                            __append(u'\n\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153087056
                            __attrs_135757153087056 = _static_135757327983760

                            # <Value u'python:isEditCommentAllowed and canEdit' (123:49)> -> __condition
                            __token = 6768
                            try:
                                __zt_tmp = __attrs_135757153087056
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u'isEditCommentAllowed and canEdit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __append(u"\n                          <!-- plone 5 will have auth_token available\n                               so we'll use modal pattern -->\n                          ")

                                # <Static value=<_ast.Dict object at 0x7b786ce2a590> name=None at 7b786ce2a410> -> __attrs_135757075683408
                                __attrs_135757075683408 = _static_135757153084816

                                # <Value u'auth_token' (127:44)> -> __condition
                                __token = 7066
                                try:
                                    __zt_tmp = __attrs_135757075683408
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('path', u'auth_token', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <a ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<a class="pat-plone-modal context commentactionsform"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075682256
                                    __default_135757075682256 = _DEFAULT_MARKER

                                    # <Substitution u'string:${reply/absolute_url}/@@edit-comment?_authenticator=${auth_token}' (128:50)> -> __attr_href
                                    __token = 7128
                                    try:
                                        __zt_tmp = __attrs_135757075683408
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_href = _static_135757244280656('string', u'${reply/absolute_url}/@@edit-comment?_authenticator=${auth_token}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_href is not None):
                                        __append((u' href="%s"' % __attr_href))
                                    __append(u'>')
                                    __stream_135757153084112 = []
                                    __append_135757153084112 = __stream_135757153084112.append
                                    __append_135757153084112(u'Edit')
                                    __msgid_135757153084112 = __re_whitespace(''.join(__stream_135757153084112)).strip()
                                    if u'Edit':
                                        __append(translate(u'Edit', mapping=None, default=__msgid_135757153084112, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                                    __append(u'</a>')
                                __append(u'\n                          ')

                                # <Static value=<_ast.Dict object at 0x7b7868459b10> name=None at 7b78684595d0> -> __attrs_135757075825936
                                __attrs_135757075825936 = _static_135757075684112

                                # <Value u'not: auth_token' (134:47)> -> __condition
                                __token = 7499
                                try:
                                    __zt_tmp = __attrs_135757075825936
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('not', u' auth_token', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <form ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<form name="edit"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075826704
                                    __default_135757075826704 = _DEFAULT_MARKER

                                    # <Substitution u'string:${reply/absolute_url}/@@edit-comment' (135:55)> -> __attr_action
                                    __token = 7571
                                    try:
                                        __zt_tmp = __attrs_135757075825936
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_action = _static_135757244280656('string', u'${reply/absolute_url}/@@edit-comment', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_action is not None):
                                        __append((u' action="%s"' % __attr_action))
                                    __append(u' method="get" class="commentactionsform"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075827472
                                    __default_135757075827472 = _DEFAULT_MARKER

                                    # <Substitution u'string:edit-${comment_id}' (136:50)> -> __attr_id
                                    __token = 7666
                                    try:
                                        __zt_tmp = __attrs_135757075825936
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('string', u'edit-${comment_id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))
                                    __append(u'>\n                              ')

                                    # <Static value=<_ast.Dict object at 0x7b786847cf90> name=None at 7b786847ca50> -> __attrs_135757073221840
                                    __attrs_135757073221840 = _static_135757075828624

                                    # <input ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<input name="form.button.EditComment" class="context" type="submit"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073221072
                                    __default_135757073221072 = _DEFAULT_MARKER

                                    # <Translate msgid=u'label_edit' node=<_ast.Str object at 0x7b7868200d10> at 7b7868200a50> -> __attr_value
                                    __attr_value = u'Edit'
                                    __attr_value = translate(u'label_edit', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    if (__attr_value is not None):
                                        __append((u' value="%s"' % __attr_value))
                                    __append(u' />\n                          </form>')
                                __append(u'\n                        ')
                            __append(u"\n\n\n                        <!-- Workflow actions (e.g. 'publish') -->\n                        ")

                            # <Static value=<_ast.Dict object at 0x7b786ce2a210> name=None at 7b786ce2a5d0> -> __attrs_135757073223120
                            __attrs_135757073223120 = _static_135757153083920

                            # <Value u'canReview' (152:45)> -> __condition
                            __token = 8392
                            try:
                                __zt_tmp = __attrs_135757073223120
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'canReview', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:
                                __backup_action_135757075408464 = get('action', __marker)

                                # <Value u'reply_dict/actions|nothing' (153:49)> -> __iterator
                                __token = 8452
                                try:
                                    __zt_tmp = __attrs_135757073223120
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __iterator = _static_135757244280656('path', u'reply_dict/actions|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                (__iterator, ____index_135757071549008, ) = getitem('repeat')(u'action', __iterator)
                                econtext['action'] = None
                                for __item in __iterator:
                                    econtext['action'] = __item

                                    # <form ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<form')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073220176
                                    __default_135757073220176 = _DEFAULT_MARKER

                                    # <Substitution u'action/id' (155:50)> -> __attr_name
                                    __token = 8632
                                    try:
                                        __zt_tmp = __attrs_135757073223120
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_name = _static_135757244280656('path', u'action/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_name is not None):
                                        __append((u' name="%s"' % __attr_name))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073222864
                                    __default_135757073222864 = _DEFAULT_MARKER

                                    # <Substitution u'string:${reply/absolute_url}/@@transmit-comment' (154:53)> -> __attr_action
                                    __token = 8533
                                    try:
                                        __zt_tmp = __attrs_135757073223120
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_action = _static_135757244280656('string', u'${reply/absolute_url}/@@transmit-comment', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                                    if (__attr_action is not None):
                                        __append((u' action="%s"' % __attr_action))
                                    __append(u' method="get" class="commentactionsform"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073221264
                                    __default_135757073221264 = _DEFAULT_MARKER

                                    # <Substitution u'string:${action/id}-${comment_id}' (156:47)> -> __attr_id
                                    __token = 8691
                                    try:
                                        __zt_tmp = __attrs_135757073223120
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('string', u'${action/id}-${comment_id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))
                                    __append(u'>\n                            ')

                                    # <Static value=<_ast.Dict object at 0x7b78680681d0> name=None at 7b7868068f90> -> __attrs_135757071551504
                                    __attrs_135757071551504 = _static_135757071548880

                                    # <input ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<input type="hidden" name="workflow_action"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071551120
                                    __default_135757071551120 = _DEFAULT_MARKER

                                    # <Substitution u'action/id' (157:94)> -> __attr_value
                                    __token = 8823
                                    try:
                                        __zt_tmp = __attrs_135757071551504
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_value = _static_135757244280656('path', u'action/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_value is not None):
                                        __append((u' value="%s"' % __attr_value))
                                    __append(u' />\n                            ')

                                    # <Static value=<_ast.Dict object at 0x7b7868068690> name=None at 7b7868068750> -> __attrs_135757073366992
                                    __attrs_135757073366992 = _static_135757071550096

                                    # <input ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<input name="form.button.TransmitComment" class="context" type="submit"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073365520
                                    __default_135757073365520 = _DEFAULT_MARKER

                                    # <Translate msgid=None node=<Substitution u'action/title' (161:57)> at 7b7868223e50> -> __attr_value

                                    # <Substitution u'action/title' (161:57)> -> __attr_value
                                    __token = 9064
                                    try:
                                        __zt_tmp = __attrs_135757073366992
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_value = _static_135757244280656('path', u'action/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                    __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    if (__attr_value is not None):
                                        __append((u' value="%s"' % __attr_value))
                                    __append(u' />\n                        </form>')
                                    ____index_135757071549008 -= 1
                                    if (____index_135757071549008 > 0):
                                        __append('\n                        ')
                                if (__backup_action_135757075408464 is __marker):
                                    del econtext['action']
                                else:
                                    econtext['action'] = __backup_action_135757075408464
                            __append(u'\n                    </div>\n\n\n                </div>\n                ')

                            # <Static value=<_ast.Dict object at 0x7b7868459050> name=None at 7b7868363710> -> __attrs_135757073366352
                            __attrs_135757073366352 = _static_135757075681360

                            # <Value u'python:isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)' (170:39)> -> __condition
                            __token = 9384
                            try:
                                __zt_tmp = __attrs_135757073366352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('python', u'isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <button ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<button class="context reply-to-comment-button hide allowMultiSubmit">')
                                __stream_135757074675408 = []
                                __append_135757074675408 = __stream_135757074675408.append
                                __append_135757074675408(u'\n                    Reply\n                ')
                                __msgid_135757074675408 = __re_whitespace(''.join(__stream_135757074675408)).strip()
                                if u'label_reply':
                                    __append(translate(u'label_reply', mapping=None, default=__msgid_135757074675408, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                                __append(u'</button>')
                            __append(u'\n            </div>')
                        if (__backup_colorclass_135756868872464 is __marker):
                            del econtext['colorclass']
                        else:
                            econtext['colorclass'] = __backup_colorclass_135756868872464
                        if (__backup_canDelete_135757075867856 is __marker):
                            del econtext['canDelete']
                        else:
                            econtext['canDelete'] = __backup_canDelete_135757075867856
                        if (__backup_canEdit_135757075749712 is __marker):
                            del econtext['canEdit']
                        else:
                            econtext['canEdit'] = __backup_canEdit_135757075749712
                        if (__backup_review_state_135757153155920 is __marker):
                            del econtext['review_state']
                        else:
                            econtext['review_state'] = __backup_review_state_135757153155920
                        if (__backup_portrait_url_135757071402256 is __marker):
                            del econtext['portrait_url']
                        else:
                            econtext['portrait_url'] = __backup_portrait_url_135757071402256
                        if (__backup_has_author_link_135757152986320 is __marker):
                            del econtext['has_author_link']
                        else:
                            econtext['has_author_link'] = __backup_has_author_link_135757152986320
                        if (__backup_author_home_url_135757071549328 is __marker):
                            del econtext['author_home_url']
                        else:
                            econtext['author_home_url'] = __backup_author_home_url_135757071549328
                        if (__backup_depth_135757075749776 is __marker):
                            del econtext['depth']
                        else:
                            econtext['depth'] = __backup_depth_135757075749776
                        if (__backup_depth_135757073441936 is __marker):
                            del econtext['depth']
                        else:
                            econtext['depth'] = __backup_depth_135757073441936
                        if (__backup_comment_id_135757149893264 is __marker):
                            del econtext['comment_id']
                        else:
                            econtext['comment_id'] = __backup_comment_id_135757149893264
                        if (__backup_reply_135757071571088 is __marker):
                            del econtext['reply']
                        else:
                            econtext['reply'] = __backup_reply_135757071571088
                        __append(u'\n\n        ')
                        ____index_135757074621264 -= 1
                        if (____index_135757074621264 > 0):
                            __append('')
                    if (__backup_reply_dict_135757075900048 is __marker):
                        del econtext['reply_dict']
                    else:
                        econtext['reply_dict'] = __backup_reply_dict_135757075900048
                    __append(u'\n\n        ')

                    # <Static value=<_ast.Dict object at 0x7b78683566d0> name=None at 7b7868356650> -> __attrs_135757073363600
                    __attrs_135757073363600 = _static_135757074622160

                    # <Value u'python: has_replies and not isDiscussionAllowed' (178:28)> -> __condition
                    __token = 9665
                    try:
                        __zt_tmp = __attrs_135757073363600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u' has_replies and not isDiscussionAllowed', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="discreet">')
                        __stream_135757074621072 = []
                        __append_135757074621072 = __stream_135757074621072.append
                        __append_135757074621072(u'\n            Commenting has been disabled.\n        ')
                        __msgid_135757074621072 = __re_whitespace(''.join(__stream_135757074621072)).strip()
                        if u'label_commenting_disabled':
                            __append(translate(u'label_commenting_disabled', mapping=None, default=__msgid_135757074621072, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</div>')
                    __append(u'\n\n    </div>')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b7868455450> name=None at 7b7868223250> -> __attrs_135757075667984
                __attrs_135757075667984 = _static_135757075666000

                # <Value u'python:has_replies and (isAnon and not isAnonymousDiscussionAllowed)' (187:24)> -> __condition
                __token = 9918
                try:
                    __zt_tmp = __attrs_135757075667984
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'has_replies and (isAnon and not isAnonymousDiscussionAllowed)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="reply">\n        ')

                    # <Static value=<_ast.Dict object at 0x7b7868455c90> name=None at 7b7868455650> -> __attrs_135757075665232
                    __attrs_135757075665232 = _static_135757075668112

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075667536
                    __default_135757075667536 = _DEFAULT_MARKER

                    # <Substitution u'view/login_action' (188:37)> -> __attr_action
                    __token = 10026
                    try:
                        __zt_tmp = __attrs_135757075665232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_135757244280656('path', u'view/login_action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b7868455090> name=None at 7b7868455810> -> __attrs_135756868775568
                    __attrs_135756868775568 = _static_135757075665040

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="standalone loginbutton" type="submit"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868774480
                    __default_135756868774480 = _DEFAULT_MARKER

                    # <Translate msgid=u'label_login_to_add_comments' node=<_ast.Str object at 0x7b7868455390> at 7b7868455890> -> __attr_value
                    __attr_value = u'Log in to add comments'
                    __attr_value = translate(u'label_login_to_add_comments', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\n        </form>\n    </div>')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b78684558d0> name=None at 7b78684559d0> -> __attrs_135756868772432
                __attrs_135756868772432 = _static_135757075667152

                # <Value u'python:isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)' (197:54)> -> __condition
                __token = 10355
                try:
                    __zt_tmp = __attrs_135756868772432
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'isDiscussionAllowed and (isAnon and isAnonymousDiscussionAllowed or userHasReplyPermission)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="commenting" class="reply">\n\n        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071403152
                    __attrs_135757071403152 = _static_135757327983760

                    # <fieldset ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<fieldset>\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071402640
                    __attrs_135757071402640 = _static_135757327983760

                    # <legend ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<legend>')
                    __stream_135757071404048 = []
                    __append_135757071404048 = __stream_135757071404048.append
                    __append_135757071404048(u'Add comment')
                    __msgid_135757071404048 = __re_whitespace(''.join(__stream_135757071404048)).strip()
                    if u'label_add_comment':
                        __append(translate(u'label_add_comment', mapping=None, default=__msgid_135757071404048, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</legend>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869003280
                    __attrs_135756869003280 = _static_135757327983760

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869004176
                    __default_135756869004176 = _DEFAULT_MARKER

                    # <Value u'view/comment_transform_message' (202:28)> -> __cache_135757071401424
                    __token = 10581
                    try:
                        __zt_tmp = __attrs_135756869003280
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757071401424 = _static_135757244280656('path', u'view/comment_transform_message', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/comment_transform_message' (202:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868044bd0> -> __condition
                    __expression = __cache_135757071401424

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                You can add a comment by filling out the form below. Plain text\n                formatting.\n            ')
                    else:
                        __content = __cache_135757071401424
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</p>\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869002640
                    __attrs_135756869002640 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869004624
                    __default_135756869004624 = _DEFAULT_MARKER

                    # <Value u'view/form/render' (207:40)> -> __cache_135756869003152
                    __token = 10780
                    try:
                        __zt_tmp = __attrs_135756869002640
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756869003152 = _static_135757244280656('path', u'view/form/render', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/form/render' (207:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf3e150> -> __condition
                    __expression = __cache_135756869003152

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div />')
                    else:
                        __content = __cache_135756869003152
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n\n        </fieldset>\n    </div>')
                __append(u'\n\n')
                __i18n_domain = __previous_i18n_domain_135757071572752
            if (__backup_auth_token_135757075900752 is __marker):
                del econtext['auth_token']
            else:
                econtext['auth_token'] = __backup_auth_token_135757075900752
            if (__backup_wtool_135757152965648 is __marker):
                del econtext['wtool']
            else:
                econtext['wtool'] = __backup_wtool_135757152965648
            if (__backup_errors_135757152968336 is __marker):
                del econtext['errors']
            else:
                econtext['errors'] = __backup_errors_135757152968336
            if (__backup_showCommenterImage_135757152966736 is __marker):
                del econtext['showCommenterImage']
            else:
                econtext['showCommenterImage'] = __backup_showCommenterImage_135757152966736
            if (__backup_has_replies_135756868936400 is __marker):
                del econtext['has_replies']
            else:
                econtext['has_replies'] = __backup_has_replies_135756868936400
            if (__backup_replies_135757075899664 is __marker):
                del econtext['replies']
            else:
                econtext['replies'] = __backup_replies_135757075899664
            if (__backup_canReview_135757153083856 is __marker):
                del econtext['canReview']
            else:
                econtext['canReview'] = __backup_canReview_135757153083856
            if (__backup_isAnon_135757075683664 is __marker):
                del econtext['isAnon']
            else:
                econtext['isAnon'] = __backup_isAnon_135757075683664
            if (__backup_isDeleteOwnCommentAllowed_135757075906704 is __marker):
                del econtext['isDeleteOwnCommentAllowed']
            else:
                econtext['isDeleteOwnCommentAllowed'] = __backup_isDeleteOwnCommentAllowed_135757075906704
            if (__backup_isEditCommentAllowed_135757071551952 is __marker):
                del econtext['isEditCommentAllowed']
            else:
                econtext['isEditCommentAllowed'] = __backup_isEditCommentAllowed_135757071551952
            if (__backup_isAnonymousDiscussionAllowed_135757071550736 is __marker):
                del econtext['isAnonymousDiscussionAllowed']
            else:
                econtext['isAnonymousDiscussionAllowed'] = __backup_isAnonymousDiscussionAllowed_135757071550736
            if (__backup_isDiscussionAllowed_135757152967056 is __marker):
                del econtext['isDiscussionAllowed']
            else:
                econtext['isDiscussionAllowed'] = __backup_isDiscussionAllowed_135757152967056
            if (__backup_userHasReplyPermission_135757071477200 is __marker):
                del econtext['userHasReplyPermission']
            else:
                econtext['userHasReplyPermission'] = __backup_userHasReplyPermission_135757071477200
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }