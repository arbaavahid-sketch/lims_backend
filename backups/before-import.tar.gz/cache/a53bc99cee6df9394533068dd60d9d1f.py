# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/datagrid/datagridrow_input.pt'

__tokens = {285: (u'view/subform/widgets/values', 8, 32), 345: (u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", 9, 30), 516: (u'widget/render', 10, 34), 560: (u'widget/error', 11, 26), 637: (u'widget/error/render', 12, 36), 868: (u'string:${view/name}-empty-marker', 20, 32), 1006: (u'view/isInsertEnabled', 25, 21), 1304: (u'view/isDeleteEnabled', 36, 21), 1622: (u'view/isReorderEnabled', 47, 21), 1937: (u'view/isReorderEnabled', 58, 21)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948309462992 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-add', u'title': u'Add row', }
_static_136948418207568 = __compile_zt_expr
_static_136948323752848 = {u'class': u'small text-danger', }
_static_136948323753936 = {u'class': u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", }
_static_136948501914768 = {}
_static_136948323751760 = {u'class': u'datagridwidget-hidden-data', }
_static_136948309443408 = {u'class': u'fas fa-arrow-down', }
_static_136948309459152 = {u'class': u'datagridwidget-manipulator insert-row', }
_static_136948325704272 = {u'type': u'hidden', u'name': u'field-empty-marker', u'value': u'1', }
_static_136948328059792 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_136948309474896 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-moveup', u'title': u'Move up', }
_static_136948327988688 = {u'href': u'', u'class': u'btn btn-sm btn-outline-secondary dgf--row-delete', u'title': u'Delete row', }
_static_136948309473616 = {u'class': u'fas fa-arrow-up', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948327988752 = {u'class': u'datagridwidget-manipulator dgf--row-moveup', }
_static_136948327986640 = {u'class': u'fas fa-trash', }
_static_136948309472656 = {u'class': u'datagridwidget-manipulator dgf--row-movedown', }
_static_136948309462032 = {u'class': u'datagridwidget-manipulator delete-row', }
_static_136948309444240 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-movedown', u'title': u'Move down', }
_static_136948328090320 = {u'class': u'fas fa-plus', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc4725390> name=None at 7c8dc4725350> -> __attrs_136948328061008
            __attrs_136948328061008 = _static_136948328059792
            __append(u'\n\n  <!-- Data rows -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948293102416
            __attrs_136948293102416 = _static_136948501914768
            __backup_widget_136948309560272 = get('widget', __marker)

            # <Value u'view/subform/widgets/values' (8:32)> -> __iterator
            __token = 285
            try:
                __zt_tmp = __attrs_136948293102416
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/subform/widgets/values', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948323751248, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc4309fd0> name=None at 7c8dc4309390> -> __attrs_136948323749968
                __attrs_136948323749968 = _static_136948323753936

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323752272
                __default_136948323752272 = _DEFAULT_MARKER

                # <Substitution u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')" (9:30)> -> __attr_class
                __token = 345
                try:
                    __zt_tmp = __attrs_136948323749968
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_136948418207568('python', u"('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323753616
                __attrs_136948323753616 = _static_136948501914768

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323752784
                __default_136948323752784 = _DEFAULT_MARKER

                # <Value u'widget/render' (10:34)> -> __cache_136948323753104
                __token = 516
                try:
                    __zt_tmp = __attrs_136948323753616
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948323753104 = _static_136948418207568('path', u'widget/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'widget/render' (10:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc4309a10> -> __condition
                __expression = __cache_136948323753104

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_136948323753104
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc4309b90> name=None at 7c8dc4309c50> -> __attrs_136948308597008
                __attrs_136948308597008 = _static_136948323752848

                # <Value u'widget/error' (11:26)> -> __condition
                __token = 560
                try:
                    __zt_tmp = __attrs_136948308597008
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'widget/error', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="small text-danger">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308597072
                    __attrs_136948308597072 = _static_136948501914768

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308598224
                    __default_136948308598224 = _DEFAULT_MARKER

                    # <Value u'widget/error/render' (12:36)> -> __cache_136948308597712
                    __token = 637
                    try:
                        __zt_tmp = __attrs_136948308597072
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308597712 = _static_136948418207568('path', u'widget/error/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/error/render' (12:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3495c90> -> __condition
                    __expression = __cache_136948308597712

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>error</div>')
                    else:
                        __content = __cache_136948308597712
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n      </div>')
                __append(u'\n    </td>\n  ')
                ____index_136948323751248 -= 1
                if (____index_136948323751248 > 0):
                    __append('')
            if (__backup_widget_136948309560272 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_136948309560272
            __append(u'\n\n  <!-- Empty marker -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc4309750> name=None at 7c8dc4309650> -> __attrs_136948308596880
            __attrs_136948308596880 = _static_136948323751760

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td class="datagridwidget-hidden-data">\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dc44e6250> name=None at 7c8dc44e6910> -> __attrs_136948309460688
            __attrs_136948309460688 = _static_136948325704272

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309514640
            __default_136948309514640 = _DEFAULT_MARKER

            # <Substitution u'string:${view/name}-empty-marker' (20:32)> -> __attr_name
            __token = 868
            try:
                __zt_tmp = __attrs_136948309460688
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_136948418207568('string', u'${view/name}-empty-marker', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'field-empty-marker', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))
            __append(u' type="hidden" value="1" />\n  </td>\n\n  <!-- Add row -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc35680d0> name=None at 7c8dc3568310> -> __attrs_136948309462736
            __attrs_136948309462736 = _static_136948309459152

            # <Value u'view/isInsertEnabled' (25:21)> -> __condition
            __token = 1006
            try:
                __zt_tmp = __attrs_136948309462736
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/isInsertEnabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator insert-row">\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3568fd0> name=None at 7c8dc3568510> -> __attrs_136948309461136
                __attrs_136948309461136 = _static_136948309462992

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button class="btn btn-sm btn-outline-secondary dgf--row-add"')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309461904
                __default_136948309461904 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7c8dc3568110> at 7c8dc3568290> -> __attr_title
                __attr_title = u'Add row'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc472cad0> name=None at 7c8dc472c090> -> __attrs_136948328088912
                __attrs_136948328088912 = _static_136948328090320

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-plus" />\n    </button>\n  </td>')
            __append(u'\n\n  <!-- Delete row -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc3568c10> name=None at 7c8dc3568790> -> __attrs_136948400710736
            __attrs_136948400710736 = _static_136948309462032

            # <Value u'view/isDeleteEnabled' (36:21)> -> __condition
            __token = 1304
            try:
                __zt_tmp = __attrs_136948400710736
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/isDeleteEnabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator delete-row">\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc4713dd0> name=None at 7c8dc4713e90> -> __attrs_136948327986256
                __attrs_136948327986256 = _static_136948327988688

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button href="" class="btn btn-sm btn-outline-secondary dgf--row-delete"')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988048
                __default_136948327988048 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7c8dc4713f10> at 7c8dc47130d0> -> __attr_title
                __attr_title = u'Delete row'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc47135d0> name=None at 7c8dc4713350> -> __attrs_136948327987920
                __attrs_136948327987920 = _static_136948327986640

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-trash" />\n    </button>\n  </td>')
            __append(u'\n\n  <!-- Move up -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc4713e10> name=None at 7c8dc47138d0> -> __attrs_136948309474512
            __attrs_136948309474512 = _static_136948327988752

            # <Value u'view/isReorderEnabled' (47:21)> -> __condition
            __token = 1622
            try:
                __zt_tmp = __attrs_136948309474512
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/isReorderEnabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator dgf--row-moveup">\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc356be50> name=None at 7c8dc356bfd0> -> __attrs_136948309473552
                __attrs_136948309473552 = _static_136948309474896

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button class="btn btn-sm btn-outline-secondary dgf--row-moveup"')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309474704
                __default_136948309474704 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7c8dc356b990> at 7c8dc356b7d0> -> __attr_title
                __attr_title = u'Move up'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc356b950> name=None at 7c8dc356b550> -> __attrs_136948309444112
                __attrs_136948309444112 = _static_136948309473616

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-arrow-up" />\n    </button>\n  </td>')
            __append(u'\n\n  <!-- Move down -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dc356b590> name=None at 7c8dc356b110> -> __attrs_136948309445328
            __attrs_136948309445328 = _static_136948309472656

            # <Value u'view/isReorderEnabled' (58:21)> -> __condition
            __token = 1937
            try:
                __zt_tmp = __attrs_136948309445328
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/isReorderEnabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator dgf--row-movedown">\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3564690> name=None at 7c8dc3564d10> -> __attrs_136948309444688
                __attrs_136948309444688 = _static_136948309444240

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button class="btn btn-sm btn-outline-secondary dgf--row-movedown"')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309446032
                __default_136948309446032 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7c8dc3564210> at 7c8dc3564750> -> __attr_title
                __attr_title = u'Move down'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc3564350> name=None at 7c8dc3564910> -> __attrs_136948323769680
                __attrs_136948323769680 = _static_136948309443408

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-arrow-down" />\n    </button>\n  </td>')
            __append(u'\n\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }