# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.layout-3.5.2-py2.7.egg/plone/app/layout/nextprevious/nextprevious.pt'

__tokens = {173: (u'view/enabled|nothing', 4, 25), 226: (u' view/isViewTemplate|nothin', 5, 31), 276: (u'python:enabled and isViewTemplate', 6, 20), 391: (u'view/site_url', 10, 32), 463: (u'view/next', 13, 26), 503: (u' view/previou', 14, 29), 543: (u'python:previous is not None or next is not None', 15, 24), 650: (u'previous', 19, 44), 795: (u'previous/url', 22, 35), 999: (u'previous/title', 26, 55), 1108: (u'next', 31, 40), 1241: (u'next/url', 34, 35), 1393: (u'next/title', 37, 55)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757073135504 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757075354256 = {u'class': u'previous', }
_static_135757149895184 = {u'class': u'pagination', }
_static_135757073131984 = {u'href': u'next/url', u'title': u'Go to next item', }
_static_135757244280656 = __compile_zt_expr
_static_135757074294288 = {u'class': u'next', }
_static_135757074294416 = {u'class': u'label', }
_static_135757148779792 = {u'class': u'label', }
_static_135757075356816 = {u'href': u'previous/url', u'title': u'Go to previous item', }
_static_135757148778576 = {u'class': u'arrow', }
_static_135757327983760 = {}
_static_135757150475408 = {u'class': u'arrow', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78681eb790> name=None at 7b78681eb310> -> __attrs_135757073135056
            __attrs_135757073135056 = _static_135757073135504
            __backup_enabled_135757163482000 = get('enabled', __marker)

            # <Value u'view/enabled|nothing' (4:25)> -> __value
            __token = 173
            try:
                __zt_tmp = __attrs_135757073135056
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/enabled|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['enabled'] = __value
            __backup_isViewTemplate_135757075152272 = get('isViewTemplate', __marker)

            # <Value u'view/isViewTemplate|nothing' (5:31)> -> __value
            __token = 226
            try:
                __zt_tmp = __attrs_135757073135056
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/isViewTemplate|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isViewTemplate'] = __value

            # <Value u'python:enabled and isViewTemplate' (6:20)> -> __condition
            __token = 276
            try:
                __zt_tmp = __attrs_135757073135056
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u'enabled and isViewTemplate', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757073133776 = __i18n_domain
                __i18n_domain = u'plone'
                __append(u'\n\n  ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149894800
                __attrs_135757149894800 = _static_135757327983760
                __backup_portal_url_135757073101648 = get('portal_url', __marker)

                # <Value u'view/site_url' (10:32)> -> __value
                __token = 391
                try:
                    __zt_tmp = __attrs_135757149894800
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'view/site_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['portal_url'] = __value
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b786cb1fa10> name=None at 7b786cb1f990> -> __attrs_135757149893584
                __attrs_135757149893584 = _static_135757149895184
                __backup_next_135757075149392 = get('next', __marker)

                # <Value u'view/next' (13:26)> -> __value
                __token = 463
                try:
                    __zt_tmp = __attrs_135757149893584
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'view/next', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['next'] = __value
                __backup_previous_135757074497232 = get('previous', __marker)

                # <Value u'view/previous' (14:29)> -> __value
                __token = 503
                try:
                    __zt_tmp = __attrs_135757149893584
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'view/previous', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['previous'] = __value

                # <Value u'python:previous is not None or next is not None' (15:24)> -> __condition
                __token = 543
                try:
                    __zt_tmp = __attrs_135757149893584
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'previous is not None or next is not None', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <nav ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<nav class="pagination">\n\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075357456
                    __attrs_135757075357456 = _static_135757327983760

                    # <ul ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<ul>\n\n        ')

                    # <Static value=<_ast.Dict object at 0x7b7868409290> name=None at 7b7868409690> -> __attrs_135757075355728
                    __attrs_135757075355728 = _static_135757075354256

                    # <Value u'previous' (19:44)> -> __condition
                    __token = 650
                    try:
                        __zt_tmp = __attrs_135757075355728
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'previous', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="previous">\n          ')

                        # <Static value=<_ast.Dict object at 0x7b7868409c90> name=None at 7b7868409e50> -> __attrs_135757150476880
                        __attrs_135757150476880 = _static_135757075356816

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166675408
                        __default_135757166675408 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_previous_item' node=<_ast.Str object at 0x7b78684097d0> at 7b7868409a50> -> __attr_title
                        __attr_title = u'Go to previous item'
                        __attr_title = translate(u'title_previous_item', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166675728
                        __default_135757166675728 = _DEFAULT_MARKER

                        # <Substitution u'previous/url' (22:35)> -> __attr_href
                        __token = 795
                        try:
                            __zt_tmp = __attrs_135757150476880
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('path', u'previous/url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b786cbad490> name=None at 7b786cbadd50> -> __attrs_135757074296016
                        __attrs_135757074296016 = _static_135757150475408

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="arrow"></span>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b7868306690> name=None at 7b7868306490> -> __attrs_135757074292880
                        __attrs_135757074292880 = _static_135757074294416

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="label">')
                        __stream_135757149805696_itemtitle = ''
                        __stream_135757074294096 = []
                        __append_135757074294096 = __stream_135757074294096.append
                        __append_135757074294096(u'\n              Previous:\n              ')
                        __stream_135757149805696_itemtitle = []
                        __append_135757149805696_itemtitle = __stream_135757149805696_itemtitle.append

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074295504
                        __attrs_135757074295504 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074294224
                        __default_135757074294224 = _DEFAULT_MARKER

                        # <Value u'previous/title' (26:55)> -> __cache_135757074294032
                        __token = 999
                        try:
                            __zt_tmp = __attrs_135757074295504
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757074294032 = _static_135757244280656('path', u'previous/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'previous/title' (26:55)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868306990> -> __condition
                        __expression = __cache_135757074294032

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append_135757149805696_itemtitle(u'<span />')
                        else:
                            __content = __cache_135757074294032
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append_135757149805696_itemtitle(__content)
                        __append_135757074294096(u'${itemtitle}')
                        __stream_135757149805696_itemtitle = ''.join(__stream_135757149805696_itemtitle)
                        __append_135757074294096(u'\n            ')
                        __msgid_135757074294096 = __re_whitespace(''.join(__stream_135757074294096)).strip()
                        if u'label_previous_item':
                            __append(translate(u'label_previous_item', mapping={u'itemtitle': __stream_135757149805696_itemtitle, }, default=__msgid_135757074294096, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\n          </a>\n        </li>')
                    __append(u'\n\n        ')

                    # <Static value=<_ast.Dict object at 0x7b7868306610> name=None at 7b786cbad250> -> __attrs_135757073130320
                    __attrs_135757073130320 = _static_135757074294288

                    # <Value u'next' (31:40)> -> __condition
                    __token = 1108
                    try:
                        __zt_tmp = __attrs_135757073130320
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'next', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="next">\n          ')

                        # <Static value=<_ast.Dict object at 0x7b78681ea9d0> name=None at 7b78681ea110> -> __attrs_135757073129552
                        __attrs_135757073129552 = _static_135757073131984

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073133328
                        __default_135757073133328 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_next_item' node=<_ast.Str object at 0x7b78681eacd0> at 7b78681eae10> -> __attr_title
                        __attr_title = u'Go to next item'
                        __attr_title = translate(u'title_next_item', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073131216
                        __default_135757073131216 = _DEFAULT_MARKER

                        # <Substitution u'next/url' (34:35)> -> __attr_href
                        __token = 1241
                        try:
                            __zt_tmp = __attrs_135757073129552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('path', u'next/url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b786ca0f510> name=None at 7b786ca0f890> -> __attrs_135757148781392
                        __attrs_135757148781392 = _static_135757148779792

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="label">')
                        __stream_135757149804736_itemtitle = ''
                        __stream_135757148782352 = []
                        __append_135757148782352 = __stream_135757148782352.append
                        __append_135757148782352(u'\n              Next:\n              ')
                        __stream_135757149804736_itemtitle = []
                        __append_135757149804736_itemtitle = __stream_135757149804736_itemtitle.append

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148781200
                        __attrs_135757148781200 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148781712
                        __default_135757148781712 = _DEFAULT_MARKER

                        # <Value u'next/title' (37:55)> -> __cache_135757148780176
                        __token = 1393
                        try:
                            __zt_tmp = __attrs_135757148781200
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757148780176 = _static_135757244280656('path', u'next/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'next/title' (37:55)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ca0fe10> -> __condition
                        __expression = __cache_135757148780176

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append_135757149804736_itemtitle(u'<span />')
                        else:
                            __content = __cache_135757148780176
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append_135757149804736_itemtitle(__content)
                        __append_135757148782352(u'${itemtitle}')
                        __stream_135757149804736_itemtitle = ''.join(__stream_135757149804736_itemtitle)
                        __append_135757148782352(u'\n            ')
                        __msgid_135757148782352 = __re_whitespace(''.join(__stream_135757148782352)).strip()
                        if u'label_next_item':
                            __append(translate(u'label_next_item', mapping={u'itemtitle': __stream_135757149804736_itemtitle, }, default=__msgid_135757148782352, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b786ca0f050> name=None at 7b786ca0fc10> -> __attrs_135757075276432
                        __attrs_135757075276432 = _static_135757148778576

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="arrow"></span>\n          </a>\n        </li>')
                    __append(u'\n\n        &nbsp;\n\n      </ul>\n\n    </nav>')
                if (__backup_previous_135757074497232 is __marker):
                    del econtext['previous']
                else:
                    econtext['previous'] = __backup_previous_135757074497232
                if (__backup_next_135757075149392 is __marker):
                    del econtext['next']
                else:
                    econtext['next'] = __backup_next_135757075149392
                __append(u'\n\n  ')
                if (__backup_portal_url_135757073101648 is __marker):
                    del econtext['portal_url']
                else:
                    econtext['portal_url'] = __backup_portal_url_135757073101648
                __append(u'\n\n')
                __i18n_domain = __previous_i18n_domain_135757073133776
            if (__backup_isViewTemplate_135757075152272 is __marker):
                del econtext['isViewTemplate']
            else:
                econtext['isViewTemplate'] = __backup_isViewTemplate_135757075152272
            if (__backup_enabled_135757163482000 is __marker):
                del econtext['enabled']
            else:
                econtext['enabled'] = __backup_enabled_135757163482000
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }