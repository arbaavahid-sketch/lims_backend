# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/z3c.form-3.7.1-py2.7.egg/z3c/form/browser/orderedselect_input.pt'

__tokens = {333: (u'view/id', 8, 26), 455: (u'string:${view/id}-from', 12, 29), 509: (u' string:${view/name}.fro', 13, 30), 566: (u's view/kla', 14, 30), 1498: (u'            m', 33, 14), 1543: (u'         ', 34, 9), 609: (u'le view/st', 15, 29), 652: (u'tle view/t', 16, 28), 694: (u'lang view', 17, 26), 738: (u'click view/o', 18, 28), 788: (u'lclick view/ond', 19, 30), 842: (u'usedown view/onm', 20, 30), 895: (u'nmouseup view/', 21, 27), 948: (u'mouseover view/o', 22, 28), 1003: (u'nmousemove view/', 23, 27), 1057: (u' onmouseout vie', 24, 25), 1110: (u'  onkeypress vi', 25, 24), 1162: (u'    onkeydown ', 26, 22), 1211: (u'       onkey', 27, 19), 1259: (u'       disabl', 28, 19), 1308: (u'        tabin', 29, 18), 1356: (u'          on', 30, 16), 1402: (u'           ', 31, 14), 1449: (u'           on', 32, 15), 1611: (u'view/notselectedItems', 35, 34), 1672: (u'entry/value', 36, 38), 1714: (u'nocall:entry/content', 37, 29), 1938: (u"string:javascript:from2to('${view/id}')", 43, 38), 2166: (u"string:javascript:to2from('${view/id}')", 48, 38), 2344: (u'string:${view/id}-to', 53, 29), 2396: (u' string:${view/name}.t', 54, 30), 2451: (u's view/kla', 55, 30), 3383: (u'            m', 74, 14), 3428: (u'         ', 75, 9), 2494: (u'le view/st', 56, 29), 2537: (u'tle view/t', 57, 28), 2579: (u'lang view', 58, 26), 2623: (u'click view/o', 59, 28), 2673: (u'lclick view/ond', 60, 30), 2727: (u'usedown view/onm', 61, 30), 2780: (u'nmouseup view/', 62, 27), 2833: (u'mouseover view/o', 63, 28), 2888: (u'nmousemove view/', 64, 27), 2942: (u' onmouseout vie', 65, 25), 2995: (u'  onkeypress vi', 66, 24), 3047: (u'    onkeydown ', 67, 22), 3096: (u'       onkey', 68, 19), 3144: (u'       disabl', 69, 19), 3193: (u'        tabin', 70, 18), 3241: (u'          on', 71, 16), 3287: (u'           ', 72, 14), 3334: (u'           on', 73, 15), 3496: (u'view/selectedItems', 76, 34), 3554: (u'entry/value', 77, 38), 3596: (u'nocall:entry/content', 78, 29), 3734: (u'string:${view/name}-empty-marker', 81, 29), 3856: (u'string:${view/id}-toDataContainer', 83, 31), 3944: (u"string:copyDataForSubmit('${view/id}');", 84, 52), 4000: (u'<![CDATA[ */\n          // initial copying of field "field.to" --> "field"\n          copyDataForSubmit("<i tal:replace="${view/id}"/>");\n          /* ]]>', 85, 14), 4121: (u'view/id', 87, 47), 4350: (u"string:javascript:moveUp('${view/id}')", 96, 34), 4577: (u"string:javascript:moveDown('${view/id}')", 102, 34)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948309384272 = {u'value': u'&darr;', u'type': u'button', u'name': u'downButton', u'onClick': u'javascript:moveDown()', }
_static_136948418207568 = __compile_zt_expr
_static_136948501914768 = {}
_static_136948323945744 = {u'type': u'hidden', u'name': u'foo-empty-marker', }
_static_136948327958288 = {u'type': u'text/javascript', }
_static_136948323765392 = {u'style': u'display: none', u'id': u'toDataContainer', }
_static_136948325615760 = {u'border': u'0', u'class': u'ordered-selection-field', u'id': u'view/id', }
_static_136948325614160 = {u'src': u'++resource++orderedselect_input.js', u'type': u'text/javascript', }
_static_136948325666960 = {u'onmousedown': u'view/onmousedown', u'disabled': u'view/disabled', u'onchange': u'view/onchange', u'id': u'to', u'size': u'5', u'style': u'view/style', u'title': u'view/title', u'onmousemove': u'view/onmousemove', u'onmouseup': u'view/onmouseup', u'onfocus': u'view/onfocus', u'onblur': u'view/onblur', u'multiple': u'', u'onclick': u'view/onclick', u'onmouseout': u'view/onmouseout', u'onkeypress': u'view/onkeypress', u'onkeydown': u'view/onkeydown', u'onmouseover': u'view/onmouseover', u'class': u'', u'lang': u'view/lang', u'name': u'to', u'onkeyup': u'view/onkeyup', u'ondblclick': u'view/ondblclick', u'tabindex': u'view/tabindex', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948328045456 = {u'value': u'&larr;', u'type': u'button', u'name': u'to2fromButton', u'onClick': u'javascript:to2from()', }
_static_136948327921104 = {u'value': u'entry/value', }
_static_136948328026704 = {u'value': u'entry/value', }
_static_136948327921680 = {u'value': u'&rarr;', u'type': u'button', u'name': u'from2toButton', u'onClick': u'javascript:from2to()', }
_static_136948327926672 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_136948327959888 = {u'value': u'&uarr;', u'type': u'button', u'name': u'upButton', u'onClick': u'javascript:moveUp()', }
_static_136948308543376 = {u'onmousedown': u'view/onmousedown', u'disabled': u'view/disabled', u'onchange': u'view/onchange', u'id': u'from', u'size': u'5', u'style': u'view/style', u'title': u'view/title', u'onmousemove': u'view/onmousemove', u'onmouseup': u'view/onmouseup', u'onfocus': u'view/onfocus', u'onblur': u'view/onblur', u'multiple': u'', u'onclick': u'view/onclick', u'onmouseout': u'view/onmouseout', u'onkeypress': u'view/onkeypress', u'onkeydown': u'view/onkeydown', u'onmouseover': u'view/onmouseover', u'class': u'', u'lang': u'view/lang', u'name': u'from', u'onkeyup': u'view/onkeyup', u'ondblclick': u'view/ondblclick', u'tabindex': u'view/tabindex', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc4704b90> name=None at 7c8dc4704d90> -> __attrs_136948325613968
            __attrs_136948325613968 = _static_136948327926672
            __append(u'\n')

            # <Static value=<_ast.Dict object at 0x7c8dc44d0250> name=None at 7c8dc44d0b90> -> __attrs_136948325616592
            __attrs_136948325616592 = _static_136948325614160

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript" src="++resource++orderedselect_input.js"></script>\n\n')

            # <Static value=<_ast.Dict object at 0x7c8dc44d0890> name=None at 7c8dc44d0a90> -> __attrs_136948309459344
            __attrs_136948309459344 = _static_136948325615760

            # <table ... (0:0)
            # --------------------------------------------------------
            __append(u'<table border="0" class="ordered-selection-field"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309460176
            __default_136948309460176 = _DEFAULT_MARKER

            # <Substitution u'view/id' (8:26)> -> __attr_id
            __token = 333
            try:
                __zt_tmp = __attrs_136948309459344
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('path', u'view/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309462160
            __attrs_136948309462160 = _static_136948501914768

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948283570256
            __attrs_136948283570256 = _static_136948501914768

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc3488790> name=None at 7c8dc3488850> -> __attrs_136948325566352
            __attrs_136948325566352 = _static_136948308543376

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325625104
            __default_136948325625104 = _DEFAULT_MARKER

            # <Substitution u'string:${view/id}-from' (12:29)> -> __attr_id
            __token = 455
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('string', u'${view/id}-from', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'from', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325623952
            __default_136948325623952 = _DEFAULT_MARKER

            # <Substitution u'string:${view/name}.from' (13:30)> -> __attr_name
            __token = 509
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_136948418207568('string', u'${view/name}.from', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'from', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309765072
            __default_136948309765072 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (14:30)> -> __attr_class
            __token = 566
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_136948418207568('path', u'view/klass', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309763664
            __default_136948309763664 = _DEFAULT_MARKER

            # <Boolean u'view/multiple' (33:14)> -> __attr_multiple
            __token = 1498
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_multiple = _static_136948418207568('path', u'view/multiple', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if (__attr_multiple is _DEFAULT_MARKER):
                __attr_multiple = u''
            else:
                if __attr_multiple:
                    __attr_multiple = u'multiple'
                else:
                    __attr_multiple = None
            if (__attr_multiple is not None):
                __append((u'  multiple="%s"' % __attr_multiple))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309765968
            __default_136948309765968 = _DEFAULT_MARKER

            # <Substitution u'view/size' (34:9)> -> __attr_size
            __token = 1543
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_size = _static_136948418207568('path', u'view/size', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_size = __quote(__attr_size, '"', '&quot;', u'5', _DEFAULT_MARKER)
            if (__attr_size is not None):
                __append((u' size="%s"' % __attr_size))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309764368
            __default_136948309764368 = _DEFAULT_MARKER

            # <Substitution u'view/style' (15:29)> -> __attr_style
            __token = 609
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_136948418207568('path', u'view/style', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309762512
            __default_136948309762512 = _DEFAULT_MARKER

            # <Substitution u'view/title' (16:28)> -> __attr_title
            __token = 652
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_136948418207568('path', u'view/title', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309762896
            __default_136948309762896 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (17:26)> -> __attr_lang
            __token = 694
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_136948418207568('path', u'view/lang', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309763216
            __default_136948309763216 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (18:28)> -> __attr_onclick
            __token = 738
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_136948418207568('path', u'view/onclick', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309764560
            __default_136948309764560 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (19:30)> -> __attr_ondblclick
            __token = 788
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_136948418207568('path', u'view/ondblclick', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309765776
            __default_136948309765776 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (20:30)> -> __attr_onmousedown
            __token = 842
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_136948418207568('path', u'view/onmousedown', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309766032
            __default_136948309766032 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (21:27)> -> __attr_onmouseup
            __token = 895
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_136948418207568('path', u'view/onmouseup', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309764304
            __default_136948309764304 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (22:28)> -> __attr_onmouseover
            __token = 948
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_136948418207568('path', u'view/onmouseover', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309765456
            __default_136948309765456 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (23:27)> -> __attr_onmousemove
            __token = 1003
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_136948418207568('path', u'view/onmousemove', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325566992
            __default_136948325566992 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (24:25)> -> __attr_onmouseout
            __token = 1057
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_136948418207568('path', u'view/onmouseout', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325566480
            __default_136948325566480 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (25:24)> -> __attr_onkeypress
            __token = 1110
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_136948418207568('path', u'view/onkeypress', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325565584
            __default_136948325565584 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (26:22)> -> __attr_onkeydown
            __token = 1162
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_136948418207568('path', u'view/onkeydown', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325566864
            __default_136948325566864 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (27:19)> -> __attr_onkeyup
            __token = 1211
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_136948418207568('path', u'view/onkeyup', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325567248
            __default_136948325567248 = _DEFAULT_MARKER

            # <Boolean u'view/disabled' (28:19)> -> __attr_disabled
            __token = 1259
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_disabled = _static_136948418207568('path', u'view/disabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if (__attr_disabled is _DEFAULT_MARKER):
                __attr_disabled = None
            else:
                if __attr_disabled:
                    __attr_disabled = u'disabled'
                else:
                    __attr_disabled = None
            if (__attr_disabled is not None):
                __append((u' disabled="%s"' % __attr_disabled))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325565904
            __default_136948325565904 = _DEFAULT_MARKER

            # <Substitution u'view/tabindex' (29:18)> -> __attr_tabindex
            __token = 1308
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_tabindex = _static_136948418207568('path', u'view/tabindex', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_tabindex is not None):
                __append((u' tabindex="%s"' % __attr_tabindex))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325568080
            __default_136948325568080 = _DEFAULT_MARKER

            # <Substitution u'view/onfocus' (30:16)> -> __attr_onfocus
            __token = 1356
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onfocus = _static_136948418207568('path', u'view/onfocus', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onfocus = __quote(__attr_onfocus, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onfocus is not None):
                __append((u' onfocus="%s"' % __attr_onfocus))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325564496
            __default_136948325564496 = _DEFAULT_MARKER

            # <Substitution u'view/onblur' (31:14)> -> __attr_onblur
            __token = 1402
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onblur = _static_136948418207568('path', u'view/onblur', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onblur = __quote(__attr_onblur, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onblur is not None):
                __append((u' onblur="%s"' % __attr_onblur))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325565136
            __default_136948325565136 = _DEFAULT_MARKER

            # <Substitution u'view/onchange' (32:15)> -> __attr_onchange
            __token = 1449
            try:
                __zt_tmp = __attrs_136948325566352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onchange = _static_136948418207568('path', u'view/onchange', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onchange = __quote(__attr_onchange, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onchange is not None):
                __append((u' onchange="%s"' % __attr_onchange))
            __append(u'>\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc47035d0> name=None at 7c8dc4703c50> -> __attrs_136948327923088
            __attrs_136948327923088 = _static_136948327921104
            __backup_entry_136948283572112 = get('entry', __marker)

            # <Value u'view/notselectedItems' (35:34)> -> __iterator
            __token = 1611
            try:
                __zt_tmp = __attrs_136948327923088
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/notselectedItems', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948327920400, ) = getitem('repeat')(u'entry', __iterator)
            econtext['entry'] = None
            for __item in __iterator:
                econtext['entry'] = __item

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327919824
                __default_136948327919824 = _DEFAULT_MARKER

                # <Substitution u'entry/value' (36:38)> -> __attr_value
                __token = 1672
                try:
                    __zt_tmp = __attrs_136948327923088
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_136948418207568('path', u'entry/value', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'>')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323789264
                __default_136948323789264 = _DEFAULT_MARKER

                # <Value u'nocall:entry/content' (37:29)> -> __cache_136948308543504
                __token = 1714
                try:
                    __zt_tmp = __attrs_136948327923088
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948308543504 = _static_136948418207568('nocall', u'entry/content', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'nocall:entry/content' (37:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc4703490> -> __condition
                __expression = __cache_136948308543504

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136948308543504
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</option>')
                ____index_136948327920400 -= 1
                if (____index_136948327920400 > 0):
                    __append('\n        ')
            if (__backup_entry_136948283572112 is __marker):
                del econtext['entry']
            else:
                econtext['entry'] = __backup_entry_136948283572112
            __append(u'\n      </select>\n    </td>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948283572048
            __attrs_136948283572048 = _static_136948501914768

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc4703810> name=None at 7c8dc4703110> -> __attrs_136948328045840
            __attrs_136948328045840 = _static_136948327921680

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328043344
            __default_136948328043344 = _DEFAULT_MARKER

            # <Substitution u"string:javascript:from2to('${view/id}')" (43:38)> -> __attr_onClick
            __token = 1938
            try:
                __zt_tmp = __attrs_136948328045840
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onClick = _static_136948418207568('string', u"javascript:from2to('${view/id}')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onClick = __quote(__attr_onClick, '"', '&quot;', u'javascript:from2to()', _DEFAULT_MARKER)
            if (__attr_onClick is not None):
                __append((u' onClick="%s"' % __attr_onClick))
            __append(u' name="from2toButton" type="button" value="&rarr;" >&rarr;</button>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328042576
            __attrs_136948328042576 = _static_136948501914768

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc4721b90> name=None at 7c8dc4721a10> -> __attrs_136948323944912
            __attrs_136948323944912 = _static_136948328045456

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309666320
            __default_136948309666320 = _DEFAULT_MARKER

            # <Substitution u"string:javascript:to2from('${view/id}')" (48:38)> -> __attr_onClick
            __token = 2166
            try:
                __zt_tmp = __attrs_136948323944912
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onClick = _static_136948418207568('string', u"javascript:to2from('${view/id}')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onClick = __quote(__attr_onClick, '"', '&quot;', u'javascript:to2from()', _DEFAULT_MARKER)
            if (__attr_onClick is not None):
                __append((u' onClick="%s"' % __attr_onClick))
            __append(u' name="to2fromButton" type="button" value="&larr;" >&larr;</button>\n    </td>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323946192
            __attrs_136948323946192 = _static_136948501914768

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc44dd090> name=None at 7c8dc44dd610> -> __attrs_136948328027088
            __attrs_136948328027088 = _static_136948325666960

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988112
            __default_136948327988112 = _DEFAULT_MARKER

            # <Substitution u'string:${view/id}-to' (53:29)> -> __attr_id
            __token = 2344
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('string', u'${view/id}-to', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'to', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327985744
            __default_136948327985744 = _DEFAULT_MARKER

            # <Substitution u'string:${view/name}.to' (54:30)> -> __attr_name
            __token = 2396
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_136948418207568('string', u'${view/name}.to', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'to', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327985872
            __default_136948327985872 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (55:30)> -> __attr_class
            __token = 2451
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_136948418207568('path', u'view/klass', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988752
            __default_136948327988752 = _DEFAULT_MARKER

            # <Boolean u'view/multiple' (74:14)> -> __attr_multiple
            __token = 3383
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_multiple = _static_136948418207568('path', u'view/multiple', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if (__attr_multiple is _DEFAULT_MARKER):
                __attr_multiple = u''
            else:
                if __attr_multiple:
                    __attr_multiple = u'multiple'
                else:
                    __attr_multiple = None
            if (__attr_multiple is not None):
                __append((u' multiple="%s"' % __attr_multiple))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327985360
            __default_136948327985360 = _DEFAULT_MARKER

            # <Substitution u'view/size' (75:9)> -> __attr_size
            __token = 3428
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_size = _static_136948418207568('path', u'view/size', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_size = __quote(__attr_size, '"', '&quot;', u'5', _DEFAULT_MARKER)
            if (__attr_size is not None):
                __append((u' size="%s"' % __attr_size))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988240
            __default_136948327988240 = _DEFAULT_MARKER

            # <Substitution u'view/style' (56:29)> -> __attr_style
            __token = 2494
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_136948418207568('path', u'view/style', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327985232
            __default_136948327985232 = _DEFAULT_MARKER

            # <Substitution u'view/title' (57:28)> -> __attr_title
            __token = 2537
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_136948418207568('path', u'view/title', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327989008
            __default_136948327989008 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (58:26)> -> __attr_lang
            __token = 2579
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_136948418207568('path', u'view/lang', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327985424
            __default_136948327985424 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (59:28)> -> __attr_onclick
            __token = 2623
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_136948418207568('path', u'view/onclick', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327988880
            __default_136948327988880 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (60:30)> -> __attr_ondblclick
            __token = 2673
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_136948418207568('path', u'view/ondblclick', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323749072
            __default_136948323749072 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (61:30)> -> __attr_onmousedown
            __token = 2727
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_136948418207568('path', u'view/onmousedown', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323747024
            __default_136948323747024 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (62:27)> -> __attr_onmouseup
            __token = 2780
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_136948418207568('path', u'view/onmouseup', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323746384
            __default_136948323746384 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (63:28)> -> __attr_onmouseover
            __token = 2833
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_136948418207568('path', u'view/onmouseover', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325632208
            __default_136948325632208 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (64:27)> -> __attr_onmousemove
            __token = 2888
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_136948418207568('path', u'view/onmousemove', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325632336
            __default_136948325632336 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (65:25)> -> __attr_onmouseout
            __token = 2942
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_136948418207568('path', u'view/onmouseout', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325631056
            __default_136948325631056 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (66:24)> -> __attr_onkeypress
            __token = 2995
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_136948418207568('path', u'view/onkeypress', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325633680
            __default_136948325633680 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (67:22)> -> __attr_onkeydown
            __token = 3047
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_136948418207568('path', u'view/onkeydown', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325632144
            __default_136948325632144 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (68:19)> -> __attr_onkeyup
            __token = 3096
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_136948418207568('path', u'view/onkeyup', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325633232
            __default_136948325633232 = _DEFAULT_MARKER

            # <Boolean u'view/disabled' (69:19)> -> __attr_disabled
            __token = 3144
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_disabled = _static_136948418207568('path', u'view/disabled', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if (__attr_disabled is _DEFAULT_MARKER):
                __attr_disabled = None
            else:
                if __attr_disabled:
                    __attr_disabled = u'disabled'
                else:
                    __attr_disabled = None
            if (__attr_disabled is not None):
                __append((u' disabled="%s"' % __attr_disabled))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325632912
            __default_136948325632912 = _DEFAULT_MARKER

            # <Substitution u'view/tabindex' (70:18)> -> __attr_tabindex
            __token = 3193
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_tabindex = _static_136948418207568('path', u'view/tabindex', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_tabindex is not None):
                __append((u' tabindex="%s"' % __attr_tabindex))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328029840
            __default_136948328029840 = _DEFAULT_MARKER

            # <Substitution u'view/onfocus' (71:16)> -> __attr_onfocus
            __token = 3241
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onfocus = _static_136948418207568('path', u'view/onfocus', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onfocus = __quote(__attr_onfocus, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onfocus is not None):
                __append((u' onfocus="%s"' % __attr_onfocus))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328028752
            __default_136948328028752 = _DEFAULT_MARKER

            # <Substitution u'view/onblur' (72:14)> -> __attr_onblur
            __token = 3287
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onblur = _static_136948418207568('path', u'view/onblur', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onblur = __quote(__attr_onblur, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onblur is not None):
                __append((u' onblur="%s"' % __attr_onblur))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328026384
            __default_136948328026384 = _DEFAULT_MARKER

            # <Substitution u'view/onchange' (73:15)> -> __attr_onchange
            __token = 3334
            try:
                __zt_tmp = __attrs_136948328027088
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onchange = _static_136948418207568('path', u'view/onchange', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onchange = __quote(__attr_onchange, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onchange is not None):
                __append((u' onchange="%s"' % __attr_onchange))
            __append(u'>\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc471d250> name=None at 7c8dc471d290> -> __attrs_136948328028816
            __attrs_136948328028816 = _static_136948328026704
            __backup_entry_136948327922832 = get('entry', __marker)

            # <Value u'view/selectedItems' (76:34)> -> __iterator
            __token = 3496
            try:
                __zt_tmp = __attrs_136948328028816
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/selectedItems', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948328026448, ) = getitem('repeat')(u'entry', __iterator)
            econtext['entry'] = None
            for __item in __iterator:
                econtext['entry'] = __item

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328029712
                __default_136948328029712 = _DEFAULT_MARKER

                # <Substitution u'entry/value' (77:38)> -> __attr_value
                __token = 3554
                try:
                    __zt_tmp = __attrs_136948328028816
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_136948418207568('path', u'entry/value', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'>')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328029904
                __default_136948328029904 = _DEFAULT_MARKER

                # <Value u'nocall:entry/content' (78:29)> -> __cache_136948328029456
                __token = 3596
                try:
                    __zt_tmp = __attrs_136948328028816
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948328029456 = _static_136948418207568('nocall', u'entry/content', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'nocall:entry/content' (78:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc471d0d0> -> __condition
                __expression = __cache_136948328029456

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136948328029456
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</option>')
                ____index_136948328026448 -= 1
                if (____index_136948328026448 > 0):
                    __append('\n        ')
            if (__backup_entry_136948327922832 is __marker):
                del econtext['entry']
            else:
                econtext['entry'] = __backup_entry_136948327922832
            __append(u'\n      </select>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc4338d10> name=None at 7c8dc4338350> -> __attrs_136948323763792
            __attrs_136948323763792 = _static_136948323945744

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328027152
            __default_136948328027152 = _DEFAULT_MARKER

            # <Substitution u'string:${view/name}-empty-marker' (81:29)> -> __attr_name
            __token = 3734
            try:
                __zt_tmp = __attrs_136948323763792
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_136948418207568('string', u'${view/name}-empty-marker', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'foo-empty-marker', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))
            __append(u' type="hidden"/>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc430cc90> name=None at 7c8dc430c9d0> -> __attrs_136948323763984
            __attrs_136948323763984 = _static_136948323765392

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323762960
            __default_136948323762960 = _DEFAULT_MARKER

            # <Substitution u'string:${view/id}-toDataContainer' (83:31)> -> __attr_id
            __token = 3856
            try:
                __zt_tmp = __attrs_136948323763984
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('string', u'${view/id}-toDataContainer', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'toDataContainer', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u' style="display: none">\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc470c710> name=None at 7c8dc470c450> -> __attrs_136948327959696
            __attrs_136948327959696 = _static_136948327958288

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript">')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323766224
            __default_136948323766224 = _DEFAULT_MARKER

            # <Value u"string:copyDataForSubmit('${view/id}');" (84:52)> -> __cache_136948323766096
            __token = 3944
            try:
                __zt_tmp = __attrs_136948327959696
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_136948323766096 = _static_136948418207568('string', u"copyDataForSubmit('${view/id}');", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

            # <BinOp left=<Value u"string:copyDataForSubmit('${view/id}');" (84:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc430c350> -> __condition
            __expression = __cache_136948323766096

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\n          /*  ')

                # <Interpolation value=<Substitution u'<![CDATA[ */\n          // initial copying of field "field.to" --> "field"\n          copyDataForSubmit("<i tal:replace="${view/id}"/>");\n          /* ]]>' (85:14)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc470c4d0> -> __content_136948571129056
                __token = 4000
                __token = 4121
                try:
                    __zt_tmp = __attrs_136948327959696
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_136948571129056 = _static_136948418207568('path', u'view/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if (__content_136948571129056 is None):
                    pass
                else:
                    if (__content_136948571129056 is None):
                        __content_136948571129056 = None
                    else:
                        __tt = type(__content_136948571129056)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_136948571129056 = unicode(__content_136948571129056)
                        else:
                            if (__tt is str):
                                __content_136948571129056 = decode(__content_136948571129056)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_136948571129056 = __content_136948571129056.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_136948571129056)
                                        __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                    else:
                                        __content_136948571129056 = __content_136948571129056()
                __content_136948571129056 = ('%s%s%s' % (u'<![CDATA[ */\n          // initial copying of field "field.to" --> "field"\n          copyDataForSubmit("<i tal:replace="', (__content_136948571129056 if (__content_136948571129056 is not None) else ''), u'"/>");\n          /* ]]>', ))
                if (__content_136948571129056 is None):
                    pass
                else:
                    if (__content_136948571129056 is None):
                        __content_136948571129056 = None
                    else:
                        __tt = type(__content_136948571129056)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_136948571129056 = unicode(__content_136948571129056)
                        else:
                            if (__tt is str):
                                __content_136948571129056 = decode(__content_136948571129056)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_136948571129056 = __content_136948571129056.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_136948571129056)
                                        __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                    else:
                                        __content_136948571129056 = __content_136948571129056()
                if (__content_136948571129056 is not None):
                    __append(__content_136948571129056)
                __append(u' */\n        ')
            else:
                __content = __cache_136948323766096
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</script>\n      </span>\n    </td>\n    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948327958160
            __attrs_136948327958160 = _static_136948501914768

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc470cd50> name=None at 7c8dc470c5d0> -> __attrs_136948309383632
            __attrs_136948309383632 = _static_136948327959888

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327957008
            __default_136948327957008 = _DEFAULT_MARKER

            # <Substitution u"string:javascript:moveUp('${view/id}')" (96:34)> -> __attr_onClick
            __token = 4350
            try:
                __zt_tmp = __attrs_136948309383632
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onClick = _static_136948418207568('string', u"javascript:moveUp('${view/id}')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onClick = __quote(__attr_onClick, '"', '&quot;', u'javascript:moveUp()', _DEFAULT_MARKER)
            if (__attr_onClick is not None):
                __append((u' onClick="%s"' % __attr_onClick))
            __append(u' name="upButton" type="button" value="&uarr;" >&uarr;</button>\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309383696
            __attrs_136948309383696 = _static_136948501914768

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n      ')

            # <Static value=<_ast.Dict object at 0x7c8dc3555c50> name=None at 7c8dc3555a90> -> __attrs_136948309381456
            __attrs_136948309381456 = _static_136948309384272

            # <button ... (0:0)
            # --------------------------------------------------------
            __append(u'<button')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309382672
            __default_136948309382672 = _DEFAULT_MARKER

            # <Substitution u"string:javascript:moveDown('${view/id}')" (102:34)> -> __attr_onClick
            __token = 4577
            try:
                __zt_tmp = __attrs_136948309381456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onClick = _static_136948418207568('string', u"javascript:moveDown('${view/id}')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_onClick = __quote(__attr_onClick, '"', '&quot;', u'javascript:moveDown()', _DEFAULT_MARKER)
            if (__attr_onClick is not None):
                __append((u' onClick="%s"' % __attr_onClick))
            __append(u' name="downButton" type="button" value="&darr;" >&darr;</button>\n    </td>\n  </tr>\n</table>\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }