# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/z3c.form-3.7.1-py2.7.egg/z3c/form/browser/textlines_hidden.pt'

__tokens = {256: (u'view/id', 7, 26), 292: (u' view/nam', 8, 27), 465: (u'alue view/', 12, 24), 331: (u'e view/tit', 9, 27), 374: (u'ex view/tabin', 10, 29), 421: (u'key view/acces', 11, 29)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525732204112 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_124525732202192 = {u'name': u'', u'title': u'', u'accesskey': u'', u'value': u'', u'id': u'', u'type': u'hidden', u'class': u'hidden-widget', u'tabindex': u'', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x714168088e50> name=None at 714168088790> -> __attrs_124525734087312
            __attrs_124525734087312 = _static_124525732204112
            __append(u'\n')

            # <Static value=<_ast.Dict object at 0x7141680886d0> name=None at 714168088c90> -> __attrs_124525732571856
            __attrs_124525732571856 = _static_124525732202192

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732202320
            __default_124525732202320 = _DEFAULT_MARKER

            # <Substitution u'view/id' (7:26)> -> __attr_id
            __token = 256
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_124525896001680('path', u'view/id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732202576
            __default_124525732202576 = _DEFAULT_MARKER

            # <Substitution u'view/name' (8:27)> -> __attr_name
            __token = 292
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_124525896001680('path', u'view/name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732203856
            __default_124525732203856 = _DEFAULT_MARKER

            # <Substitution u'view/value' (12:24)> -> __attr_value
            __token = 465
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_124525896001680('path', u'view/value', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' class="hidden-widget"')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732571984
            __default_124525732571984 = _DEFAULT_MARKER

            # <Substitution u'view/title' (9:27)> -> __attr_title
            __token = 331
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_124525896001680('path', u'view/title', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732572560
            __default_124525732572560 = _DEFAULT_MARKER

            # <Substitution u'view/tabindex' (10:29)> -> __attr_tabindex
            __token = 374
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_tabindex = _static_124525896001680('path', u'view/tabindex', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_tabindex is not None):
                __append((u' tabindex="%s"' % __attr_tabindex))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732571920
            __default_124525732571920 = _DEFAULT_MARKER

            # <Substitution u'view/accesskey' (11:29)> -> __attr_accesskey
            __token = 421
            try:
                __zt_tmp = __attrs_124525732571856
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_accesskey = _static_124525896001680('path', u'view/accesskey', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_accesskey = __quote(__attr_accesskey, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_accesskey is not None):
                __append((u' accesskey="%s"' % __attr_accesskey))
            __append(u' type="hidden" />\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }