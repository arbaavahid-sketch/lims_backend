# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/base_edit.cpt'

__tokens = {4008: (u'header_macro', 88, 37), 4008: (u'header_macro', 88, 37), 4061: (u'provider:plone.belowcontenttitle', 89, 36), 4144: (u'typedescription_macro', 90, 46), 4144: (u'typedescription_macro', 90, 46), 4205: (u'body_macro', 91, 35), 4205: (u'body_macro', 91, 35), 4257: (u'footer_macro', 92, 37), 4257: (u'footer_macro', 92, 37), 190: (u'context/@@at_base_edit_view', 7, 24), 243: (u" python:view.isTemporaryObject() and request.set('disable_border', True", 8, 24), 344: (u'e context/@@at_lifecycle_vi', 9, 27), 401: (u'fo context/@@plone_lock_info|noth', 10, 26), 460: (u'mmy lifecycle/begin_', 11, 21), 507: (u'rors options/state/getErrors | no', 12, 21), 570: (u'matas context/Sc', 13, 23), 620: (u'abbing python: not view.isMultiPageS', 14, 26), 686: (u'eldsets python: view.fie', 15, 21), 747: (u"fieldset python:'default' in fieldsets and 'default' or fieldsets and fieldsets[0", 16, 27), 857: (u' fieldset request/fieldset|options/fieldset|defaul', 17, 18), 934: (u'    fields python: view.fields', 18, 15), 990: (u'      dummy python:context.at_isEdit', 19, 13), 1058: (u' portal_type python:context.getPortalTypeName().lower().repl', 20, 18), 1149: (u'   portal_url nocall:cont', 21, 16), 1201: (u'        portal portal_url/', 22, 11), 1257: (u'      type_name context/getPortalTypeName|contex', 23, 13), 1337: (u'     base_macros context/e', 24, 14), 1397: (u'    edit_template string:$', 25, 15), 1455: (u"       edit_macros python:path('context/%s/macros | nothin", 26, 12), 1546: (u'       header_macro edit_macros/header | header_macro ', 27, 12), 1642: (u'ypedescription_macro edit_macros/typedescription | typedescription_macro | base_m', 28, 20), 1754: (u'           body_macro edit_macros/body | body_ma', 29, 8), 1835: (u'          footer_macro edit_macros/footer | footer_mac', 30, 9), 1918: (u'               isLocked isLocked | lock_info/is_locked_fo', 31, 4), 1999: (u';\n                   css python:context.getUniqueWidgetA', 31, 85), 2078: (u"');\n                   js python:context.getUniqueWidge", 32, 77), 2561: (u'edit_macros/topslot | nothing', 45, 29), 2618: (u'macro', 46, 26), 2656: (u'macro', 47, 30), 2656: (u'macro', 47, 30), 2785: (u'context/archetypes_custom_js/macros/javascript_head | nothing', 52, 29), 2874: (u'macro', 53, 26), 2912: (u'macro', 54, 30), 2912: (u'macro', 54, 30), 2962: (u'js', 56, 23), 2991: (u'js', 57, 25), 3062: (u"python:exists('portal/%s' % item)", 59, 29), 3131: (u'string:$portal_url/$item', 60, 34), 3217: (u'edit_macros/javascript_head | nothing', 63, 29), 3282: (u'macro', 64, 26), 3320: (u'macro', 65, 30), 3320: (u'macro', 65, 30), 3444: (u'css', 70, 24), 3475: (u'css', 71, 26), 3563: (u"python:exists('portal/%s' % item)", 74, 28), 3634: (u'string:&lt;!-- @import url($portal_url/$item); ', 75, 36), 3749: (u'edit_macros/css | nothing', 78, 29), 3807: (u'macro', 79, 31), 3845: (u'macro', 80, 30), 3845: (u'macro', 80, 30), 2431: (u'context/main_template/macros/master', 41, 23), 2431: (u'context/main_template/macros/master', 41, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757071385040 = {u'src': u'string:$portal_url/$item', u'type': u'text/javascript', }
_static_135757071478032 = u'macro'
_static_135756868961232 = u'macro'
_static_135757075932944 = {u'media': u'all', u'type': u'text/css', }
_static_135757153014736 = u'body_macro'
_static_135757244280656 = __compile_zt_expr
_static_135757153148624 = u'master'
_static_135757075865680 = u'header_macro'
_static_135757153017296 = u'footer_macro'
_static_135757071476816 = u'macro'
_static_135757327983760 = {}
_static_135757075868304 = u'typedescription_macro'
_static_135757244301584 = __C2ZContextWrapper
_static_135757075933328 = u'macro'

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_main(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075867984
            __attrs_135757075867984 = _static_135757327983760
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075866704
            __attrs_135757075866704 = _static_135757327983760
            __backup_macroname_135757118074544 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868486050> name=None at 7b7868486810> -> __value
            __value = _static_135757075865680
            econtext['macroname'] = __value

            # <Value u'header_macro' (88:37)> -> __macro
            __token = 4008
            try:
                __zt_tmp = __attrs_135757075866704
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'header_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 4008
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118074544 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118074544
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075867600
            __attrs_135757075867600 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075866832
            __default_135757075866832 = _DEFAULT_MARKER

            # <Value u'provider:plone.belowcontenttitle' (89:36)> -> __cache_135757075869648
            __token = 4061
            try:
                __zt_tmp = __attrs_135757075867600
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075869648 = _static_135757244280656('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.belowcontenttitle' (89:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868486ed0> -> __condition
            __expression = __cache_135757075869648

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_135757075869648
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153016464
            __attrs_135757153016464 = _static_135757327983760
            __backup_macroname_135757118071744 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868486a90> name=None at 7b786ce19990> -> __value
            __value = _static_135757075868304
            econtext['macroname'] = __value

            # <Value u'typedescription_macro' (90:46)> -> __macro
            __token = 4144
            try:
                __zt_tmp = __attrs_135757153016464
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'typedescription_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 4144
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118071744 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118071744
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153014672
            __attrs_135757153014672 = _static_135757327983760
            __backup_macroname_135757118620688 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786ce193d0> name=None at 7b786ce19d10> -> __value
            __value = _static_135757153014736
            econtext['macroname'] = __value

            # <Value u'body_macro' (91:35)> -> __macro
            __token = 4205
            try:
                __zt_tmp = __attrs_135757153014672
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'body_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 4205
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118620688 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118620688
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153014608
            __attrs_135757153014608 = _static_135757327983760
            __backup_macroname_135757118622208 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786ce19dd0> name=None at 7b786ce19ad0> -> __value
            __value = _static_135757153017296
            econtext['macroname'] = __value

            # <Value u'footer_macro' (92:37)> -> __macro
            __token = 4257
            try:
                __zt_tmp = __attrs_135757153014608
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'footer_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 4257
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118622208 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118622208
            __append(u'\n      ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_master(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075900112
            __attrs_135757075900112 = _static_135757327983760
            __backup_view_135757075848592 = get('view', __marker)

            # <Value u'context/@@at_base_edit_view' (7:24)> -> __value
            __token = 190
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@at_base_edit_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['view'] = __value
            __backup_dummy_135757071403664 = get('dummy', __marker)

            # <Value u"python:view.isTemporaryObject() and request.set('disable_border', True)" (8:24)> -> __value
            __token = 243
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"view.isTemporaryObject() and request.set('disable_border', True)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_lifecycle_135757150166992 = get('lifecycle', __marker)

            # <Value u'context/@@at_lifecycle_view' (9:27)> -> __value
            __token = 344
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@at_lifecycle_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['lifecycle'] = __value
            __backup_lock_info_135757075683216 = get('lock_info', __marker)

            # <Value u'context/@@plone_lock_info|nothing' (10:26)> -> __value
            __token = 401
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@plone_lock_info|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['lock_info'] = __value
            __backup_dummy_135757150164560 = get('dummy', __marker)

            # <Value u'lifecycle/begin_edit' (11:21)> -> __value
            __token = 460
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'lifecycle/begin_edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_errors_135757150165840 = get('errors', __marker)

            # <Value u'options/state/getErrors | nothing' (12:21)> -> __value
            __token = 507
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'options/state/getErrors | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['errors'] = __value
            __backup_schematas_135757153155856 = get('schematas', __marker)

            # <Value u'context/Schemata' (13:23)> -> __value
            __token = 570
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/Schemata', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['schematas'] = __value
            __backup_allow_tabbing_135757075682960 = get('allow_tabbing', __marker)

            # <Value u'python: not view.isMultiPageSchema()' (14:26)> -> __value
            __token = 620
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u' not view.isMultiPageSchema()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['allow_tabbing'] = __value
            __backup_fieldsets_135757150163088 = get('fieldsets', __marker)

            # <Value u'python: view.fieldsets()' (15:21)> -> __value
            __token = 686
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u' view.fieldsets()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fieldsets'] = __value
            __backup_default_fieldset_135757075682384 = get('default_fieldset', __marker)

            # <Value u"python:'default' in fieldsets and 'default' or fieldsets and fieldsets[0] or None" (16:27)> -> __value
            __token = 747
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"'default' in fieldsets and 'default' or fieldsets and fieldsets[0] or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['default_fieldset'] = __value
            __backup_fieldset_135757148779408 = get('fieldset', __marker)

            # <Value u'request/fieldset|options/fieldset|default_fieldset' (17:18)> -> __value
            __token = 857
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'request/fieldset|options/fieldset|default_fieldset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fieldset'] = __value
            __backup_fields_135757071510288 = get('fields', __marker)

            # <Value u'python: view.fields(fieldsets)' (18:15)> -> __value
            __token = 934
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u' view.fields(fieldsets)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fields'] = __value
            __backup_dummy_135757071551824 = get('dummy', __marker)

            # <Value u'python:context.at_isEditable(fields)' (19:13)> -> __value
            __token = 990
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.at_isEditable(fields)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_portal_type_135757071551952 = get('portal_type', __marker)

            # <Value u"python:context.getPortalTypeName().lower().replace(' ', '_')" (20:18)> -> __value
            __token = 1058
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.getPortalTypeName().lower().replace(' ', '_')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_type'] = __value
            __backup_portal_url_135756868771920 = get('portal_url', __marker)

            # <Value u'nocall:context/portal_url' (21:16)> -> __value
            __token = 1149
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'context/portal_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_portal_135757071600784 = get('portal', __marker)

            # <Value u'portal_url/getPortalObject' (22:11)> -> __value
            __token = 1201
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'portal_url/getPortalObject', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal'] = __value
            __backup_type_name_135757075681936 = get('type_name', __marker)

            # <Value u'context/getPortalTypeName|context/archetype_name' (23:13)> -> __value
            __token = 1257
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/getPortalTypeName|context/archetype_name', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['type_name'] = __value
            __backup_base_macros_135757071558544 = get('base_macros', __marker)

            # <Value u'context/edit_macros/macros' (24:14)> -> __value
            __token = 1337
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/edit_macros/macros', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['base_macros'] = __value
            __backup_edit_template_135756868772112 = get('edit_template', __marker)

            # <Value u'string:${portal_type}_edit' (25:15)> -> __value
            __token = 1397
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('string', u'${portal_type}_edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['edit_template'] = __value
            __backup_edit_macros_135757071469136 = get('edit_macros', __marker)

            # <Value u"python:path('context/%s/macros | nothing' % edit_template)" (26:12)> -> __value
            __token = 1455
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"path('context/%s/macros | nothing' % edit_template)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['edit_macros'] = __value
            __backup_header_macro_135757075724432 = get('header_macro', __marker)

            # <Value u'edit_macros/header | header_macro | base_macros/header' (27:12)> -> __value
            __token = 1546
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'edit_macros/header | header_macro | base_macros/header', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['header_macro'] = __value
            __backup_typedescription_macro_135757075219408 = get('typedescription_macro', __marker)

            # <Value u'edit_macros/typedescription | typedescription_macro | base_macros/typedescription' (28:20)> -> __value
            __token = 1642
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'edit_macros/typedescription | typedescription_macro | base_macros/typedescription', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['typedescription_macro'] = __value
            __backup_body_macro_135757152968336 = get('body_macro', __marker)

            # <Value u'edit_macros/body | body_macro | base_macros/body' (29:8)> -> __value
            __token = 1754
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'edit_macros/body | body_macro | base_macros/body', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['body_macro'] = __value
            __backup_footer_macro_135757075738256 = get('footer_macro', __marker)

            # <Value u'edit_macros/footer | footer_macro | base_macros/footer' (30:9)> -> __value
            __token = 1835
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'edit_macros/footer | footer_macro | base_macros/footer', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['footer_macro'] = __value
            __backup_isLocked_135756868773520 = get('isLocked', __marker)

            # <Value u'isLocked | lock_info/is_locked_for_current_user | nothing' (31:4)> -> __value
            __token = 1918
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'isLocked | lock_info/is_locked_for_current_user | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['isLocked'] = __value
            __backup_css_135757075410256 = get('css', __marker)

            # <Value u"python:context.getUniqueWidgetAttr(fields, 'helper_css')" (31:85)> -> __value
            __token = 1999
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.getUniqueWidgetAttr(fields, 'helper_css')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['css'] = __value
            __backup_js_135757071574800 = get('js', __marker)

            # <Value u"python:context.getUniqueWidgetAttr(fields, 'helper_js')" (32:77)> -> __value
            __token = 2078
            try:
                __zt_tmp = __attrs_135757075900112
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"context.getUniqueWidgetAttr(fields, 'helper_js')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['js'] = __value
            __append(u'\n\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153146000
            __attrs_135757153146000 = _static_135757327983760
            __previous_i18n_domain_135757153145936 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_135757119202080 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786ce39ed0> name=None at 7b786ce391d0> -> __value
            __value = _static_135757153148624
            econtext['macroname'] = __value

            def __fill_top_slot(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153146512
                __attrs_135757153146512 = _static_135757327983760
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071477264
                __attrs_135757071477264 = _static_135757327983760
                __backup_macro_135756868775696 = get('macro', __marker)

                # <Value u'edit_macros/topslot | nothing' (45:29)> -> __value
                __token = 2561
                try:
                    __zt_tmp = __attrs_135757071477264
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'edit_macros/topslot | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['macro'] = __value

                # <Value u'macro' (46:26)> -> __condition
                __token = 2618
                try:
                    __zt_tmp = __attrs_135757071477264
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071475600
                    __attrs_135757071475600 = _static_135757327983760
                    __backup_macroname_135757119498992 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7b7868056850> name=None at 7b7868056d90> -> __value
                    __value = _static_135757071476816
                    econtext['macroname'] = __value

                    # <Value u'macro' (47:30)> -> __macro
                    __token = 2656
                    try:
                        __zt_tmp = __attrs_135757071475600
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __token = 2656
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_135757119498992 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_135757119498992
                    __append(u'\n    ')
                if (__backup_macro_135756868775696 is __marker):
                    del econtext['macro']
                else:
                    econtext['macro'] = __backup_macro_135756868775696
                __append(u'\n  ')
            _slots = econtext[u'__slot_top_slot'] = _deque((__fill_top_slot, ))

            def __fill_senaite_legacy_js(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071475984
                __attrs_135757071475984 = _static_135757327983760
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071478672
                __attrs_135757071478672 = _static_135757327983760
                __backup_macro_135757071536080 = get('macro', __marker)

                # <Value u'context/archetypes_custom_js/macros/javascript_head | nothing' (52:29)> -> __value
                __token = 2785
                try:
                    __zt_tmp = __attrs_135757071478672
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/archetypes_custom_js/macros/javascript_head | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['macro'] = __value

                # <Value u'macro' (53:26)> -> __condition
                __token = 2874
                try:
                    __zt_tmp = __attrs_135757071478672
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071385744
                    __attrs_135757071385744 = _static_135757327983760
                    __backup_macroname_135757119499232 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7b7868056d10> name=None at 7b7868040a10> -> __value
                    __value = _static_135757071478032
                    econtext['macroname'] = __value

                    # <Value u'macro' (54:30)> -> __macro
                    __token = 2912
                    try:
                        __zt_tmp = __attrs_135757071385744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __token = 2912
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_135757119499232 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_135757119499232
                    __append(u'\n    ')
                if (__backup_macro_135757071536080 is __marker):
                    del econtext['macro']
                else:
                    econtext['macro'] = __backup_macro_135757071536080
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071476112
                __attrs_135757071476112 = _static_135757327983760

                # <Value u'js' (56:23)> -> __condition
                __token = 2962
                try:
                    __zt_tmp = __attrs_135757071476112
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __backup_item_135757151705424 = get('item', __marker)

                    # <Value u'js' (57:25)> -> __iterator
                    __token = 2991
                    try:
                        __zt_tmp = __attrs_135757071476112
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757071385936, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item
                        __append(u'\n      ')

                        # <Static value=<_ast.Dict object at 0x7b78680401d0> name=None at 7b7868040d10> -> __attrs_135757071386320
                        __attrs_135757071386320 = _static_135757071385040

                        # <Value u"python:exists('portal/%s' % item)" (59:29)> -> __condition
                        __token = 3062
                        try:
                            __zt_tmp = __attrs_135757071386320
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"exists('portal/%s' % item)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <script ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<script type="text/javascript"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071386640
                            __default_135757071386640 = _DEFAULT_MARKER

                            # <Substitution u'string:$portal_url/$item' (60:34)> -> __attr_src
                            __token = 3131
                            try:
                                __zt_tmp = __attrs_135757071386320
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_src = _static_135757244280656('string', u'$portal_url/$item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_src is not None):
                                __append((u' src="%s"' % __attr_src))
                            __append(u'>\n      </script>')
                        __append(u'\n    ')
                        ____index_135757071385936 -= 1
                        if (____index_135757071385936 > 0):
                            __append('')
                    if (__backup_item_135757151705424 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_135757151705424
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071387792
                __attrs_135757071387792 = _static_135757327983760
                __backup_macro_135757074507856 = get('macro', __marker)

                # <Value u'edit_macros/javascript_head | nothing' (63:29)> -> __value
                __token = 3217
                try:
                    __zt_tmp = __attrs_135757071387792
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'edit_macros/javascript_head | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['macro'] = __value

                # <Value u'macro' (64:26)> -> __condition
                __token = 3282
                try:
                    __zt_tmp = __attrs_135757071387792
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075931856
                    __attrs_135757075931856 = _static_135757327983760
                    __backup_macroname_135757118067568 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7b7868496890> name=None at 7b7868496310> -> __value
                    __value = _static_135757075933328
                    econtext['macroname'] = __value

                    # <Value u'macro' (65:30)> -> __macro
                    __token = 3320
                    try:
                        __zt_tmp = __attrs_135757075931856
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __token = 3320
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_135757118067568 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_135757118067568
                    __append(u'\n    ')
                if (__backup_macro_135757074507856 is __marker):
                    del econtext['macro']
                else:
                    econtext['macro'] = __backup_macro_135757074507856
                __append(u'\n  ')
            _slots = econtext[u'__slot_senaite_legacy_js'] = _deque((__fill_senaite_legacy_js, ))

            def __fill_senaite_legacy_css(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071387984
                __attrs_135757071387984 = _static_135757327983760
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075934480
                __attrs_135757075934480 = _static_135757327983760

                # <Value u'css' (70:24)> -> __condition
                __token = 3444
                try:
                    __zt_tmp = __attrs_135757075934480
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __backup_item_135757151703440 = get('item', __marker)

                    # <Value u'css' (71:26)> -> __iterator
                    __token = 3475
                    try:
                        __zt_tmp = __attrs_135757075934480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('path', u'css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757075931536, ) = getitem('repeat')(u'item', __iterator)
                    econtext['item'] = None
                    for __item in __iterator:
                        econtext['item'] = __item
                        __append(u'\n      ')

                        # <Static value=<_ast.Dict object at 0x7b7868496710> name=None at 7b7868496950> -> __attrs_135756868963280
                        __attrs_135756868963280 = _static_135757075932944

                        # <Value u"python:exists('portal/%s' % item)" (74:28)> -> __condition
                        __token = 3563
                        try:
                            __zt_tmp = __attrs_135756868963280
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"exists('portal/%s' % item)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <style ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<style type="text/css" media="all">')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075933264
                            __default_135757075933264 = _DEFAULT_MARKER

                            # <Value u'string:<!-- @import url($portal_url/$item); -->' (75:36)> -> __cache_135757075931664
                            __token = 3634
                            try:
                                __zt_tmp = __attrs_135756868963280
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757075931664 = _static_135757244280656('string', u'<!-- @import url($portal_url/$item); -->', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'string:<!-- @import url($portal_url/$item); -->' (75:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868496450> -> __condition
                            __expression = __cache_135757075931664

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'\n      ')
                            else:
                                __content = __cache_135757075931664
                                __content = __convert(__content)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</style>')
                        __append(u'\n    ')
                        ____index_135757075931536 -= 1
                        if (____index_135757075931536 > 0):
                            __append('')
                    if (__backup_item_135757151703440 is __marker):
                        del econtext['item']
                    else:
                        econtext['item'] = __backup_item_135757151703440
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075932624
                __attrs_135757075932624 = _static_135757327983760
                __backup_macro_135757075750224 = get('macro', __marker)

                # <Value u'edit_macros/css | nothing' (78:29)> -> __value
                __token = 3749
                try:
                    __zt_tmp = __attrs_135757075932624
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'edit_macros/css | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['macro'] = __value

                # <Value u'macro' (79:31)> -> __condition
                __token = 3807
                try:
                    __zt_tmp = __attrs_135757075932624
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868960720
                    __attrs_135756868960720 = _static_135757327983760
                    __backup_macroname_135757118071264 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7b785bf343d0> name=None at 7b785bf345d0> -> __value
                    __value = _static_135756868961232
                    econtext['macroname'] = __value

                    # <Value u'macro' (80:30)> -> __macro
                    __token = 3845
                    try:
                        __zt_tmp = __attrs_135756868960720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_135757244280656('path', u'macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __token = 3845
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_135757118071264 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_135757118071264
                    __append(u'\n    ')
                if (__backup_macro_135757075750224 is __marker):
                    del econtext['macro']
                else:
                    econtext['macro'] = __backup_macro_135757075750224
                __append(u'\n  ')
            _slots = econtext[u'__slot_senaite_legacy_css'] = _deque((__fill_senaite_legacy_css, ))

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075865936
                __attrs_135757075865936 = _static_135757327983760
                __append(u'\n      ')
                __token = None
                render_main(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n    ')
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/main_template/macros/master' (41:23)> -> __macro
            __token = 2431
            try:
                __zt_tmp = __attrs_135757153146000
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 2431
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757119202080 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757119202080
            __i18n_domain = __previous_i18n_domain_135757153145936
            __append(u'\n\n')
            if (__backup_js_135757071574800 is __marker):
                del econtext['js']
            else:
                econtext['js'] = __backup_js_135757071574800
            if (__backup_css_135757075410256 is __marker):
                del econtext['css']
            else:
                econtext['css'] = __backup_css_135757075410256
            if (__backup_isLocked_135756868773520 is __marker):
                del econtext['isLocked']
            else:
                econtext['isLocked'] = __backup_isLocked_135756868773520
            if (__backup_footer_macro_135757075738256 is __marker):
                del econtext['footer_macro']
            else:
                econtext['footer_macro'] = __backup_footer_macro_135757075738256
            if (__backup_body_macro_135757152968336 is __marker):
                del econtext['body_macro']
            else:
                econtext['body_macro'] = __backup_body_macro_135757152968336
            if (__backup_typedescription_macro_135757075219408 is __marker):
                del econtext['typedescription_macro']
            else:
                econtext['typedescription_macro'] = __backup_typedescription_macro_135757075219408
            if (__backup_header_macro_135757075724432 is __marker):
                del econtext['header_macro']
            else:
                econtext['header_macro'] = __backup_header_macro_135757075724432
            if (__backup_edit_macros_135757071469136 is __marker):
                del econtext['edit_macros']
            else:
                econtext['edit_macros'] = __backup_edit_macros_135757071469136
            if (__backup_edit_template_135756868772112 is __marker):
                del econtext['edit_template']
            else:
                econtext['edit_template'] = __backup_edit_template_135756868772112
            if (__backup_base_macros_135757071558544 is __marker):
                del econtext['base_macros']
            else:
                econtext['base_macros'] = __backup_base_macros_135757071558544
            if (__backup_type_name_135757075681936 is __marker):
                del econtext['type_name']
            else:
                econtext['type_name'] = __backup_type_name_135757075681936
            if (__backup_portal_135757071600784 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_135757071600784
            if (__backup_portal_url_135756868771920 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_135756868771920
            if (__backup_portal_type_135757071551952 is __marker):
                del econtext['portal_type']
            else:
                econtext['portal_type'] = __backup_portal_type_135757071551952
            if (__backup_dummy_135757071551824 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_135757071551824
            if (__backup_fields_135757071510288 is __marker):
                del econtext['fields']
            else:
                econtext['fields'] = __backup_fields_135757071510288
            if (__backup_fieldset_135757148779408 is __marker):
                del econtext['fieldset']
            else:
                econtext['fieldset'] = __backup_fieldset_135757148779408
            if (__backup_default_fieldset_135757075682384 is __marker):
                del econtext['default_fieldset']
            else:
                econtext['default_fieldset'] = __backup_default_fieldset_135757075682384
            if (__backup_fieldsets_135757150163088 is __marker):
                del econtext['fieldsets']
            else:
                econtext['fieldsets'] = __backup_fieldsets_135757150163088
            if (__backup_allow_tabbing_135757075682960 is __marker):
                del econtext['allow_tabbing']
            else:
                econtext['allow_tabbing'] = __backup_allow_tabbing_135757075682960
            if (__backup_schematas_135757153155856 is __marker):
                del econtext['schematas']
            else:
                econtext['schematas'] = __backup_schematas_135757153155856
            if (__backup_errors_135757150165840 is __marker):
                del econtext['errors']
            else:
                econtext['errors'] = __backup_errors_135757150165840
            if (__backup_dummy_135757150164560 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_135757150164560
            if (__backup_lock_info_135757075683216 is __marker):
                del econtext['lock_info']
            else:
                econtext['lock_info'] = __backup_lock_info_135757075683216
            if (__backup_lifecycle_135757150166992 is __marker):
                del econtext['lifecycle']
            else:
                econtext['lifecycle'] = __backup_lifecycle_135757150166992
            if (__backup_dummy_135757071403664 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_135757071403664
            if (__backup_view_135757075848592 is __marker):
                del econtext['view']
            else:
                econtext['view'] = __backup_view_135757075848592
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!-- SENAITE customized edit_macros.pt\n\n   - Use senaite_legacy_js and senaite_legacy_css slots to register helper css/js\n\n-->\n')
            __token = None
            render_master(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_main': render_main, u'render_master': render_master, 'render': render, }