# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/durationwidget.pt'

__tokens = {2125: (u'python:field.getEditAccessor(here)()', 48, 34), 2209: (u' python:here.session_restore_value(fieldName, values', 49, 46), 2308: (u's python:request.get(fieldName,session_value', 50, 44), 2392: (u'es python:cached_values or val', 51, 36), 2481: (u'python:field.getSubfields()', 53, 38), 2546: (u'python:field.testSubfieldCondition(key,here,portal,template)', 54, 35), 2803: (u'string:${fieldName}_${key}', 58, 44), 2723: (u'python:field.getSubfieldLabel(key)', 57, 37), 2943: (u'python:field.isRequired(key)', 61, 39), 3102: (u'python: field.getSubfieldType(key)', 65, 37), 3180: (u"python: type == 'string' and not field.isSelection(key)", 66, 41), 3473: (u'string:${fieldName}.${key}:record:ignore_empty', 72, 48), 3559: (u' python:values.get(key', 73, 38), 3620: (u'e python:field.getSubfieldSize(ke', 74, 36), 3778: (u'dex tabindex/next|not', 76, 38), 3697: (u'th python:field.getSubfieldMaxlength(k', 75, 40), 3905: (u'python: field.isSelection(key)', 79, 44), 3987: (u'python:values.get(key)', 80, 49), 4059: (u' python:field.getVocabularyFor(key, here', 81, 48), 4154: (u'string:${fieldName}.${key}:record:ignore_empty', 82, 51), 4250: (u' fieldNam', 83, 48), 4315: (u'x tabindex/next|nothi', 84, 53), 4391: (u'vocab', 85, 49), 4452: (u'item', 86, 54), 4510: (u" python:test(here.checkSelected(item, value), 'selected', None", 87, 52), 4621: (u'python: vocab.getValue(item)', 88, 45), 4867: (u"python:type == 'lines'", 94, 39), 5103: (u'string:${fieldName}.${key}:record:lines:ignore_empty', 99, 51), 5201: (u' tabindex/next|nothin', 100, 44), 5269: (u"python:'\\n'.join(values.get(key,[]))", 101, 43), 5410: (u"python:type == 'datetime'", 104, 39), 5478: (u'string:${fieldName}_${key}', 105, 40), 5548: (u' python:values.get(key', 106, 42), 5619: (u'  widget/show_', 107, 46), 5681: (u'e  string:${fieldName}.${key}:rec', 108, 44), 5762: (u'e   string:edit_', 109, 43), 5826: (u'alue python: test(value, value', 110, 42), 5902: (u'index tabindex/next|n', 111, 39), 6016: (u'here/calendar_macros/macros/calendarDatePickerBox|here/calendar_slot/macros/calendarDatePickerBox', 113, 43), 6016: (u'here/calendar_macros/macros/calendarDatePickerBox|here/calendar_slot/macros/calendarDatePickerBox', 113, 43), 6284: (u"python: type in ['float', 'int', 'long']", 118, 40), 6556: (u'string:${fieldName}.${key}:${type}:record', 124, 47), 6636: (u' python:values.get(key', 125, 37), 6696: (u'e python:field.getSubfieldSize(ke', 126, 35), 6852: (u'dex tabindex/next|not', 128, 37), 6772: (u'th python:field.getSubfieldMaxlength(k', 127, 39), 2013: (u'here/widgets/field/macros/edit', 46, 28), 2013: (u'here/widgets/field/macros/edit', 46, 28), 7140: (u'here/widgets/string/macros/edit', 140, 28), 7140: (u'here/widgets/string/macros/edit', 140, 28), 628: (u"python:getKssClasses(fieldName,\n                        templateId='durationwidget', macro='duration-field-view')", 14, 34), 778: (u'kss_class', 16, 34), 819: (u' string:parent-fieldname-$fieldNam', 17, 30), 936: (u'python:field.getAccessor(here)()', 19, 38), 1012: (u' field/innerJoi', 20, 42), 1071: (u'n field/outerJo', 21, 41), 1167: (u'field/getSubfields', 25, 40), 1230: (u'python:field.testSubfieldCondition(key,here,portal,template)', 26, 42), 1360: (u'python:values_dict.get(key)', 28, 38), 1424: (u'value', 29, 35), 1553: (u"python:field.getSubfieldLabel(key)+':'", 32, 41), 1687: (u"python:here.getDisplayView(value,'<br />')", 34, 51), 404: (u'context/@@kss_field_decorator_view', 11, 49), 487: (u' nocall:kssClassesView/getKssClassesInlineEditabl', 12, 47)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756866244944 = u'calendarDatePickerBox'
_static_135757074902544 = {u'class': u'label', }
_static_135756866561168 = u'edit'
_static_135756867867408 = {u'tabindex': u'#', u'rows': u'4', u'name': u'', u'cols': u'30', }
_static_135756869515536 = {u'class': u'fieldRequired', u'title': u'Required', }
_static_135756866400656 = {u'name': u'', u'value': u'', u'maxlength': u'python:field.getSubfieldMaxlength(key)', u'size': u'30', u'type': u'text', u'tabindex': u'#', }
_static_135757244280656 = __compile_zt_expr
_static_135757072826576 = {u'valign': u'top', }
_static_135756868296336 = {u'tabindex': u'tabindex/next|nothing', u'name': u'string:${fieldName}.${key}:record:ignore_empty', u'id': u'fieldName', }
_static_135756866266064 = {u'class': u'kss_class', u'id': u'string:parent-fieldname-$fieldName', }
_static_135756867868752 = {u'selected': u"python:test(here.checkSelected(item, value), 'selected', None)", u'value': u'item', }
_static_135757072723664 = {u'class': u'field', }
_static_135756866247120 = {u'name': u'', u'value': u'', u'maxlength': u'python:field.getSubfieldMaxlength(key)', u'size': u'10', u'type': u'text', u'tabindex': u'#', }
_static_135757072723216 = {u'for': u'string:${fieldName}_${key}', }
_static_135757327983760 = {}
_static_135756866372752 = u'edit'
_static_135757244301584 = __C2ZContextWrapper
_static_135756865674384 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866373456
            __attrs_135756866373456 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869380432
            __attrs_135756869380432 = _static_135757327983760
            __backup_macroname_135757111175040 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bcbc490> name=None at 7b785bf9a850> -> __value
            __value = _static_135756866372752
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869381456
                __attrs_135756869381456 = _static_135757327983760
                __backup_values_135756869120528 = get('values', __marker)

                # <Value u'python:field.getEditAccessor(here)()' (48:34)> -> __value
                __token = 2125
                try:
                    __zt_tmp = __attrs_135756869381456
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.getEditAccessor(here)()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value
                __backup_session_values_135756866019280 = get('session_values', __marker)

                # <Value u'python:here.session_restore_value(fieldName, values)' (49:46)> -> __value
                __token = 2209
                try:
                    __zt_tmp = __attrs_135756869381456
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'here.session_restore_value(fieldName, values)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['session_values'] = __value
                __backup_cached_values_135757074621008 = get('cached_values', __marker)

                # <Value u'python:request.get(fieldName,session_values)' (50:44)> -> __value
                __token = 2308
                try:
                    __zt_tmp = __attrs_135756869381456
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'request.get(fieldName,session_values)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['cached_values'] = __value
                __backup_values_135757075191888 = get('values', __marker)

                # <Value u'python:cached_values or values' (51:36)> -> __value
                __token = 2392
                try:
                    __zt_tmp = __attrs_135756869381456
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'cached_values or values', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values'] = __value

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table>\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866561744
                __attrs_135756866561744 = _static_135757327983760

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866561232
                __attrs_135756866561232 = _static_135757327983760
                __backup_key_135756867728592 = get('key', __marker)

                # <Value u'python:field.getSubfields()' (53:38)> -> __iterator
                __token = 2481
                try:
                    __zt_tmp = __attrs_135756866561232
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u'field.getSubfields()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756866560656, ) = getitem('repeat')(u'key', __iterator)
                econtext['key'] = None
                for __item in __iterator:
                    econtext['key'] = __item
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072723280
                    __attrs_135757072723280 = _static_135757327983760

                    # <Value u'python:field.testSubfieldCondition(key,here,portal,template)' (54:35)> -> __condition
                    __token = 2546
                    try:
                        __zt_tmp = __attrs_135757072723280
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'field.testSubfieldCondition(key,here,portal,template)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b7868186ed0> name=None at 7b78681860d0> -> __attrs_135757072721936
                        __attrs_135757072721936 = _static_135757072723664

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td class="field">\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b7868186d10> name=None at 7b7868186cd0> -> __attrs_135756869513296
                        __attrs_135756869513296 = _static_135757072723216

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869514832
                        __default_135756869514832 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_${key}' (58:44)> -> __attr_for
                        __token = 2803
                        try:
                            __zt_tmp = __attrs_135756869513296
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_135757244280656('string', u'${fieldName}_${key}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072721744
                        __default_135757072721744 = _DEFAULT_MARKER

                        # <Value u'python:field.getSubfieldLabel(key)' (57:37)> -> __cache_135757072721616
                        __token = 2723
                        try:
                            __zt_tmp = __attrs_135756869513296
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757072721616 = _static_135757244280656('python', u'field.getSubfieldLabel(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:field.getSubfieldLabel(key)' (57:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868186f10> -> __condition
                        __expression = __cache_135757072721616

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                  ')
                        else:
                            __content = __cache_135757072721616
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b785bfbb910> name=None at 7b785bfbb450> -> __attrs_135756869514576
                        __attrs_135756869514576 = _static_135756869515536

                        # <Value u'python:field.isRequired(key)' (61:39)> -> __condition
                        __token = 2943
                        try:
                            __zt_tmp = __attrs_135756869514576
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u'field.isRequired(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="fieldRequired" title="Required"> #\n                  </span>')
                        __append(u'\n                </td>\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109939024
                        __attrs_135757109939024 = _static_135757327983760
                        __backup_type_135756867728144 = get('type', __marker)

                        # <Value u'python: field.getSubfieldType(key)' (65:37)> -> __value
                        __token = 3102
                        try:
                            __zt_tmp = __attrs_135757109939024
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u' field.getSubfieldType(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['type'] = __value

                        # <td ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<td>\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109938640
                        __attrs_135757109938640 = _static_135757327983760

                        # <Value u"python: type == 'string' and not field.isSelection(key)" (66:41)> -> __condition
                        __token = 3180
                        try:
                            __zt_tmp = __attrs_135757109938640
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u" type == 'string' and not field.isSelection(key)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b785bcc3190> name=None at 7b785bcc37d0> -> __attrs_135756866400592
                            __attrs_135756866400592 = _static_135756866400656

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="text"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866401360
                            __default_135756866401360 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}.${key}:record:ignore_empty' (72:48)> -> __attr_name
                            __token = 3473
                            try:
                                __zt_tmp = __attrs_135756866400592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:record:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866403536
                            __default_135756866403536 = _DEFAULT_MARKER

                            # <Substitution u'python:values.get(key)' (73:38)> -> __attr_value
                            __token = 3559
                            try:
                                __zt_tmp = __attrs_135756866400592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('python', u'values.get(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866402512
                            __default_135756866402512 = _DEFAULT_MARKER

                            # <Substitution u'python:field.getSubfieldSize(key)' (74:36)> -> __attr_size
                            __token = 3620
                            try:
                                __zt_tmp = __attrs_135756866400592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_size = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_size = __quote(__attr_size, '"', '&quot;', u'30', _DEFAULT_MARKER)
                            if (__attr_size is not None):
                                __append((u' size="%s"' % __attr_size))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866404112
                            __default_135756866404112 = _DEFAULT_MARKER

                            # <Substitution u'tabindex/next|nothing' (76:38)> -> __attr_tabindex
                            __token = 3778
                            try:
                                __zt_tmp = __attrs_135756866400592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                            if (__attr_tabindex is not None):
                                __append((u' tabindex="%s"' % __attr_tabindex))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866402832
                            __default_135756866402832 = _DEFAULT_MARKER

                            # <Substitution u'python:field.getSubfieldMaxlength(key)' (75:40)> -> __attr_maxlength
                            __token = 3697
                            try:
                                __zt_tmp = __attrs_135756866400592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_maxlength = _static_135757244280656('python', u'field.getSubfieldMaxlength(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_maxlength is not None):
                                __append((u' maxlength="%s"' % __attr_maxlength))
                            __append(u' />\n                  ')
                        __append(u'\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866400464
                        __attrs_135756866400464 = _static_135757327983760

                        # <Value u'python: field.isSelection(key)' (79:44)> -> __condition
                        __token = 3905
                        try:
                            __zt_tmp = __attrs_135756866400464
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u' field.isSelection(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868294352
                            __attrs_135756868294352 = _static_135757327983760
                            __backup_value_135756869218192 = get('value', __marker)

                            # <Value u'python:values.get(key)' (80:49)> -> __value
                            __token = 3987
                            try:
                                __zt_tmp = __attrs_135756868294352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'values.get(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['value'] = __value
                            __backup_vocab_135757075899920 = get('vocab', __marker)

                            # <Value u'python:field.getVocabularyFor(key, here)' (81:48)> -> __value
                            __token = 4059
                            try:
                                __zt_tmp = __attrs_135756868294352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'field.getVocabularyFor(key, here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['vocab'] = __value
                            __append(u'\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b785be91e90> name=None at 7b785be91810> -> __attrs_135756868296592
                            __attrs_135756868296592 = _static_135756868296336

                            # <select ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<select')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868294608
                            __default_135756868294608 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}.${key}:record:ignore_empty' (82:51)> -> __attr_name
                            __token = 4154
                            try:
                                __zt_tmp = __attrs_135756868296592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:record:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868296272
                            __default_135756868296272 = _DEFAULT_MARKER

                            # <Substitution u'fieldName' (83:48)> -> __attr_id
                            __token = 4250
                            try:
                                __zt_tmp = __attrs_135756868296592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868294736
                            __default_135756868294736 = _DEFAULT_MARKER

                            # <Substitution u'tabindex/next|nothing' (84:53)> -> __attr_tabindex
                            __token = 4315
                            try:
                                __zt_tmp = __attrs_135756868296592
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_tabindex is not None):
                                __append((u' tabindex="%s"' % __attr_tabindex))
                            __append(u'>\n                        ')

                            # <Static value=<_ast.Dict object at 0x7b785be29850> name=None at 7b785be29cd0> -> __attrs_135756867869968
                            __attrs_135756867869968 = _static_135756867868752
                            __backup_item_135756868292880 = get('item', __marker)

                            # <Value u'vocab' (85:49)> -> __iterator
                            __token = 4391
                            try:
                                __zt_tmp = __attrs_135756867869968
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            (__iterator, ____index_135756867867600, ) = getitem('repeat')(u'item', __iterator)
                            econtext['item'] = None
                            for __item in __iterator:
                                econtext['item'] = __item

                                # <option ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<option')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867867088
                                __default_135756867867088 = _DEFAULT_MARKER

                                # <Substitution u'item' (86:54)> -> __attr_value
                                __token = 4452
                                try:
                                    __zt_tmp = __attrs_135756867869968
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_value is not None):
                                    __append((u' value="%s"' % __attr_value))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867867472
                                __default_135756867867472 = _DEFAULT_MARKER

                                # <Boolean u"python:test(here.checkSelected(item, value), 'selected', None)" (87:52)> -> __attr_selected
                                __token = 4510
                                try:
                                    __zt_tmp = __attrs_135756867869968
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_selected = _static_135757244280656('python', u"test(here.checkSelected(item, value), 'selected', None)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if (__attr_selected is _DEFAULT_MARKER):
                                    __attr_selected = None
                                else:
                                    if __attr_selected:
                                        __attr_selected = u'selected'
                                    else:
                                        __attr_selected = None
                                if (__attr_selected is not None):
                                    __append((u' selected="%s"' % __attr_selected))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867867984
                                __default_135756867867984 = _DEFAULT_MARKER

                                # <Value u'python: vocab.getValue(item)' (88:45)> -> __cache_135756867869200
                                __token = 4621
                                try:
                                    __zt_tmp = __attrs_135756867869968
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135756867869200 = _static_135757244280656('python', u' vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'python: vocab.getValue(item)' (88:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785be29c10> -> __condition
                                __expression = __cache_135756867869200

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    pass
                                else:
                                    __content = __cache_135756867869200
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</option>')
                                ____index_135756867867600 -= 1
                                if (____index_135756867867600 > 0):
                                    __append('\n                        ')
                            if (__backup_item_135756868292880 is __marker):
                                del econtext['item']
                            else:
                                econtext['item'] = __backup_item_135756868292880
                            __append(u'\n                      </select>\n                    ')
                            if (__backup_vocab_135757075899920 is __marker):
                                del econtext['vocab']
                            else:
                                econtext['vocab'] = __backup_vocab_135757075899920
                            if (__backup_value_135756869218192 is __marker):
                                del econtext['value']
                            else:
                                econtext['value'] = __backup_value_135756869218192
                            __append(u'\n                  ')
                        __append(u'\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868292816
                        __attrs_135756868292816 = _static_135757327983760

                        # <Value u"python:type == 'lines'" (94:39)> -> __condition
                        __token = 4867
                        try:
                            __zt_tmp = __attrs_135756868292816
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"type == 'lines'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b785be29310> name=None at 7b785be29ed0> -> __attrs_135757072743440
                            __attrs_135757072743440 = _static_135756867867408

                            # <textarea ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<textarea')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867868688
                            __default_135756867868688 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}.${key}:record:lines:ignore_empty' (99:51)> -> __attr_name
                            __token = 5103
                            try:
                                __zt_tmp = __attrs_135757072743440
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:record:lines:ignore_empty', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))
                            __append(u' cols="30" rows="4"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073220240
                            __default_135757073220240 = _DEFAULT_MARKER

                            # <Substitution u'tabindex/next|nothing' (100:44)> -> __attr_tabindex
                            __token = 5201
                            try:
                                __zt_tmp = __attrs_135757072743440
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                            if (__attr_tabindex is not None):
                                __append((u' tabindex="%s"' % __attr_tabindex))
                            __append(u' >')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756867867280
                            __default_135756867867280 = _DEFAULT_MARKER

                            # <Value u"python:'\\n'.join(values.get(key,[]))" (101:43)> -> __cache_135756868294096
                            __token = 5269
                            try:
                                __zt_tmp = __attrs_135757072743440
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135756868294096 = _static_135757244280656('python', u"'\\n'.join(values.get(key,[]))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u"python:'\\n'.join(values.get(key,[]))" (101:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785be29bd0> -> __condition
                            __expression = __cache_135756868294096

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'\n                    ')
                            else:
                                __content = __cache_135756868294096
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</textarea>\n                  ')
                        __append(u'\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757109936784
                        __attrs_135757109936784 = _static_135757327983760

                        # <Value u"python:type == 'datetime'" (104:39)> -> __condition
                        __token = 5410
                        try:
                            __zt_tmp = __attrs_135757109936784
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u"type == 'datetime'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072743696
                            __attrs_135757072743696 = _static_135757327983760
                            __backup_id_135756869251856 = get('id', __marker)

                            # <Value u'string:${fieldName}_${key}' (105:40)> -> __value
                            __token = 5478
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('string', u'${fieldName}_${key}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['id'] = __value
                            __backup_value_135756866400336 = get('value', __marker)

                            # <Value u'python:values.get(key)' (106:42)> -> __value
                            __token = 5548
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'values.get(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['value'] = __value
                            __backup_show_hm_135756868293712 = get('show_hm', __marker)

                            # <Value u'widget/show_hm' (107:46)> -> __value
                            __token = 5619
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('path', u'widget/show_hm', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['show_hm'] = __value
                            __backup_inputname_135756866401552 = get('inputname', __marker)

                            # <Value u'string:${fieldName}.${key}:record' (108:44)> -> __value
                            __token = 5681
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('string', u'${fieldName}.${key}:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['inputname'] = __value
                            __backup_formname_135756867867344 = get('formname', __marker)

                            # <Value u'string:edit_form' (109:43)> -> __value
                            __token = 5762
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('string', u'edit_form', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['formname'] = __value
                            __backup_inputvalue_135756867870096 = get('inputvalue', __marker)

                            # <Value u"python: test(value, value, '')" (110:42)> -> __value
                            __token = 5826
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u" test(value, value, '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['inputvalue'] = __value
                            __backup_tabindex_135756868296528 = get('tabindex', __marker)

                            # <Value u'tabindex/next|nothing' (111:39)> -> __value
                            __token = 5902
                            try:
                                __zt_tmp = __attrs_135757072743696
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['tabindex'] = __value
                            __append(u'\n\t                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866248656
                            __attrs_135756866248656 = _static_135757327983760
                            __backup_macroname_135757134096656 = get('macroname', __marker)

                            # <Static value=<_ast.Str object at 0x7b785bc9d150> name=None at 7b785bc9d850> -> __value
                            __value = _static_135756866244944
                            econtext['macroname'] = __value

                            # <Value u'here/calendar_macros/macros/calendarDatePickerBox|here/calendar_slot/macros/calendarDatePickerBox' (113:43)> -> __macro
                            __token = 6016
                            try:
                                __zt_tmp = __attrs_135756866248656
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __macro = _static_135757244280656('path', u'here/calendar_macros/macros/calendarDatePickerBox|here/calendar_slot/macros/calendarDatePickerBox', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __token = 6016
                            __m = __macro.include
                            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                            econtext.update(rcontext)
                            if (__backup_macroname_135757134096656 is __marker):
                                del econtext['macroname']
                            else:
                                econtext['macroname'] = __backup_macroname_135757134096656
                            __append(u'\n\t                  ')
                            if (__backup_tabindex_135756868296528 is __marker):
                                del econtext['tabindex']
                            else:
                                econtext['tabindex'] = __backup_tabindex_135756868296528
                            if (__backup_inputvalue_135756867870096 is __marker):
                                del econtext['inputvalue']
                            else:
                                econtext['inputvalue'] = __backup_inputvalue_135756867870096
                            if (__backup_formname_135756867867344 is __marker):
                                del econtext['formname']
                            else:
                                econtext['formname'] = __backup_formname_135756867867344
                            if (__backup_inputname_135756866401552 is __marker):
                                del econtext['inputname']
                            else:
                                econtext['inputname'] = __backup_inputname_135756866401552
                            if (__backup_show_hm_135756868293712 is __marker):
                                del econtext['show_hm']
                            else:
                                econtext['show_hm'] = __backup_show_hm_135756868293712
                            if (__backup_value_135756866400336 is __marker):
                                del econtext['value']
                            else:
                                econtext['value'] = __backup_value_135756866400336
                            if (__backup_id_135756869251856 is __marker):
                                del econtext['id']
                            else:
                                econtext['id'] = __backup_id_135756869251856
                            __append(u'\n\t                ')
                        __append(u'\n\t                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072741392
                        __attrs_135757072741392 = _static_135757327983760

                        # <Value u"python: type in ['float', 'int', 'long']" (118:40)> -> __condition
                        __token = 6284
                        try:
                            __zt_tmp = __attrs_135757072741392
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u" type in ['float', 'int', 'long']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n\t                  ')

                            # <Static value=<_ast.Dict object at 0x7b785bc9d9d0> name=None at 7b785bc9d510> -> __attrs_135756869443344
                            __attrs_135756869443344 = _static_135756866247120

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="text"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866247312
                            __default_135756866247312 = _DEFAULT_MARKER

                            # <Substitution u'string:${fieldName}.${key}:${type}:record' (124:47)> -> __attr_name
                            __token = 6556
                            try:
                                __zt_tmp = __attrs_135756869443344
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'${fieldName}.${key}:${type}:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866246416
                            __default_135756866246416 = _DEFAULT_MARKER

                            # <Substitution u'python:values.get(key)' (125:37)> -> __attr_value
                            __token = 6636
                            try:
                                __zt_tmp = __attrs_135756869443344
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('python', u'values.get(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866244688
                            __default_135756866244688 = _DEFAULT_MARKER

                            # <Substitution u'python:field.getSubfieldSize(key)' (126:35)> -> __attr_size
                            __token = 6696
                            try:
                                __zt_tmp = __attrs_135756869443344
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_size = _static_135757244280656('python', u'field.getSubfieldSize(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_size = __quote(__attr_size, '"', '&quot;', u'10', _DEFAULT_MARKER)
                            if (__attr_size is not None):
                                __append((u' size="%s"' % __attr_size))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866248016
                            __default_135756866248016 = _DEFAULT_MARKER

                            # <Substitution u'tabindex/next|nothing' (128:37)> -> __attr_tabindex
                            __token = 6852
                            try:
                                __zt_tmp = __attrs_135756869443344
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_tabindex = _static_135757244280656('path', u'tabindex/next|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'#', _DEFAULT_MARKER)
                            if (__attr_tabindex is not None):
                                __append((u' tabindex="%s"' % __attr_tabindex))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866246672
                            __default_135756866246672 = _DEFAULT_MARKER

                            # <Substitution u'python:field.getSubfieldMaxlength(key)' (127:39)> -> __attr_maxlength
                            __token = 6772
                            try:
                                __zt_tmp = __attrs_135756869443344
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_maxlength = _static_135757244280656('python', u'field.getSubfieldMaxlength(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_maxlength is not None):
                                __append((u' maxlength="%s"' % __attr_maxlength))
                            __append(u' />\n\t                ')
                        __append(u'\n\t              </td>')
                        if (__backup_type_135756867728144 is __marker):
                            del econtext['type']
                        else:
                            econtext['type'] = __backup_type_135756867728144
                        __append(u'\n\t\t          ')
                    __append(u'\n            ')
                    ____index_135756866560656 -= 1
                    if (____index_135756866560656 > 0):
                        __append('')
                if (__backup_key_135756867728592 is __marker):
                    del econtext['key']
                else:
                    econtext['key'] = __backup_key_135756867728592
                __append(u'\n\t        </tr>\n        </table>')
                if (__backup_values_135757075191888 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135757075191888
                if (__backup_cached_values_135757074621008 is __marker):
                    del econtext['cached_values']
                else:
                    econtext['cached_values'] = __backup_cached_values_135757074621008
                if (__backup_session_values_135756866019280 is __marker):
                    del econtext['session_values']
                else:
                    econtext['session_values'] = __backup_session_values_135756866019280
                if (__backup_values_135756869120528 is __marker):
                    del econtext['values']
                else:
                    econtext['values'] = __backup_values_135756869120528
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'here/widgets/field/macros/edit' (46:28)> -> __macro
            __token = 2013
            try:
                __zt_tmp = __attrs_135756869380432
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 2013
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757111175040 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757111175040
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866375440
            __attrs_135756866375440 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866563984
            __attrs_135756866563984 = _static_135757327983760
            __backup_macroname_135757118855680 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bcea490> name=None at 7b785bcea550> -> __value
            __value = _static_135756866561168
            econtext['macroname'] = __value

            # <Value u'here/widgets/string/macros/edit' (140:28)> -> __macro
            __token = 7140
            try:
                __zt_tmp = __attrs_135756866563984
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/widgets/string/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 7140
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757118855680 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757118855680
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_duration_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bca23d0> name=None at 7b785bca2dd0> -> __attrs_135757071469584
            __attrs_135757071469584 = _static_135756866266064
            __backup_kss_class_135756867841232 = get('kss_class', __marker)

            # <Value u"python:getKssClasses(fieldName,\n                        templateId='durationwidget', macro='duration-field-view')" (14:34)> -> __value
            __token = 628
            try:
                __zt_tmp = __attrs_135757071469584
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"getKssClasses(fieldName,\n                        templateId='durationwidget', macro='duration-field-view')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kss_class'] = __value

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866267600
            __default_135756866267600 = _DEFAULT_MARKER

            # <Substitution u'kss_class' (16:34)> -> __attr_class
            __token = 778
            try:
                __zt_tmp = __attrs_135757071469584
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('path', u'kss_class', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866266448
            __default_135756866266448 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName' (17:30)> -> __attr_id
            __token = 819
            try:
                __zt_tmp = __attrs_135757071469584
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('string', u'parent-fieldname-$fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n        ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866373904
                __attrs_135756866373904 = _static_135757327983760
                __backup_values_dict_135756867728848 = get('values_dict', __marker)

                # <Value u'python:field.getAccessor(here)()' (19:38)> -> __value
                __token = 936
                try:
                    __zt_tmp = __attrs_135756866373904
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.getAccessor(here)()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['values_dict'] = __value
                __backup_innerJoin_135757151845008 = get('innerJoin', __marker)

                # <Value u'field/innerJoin' (20:42)> -> __value
                __token = 1012
                try:
                    __zt_tmp = __attrs_135756866373904
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'field/innerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['innerJoin'] = __value
                __backup_outerJoin_135756863554256 = get('outerJoin', __marker)

                # <Value u'field/outerJoin' (21:41)> -> __value
                __token = 1071
                try:
                    __zt_tmp = __attrs_135756866373904
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'field/outerJoin', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['outerJoin'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866372944
                __attrs_135756866372944 = _static_135757327983760

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table>\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866371792
                __attrs_135756866371792 = _static_135757327983760

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\n              ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869381840
                __attrs_135756869381840 = _static_135757327983760
                __backup_key_135756869381200 = get('key', __marker)

                # <Value u'field/getSubfields' (25:40)> -> __iterator
                __token = 1167
                try:
                    __zt_tmp = __attrs_135756869381840
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'field/getSubfields', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756869380240, ) = getitem('repeat')(u'key', __iterator)
                econtext['key'] = None
                for __item in __iterator:
                    econtext['key'] = __item
                    __append(u'\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869378576
                    __attrs_135756869378576 = _static_135757327983760

                    # <Value u'python:field.testSubfieldCondition(key,here,portal,template)' (26:42)> -> __condition
                    __token = 1230
                    try:
                        __zt_tmp = __attrs_135756869378576
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'field.testSubfieldCondition(key,here,portal,template)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                  ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869378768
                        __attrs_135756869378768 = _static_135757327983760
                        __backup_value_135757075006480 = get('value', __marker)

                        # <Value u'python:values_dict.get(key)' (28:38)> -> __value
                        __token = 1360
                        try:
                            __zt_tmp = __attrs_135756869378768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'values_dict.get(key)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['value'] = __value

                        # <Value u'value' (29:35)> -> __condition
                        __token = 1424
                        try:
                            __zt_tmp = __attrs_135756869378768
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78681a00d0> name=None at 7b78681a0c50> -> __attrs_135757074899152
                            __attrs_135757074899152 = _static_135757072826576

                            # <td ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<td valign="top">\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b786839ae10> name=None at 7b786839a910> -> __attrs_135757074899024
                            __attrs_135757074899024 = _static_135757074902544

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074901072
                            __default_135757074901072 = _DEFAULT_MARKER

                            # <Value u"python:field.getSubfieldLabel(key)+':'" (32:41)> -> __cache_135757074902992
                            __token = 1553
                            try:
                                __zt_tmp = __attrs_135757074899024
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757074902992 = _static_135757244280656('python', u"field.getSubfieldLabel(key)+':'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u"python:field.getSubfieldLabel(key)+':'" (32:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786839abd0> -> __condition
                            __expression = __cache_135757074902992

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span class="label">Label</span>')
                            else:
                                __content = __cache_135757074902992
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</td>\n                    ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866562640
                            __attrs_135756866562640 = _static_135757327983760

                            # <td ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<td>\n                      ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866563152
                            __attrs_135756866563152 = _static_135757327983760

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866562192
                            __default_135756866562192 = _DEFAULT_MARKER

                            # <Value u"python:here.getDisplayView(value,'<br />')" (34:51)> -> __cache_135756866563088
                            __token = 1687
                            try:
                                __zt_tmp = __attrs_135756866563152
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135756866563088 = _static_135757244280656('python', u"here.getDisplayView(value,'<br />')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u"python:here.getDisplayView(value,'<br />')" (34:51)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bcead50> -> __condition
                            __expression = __cache_135756866563088

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span>value</span>')
                            else:
                                __content = __cache_135756866563088
                                __content = __convert(__content)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'\n                    </td>\n                  ')
                        if (__backup_value_135757075006480 is __marker):
                            del econtext['value']
                        else:
                            econtext['value'] = __backup_value_135757075006480
                        __append(u'\n                ')
                    __append(u'\n              ')
                    ____index_135756869380240 -= 1
                    if (____index_135756869380240 > 0):
                        __append('')
                if (__backup_key_135756869381200 is __marker):
                    del econtext['key']
                else:
                    econtext['key'] = __backup_key_135756869381200
                __append(u'\n            </tr>\n          </table>\n        </div>')
                if (__backup_outerJoin_135756863554256 is __marker):
                    del econtext['outerJoin']
                else:
                    econtext['outerJoin'] = __backup_outerJoin_135756863554256
                if (__backup_innerJoin_135757151845008 is __marker):
                    del econtext['innerJoin']
                else:
                    econtext['innerJoin'] = __backup_innerJoin_135757151845008
                if (__backup_values_dict_135756867728848 is __marker):
                    del econtext['values_dict']
                else:
                    econtext['values_dict'] = __backup_values_dict_135756867728848
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n      </span>')
            if (__backup_kss_class_135756867841232 is __marker):
                del econtext['kss_class']
            else:
                econtext['kss_class'] = __backup_kss_class_135756867841232
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866265296
            __attrs_135756866265296 = _static_135757327983760
            __backup_kssClassesView_135756866130320 = get('kssClassesView', __marker)

            # <Value u'context/@@kss_field_decorator_view' (11:49)> -> __value
            __token = 404
            try:
                __zt_tmp = __attrs_135756866265296
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['kssClassesView'] = __value
            __backup_getKssClasses_135756867731280 = get('getKssClasses', __marker)

            # <Value u'nocall:kssClassesView/getKssClassesInlineEditable' (12:47)> -> __value
            __token = 487
            try:
                __zt_tmp = __attrs_135756866265296
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('nocall', u'kssClassesView/getKssClassesInlineEditable', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['getKssClasses'] = __value
            __append(u'\n      ')
            __token = None
            render_duration_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
            if (__backup_getKssClasses_135756867731280 is __marker):
                del econtext['getKssClasses']
            else:
                econtext['getKssClasses'] = __backup_getKssClasses_135756867731280
            if (__backup_kssClassesView_135756866130320 is __marker):
                del econtext['kssClassesView']
            else:
                econtext['kssClassesView'] = __backup_kssClassesView_135756866130320
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bc11c90> name=None at 7b785bc11f10> -> __attrs_135756865671568
            __attrs_135756865671568 = _static_135756865674384
            __previous_i18n_domain_135756865672592 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868964304
            __attrs_135756868964304 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866265936
            __attrs_135756866265936 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866265680
            __attrs_135756866265680 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Duration Widgets -->\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_135756865672592
            __append(u'\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_duration_field_view': render_duration_field_view, u'render_view': render_view, 'render': render, }