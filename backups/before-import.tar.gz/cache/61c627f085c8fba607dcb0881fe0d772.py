# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.textfield-1.3.7-py2.7.egg/plone/app/textfield/widget_input.pt'

__tokens = {403: (u'ng view/l', 11, 23), 290: (u'view/klass', 8, 27), 328: (u' view/styl', 9, 26), 366: (u'e view/tit', 10, 25), 442: (u'ick view/onc', 12, 25), 487: (u'lick view/ondbl', 13, 27), 536: (u'edown view/onmou', 14, 27), 584: (u'ouseup view/on', 15, 24), 632: (u'useover view/onm', 16, 25), 682: (u'ousemove view/on', 17, 24), 731: (u'nmouseout view/', 18, 22), 779: (u'onkeypress view', 19, 21), 826: (u'  onkeydown vi', 20, 19), 870: (u'     onkeyup', 21, 16), 933: (u'view/name', 23, 34), 976: (u' view/value/mimeType | view/field/default_mime_typ', 24, 32), 1068: (u's view/allowedMimeTyp', 25, 39), 1147: (u'python: len(allowedMimeTypes) > 1', 27, 52), 1299: (u'string:${fieldName}_text_format', 30, 41), 1372: (u' string:${fieldName}.mimeTyp', 31, 40), 1478: (u'allowedMimeTypes', 33, 37), 1541: (u"python:item == mimeType and 'selected' or None", 34, 45), 1630: (u' ite', 35, 41), 1671: (u'item', 36, 33), 1749: (u'python: len(allowedMimeTypes) == 1', 40, 31), 1838: (u'string:${fieldName}_text_format', 41, 52), 1924: (u' string:${fieldName}.mimeTyp', 42, 53), 2008: (u'e python:allowedMimeTypes[', 43, 53), 2124: (u'view/wrapped_context', 47, 43), 2188: (u' python:(not view.ignoreContext) and context or Non', 48, 42), 2283: (u'  nocall:conte', 49, 41), 2341: (u'   nocall:context/portal_', 50, 40), 2410: (u'    portal_url/getPortalOb', 51, 39), 2480: (u'     view/value/mimeType | view/field/default_mime', 52, 38), 2574: (u'      pytho', 53, 37), 2629: (u'       vi', 54, 36), 2682: (u'        view/value/raw |', 55, 35), 2750: (u'         reque', 56, 34), 2796: (u'   member context/portal_membership/getAuthentic', 57, 21), 2876: (u'    isAnon context/@@plone_portal_stat', 58, 20), 2946: (u'     editor view/getW', 59, 19), 3005: (u'support_path string:nocall:here/@@${editor}_wysiwyg_support|here/${editor}_wysiwyg_support|here/${editor}/wysiwyg_support|here/portal_skins/plone_wysiwyg/wy', 60, 24), 3194: (u'      support python: path', 61, 18), 3264: (u'ndex   ', 62, 28), 3315: (u's               python', 63, 27), 3381: (u'ls               pytho', 64, 26), 3447: (u'axlength          python:view.field.', 65, 25), 3527: (u'field     ', 66, 24), 3590: (u'support/macros/wysiwygEditorBox', 67, 30), 3590: (u'support/macros/wysiwygEditorBox', 67, 30)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402099470992 = {u'id': u'string:${fieldName}_text_format', u'name': u'string:${fieldName}.mimeType', }
_static_140402102316880 = {u'type': u'hidden', u'id': u'string:${fieldName}_text_format', u'value': u'python:allowedMimeTypes[0]', u'name': u'string:${fieldName}.mimeType', }
_static_140402356200592 = {}
_static_140402099470416 = {u'selected': u'', u'value': u'item', }
_static_140402272508048 = __compile_zt_expr
_static_140402100148240 = {u'lang': u'en', u'style': u'view/style', u'xmlns': u'http://www.w3.org/1999/xhtml', u'onmouseup': u'view/onmouseup', u'onmouseout': u'view/onmouseout', u'title': u'view/title', u'onkeypress': u'view/onkeypress', u'onkeydown': u'view/onkeydown', u'onmousedown': u'view/onmousedown', u'xml:lang': u'en', u'onmousemove': u'view/onmousemove', u'onmouseover': u'view/onmouseover', u'onclick': u'view/onclick', u'onkeyup': u'view/onkeyup', u'ondblclick': u'view/ondblclick', u'class': u'view/klass', }
_static_140402102831248 = {u'class': u'fieldTextFormat', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402099032336 = u'wysiwygEditorBox'

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e94e1810> name=None at 7fb1e94e1bd0> -> __attrs_140402100088528
            __attrs_140402100088528 = _static_140402100148240
            __previous_i18n_domain_140402102540304 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099576208
            __default_140402099576208 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (11:23)> -> __attr_lang
            __token = 403
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_140402272508048('path', u'view/lang', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', u'en', _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u' xml:lang="en" xmlns="http://www.w3.org/1999/xhtml"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099576528
            __default_140402099576528 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (8:27)> -> __attr_class
            __token = 290
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099576464
            __default_140402099576464 = _DEFAULT_MARKER

            # <Substitution u'view/style' (9:26)> -> __attr_style
            __token = 328
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099575568
            __default_140402099575568 = _DEFAULT_MARKER

            # <Substitution u'view/title' (10:25)> -> __attr_title
            __token = 366
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099575376
            __default_140402099575376 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (12:25)> -> __attr_onclick
            __token = 442
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_140402272508048('path', u'view/onclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099573904
            __default_140402099573904 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (13:27)> -> __attr_ondblclick
            __token = 487
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_140402272508048('path', u'view/ondblclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099574480
            __default_140402099574480 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (14:27)> -> __attr_onmousedown
            __token = 536
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_140402272508048('path', u'view/onmousedown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099573456
            __default_140402099573456 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (15:24)> -> __attr_onmouseup
            __token = 584
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_140402272508048('path', u'view/onmouseup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099574928
            __default_140402099574928 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (16:25)> -> __attr_onmouseover
            __token = 632
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_140402272508048('path', u'view/onmouseover', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099575952
            __default_140402099575952 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (17:24)> -> __attr_onmousemove
            __token = 682
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_140402272508048('path', u'view/onmousemove', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102540368
            __default_140402102540368 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (18:22)> -> __attr_onmouseout
            __token = 731
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_140402272508048('path', u'view/onmouseout', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102540432
            __default_140402102540432 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (19:21)> -> __attr_onkeypress
            __token = 779
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_140402272508048('path', u'view/onkeypress', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102540816
            __default_140402102540816 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (20:19)> -> __attr_onkeydown
            __token = 826
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_140402272508048('path', u'view/onkeydown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402180696592
            __default_140402180696592 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (21:16)> -> __attr_onkeyup
            __token = 870
            try:
                __zt_tmp = __attrs_140402100088528
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_140402272508048('path', u'view/onkeyup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))
            __append(u'>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402102838928
            __attrs_140402102838928 = _static_140402356200592
            __backup_fieldName_140402100335568 = get('fieldName', __marker)

            # <Value u'view/name' (23:34)> -> __value
            __token = 933
            try:
                __zt_tmp = __attrs_140402102838928
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['fieldName'] = __value
            __backup_mimeType_140402098206800 = get('mimeType', __marker)

            # <Value u'view/value/mimeType | view/field/default_mime_type' (24:32)> -> __value
            __token = 976
            try:
                __zt_tmp = __attrs_140402102838928
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/value/mimeType | view/field/default_mime_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['mimeType'] = __value
            __backup_allowedMimeTypes_140402100021776 = get('allowedMimeTypes', __marker)

            # <Value u'view/allowedMimeTypes' (25:39)> -> __value
            __token = 1068
            try:
                __zt_tmp = __attrs_140402102838928
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/allowedMimeTypes', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['allowedMimeTypes'] = __value
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9770890> name=None at 7fb1e9770d10> -> __attrs_140402102711184
            __attrs_140402102711184 = _static_140402102831248

            # <Value u'python: len(allowedMimeTypes) > 1' (27:52)> -> __condition
            __token = 1147
            try:
                __zt_tmp = __attrs_140402102711184
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u' len(allowedMimeTypes) > 1', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="fieldTextFormat">\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099471184
                __attrs_140402099471184 = _static_140402356200592

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label>')
                __stream_140402099473936 = []
                __append_140402099473936 = __stream_140402099473936.append
                __append_140402099473936(u'Text Format')
                __msgid_140402099473936 = __re_whitespace(''.join(__stream_140402099473936)).strip()
                if u'label_text_format':
                    __append(translate(u'label_text_format', mapping=None, default=__msgid_140402099473936, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1e943c290> name=None at 7fb1e943c3d0> -> __attrs_140402099470672
                __attrs_140402099470672 = _static_140402099470992

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099474064
                __default_140402099474064 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_text_format' (30:41)> -> __attr_id
                __token = 1299
                try:
                    __zt_tmp = __attrs_140402099470672
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_140402272508048('string', u'${fieldName}_text_format', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099472592
                __default_140402099472592 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.mimeType' (31:40)> -> __attr_name
                __token = 1372
                try:
                    __zt_tmp = __attrs_140402099470672
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_140402272508048('string', u'${fieldName}.mimeType', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))
                __append(u'>\n                ')

                # <Static value=<_ast.Dict object at 0x7fb1e943c050> name=None at 7fb1e943c550> -> __attrs_140402102596752
                __attrs_140402102596752 = _static_140402099470416
                __backup_item_140402099169488 = get('item', __marker)

                # <Value u'allowedMimeTypes' (33:37)> -> __iterator
                __token = 1478
                try:
                    __zt_tmp = __attrs_140402102596752
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_140402272508048('path', u'allowedMimeTypes', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                (__iterator, ____index_140402102596176, ) = getitem('repeat')(u'item', __iterator)
                econtext['item'] = None
                for __item in __iterator:
                    econtext['item'] = __item

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102596624
                    __default_140402102596624 = _DEFAULT_MARKER

                    # <Boolean u"python:item == mimeType and 'selected' or None" (34:45)> -> __attr_selected
                    __token = 1541
                    try:
                        __zt_tmp = __attrs_140402102596752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_selected = _static_140402272508048('python', u"item == mimeType and 'selected' or None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    if (__attr_selected is _DEFAULT_MARKER):
                        __attr_selected = u''
                    else:
                        if __attr_selected:
                            __attr_selected = u'selected'
                        else:
                            __attr_selected = None
                    if (__attr_selected is not None):
                        __append((u' selected="%s"' % __attr_selected))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102596304
                    __default_140402102596304 = _DEFAULT_MARKER

                    # <Substitution u'item' (35:41)> -> __attr_value
                    __token = 1630
                    try:
                        __zt_tmp = __attrs_140402102596752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_140402272508048('path', u'item', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099472848
                    __default_140402099472848 = _DEFAULT_MARKER

                    # <Value u'item' (36:33)> -> __cache_140402099472080
                    __token = 1671
                    try:
                        __zt_tmp = __attrs_140402102596752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402099472080 = _static_140402272508048('path', u'item', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'item' (36:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e943cf90> -> __condition
                    __expression = __cache_140402099472080

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_140402099472080
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>')
                    ____index_140402102596176 -= 1
                    if (____index_140402102596176 > 0):
                        __append('\n                ')
                if (__backup_item_140402099169488 is __marker):
                    del econtext['item']
                else:
                    econtext['item'] = __backup_item_140402099169488
                __append(u'\n            </select>\n        </div>')
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099474000
            __attrs_140402099474000 = _static_140402356200592

            # <Value u'python: len(allowedMimeTypes) == 1' (40:31)> -> __condition
            __token = 1749
            try:
                __zt_tmp = __attrs_140402099474000
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u' len(allowedMimeTypes) == 1', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1e96f2f50> name=None at 7fb1e96f2a50> -> __attrs_140402102516880
                __attrs_140402102516880 = _static_140402102316880

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102515024
                __default_140402102515024 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_text_format' (41:52)> -> __attr_id
                __token = 1838
                try:
                    __zt_tmp = __attrs_140402102516880
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_140402272508048('string', u'${fieldName}_text_format', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102517648
                __default_140402102517648 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}.mimeType' (42:53)> -> __attr_name
                __token = 1924
                try:
                    __zt_tmp = __attrs_140402102516880
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_140402272508048('string', u'${fieldName}.mimeType', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102516560
                __default_140402102516560 = _DEFAULT_MARKER

                # <Substitution u'python:allowedMimeTypes[0]' (43:53)> -> __attr_value
                __token = 2008
                try:
                    __zt_tmp = __attrs_140402102516880
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_140402272508048('python', u'allowedMimeTypes[0]', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\n        ')
            __append(u'\n    ')
            if (__backup_allowedMimeTypes_140402100021776 is __marker):
                del econtext['allowedMimeTypes']
            else:
                econtext['allowedMimeTypes'] = __backup_allowedMimeTypes_140402100021776
            if (__backup_mimeType_140402098206800 is __marker):
                del econtext['mimeType']
            else:
                econtext['mimeType'] = __backup_mimeType_140402098206800
            if (__backup_fieldName_140402100335568 is __marker):
                del econtext['fieldName']
            else:
                econtext['fieldName'] = __backup_fieldName_140402100335568
            __append(u'\n\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099473424
            __attrs_140402099473424 = _static_140402356200592
            __backup_context_140402098512016 = get('context', __marker)

            # <Value u'view/wrapped_context' (47:43)> -> __value
            __token = 2124
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/wrapped_context', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['context'] = __value
            __backup_object_140402099704208 = get('object', __marker)

            # <Value u'python:(not view.ignoreContext) and context or None' (48:42)> -> __value
            __token = 2188
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'(not view.ignoreContext) and context or None', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['object'] = __value
            __backup_here_140402098262480 = get('here', __marker)

            # <Value u'nocall:context' (49:41)> -> __value
            __token = 2283
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('nocall', u'context', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['here'] = __value
            __backup_portal_url_140402098262224 = get('portal_url', __marker)

            # <Value u'nocall:context/portal_url' (50:40)> -> __value
            __token = 2341
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('nocall', u'context/portal_url', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_portal_140402098623760 = get('portal', __marker)

            # <Value u'portal_url/getPortalObject' (51:39)> -> __value
            __token = 2410
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'portal_url/getPortalObject', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['portal'] = __value
            __backup_text_format_140402101067984 = get('text_format', __marker)

            # <Value u'view/value/mimeType | view/field/default_mime_type' (52:38)> -> __value
            __token = 2480
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/value/mimeType | view/field/default_mime_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['text_format'] = __value
            __backup_force_wysiwyg_140402101931024 = get('force_wysiwyg', __marker)

            # <Value u'python:True' (53:37)> -> __value
            __token = 2574
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'True', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['force_wysiwyg'] = __value
            __backup_inputname_140402098622672 = get('inputname', __marker)

            # <Value u'view/name' (54:36)> -> __value
            __token = 2629
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['inputname'] = __value
            __backup_inputvalue_140402098331472 = get('inputvalue', __marker)

            # <Value u'view/value/raw | nothing' (55:35)> -> __value
            __token = 2682
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/value/raw | nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['inputvalue'] = __value
            __backup_here_url_140402098804560 = get('here_url', __marker)

            # <Value u'request/getURL' (56:34)> -> __value
            __token = 2750
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'request/getURL', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['here_url'] = __value
            __backup_member_140402098625296 = get('member', __marker)

            # <Value u'context/portal_membership/getAuthenticatedMember' (57:21)> -> __value
            __token = 2796
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'context/portal_membership/getAuthenticatedMember', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['member'] = __value
            __backup_isAnon_140402098262288 = get('isAnon', __marker)

            # <Value u'context/@@plone_portal_state/anonymous' (58:20)> -> __value
            __token = 2876
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'context/@@plone_portal_state/anonymous', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['isAnon'] = __value
            __backup_editor_140402201949072 = get('editor', __marker)

            # <Value u'view/getWysiwygEditor' (59:19)> -> __value
            __token = 2946
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/getWysiwygEditor', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['editor'] = __value
            __backup_support_path_140402098262544 = get('support_path', __marker)

            # <Value u'string:nocall:here/@@${editor}_wysiwyg_support|here/${editor}_wysiwyg_support|here/${editor}/wysiwyg_support|here/portal_skins/plone_wysiwyg/wysiwyg_support' (60:24)> -> __value
            __token = 3005
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('string', u'nocall:here/@@${editor}_wysiwyg_support|here/${editor}_wysiwyg_support|here/${editor}/wysiwyg_support|here/portal_skins/plone_wysiwyg/wysiwyg_support', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['support_path'] = __value
            __backup_support_140402102462800 = get('support', __marker)

            # <Value u'python: path(support_path)' (61:18)> -> __value
            __token = 3194
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u' path(support_path)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['support'] = __value
            __backup_tabindex_140402098515216 = get('tabindex', __marker)

            # <Value u'nothing' (62:28)> -> __value
            __token = 3264
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['tabindex'] = __value
            __backup_rows_140402098511952 = get('rows', __marker)

            # <Value u'python:view.rows or 25' (63:27)> -> __value
            __token = 3315
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.rows or 25', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['rows'] = __value
            __backup_cols_140402100281232 = get('cols', __marker)

            # <Value u'python:view.cols or 80' (64:26)> -> __value
            __token = 3381
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.cols or 80', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['cols'] = __value
            __backup_maxlength_140402101089488 = get('maxlength', __marker)

            # <Value u'python:view.field.max_length or None' (65:25)> -> __value
            __token = 3447
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.field.max_length or None', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['maxlength'] = __value
            __backup_field_140402098564624 = get('field', __marker)

            # <Value u'view/field' (66:24)> -> __value
            __token = 3527
            try:
                __zt_tmp = __attrs_140402099473424
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/field', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['field'] = __value
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101392144
            __attrs_140402101392144 = _static_140402356200592
            __backup_macroname_140402145368896 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7fb1e93d1110> name=None at 7fb1e93d1150> -> __value
            __value = _static_140402099032336
            econtext['macroname'] = __value

            # <Value u'support/macros/wysiwygEditorBox' (67:30)> -> __macro
            __token = 3590
            try:
                __zt_tmp = __attrs_140402101392144
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_140402272508048('path', u'support/macros/wysiwygEditorBox', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __token = 3590
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_140402145368896 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_140402145368896
            __append(u'\n    ')
            if (__backup_field_140402098564624 is __marker):
                del econtext['field']
            else:
                econtext['field'] = __backup_field_140402098564624
            if (__backup_maxlength_140402101089488 is __marker):
                del econtext['maxlength']
            else:
                econtext['maxlength'] = __backup_maxlength_140402101089488
            if (__backup_cols_140402100281232 is __marker):
                del econtext['cols']
            else:
                econtext['cols'] = __backup_cols_140402100281232
            if (__backup_rows_140402098511952 is __marker):
                del econtext['rows']
            else:
                econtext['rows'] = __backup_rows_140402098511952
            if (__backup_tabindex_140402098515216 is __marker):
                del econtext['tabindex']
            else:
                econtext['tabindex'] = __backup_tabindex_140402098515216
            if (__backup_support_140402102462800 is __marker):
                del econtext['support']
            else:
                econtext['support'] = __backup_support_140402102462800
            if (__backup_support_path_140402098262544 is __marker):
                del econtext['support_path']
            else:
                econtext['support_path'] = __backup_support_path_140402098262544
            if (__backup_editor_140402201949072 is __marker):
                del econtext['editor']
            else:
                econtext['editor'] = __backup_editor_140402201949072
            if (__backup_isAnon_140402098262288 is __marker):
                del econtext['isAnon']
            else:
                econtext['isAnon'] = __backup_isAnon_140402098262288
            if (__backup_member_140402098625296 is __marker):
                del econtext['member']
            else:
                econtext['member'] = __backup_member_140402098625296
            if (__backup_here_url_140402098804560 is __marker):
                del econtext['here_url']
            else:
                econtext['here_url'] = __backup_here_url_140402098804560
            if (__backup_inputvalue_140402098331472 is __marker):
                del econtext['inputvalue']
            else:
                econtext['inputvalue'] = __backup_inputvalue_140402098331472
            if (__backup_inputname_140402098622672 is __marker):
                del econtext['inputname']
            else:
                econtext['inputname'] = __backup_inputname_140402098622672
            if (__backup_force_wysiwyg_140402101931024 is __marker):
                del econtext['force_wysiwyg']
            else:
                econtext['force_wysiwyg'] = __backup_force_wysiwyg_140402101931024
            if (__backup_text_format_140402101067984 is __marker):
                del econtext['text_format']
            else:
                econtext['text_format'] = __backup_text_format_140402101067984
            if (__backup_portal_140402098623760 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_140402098623760
            if (__backup_portal_url_140402098262224 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_140402098262224
            if (__backup_here_140402098262480 is __marker):
                del econtext['here']
            else:
                econtext['here'] = __backup_here_140402098262480
            if (__backup_object_140402099704208 is __marker):
                del econtext['object']
            else:
                econtext['object'] = __backup_object_140402099704208
            if (__backup_context_140402098512016 is __marker):
                del econtext['context']
            else:
                econtext['context'] = __backup_context_140402098512016
            __append(u'\n\n</div>')
            __i18n_domain = __previous_i18n_domain_140402102540304
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }