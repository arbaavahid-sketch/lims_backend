# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/install/templates/senaite-addsite.pt'

__tokens = {648: (u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', 15, 31), 878: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', 18, 31), 1074: (u'string:${context/absolute_url}/++resource++jstz-1.0.4.min.js', 20, 55), 1201: (u'string:${context/absolute_url}/++resource++plone-admin-ui.js', 21, 55), 1510: (u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', 32, 37), 1947: (u'view/profiles', 42, 41), 2003: (u' profiles/bas', 43, 41), 2061: (u'e profiles/defau', 44, 42), 2125: (u'es profiles/extensi', 45, 44), 2182: (u'ced request/advanced|not', 46, 33), 1856: (u'string:${context/absolute_url}/@@senaite-addsite', 41, 43), 2538: (u'request/site_id|nothing', 53, 47), 3153: (u'request/site_title|nothing', 65, 47), 3756: (u'view/browser_language', 77, 55), 3828: (u' python:view.grouped_languages(browser_language', 78, 49), 3927: (u'grouped_languages', 79, 48), 3968: (u'group/label', 79, 89), 4071: (u'group/languages', 82, 47), 4140: (u"python:lang['langcode']", 83, 52), 4210: (u" python:lang['langcode'] == browser_languag", 84, 45), 4299: (u"python: lang['label']", 85, 43), 5013: (u'view/timezones', 103, 46), 5078: (u'tz_list', 104, 48), 5109: (u'group', 104, 79), 5204: (u'python:tz_list[group]', 106, 45), 5279: (u'tz/value', 107, 52), 5332: (u'tz/label', 108, 43), 5890: (u'advanced', 122, 50), 6353: (u'not:advanced', 132, 44), 6528: (u'python: len(base_profiles) > 1', 136, 44), 6781: (u'base_profiles', 142, 48), 7075: (u' info/i', 148, 42), 7024: (u'info/id', 147, 50), 7128: (u"d python: default_profile==info['id'] and 'checked' or nothi", 149, 43), 7268: (u'info/id', 151, 49), 7319: (u'info/title', 152, 42), 7459: (u'info/description', 154, 75), 7957: (u'python: extension_profiles', 167, 50), 8045: (u'python: not advanced', 168, 59), 8129: (u'python: advanced', 169, 61), 8258: (u'extension_profiles', 173, 49), 8383: (u'info/selected|nothing', 175, 55), 8460: (u'python: not selected or advanced', 176, 53), 8543: (u'python: advanced', 177, 48), 8751: (u'info/id', 180, 61), 8807: (u' info/i', 181, 47), 8868: (u'd info/selected|nothi', 182, 51), 8989: (u'info/id', 184, 54), 9045: (u'info/title', 185, 47), 9264: (u'python: advanced', 188, 112), 9231: (u'info/description', 188, 79), 9459: (u'python: selected and not advanced', 192, 53), 9731: (u'info/id', 196, 57), 9788: (u' info/selected|nothin', 197, 48), 10043: (u'python: advanced', 203, 87)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757154831120 = {u'value': u'UTC', }
_static_135757365988432 = {u'for': u'default_language', }
_static_135757226788816 = {u'href': u'bootstrap.min.css', u'type': u'text/css', u'rel': u'stylesheet', }
_static_135757305497744 = {u'class': u'form-group', }
_static_135757134665296 = {u'type': u'submit', u'name': u'submit', u'value': u'Create SENAITE Site', u'class': u'btn btn-primary', }
_static_135757134821840 = {u'class': u'addons-group', }
_static_135757149540240 = {u'class': u'form-text small text-muted', }
_static_135757154874320 = {u'class': u'col-sm-12', }
_static_135757149539024 = {u'class': u'form-control', u'type': u'text', u'name': u'title', u'value': u'Site', u'size': u'30', }
_static_135757305570640 = {u'id': u'add-on-list', }
_static_135757365985680 = {u'class': u'form-text small text-muted', }
_static_135757134635600 = {u'class': u'form-group', }
_static_135757365915920 = {u'class': u'form-text small text-muted', }
_static_135757132662672 = {u'for': u'info/id', }
_static_135757154860048 = {u'class': u'row', }
_static_135757166676240 = {u'charset': u'utf-8', }
_static_135757365996304 = {u'src': u'string:${context/absolute_url}/++resource++plone-admin-ui.js', u'type': u'text/javascript', }
_static_135757134635920 = {u'for': u'site_id', }
_static_135757134823376 = {u'class': u'form-text text-muted', }
_static_135757237125520 = {u'class': u'field', }
_static_135757151940560 = {u'href': u'favicon.ico', u'type': u'image/x-icon', u'rel': u'icon', }
_static_135757305495632 = {u'for': u'title', }
_static_135757237310928 = {u'class': u'form-text small text-muted', }
_static_135757166674064 = {u'content': u'width=device-width, initial-scale=1', u'name': u'viewport', }
_static_135757154876240 = {u'action': u'#', u'method': u'post', }
_static_135757366004752 = {u'class': u'form-text text-muted small', }
_static_135757365962576 = {u'for': u'portal_timezone', }
_static_135757154828496 = {u'class': u'field', }
_static_135757327983760 = {}
_static_135757226824848 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135757149536336 = {u'class': u'form-group', }
_static_135757151937232 = {u'src': u'string:${context/absolute_url}/++resource++jstz-1.0.4.min.js', u'type': u'text/javascript', }
_static_135757305571920 = {u'class': u'form-text small text-muted', }
_static_135757159740176 = {u'type': u'hidden', u'name': u'setup_content:boolean', u'value': u'true', }
_static_135757154867280 = {u'name': u'site_id', u'value': u'request/site_id|nothing', u'class': u'form-control', u'type': u'text', u'id': u'site_id', u'size': u'20', }
_static_135757237127760 = {u'for': u'profile_id', }
_static_135757305570960 = {u'class': u'formControls mt-2', }
_static_135757365918608 = {u'type': u'checkbox', u'name': u'setup_content:boolean', }
_static_135757151923536 = {u'label': u'group', }
_static_135757244280656 = __compile_zt_expr
_static_135757154839504 = {u'checked': u'info/selected|nothing', u'type': u'checkbox', u'name': u'extension_ids:list', u'value': u'', u'id': u'info/id', }
_static_135757232037264 = {u'class': u'col-sm-6 offset-sm-3', }
_static_135757365961296 = {u'id': u'portal_timezone', u'name': u'portal_timezone', u'class': u'form-control', }
_static_135757154860176 = {u'class': u'lead', }
_static_135757365961360 = {u'class': u'field', }
_static_135757134667472 = {u'type': u'hidden', u'name': u'form.submitted:boolean', u'value': u'True', }
_static_135757237124112 = {u'selected': u"python:lang['langcode'] == browser_language", u'value': u'en', }
_static_135757154838096 = {u'for': u'info/id', }
_static_135757237310224 = {u'checked': u"python: default_profile==info['id'] and 'checked' or nothing", u'type': u'radio', u'name': u'profile_id:string', u'value': u'profile', u'id': u'info/id', }
_static_135757305498000 = {u'class': u'form-text small text-muted', }
_static_135757366005008 = {u'checked': u'info/selected|nothing', u'type': u'hidden', u'class': u'form-check-input', u'value': u'', u'name': u'extension_ids:list', }
_static_135757365995536 = {u'class': u'container', }
_static_135757365985936 = {u'name': u'default_language', u'class': u'form-control', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757365995664 = {u'class': u'row', }
_static_135757237124688 = {u'label': u'group/label', }
_static_135757154859728 = {u'src': u'senaite-logo.png', u'height': u'30', }
_static_135757151922448 = {u'class': u'form-text small text-muted', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n')

            # <Static value=<_ast.Dict object at 0x7b787147d490> name=None at 7b787147dd90> -> __attrs_135757166676816
            __attrs_135757166676816 = _static_135757226824848
            __previous_i18n_domain_135757166675216 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757166676944
            __attrs_135757166676944 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786db20910> name=None at 7b786db20590> -> __attrs_135757166674896
            __attrs_135757166674896 = _static_135757166676240

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta charset="utf-8"/>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786db20090> name=None at 7b786db20610> -> __attrs_135757226790224
            __attrs_135757226790224 = _static_135757166674064

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport" content="width=device-width, initial-scale=1"/>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226790800
            __attrs_135757226790800 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title>')
            __stream_135757226788752 = []
            __append_135757226788752 = __stream_135757226788752.append
            __append_135757226788752(u'Install SENAITE LIMS')
            __msgid_135757226788752 = __re_whitespace(''.join(__stream_135757226788752)).strip()
            if __msgid_135757226788752:
                __append(translate(__msgid_135757226788752, mapping=None, default=__msgid_135757226788752, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</title>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78714747d0> name=None at 7b78714742d0> -> __attrs_135757151938192
            __attrs_135757151938192 = _static_135757226788816

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet" type="text/css"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226788560
            __default_135757226788560 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css' (15:31)> -> __attr_href
            __token = 648
            try:
                __zt_tmp = __attrs_135757151938192
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/modules/bootstrap/css/bootstrap.min.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'bootstrap.min.css', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' />\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cd12fd0> name=None at 7b786cd12ad0> -> __attrs_135757151938384
            __attrs_135757151938384 = _static_135757151940560

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151939920
            __default_135757151939920 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico' (18:31)> -> __attr_href
            __token = 878
            try:
                __zt_tmp = __attrs_135757151938384
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/favicon.ico', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'favicon.ico', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' rel="icon" type="image/x-icon"/>\n    <!-- required to get the correct timezone selected -->\n    ')

            # <Static value=<_ast.Dict object at 0x7b786cd122d0> name=None at 7b786cd12e50> -> __attrs_135757151940240
            __attrs_135757151940240 = _static_135757151937232

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151937744
            __default_135757151937744 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++resource++jstz-1.0.4.min.js' (20:55)> -> __attr_src
            __token = 1074
            try:
                __zt_tmp = __attrs_135757151940240
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++resource++jstz-1.0.4.min.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>\n    ')

            # <Static value=<_ast.Dict object at 0x7b7879936b10> name=None at 7b7879936d50> -> __attrs_135757365994256
            __attrs_135757365994256 = _static_135757365996304

            # <script ... (0:0)
            # --------------------------------------------------------
            __append(u'<script type="text/javascript"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757365996112
            __default_135757365996112 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++resource++plone-admin-ui.js' (21:55)> -> __attr_src
            __token = 1201
            try:
                __zt_tmp = __attrs_135757365994256
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++resource++plone-admin-ui.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u'></script>\n  </head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365994448
            __attrs_135757365994448 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b7879936810> name=None at 7b7879936c90> -> __attrs_135757365995152
            __attrs_135757365995152 = _static_135757365995536

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container">\n      ')

            # <Static value=<_ast.Dict object at 0x7b7879936890> name=None at 7b7879936750> -> __attrs_135757232037584
            __attrs_135757232037584 = _static_135757365995664

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n        ')

            # <Static value=<_ast.Dict object at 0x7b7871975d90> name=None at 7b7871975990> -> __attrs_135757232034640
            __attrs_135757232034640 = _static_135757232037264

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-6 offset-sm-3">\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232035408
            __attrs_135757232035408 = _static_135757327983760

            # <h1 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h1>\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cfdbad0> name=None at 7b7871975c10> -> __attrs_135757154858192
            __attrs_135757154858192 = _static_135757154859728

            # <img ... (0:0)
            # --------------------------------------------------------
            __append(u'<img')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154857872
            __default_135757154857872 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg' (32:37)> -> __attr_src
            __token = 1510
            try:
                __zt_tmp = __attrs_135757154858192
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_src = _static_135757244280656('string', u'${context/absolute_url}/++plone++senaite.core.static/images/senaite.svg', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_src = __quote(__attr_src, '"', '&quot;', u'senaite-logo.png', _DEFAULT_MARKER)
            if (__attr_src is not None):
                __append((u' src="%s"' % __attr_src))
            __append(u' height="30" />\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cfdbc90> name=None at 7b786cfdbd90> -> __attrs_135757154861008
            __attrs_135757154861008 = _static_135757154860176

            # <small ... (0:0)
            # --------------------------------------------------------
            __append(u'<small class="lead">Site Installation</small>\n          </h1>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757154857232
            __attrs_135757154857232 = _static_135757327983760

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\n\n          ')

            # <Static value=<_ast.Dict object at 0x7b786cfdbc10> name=None at 7b786cfdb950> -> __attrs_135757154859024
            __attrs_135757154859024 = _static_135757154860048

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n            ')

            # <Static value=<_ast.Dict object at 0x7b786cfdf3d0> name=None at 7b786cfdf610> -> __attrs_135757154875088
            __attrs_135757154875088 = _static_135757154874320

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\n              ')

            # <Static value=<_ast.Dict object at 0x7b786cfdfb50> name=None at 7b786cfdfa10> -> __attrs_135757154875536
            __attrs_135757154875536 = _static_135757154876240
            __backup_profiles_135757232035280 = get('profiles', __marker)

            # <Value u'view/profiles' (42:41)> -> __value
            __token = 1947
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/profiles', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['profiles'] = __value
            __backup_base_profiles_135757154858384 = get('base_profiles', __marker)

            # <Value u'profiles/base' (43:41)> -> __value
            __token = 2003
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'profiles/base', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['base_profiles'] = __value
            __backup_default_profile_135757154876752 = get('default_profile', __marker)

            # <Value u'profiles/default' (44:42)> -> __value
            __token = 2061
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'profiles/default', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['default_profile'] = __value
            __backup_extension_profiles_135757154877136 = get('extension_profiles', __marker)

            # <Value u'profiles/extensions' (45:44)> -> __value
            __token = 2125
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'profiles/extensions', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['extension_profiles'] = __value
            __backup_advanced_135757154875856 = get('advanced', __marker)

            # <Value u'request/advanced|nothing' (46:33)> -> __value
            __token = 2182
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'request/advanced|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['advanced'] = __value

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154874384
            __default_135757154874384 = _DEFAULT_MARKER

            # <Substitution u'string:${context/absolute_url}/@@senaite-addsite' (41:43)> -> __attr_action
            __token = 1856
            try:
                __zt_tmp = __attrs_135757154875536
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_135757244280656('string', u'${context/absolute_url}/@@senaite-addsite', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'#', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u' method="post">\n\n                <!-- Site ID -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b786bc92250> name=None at 7b786bc92690> -> __attrs_135757134638288
            __attrs_135757134638288 = _static_135757134635600

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-group">\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786bc92390> name=None at 7b786bc92b90> -> __attrs_135757154866896
            __attrs_135757154866896 = _static_135757134635920

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="site_id">')
            __stream_135757134638160 = []
            __append_135757134638160 = __stream_135757134638160.append
            __append_135757134638160(u'Path identifier')
            __msgid_135757134638160 = __re_whitespace(''.join(__stream_135757134638160)).strip()
            if __msgid_135757134638160:
                __append(translate(__msgid_135757134638160, mapping=None, default=__msgid_135757134638160, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786cfdd850> name=None at 7b786cfdd210> -> __attrs_135757154867536
            __attrs_135757154867536 = _static_135757154867280

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="text" name="site_id" size="20" id="site_id" class="form-control"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154866768
            __default_135757154866768 = _DEFAULT_MARKER

            # <Substitution u'request/site_id|nothing' (53:47)> -> __attr_value
            __token = 2538
            try:
                __zt_tmp = __attrs_135757154867536
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('path', u'request/site_id|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7875f84990> name=None at 7b7875f84ed0> -> __attrs_135757305496592
            __attrs_135757305496592 = _static_135757305498000

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-text small text-muted">')
            __stream_135757305499472 = []
            __append_135757305499472 = __stream_135757305499472.append
            __append_135757305499472(u'\n                    The ID of the site. This ends up as part of the URL.\n                    No special characters or spaces are allowed.\n                  ')
            __msgid_135757305499472 = __re_whitespace(''.join(__stream_135757305499472)).strip()
            if __msgid_135757305499472:
                __append(translate(__msgid_135757305499472, mapping=None, default=__msgid_135757305499472, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n                </div>\n\n                <!-- Site Title -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b7875f84890> name=None at 7b7875f84c10> -> __attrs_135757305496336
            __attrs_135757305496336 = _static_135757305497744

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-group">\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7875f84050> name=None at 7b7875f844d0> -> __attrs_135757305496848
            __attrs_135757305496848 = _static_135757305495632

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="title">')
            __stream_135757305497360 = []
            __append_135757305497360 = __stream_135757305497360.append
            __append_135757305497360(u'Title')
            __msgid_135757305497360 = __re_whitespace(''.join(__stream_135757305497360)).strip()
            if u'label_title':
                __append(translate(u'label_title', mapping=None, default=__msgid_135757305497360, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786cac8ad0> name=None at 7b7875f84190> -> __attrs_135757149536848
            __attrs_135757149536848 = _static_135757149539024

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="text" name="title" size="30"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757149537488
            __default_135757149537488 = _DEFAULT_MARKER

            # <Substitution u'request/site_title|nothing' (65:47)> -> __attr_value
            __token = 3153
            try:
                __zt_tmp = __attrs_135757149536848
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('path', u'request/site_title|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', u'Site', _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' class="form-control" />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786cac8f90> name=None at 7b786cac8450> -> __attrs_135757149539600
            __attrs_135757149539600 = _static_135757149540240

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-text small text-muted">')
            __stream_135757149539152 = []
            __append_135757149539152 = __stream_135757149539152.append
            __append_135757149539152(u'\n                    A short title for the site. This will be shown in the title of the\n                    browser window on each page.\n                  ')
            __msgid_135757149539152 = __re_whitespace(''.join(__stream_135757149539152)).strip()
            if __msgid_135757149539152:
                __append(translate(__msgid_135757149539152, mapping=None, default=__msgid_135757149539152, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n                </div>\n\n                <!-- Language -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cac8050> name=None at 7b786cac8290> -> __attrs_135757149538320
            __attrs_135757149538320 = _static_135757149536336

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-group">\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7879934c50> name=None at 7b7879934850> -> __attrs_135757365986320
            __attrs_135757365986320 = _static_135757365988432

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="default_language">')
            __stream_135757365986768 = []
            __append_135757365986768 = __stream_135757365986768.append
            __append_135757365986768(u'Language')
            __msgid_135757365986768 = __re_whitespace(''.join(__stream_135757365986768)).strip()
            if __msgid_135757365986768:
                __append(translate(__msgid_135757365986768, mapping=None, default=__msgid_135757365986768, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7879934290> name=None at 7b7879934f90> -> __attrs_135757365986448
            __attrs_135757365986448 = _static_135757365985936
            __backup_browser_language_135757134636880 = get('browser_language', __marker)

            # <Value u'view/browser_language' (77:55)> -> __value
            __token = 3756
            try:
                __zt_tmp = __attrs_135757365986448
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/browser_language', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['browser_language'] = __value
            __backup_grouped_languages_135757134635216 = get('grouped_languages', __marker)

            # <Value u'python:view.grouped_languages(browser_language)' (78:49)> -> __value
            __token = 3828
            try:
                __zt_tmp = __attrs_135757365986448
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'view.grouped_languages(browser_language)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['grouped_languages'] = __value

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select name="default_language" class="form-control">\n                    ')

            # <Static value=<_ast.Dict object at 0x7b7871e4fe50> name=None at 7b7879934590> -> __attrs_135757237124944
            __attrs_135757237124944 = _static_135757237124688
            __backup_group_135757134637072 = get('group', __marker)

            # <Value u'grouped_languages' (79:48)> -> __iterator
            __token = 3927
            try:
                __zt_tmp = __attrs_135757237124944
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_135757244280656('path', u'grouped_languages', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            (__iterator, ____index_135757237121232, ) = getitem('repeat')(u'group', __iterator)
            econtext['group'] = None
            for __item in __iterator:
                econtext['group'] = __item

                # <optgroup ... (0:0)
                # --------------------------------------------------------
                __append(u'<optgroup')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237123984
                __default_135757237123984 = _DEFAULT_MARKER

                # <Substitution u'group/label' (79:89)> -> __attr_label
                __token = 3968
                try:
                    __zt_tmp = __attrs_135757237124944
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_label = _static_135757244280656('path', u'group/label', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_label = __quote(__attr_label, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_label is not None):
                    __append((u' label="%s"' % __attr_label))
                __append(u'>\n\n                      ')

                # <Static value=<_ast.Dict object at 0x7b7871e4fc10> name=None at 7b7871e4f750> -> __attrs_135757237122384
                __attrs_135757237122384 = _static_135757237124112
                __backup_lang_135757237123856 = get('lang', __marker)

                # <Value u'group/languages' (82:47)> -> __iterator
                __token = 4071
                try:
                    __zt_tmp = __attrs_135757237122384
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'group/languages', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757365964496, ) = getitem('repeat')(u'lang', __iterator)
                econtext['lang'] = None
                for __item in __iterator:
                    econtext['lang'] = __item

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237121744
                    __default_135757237121744 = _DEFAULT_MARKER

                    # <Substitution u"python:lang['langcode']" (83:52)> -> __attr_value
                    __token = 4140
                    try:
                        __zt_tmp = __attrs_135757237122384
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('python', u"lang['langcode']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', u'en', _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237121936
                    __default_135757237121936 = _DEFAULT_MARKER

                    # <Boolean u"python:lang['langcode'] == browser_language" (84:45)> -> __attr_selected
                    __token = 4210
                    try:
                        __zt_tmp = __attrs_135757237122384
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_selected = _static_135757244280656('python', u"lang['langcode'] == browser_language", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (__attr_selected is _DEFAULT_MARKER):
                        __attr_selected = None
                    else:
                        if __attr_selected:
                            __attr_selected = u'selected'
                        else:
                            __attr_selected = None
                    if (__attr_selected is not None):
                        __append((u' selected="%s"' % __attr_selected))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237123664
                    __default_135757237123664 = _DEFAULT_MARKER

                    # <Value u"python: lang['label']" (85:43)> -> __cache_135757237121552
                    __token = 4299
                    try:
                        __zt_tmp = __attrs_135757237122384
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757237121552 = _static_135757244280656('python', u" lang['label']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u"python: lang['label']" (85:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871e4f5d0> -> __condition
                    __expression = __cache_135757237121552

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                        English\n                      ')
                    else:
                        __content = __cache_135757237121552
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>')
                    ____index_135757365964496 -= 1
                    if (____index_135757365964496 > 0):
                        __append('\n                      ')
                if (__backup_lang_135757237123856 is __marker):
                    del econtext['lang']
                else:
                    econtext['lang'] = __backup_lang_135757237123856
                __append(u'\n                    </optgroup>')
                ____index_135757237121232 -= 1
                if (____index_135757237121232 > 0):
                    __append('\n                    ')
            if (__backup_group_135757134637072 is __marker):
                del econtext['group']
            else:
                econtext['group'] = __backup_group_135757134637072
            __append(u'\n                  </select>')
            if (__backup_grouped_languages_135757134635216 is __marker):
                del econtext['grouped_languages']
            else:
                econtext['grouped_languages'] = __backup_grouped_languages_135757134635216
            if (__backup_browser_language_135757134636880 is __marker):
                del econtext['browser_language']
            else:
                econtext['browser_language'] = __backup_browser_language_135757134636880
            __append(u'\n                  ')

            # <Static value=<_ast.Dict object at 0x7b7879934190> name=None at 7b78799346d0> -> __attrs_135757365964688
            __attrs_135757365964688 = _static_135757365985680

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-text small text-muted">')
            __stream_135757365989328 = []
            __append_135757365989328 = __stream_135757365989328.append
            __append_135757365989328(u'\n                    The main language of the site.\n                  ')
            __msgid_135757365989328 = __re_whitespace(''.join(__stream_135757365989328)).strip()
            if __msgid_135757365989328:
                __append(translate(__msgid_135757365989328, mapping=None, default=__msgid_135757365989328, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n                </div>\n\n                <!-- Timezone -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b787992e290> name=None at 7b7871e4f650> -> __attrs_135757365960912
            __attrs_135757365960912 = _static_135757365961360

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="field">\n                  ')

            # <Static value=<_ast.Dict object at 0x7b787992e750> name=None at 7b787992e4d0> -> __attrs_135757365964560
            __attrs_135757365964560 = _static_135757365962576

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label for="portal_timezone">')
            __stream_135757365962704 = []
            __append_135757365962704 = __stream_135757365962704.append
            __append_135757365962704(u'\n                    Default timezone\n                  ')
            __msgid_135757365962704 = __re_whitespace(''.join(__stream_135757365962704)).strip()
            if __msgid_135757365962704:
                __append(translate(__msgid_135757365962704, mapping=None, default=__msgid_135757365962704, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\n                  ')

            # <Static value=<_ast.Dict object at 0x7b787992e250> name=None at 7b787992e450> -> __attrs_135757151920912
            __attrs_135757151920912 = _static_135757365961296
            __backup_tz_list_135757365988816 = get('tz_list', __marker)

            # <Value u'view/timezones' (103:46)> -> __value
            __token = 5013
            try:
                __zt_tmp = __attrs_135757151920912
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/timezones', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['tz_list'] = __value

            # <select ... (0:0)
            # --------------------------------------------------------
            __append(u'<select id="portal_timezone" class="form-control" name="portal_timezone">\n                    ')

            # <Static value=<_ast.Dict object at 0x7b786cd0ed50> name=None at 7b786cd0ea10> -> __attrs_135757151923344
            __attrs_135757151923344 = _static_135757151923536
            __backup_group_135757154867472 = get('group', __marker)

            # <Value u'tz_list' (104:48)> -> __iterator
            __token = 5078
            try:
                __zt_tmp = __attrs_135757151923344
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_135757244280656('path', u'tz_list', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            (__iterator, ____index_135757151921424, ) = getitem('repeat')(u'group', __iterator)
            econtext['group'] = None
            for __item in __iterator:
                econtext['group'] = __item

                # <optgroup ... (0:0)
                # --------------------------------------------------------
                __append(u'<optgroup')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151922512
                __default_135757151922512 = _DEFAULT_MARKER

                # <Substitution u'group' (104:79)> -> __attr_label
                __token = 5109
                try:
                    __zt_tmp = __attrs_135757151923344
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_label = _static_135757244280656('path', u'group', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_label = __quote(__attr_label, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_label is not None):
                    __append((u' label="%s"' % __attr_label))
                __append(u'>\n                      ')

                # <Static value=<_ast.Dict object at 0x7b786cfd4b10> name=None at 7b786cfd4690> -> __attrs_135757154831312
                __attrs_135757154831312 = _static_135757154831120
                __backup_tz_135757237123408 = get('tz', __marker)

                # <Value u'python:tz_list[group]' (106:45)> -> __iterator
                __token = 5204
                try:
                    __zt_tmp = __attrs_135757154831312
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u'tz_list[group]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757154831632, ) = getitem('repeat')(u'tz', __iterator)
                econtext['tz'] = None
                for __item in __iterator:
                    econtext['tz'] = __item

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154829392
                    __default_135757154829392 = _DEFAULT_MARKER

                    # <Substitution u'tz/value' (107:52)> -> __attr_value
                    __token = 5279
                    try:
                        __zt_tmp = __attrs_135757154831312
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'tz/value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', u'UTC', _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154830480
                    __default_135757154830480 = _DEFAULT_MARKER

                    # <Value u'tz/label' (108:43)> -> __cache_135757151922384
                    __token = 5332
                    try:
                        __zt_tmp = __attrs_135757154831312
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757151922384 = _static_135757244280656('path', u'tz/label', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'tz/label' (108:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cfd41d0> -> __condition
                    __expression = __cache_135757151922384

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                        UTC\n                      ')
                    else:
                        __content = __cache_135757151922384
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>')
                    ____index_135757154831632 -= 1
                    if (____index_135757154831632 > 0):
                        __append('\n                      ')
                if (__backup_tz_135757237123408 is __marker):
                    del econtext['tz']
                else:
                    econtext['tz'] = __backup_tz_135757237123408
                __append(u'\n                    </optgroup>')
                ____index_135757151921424 -= 1
                if (____index_135757151921424 > 0):
                    __append('\n                    ')
            if (__backup_group_135757154867472 is __marker):
                del econtext['group']
            else:
                econtext['group'] = __backup_group_135757154867472
            __append(u'\n                  </select>')
            if (__backup_tz_list_135757365988816 is __marker):
                del econtext['tz_list']
            else:
                econtext['tz_list'] = __backup_tz_list_135757365988816
            __append(u'\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786cd0e910> name=None at 7b786cd0e290> -> __attrs_135757154829904
            __attrs_135757154829904 = _static_135757151922448

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-text small text-muted">')
            __stream_135757151920720 = []
            __append_135757151920720 = __stream_135757151920720.append
            __append_135757151920720(u'\n                    The default timezone setting of the portal. Users will be able to set\n                    their own timezone, if available timezones are defined in the date and\n                    time settings.\n                  ')
            __msgid_135757151920720 = __re_whitespace(''.join(__stream_135757151920720)).strip()
            if __msgid_135757151920720:
                __append(translate(__msgid_135757151920720, mapping=None, default=__msgid_135757151920720, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</div>\n\n                </div>\n\n                <!-- Advanced -->\n                ')

            # <Static value=<_ast.Dict object at 0x7b786cfd40d0> name=None at 7b787992e050> -> __attrs_135757154828624
            __attrs_135757154828624 = _static_135757154828496

            # <Value u'advanced' (122:50)> -> __condition
            __token = 5890
            try:
                __zt_tmp = __attrs_135757154828624
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="field">\n                  ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365919632
                __attrs_135757365919632 = _static_135757327983760

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label>\n                    ')

                # <Static value=<_ast.Dict object at 0x7b7879923b90> name=None at 7b7879923990> -> __attrs_135757365916752
                __attrs_135757365916752 = _static_135757365918608

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="checkbox" name="setup_content:boolean" />\n                    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365916176
                __attrs_135757365916176 = _static_135757327983760
                __stream_135757365917904 = []
                __append_135757365917904 = __stream_135757365917904.append
                __append_135757365917904(u'Example content')
                __msgid_135757365917904 = __re_whitespace(''.join(__stream_135757365917904)).strip()
                if __msgid_135757365917904:
                    __append(translate(__msgid_135757365917904, mapping=None, default=__msgid_135757365917904, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n                  </label>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b7879923110> name=None at 7b7879923890> -> __attrs_135757365916368
                __attrs_135757365916368 = _static_135757365915920

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="form-text small text-muted">')
                __stream_135757365916880 = []
                __append_135757365916880 = __stream_135757365916880.append
                __append_135757365916880(u'\n                    Should the default example content be added to the site?\n                  ')
                __msgid_135757365916880 = __re_whitespace(''.join(__stream_135757365916880)).strip()
                if __msgid_135757365916880:
                    __append(translate(__msgid_135757365916880, mapping=None, default=__msgid_135757365916880, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</div>\n                </div>')
            __append(u'\n\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365918736
            __attrs_135757365918736 = _static_135757327983760

            # <Value u'not:advanced' (132:44)> -> __condition
            __token = 6353
            try:
                __zt_tmp = __attrs_135757365918736
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n                  ')

                # <Static value=<_ast.Dict object at 0x7b786d483310> name=None at 7b786d483210> -> __attrs_135757159739600
                __attrs_135757159739600 = _static_135757159740176

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="setup_content:boolean" value="true" />\n                ')
            __append(u'\n\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159741520
            __attrs_135757159741520 = _static_135757327983760

            # <Value u'python: len(base_profiles) > 1' (136:44)> -> __condition
            __token = 6528
            try:
                __zt_tmp = __attrs_135757159741520
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u' len(base_profiles) > 1', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n                  ')

                # <Static value=<_ast.Dict object at 0x7b7871e50190> name=None at 7b7871e50cd0> -> __attrs_135757237128976
                __attrs_135757237128976 = _static_135757237125520

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="field">\n                    ')

                # <Static value=<_ast.Dict object at 0x7b7871e50a50> name=None at 7b7871e504d0> -> __attrs_135757237125392
                __attrs_135757237125392 = _static_135757237127760

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label for="profile_id">')
                __stream_135757237125648 = []
                __append_135757237125648 = __stream_135757237125648.append
                __append_135757237125648(u'\n                      Base configuration\n                    ')
                __msgid_135757237125648 = __re_whitespace(''.join(__stream_135757237125648)).strip()
                if __msgid_135757237125648:
                    __append(translate(__msgid_135757237125648, mapping=None, default=__msgid_135757237125648, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n\n                    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237127120
                __attrs_135757237127120 = _static_135757327983760
                __backup_info_135757365988496 = get('info', __marker)

                # <Value u'base_profiles' (142:48)> -> __iterator
                __token = 6781
                try:
                    __zt_tmp = __attrs_135757237127120
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'base_profiles', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757237127952, ) = getitem('repeat')(u'info', __iterator)
                econtext['info'] = None
                for __item in __iterator:
                    econtext['info'] = __item
                    __append(u'\n                      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237309648
                    __attrs_135757237309648 = _static_135757327983760

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label>\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b7871e7d310> name=None at 7b7871e7de10> -> __attrs_135757237313360
                    __attrs_135757237313360 = _static_135757237310224

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="radio" name="profile_id:string"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237313488
                    __default_135757237313488 = _DEFAULT_MARKER

                    # <Substitution u'info/id' (148:42)> -> __attr_value
                    __token = 7075
                    try:
                        __zt_tmp = __attrs_135757237313360
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', u'profile', _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237310416
                    __default_135757237310416 = _DEFAULT_MARKER

                    # <Substitution u'info/id' (147:50)> -> __attr_id
                    __token = 7024
                    try:
                        __zt_tmp = __attrs_135757237313360
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237310352
                    __default_135757237310352 = _DEFAULT_MARKER

                    # <Boolean u"python: default_profile==info['id'] and 'checked' or nothing" (149:43)> -> __attr_checked
                    __token = 7128
                    try:
                        __zt_tmp = __attrs_135757237313360
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_checked = _static_135757244280656('python', u" default_profile==info['id'] and 'checked' or nothing", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (__attr_checked is _DEFAULT_MARKER):
                        __attr_checked = None
                    else:
                        if __attr_checked:
                            __attr_checked = u'checked'
                        else:
                            __attr_checked = None
                    if (__attr_checked is not None):
                        __append((u' checked="%s"' % __attr_checked))
                    __append(u' />\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b786bab0790> name=None at 7b786bab0c10> -> __attrs_135757305572432
                    __attrs_135757305572432 = _static_135757132662672

                    # <tal ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<tal')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757132661328
                    __default_135757132661328 = _DEFAULT_MARKER

                    # <Substitution u'info/id' (151:49)> -> __attr_for
                    __token = 7268
                    try:
                        __zt_tmp = __attrs_135757305572432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757132662992
                    __default_135757132662992 = _DEFAULT_MARKER

                    # <Value u'info/title' (152:42)> -> __cache_135757132661072
                    __token = 7319
                    try:
                        __zt_tmp = __attrs_135757305572432
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757132661072 = _static_135757244280656('path', u'info/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'info/title' (152:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786bab0110> -> __condition
                    __expression = __cache_135757132661072

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u' Profile title ')
                    else:
                        __content = __cache_135757132661072
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</tal>\n                      </label>\n                      ')

                    # <Static value=<_ast.Dict object at 0x7b7875f96a50> name=None at 7b7875f96090> -> __attrs_135757305572880
                    __attrs_135757305572880 = _static_135757305571920

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-text small text-muted">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757305572176
                    __default_135757305572176 = _DEFAULT_MARKER

                    # <Value u'info/description' (154:75)> -> __cache_135757237310480
                    __token = 7459
                    try:
                        __zt_tmp = __attrs_135757305572880
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757237310480 = _static_135757244280656('path', u'info/description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'info/description' (154:75)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7875f96d90> -> __condition
                    __expression = __cache_135757237310480

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                        Profile description\n                      ')
                    else:
                        __content = __cache_135757237310480
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n                    ')
                    ____index_135757237127952 -= 1
                    if (____index_135757237127952 > 0):
                        __append('')
                if (__backup_info_135757365988496 is __marker):
                    del econtext['info']
                else:
                    econtext['info'] = __backup_info_135757365988496
                __append(u'\n\n                    ')

                # <Static value=<_ast.Dict object at 0x7b7871e7d5d0> name=None at 7b7871e7da50> -> __attrs_135757305571408
                __attrs_135757305571408 = _static_135757237310928

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="form-text small text-muted">')
                __stream_135757237128656 = []
                __append_135757237128656 = __stream_135757237128656.append
                __append_135757237128656(u"\n                      You normally don't need to change anything here unless you have\n                      specific reasons and know what you are doing.\n                    ")
                __msgid_135757237128656 = __re_whitespace(''.join(__stream_135757237128656)).strip()
                if __msgid_135757237128656:
                    __append(translate(__msgid_135757237128656, mapping=None, default=__msgid_135757237128656, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</div>\n\n                  </div>\n                ')
            __append(u'\n\n                ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237125200
            __attrs_135757237125200 = _static_135757327983760

            # <Value u'python: extension_profiles' (167:50)> -> __condition
            __token = 7957
            try:
                __zt_tmp = __attrs_135757237125200
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u' extension_profiles', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n                  ')

                # <Static value=<_ast.Dict object at 0x7b7875f96550> name=None at 7b7875f96250> -> __attrs_135757134819664
                __attrs_135757134819664 = _static_135757305570640

                # <Negate value=<Value u'python: not advanced' (168:59)> at 7b786bcbf890> -> __cache_135757134821520

                # <Value u'python: not advanced' (168:59)> -> __cache_135757134821520
                __token = 8045
                try:
                    __zt_tmp = __attrs_135757134819664
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757134821520 = _static_135757244280656('python', u' not advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __cache_135757134821520 = not __cache_135757134821520
                __condition = __cache_135757134821520
                if __condition:

                    # <fieldset ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<fieldset id="add-on-list">')
                __append(u'\n                    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134821136
                __attrs_135757134821136 = _static_135757327983760

                # <Value u'python: advanced' (169:61)> -> __condition
                __token = 8129
                try:
                    __zt_tmp = __attrs_135757134821136
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u' advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <legend ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<legend>')
                    __stream_135757134819472 = []
                    __append_135757134819472 = __stream_135757134819472.append
                    __append_135757134819472(u'\n                      Add-ons\n                    ')
                    __msgid_135757134819472 = __re_whitespace(''.join(__stream_135757134819472)).strip()
                    if __msgid_135757134819472:
                        __append(translate(__msgid_135757134819472, mapping=None, default=__msgid_135757134819472, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</legend>')
                __append(u'\n\n                    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134821072
                __attrs_135757134821072 = _static_135757327983760
                __backup_info_135757151923408 = get('info', __marker)

                # <Value u'extension_profiles' (173:49)> -> __iterator
                __token = 8258
                try:
                    __zt_tmp = __attrs_135757134821072
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'extension_profiles', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757134821456, ) = getitem('repeat')(u'info', __iterator)
                econtext['info'] = None
                for __item in __iterator:
                    econtext['info'] = __item
                    __append(u'\n                      ')

                    # <Static value=<_ast.Dict object at 0x7b786bcbf9d0> name=None at 7b786bcbf950> -> __attrs_135757134823120
                    __attrs_135757134823120 = _static_135757134821840

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="addons-group">\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237336144
                    __attrs_135757237336144 = _static_135757327983760
                    __backup_selected_135757237312464 = get('selected', __marker)

                    # <Value u'info/selected|nothing' (175:55)> -> __value
                    __token = 8383
                    try:
                        __zt_tmp = __attrs_135757237336144
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'info/selected|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['selected'] = __value
                    __append(u'\n                          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237336848
                    __attrs_135757237336848 = _static_135757327983760

                    # <Value u'python: not selected or advanced' (176:53)> -> __condition
                    __token = 8460
                    try:
                        __zt_tmp = __attrs_135757237336848
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u' not selected or advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237334224
                        __attrs_135757237334224 = _static_135757327983760

                        # <Value u'python: advanced' (177:48)> -> __condition
                        __token = 8543
                        try:
                            __zt_tmp = __attrs_135757237334224
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u' advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div>\n                              ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237334608
                            __attrs_135757237334608 = _static_135757327983760

                            # <label ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<label>\n                                ')

                            # <Static value=<_ast.Dict object at 0x7b786cfd6bd0> name=None at 7b786cfd6d90> -> __attrs_135757154838352
                            __attrs_135757154838352 = _static_135757154839504

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="checkbox" name="extension_ids:list"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154840272
                            __default_135757154840272 = _DEFAULT_MARKER

                            # <Substitution u'info/id' (180:61)> -> __attr_value
                            __token = 8751
                            try:
                                __zt_tmp = __attrs_135757154838352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154837584
                            __default_135757154837584 = _DEFAULT_MARKER

                            # <Substitution u'info/id' (181:47)> -> __attr_id
                            __token = 8807
                            try:
                                __zt_tmp = __attrs_135757154838352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154839888
                            __default_135757154839888 = _DEFAULT_MARKER

                            # <Boolean u'info/selected|nothing' (182:51)> -> __attr_checked
                            __token = 8868
                            try:
                                __zt_tmp = __attrs_135757154838352
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_checked = _static_135757244280656('path', u'info/selected|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if (__attr_checked is _DEFAULT_MARKER):
                                __attr_checked = None
                            else:
                                if __attr_checked:
                                    __attr_checked = u'checked'
                                else:
                                    __attr_checked = None
                            if (__attr_checked is not None):
                                __append((u' checked="%s"' % __attr_checked))
                            __append(u' />\n                                ')

                            # <Static value=<_ast.Dict object at 0x7b786cfd6650> name=None at 7b786cfd6b90> -> __attrs_135757366002384
                            __attrs_135757366002384 = _static_135757154838096

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757366003920
                            __default_135757366003920 = _DEFAULT_MARKER

                            # <Substitution u'info/id' (184:54)> -> __attr_for
                            __token = 8989
                            try:
                                __zt_tmp = __attrs_135757366002384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_for = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_for is not None):
                                __append((u' for="%s"' % __attr_for))
                            __append(u'>')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757154838224
                            __default_135757154838224 = _DEFAULT_MARKER

                            # <Value u'info/title' (185:47)> -> __cache_135757154837648
                            __token = 9045
                            try:
                                __zt_tmp = __attrs_135757366002384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757154837648 = _static_135757244280656('path', u'info/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'info/title' (185:47)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cfd6310> -> __condition
                            __expression = __cache_135757154837648

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'profile title')
                            else:
                                __content = __cache_135757154837648
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</span>\n                              </label>\n                            </div>')
                        __append(u'\n                            ')

                        # <Static value=<_ast.Dict object at 0x7b7879938c10> name=None at 7b7879938b10> -> __attrs_135757366002064
                        __attrs_135757366002064 = _static_135757366004752

                        # <Value u'python: advanced' (188:112)> -> __condition
                        __token = 9264
                        try:
                            __zt_tmp = __attrs_135757366002064
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('python', u' advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <p ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<p class="form-text text-muted small">')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757366004240
                            __default_135757366004240 = _DEFAULT_MARKER

                            # <Value u'info/description' (188:79)> -> __cache_135757237337872
                            __token = 9231
                            try:
                                __zt_tmp = __attrs_135757366002064
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757237337872 = _static_135757244280656('path', u'info/description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'info/description' (188:79)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cfd6350> -> __condition
                            __expression = __cache_135757237337872

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'\n                              profile description\n                            ')
                            else:
                                __content = __cache_135757237337872
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</p>')
                        __append(u'\n                          ')
                    __append(u'\n                          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237338064
                    __attrs_135757237338064 = _static_135757327983760

                    # <Value u'python: selected and not advanced' (192:53)> -> __condition
                    __token = 9459
                    try:
                        __zt_tmp = __attrs_135757237338064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u' selected and not advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                            ')

                        # <Static value=<_ast.Dict object at 0x7b7879938d10> name=None at 7b7879938850> -> __attrs_135757134663952
                        __attrs_135757134663952 = _static_135757366005008

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden" class="form-check-input" name="extension_ids:list"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134664720
                        __default_135757134664720 = _DEFAULT_MARKER

                        # <Substitution u'info/id' (196:57)> -> __attr_value
                        __token = 9731
                        try:
                            __zt_tmp = __attrs_135757134663952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('path', u'info/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134664272
                        __default_135757134664272 = _DEFAULT_MARKER

                        # <Boolean u'info/selected|nothing' (197:48)> -> __attr_checked
                        __token = 9788
                        try:
                            __zt_tmp = __attrs_135757134663952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_checked = _static_135757244280656('path', u'info/selected|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_checked is _DEFAULT_MARKER):
                            __attr_checked = None
                        else:
                            if __attr_checked:
                                __attr_checked = u'checked'
                            else:
                                __attr_checked = None
                        if (__attr_checked is not None):
                            __append((u' checked="%s"' % __attr_checked))
                        __append(u' />\n                          ')
                    __append(u'\n                        ')
                    if (__backup_selected_135757237312464 is __marker):
                        del econtext['selected']
                    else:
                        econtext['selected'] = __backup_selected_135757237312464
                    __append(u'\n                      </div>\n                    ')
                    ____index_135757134821456 -= 1
                    if (____index_135757134821456 > 0):
                        __append('')
                if (__backup_info_135757151923408 is __marker):
                    del econtext['info']
                else:
                    econtext['info'] = __backup_info_135757151923408
                __append(u'\n\n                    ')

                # <Static value=<_ast.Dict object at 0x7b786bcbffd0> name=None at 7b786bcbf450> -> __attrs_135757237337616
                __attrs_135757237337616 = _static_135757134823376

                # <Value u'python: advanced' (203:87)> -> __condition
                __token = 10043
                try:
                    __zt_tmp = __attrs_135757237337616
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u' advanced', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="form-text text-muted">')
                    __stream_135757134822352 = []
                    __append_135757134822352 = __stream_135757134822352.append
                    __append_135757134822352(u'\n                      Select any add-ons you want to activate immediately. You can\n                      also activate add-ons after the site has been created using the\n                      Add-ons control panel.\n                    ')
                    __msgid_135757134822352 = __re_whitespace(''.join(__stream_135757134822352)).strip()
                    if __msgid_135757134822352:
                        __append(translate(__msgid_135757134822352, mapping=None, default=__msgid_135757134822352, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</div>')
                __append(u'\n\n                  ')
                __condition = __cache_135757134821520
                if __condition:
                    __append(u'</fieldset>')
                __append(u'\n                ')
            __append(u'\n\n                ')

            # <Static value=<_ast.Dict object at 0x7b7875f96690> name=None at 7b7871e50a10> -> __attrs_135757237336528
            __attrs_135757237336528 = _static_135757305570960

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="formControls mt-2">\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786bc99ed0> name=None at 7b786bc99b50> -> __attrs_135757134667536
            __attrs_135757134667536 = _static_135757134667472

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="form.submitted:boolean" value="True" />\n                  ')

            # <Static value=<_ast.Dict object at 0x7b786bc99650> name=None at 7b786bc99910> -> __attrs_135757237096912
            __attrs_135757237096912 = _static_135757134665296

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="submit" name="submit"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757237099024
            __default_135757237099024 = _DEFAULT_MARKER

            # <Translate msgid=None node=<_ast.Str object at 0x7b7871e49a90> at 7b7871e49990> -> __attr_value
            __attr_value = u'Create SENAITE Site'
            __attr_value = translate(__attr_value, default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' class="btn btn-primary" />\n                </div>\n\n              </form>')
            if (__backup_advanced_135757154875856 is __marker):
                del econtext['advanced']
            else:
                econtext['advanced'] = __backup_advanced_135757154875856
            if (__backup_extension_profiles_135757154877136 is __marker):
                del econtext['extension_profiles']
            else:
                econtext['extension_profiles'] = __backup_extension_profiles_135757154877136
            if (__backup_default_profile_135757154876752 is __marker):
                del econtext['default_profile']
            else:
                econtext['default_profile'] = __backup_default_profile_135757154876752
            if (__backup_base_profiles_135757154858384 is __marker):
                del econtext['base_profiles']
            else:
                econtext['base_profiles'] = __backup_base_profiles_135757154858384
            if (__backup_profiles_135757232035280 is __marker):
                del econtext['profiles']
            else:
                econtext['profiles'] = __backup_profiles_135757232035280
            __append(u'\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135757166675216
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }