# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/controlpanel/templates/setupview.pt'

__tokens = {449: (u"python:request.set('disable_plone.leftcolumn', 1)", 12, 51), 551: (u" python:request.set('disable_plone.rightcolumn', 1", 13, 50), 694: (u'context/@@plone_portal_state/portal', 16, 36), 853: (u'string:${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.setupview.js', 19, 34), 1464: (u'python:view.setup', 36, 37), 1668: (u'setup/absolute_url', 39, 36), 1725: (u' setup/Titl', 40, 36), 1903: (u"python:view.get_icon_for(setup, css_class='icon')", 44, 44), 2105: (u'setup/Title', 47, 34), 2339: (u'view/setupitems', 56, 36), 2535: (u'item/absolute_url', 59, 36), 2591: (u' item/Titl', 60, 36), 2803: (u"python:view.get_icon_for(item, css_class='icon')", 65, 44), 2969: (u'item/Title', 68, 35), 3148: (u'python:view.get_count(item)', 73, 37), 3212: (u'python:count>0', 74, 34), 3314: (u'count', 76, 37), 3453: (u'python:count == 1', 79, 37), 3630: (u'python:count > 1', 82, 37), 266: (u'here/prefs_main_template/macros/master', 6, 23), 266: (u'here/prefs_main_template/macros/master', 6, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_133838705476688 = {u'class': u'text-secondary', }
_static_133838705470736 = {u'class': u'item text-truncate', }
_static_133838705480208 = {u'src': u'#', u'class': u'icon', }
_static_133838705423248 = {u'placeholder': u'Type to filter ...', u'autofocus': '', u'type': u'text', u'id': u'searchbox', u'class': u'form-control form-control-lg', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838705488336 = {u'class': u'text-secondary', }
_static_133838705446736 = {u'class': u'tilewrapper col-xs-12 col-sm-6 col-md-4 col-lg-3', }
_static_133838705445584 = {u'class': u'title vcenter text-truncate d-inline-block', }
_static_133838705409616 = {u'class': u'col-sm-12 mb-4', }
_static_133838705478800 = {u'class': u'text-secondary', }
_static_133838705432144 = {u'href': u'setup/absolute_url', u'class': u'tile setup text-capitalized text-decoration-none', u'title': u'setup/Title', }
_static_133838705434256 = {u'class': u'item text-truncate', }
_static_133838705483088 = {u'class': u'small text-right', }
_static_133838878659728 = {}
_static_133838705482448 = {u'class': u'title', }
_static_133838705407952 = {u'id': u'setupview', u'class': u'row', }
_static_133838705468624 = {u'href': u'item/absolute_url', u'class': u'tile text-capitalized text-decoration-none', u'title': u'item/Title', }
_static_133838705443856 = {u'src': u'#', }
_static_133838794967184 = __compile_zt_expr
_static_133838701257296 = {u'id': u'lims-controlpanel', }
_static_133838701268688 = {u'src': u'senaite.core.setupview.js', u'type': u'text/javascript', }
_static_133838701255376 = u'master'
_static_133838705430800 = {u'class': u'tilewrapper col-xs-12 col-sm-6 col-md-4 col-lg-3', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838701256656
            __attrs_133838701256656 = _static_133838878659728
            __previous_i18n_domain_133838701255952 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_133838705036016 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79b9c03edad0> name=None at 79b9c03ed7d0> -> __value
            __value = _static_133838701255376
            econtext['macroname'] = __value

            def __fill_top_slot(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838701259536
                __attrs_133838701259536 = _static_133838878659728
                __backup_disable_column_one_133838733004688 = get('disable_column_one', __marker)

                # <Value u"python:request.set('disable_plone.leftcolumn', 1)" (12:51)> -> __value
                __token = 449
                try:
                    __zt_tmp = __attrs_133838701259536
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u"request.set('disable_plone.leftcolumn', 1)", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['disable_column_one'] = __value
                __backup_disable_column_two_133838687944080 = get('disable_column_two', __marker)

                # <Value u"python:request.set('disable_plone.rightcolumn', 1)" (13:50)> -> __value
                __token = 551
                try:
                    __zt_tmp = __attrs_133838701259536
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u"request.set('disable_plone.rightcolumn', 1)", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['disable_column_two'] = __value
                if (__backup_disable_column_two_133838687944080 is __marker):
                    del econtext['disable_column_two']
                else:
                    econtext['disable_column_two'] = __backup_disable_column_two_133838687944080
                if (__backup_disable_column_one_133838733004688 is __marker):
                    del econtext['disable_column_one']
                else:
                    econtext['disable_column_one'] = __backup_disable_column_one_133838733004688
            _slots = econtext[u'__slot_top_slot'] = _deque((__fill_top_slot, ))

            def __fill_senaite_legacy_js(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838701267984
                __attrs_133838701267984 = _static_133838878659728
                __backup_portal_133838701255568 = get('portal', __marker)

                # <Value u'context/@@plone_portal_state/portal' (16:36)> -> __value
                __token = 694
                try:
                    __zt_tmp = __attrs_133838701267984
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'context/@@plone_portal_state/portal', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['portal'] = __value
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9c03f0ed0> name=None at 79b9c03f0e90> -> __attrs_133838705406736
                __attrs_133838705406736 = _static_133838701268688

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript"')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705406416
                __default_133838705406416 = _DEFAULT_MARKER

                # <Substitution u'string:${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.setupview.js' (19:34)> -> __attr_src
                __token = 853
                try:
                    __zt_tmp = __attrs_133838705406736
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_133838794967184('string', u'${portal/absolute_url}/++plone++senaite.core.static/js/senaite.core.setupview.js', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', u'senaite.core.setupview.js', _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u'               src="%s"' % __attr_src))
                __append(u'></script>\r\n    ')
                if (__backup_portal_133838701255568 is __marker):
                    del econtext['portal']
                else:
                    econtext['portal'] = __backup_portal_133838701255568
            _slots = econtext[u'__slot_senaite_legacy_js'] = _deque((__fill_senaite_legacy_js, ))

            def __fill_prefs_configlet_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79b9c03ee250> name=None at 79b9c03ee790> -> __attrs_133838705407312
                __attrs_133838705407312 = _static_133838701257296

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="lims-controlpanel">\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9c07e37d0> name=None at 79b9c07e3810> -> __attrs_133838705408912
                __attrs_133838705408912 = _static_133838705407952

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="setupview" class="row">\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9c07e3e50> name=None at 79b9c07e3dd0> -> __attrs_133838705422608
                __attrs_133838705422608 = _static_133838705409616

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="col-sm-12 mb-4">\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9c07e7390> name=None at 79b9c07e7350> -> __attrs_133838705425296
                __attrs_133838705425296 = _static_133838705423248

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input id="searchbox"                  autofocus                  type="text"                  class="form-control form-control-lg"')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705425040
                __default_133838705425040 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x79b9c07e79d0> at 79b9c07e7a10> -> __attr_placeholder
                __attr_placeholder = u'Type to filter ...'
                __attr_placeholder = translate(__attr_placeholder, default=__attr_placeholder, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_placeholder is not None):
                    __append((u'                  placeholder="%s"' % __attr_placeholder))
                __append(u'>\r\n        </div>\r\n\r\n        <!-- The setup item -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838705425872
                __attrs_133838705425872 = _static_133838878659728
                __backup_setup_133838701256208 = get('setup', __marker)

                # <Value u'python:view.setup' (36:37)> -> __value
                __token = 1464
                try:
                    __zt_tmp = __attrs_133838705425872
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u'view.setup', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['setup'] = __value
                __append(u'\r\n          ')

                # <Static value=<_ast.Dict object at 0x79b9c07e9110> name=None at 79b9c07e90d0> -> __attrs_133838705431440
                __attrs_133838705431440 = _static_133838705430800

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="tilewrapper col-xs-12 col-sm-6 col-md-4 col-lg-3">\r\n            ')

                # <Static value=<_ast.Dict object at 0x79b9c07e9650> name=None at 79b9c07e9610> -> __attrs_133838705433616
                __attrs_133838705433616 = _static_133838705432144

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="tile setup text-capitalized text-decoration-none"')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705432976
                __default_133838705432976 = _DEFAULT_MARKER

                # <Substitution u'setup/absolute_url' (39:36)> -> __attr_href
                __token = 1668
                try:
                    __zt_tmp = __attrs_133838705433616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133838794967184('path', u'setup/absolute_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705433296
                __default_133838705433296 = _DEFAULT_MARKER

                # <Translate msgid=None node=<Substitution u'setup/Title' (40:36)> at 79b9c07e9a50> -> __attr_title

                # <Substitution u'setup/Title' (40:36)> -> __attr_title
                __token = 1725
                try:
                    __zt_tmp = __attrs_133838705433616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_title = _static_133838794967184('path', u'setup/Title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u' title="%s"' % __attr_title))
                __append(u'>\r\n              ')

                # <Static value=<_ast.Dict object at 0x79b9c07e9e90> name=None at 79b9c07e9e50> -> __attrs_133838705443152
                __attrs_133838705443152 = _static_133838705434256

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="item text-truncate">\r\n                ')

                # <Static value=<_ast.Dict object at 0x79b9c07ec410> name=None at 79b9c07ec3d0> -> __attrs_133838705444816
                __attrs_133838705444816 = _static_133838705443856

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705444688
                __default_133838705444688 = _DEFAULT_MARKER

                # <Value u"python:view.get_icon_for(setup, css_class='icon')" (44:44)> -> __cache_133838705444368
                __token = 1903
                try:
                    __zt_tmp = __attrs_133838705444816
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838705444368 = _static_133838794967184('python', u"view.get_icon_for(setup, css_class='icon')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u"python:view.get_icon_for(setup, css_class='icon')" (44:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c07ec690> -> __condition
                __expression = __cache_133838705444368

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img src="#"/>')
                else:
                    __content = __cache_133838705444368
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n                ')

                # <Static value=<_ast.Dict object at 0x79b9c07ecad0> name=None at 79b9c07eca90> -> __attrs_133838705446224
                __attrs_133838705446224 = _static_133838705445584

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="title vcenter text-truncate d-inline-block">')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705445392
                __default_133838705445392 = _DEFAULT_MARKER

                # <Value u'setup/Title' (47:34)> -> __cache_133838705445008
                __token = 2105
                try:
                    __zt_tmp = __attrs_133838705446224
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838705445008 = _static_133838794967184('path', u'setup/Title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'setup/Title' (47:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c07ec950> -> __condition
                __expression = __cache_133838705445008

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\r\n                  Setup Item Title\r\n                ')
                else:
                    __content = __cache_133838705445008
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n              </div>\r\n            </a>\r\n          </div>\r\n        ')
                if (__backup_setup_133838701256208 is __marker):
                    del econtext['setup']
                else:
                    econtext['setup'] = __backup_setup_133838701256208
                __append(u'\r\n\r\n        <!-- The other setup items -->\r\n        ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838705433680
                __attrs_133838705433680 = _static_133838878659728
                __backup_item_133838684097232 = get('item', __marker)

                # <Value u'view/setupitems' (56:36)> -> __iterator
                __token = 2339
                try:
                    __zt_tmp = __attrs_133838705433680
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_133838794967184('path', u'view/setupitems', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                (__iterator, ____index_133838705445072, ) = getitem('repeat')(u'item', __iterator)
                econtext['item'] = None
                for __item in __iterator:
                    econtext['item'] = __item
                    __append(u'\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79b9c07ecf50> name=None at 79b9c07ecf10> -> __attrs_133838705467920
                    __attrs_133838705467920 = _static_133838705446736

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="tilewrapper col-xs-12 col-sm-6 col-md-4 col-lg-3">\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79b9c07f24d0> name=None at 79b9c07f2490> -> __attrs_133838705470096
                    __attrs_133838705470096 = _static_133838705468624

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a class="tile text-capitalized text-decoration-none"')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705469456
                    __default_133838705469456 = _DEFAULT_MARKER

                    # <Substitution u'item/absolute_url' (59:36)> -> __attr_href
                    __token = 2535
                    try:
                        __zt_tmp = __attrs_133838705470096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133838794967184('path', u'item/absolute_url', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705469776
                    __default_133838705469776 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<Substitution u'item/Title' (60:36)> at 79b9c07f28d0> -> __attr_title

                    # <Substitution u'item/Title' (60:36)> -> __attr_title
                    __token = 2591
                    try:
                        __zt_tmp = __attrs_133838705470096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_133838794967184('path', u'item/Title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9c07f2d10> name=None at 79b9c07f2cd0> -> __attrs_133838705471376
                    __attrs_133838705471376 = _static_133838705470736

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="item text-truncate">\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79b9c07f5210> name=None at 79b9c07f5290> -> __attrs_133838705481616
                    __attrs_133838705481616 = _static_133838705480208

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705481488
                    __default_133838705481488 = _DEFAULT_MARKER

                    # <Value u"python:view.get_icon_for(item, css_class='icon')" (65:44)> -> __cache_133838705481168
                    __token = 2803
                    try:
                        __zt_tmp = __attrs_133838705481616
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838705481168 = _static_133838794967184('python', u"view.get_icon_for(item, css_class='icon')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u"python:view.get_icon_for(item, css_class='icon')" (65:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c07f5650> -> __condition
                    __expression = __cache_133838705481168

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <img ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<img src="#"                      class="icon"/>')
                    else:
                        __content = __cache_133838705481168
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n                ')

                    # <Static value=<_ast.Dict object at 0x79b9c07f5ad0> name=None at 79b9c07f5a90> -> __attrs_133838705483024
                    __attrs_133838705483024 = _static_133838705482448

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="title">')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705482192
                    __default_133838705482192 = _DEFAULT_MARKER

                    # <Value u'item/Title' (68:35)> -> __cache_133838705481808
                    __token = 2969
                    try:
                        __zt_tmp = __attrs_133838705483024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838705481808 = _static_133838794967184('path', u'item/Title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'item/Title' (68:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c07f5910> -> __condition
                    __expression = __cache_133838705481808

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n                  Setup Item Title\r\n                ')
                    else:
                        __content = __cache_133838705481808
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n              </div>\r\n              ')

                    # <Static value=<_ast.Dict object at 0x79b9c07f5d50> name=None at 79b9c07f5150> -> __attrs_133838705475728
                    __attrs_133838705475728 = _static_133838705483088
                    __backup_count_133838701257680 = get('count', __marker)

                    # <Value u'python:view.get_count(item)' (73:37)> -> __value
                    __token = 3148
                    try:
                        __zt_tmp = __attrs_133838705475728
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_133838794967184('python', u'view.get_count(item)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    econtext['count'] = __value

                    # <Value u'python:count>0' (74:34)> -> __condition
                    __token = 3212
                    try:
                        __zt_tmp = __attrs_133838705475728
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133838794967184('python', u'count>0', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="small text-right">\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c07f4450> name=None at 79b9c07f43d0> -> __attrs_133838705477328
                        __attrs_133838705477328 = _static_133838705476688

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="text-secondary">\r\n                  ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838705478608
                        __attrs_133838705478608 = _static_133838878659728

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705478224
                        __default_133838705478224 = _DEFAULT_MARKER

                        # <Value u'count' (76:37)> -> __cache_133838705477904
                        __token = 3314
                        try:
                            __zt_tmp = __attrs_133838705478608
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838705477904 = _static_133838794967184('path', u'count', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'count' (76:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c07f4990> -> __condition
                        __expression = __cache_133838705477904

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133838705477904
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n                </span>\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c07f4c90> name=None at 79b9c07f4290> -> __attrs_133838705479440
                        __attrs_133838705479440 = _static_133838705478800

                        # <Value u'python:count == 1' (79:37)> -> __condition
                        __token = 3453
                        try:
                            __zt_tmp = __attrs_133838705479440
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_133838794967184('python', u'count == 1', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span                       class="text-secondary">')
                            __stream_133838705477392 = []
                            __append_133838705477392 = __stream_133838705477392.append
                            __append_133838705477392(u'Item')
                            __msgid_133838705477392 = __re_whitespace(''.join(__stream_133838705477392)).strip()
                            if u'label_setupview_item':
                                __append(translate(u'label_setupview_item', mapping=None, default=__msgid_133838705477392, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>')
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9c07f71d0> name=None at 79b9c07f7150> -> __attrs_133838705488976
                        __attrs_133838705488976 = _static_133838705488336

                        # <Value u'python:count > 1' (82:37)> -> __condition
                        __token = 3630
                        try:
                            __zt_tmp = __attrs_133838705488976
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_133838794967184('python', u'count > 1', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span                       class="text-secondary">')
                            __stream_133838705488080 = []
                            __append_133838705488080 = __stream_133838705488080.append
                            __append_133838705488080(u'Items')
                            __msgid_133838705488080 = __re_whitespace(''.join(__stream_133838705488080)).strip()
                            if u'label_setupview_items':
                                __append(translate(u'label_setupview_items', mapping=None, default=__msgid_133838705488080, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</span>')
                        __append(u'\r\n              </div>')
                    if (__backup_count_133838701257680 is __marker):
                        del econtext['count']
                    else:
                        econtext['count'] = __backup_count_133838701257680
                    __append(u'\r\n            </a>\r\n          </div>\r\n        ')
                    ____index_133838705445072 -= 1
                    if (____index_133838705445072 > 0):
                        __append('')
                if (__backup_item_133838684097232 is __marker):
                    del econtext['item']
                else:
                    econtext['item'] = __backup_item_133838684097232
                __append(u'\r\n      </div>\r\n\r\n    </div>')
            _slots = econtext[u'__slot_prefs_configlet_main'] = _deque((__fill_prefs_configlet_main, ))

            # <Value u'here/prefs_main_template/macros/master' (6:23)> -> __macro
            __token = 266
            try:
                __zt_tmp = __attrs_133838701256656
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133838794967184('path', u'here/prefs_main_template/macros/master', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __token = 266
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133838705036016 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133838705036016
            __i18n_domain = __previous_i18n_domain_133838701255952
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }