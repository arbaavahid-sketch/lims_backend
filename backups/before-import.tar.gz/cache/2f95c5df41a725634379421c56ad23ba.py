# -*- coding: utf-8 -*-
__filename = 'login_form'

__tokens = {166: (u'string:${here/absolute_url}/login', 11, 33), 291: (u'request/came_from | string:', 14, 35)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757159487440 = {u'type': u'password', u'name': u'__ac_password', u'size': u'30', }
_static_135757159509648 = {u'type': u'text', u'name': u'__ac_name', u'size': u'30', }
_static_135757137860496 = {u'type': u'hidden', u'name': u'came_from', u'value': u'', }
_static_135757244280656 = __compile_zt_expr
_static_135757137724816 = {u'type': u'submit', u'value': u' Log In ', }
_static_135757137861328 = {u'action': u'', u'method': u'post', }
_static_135757327983760 = {}
_static_135757137860112 = {u'cellpadding': u'2', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757137726352 = {u'colspan': u'2', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150434640
            __attrs_135757150434640 = _static_135757327983760

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150435728
            __attrs_135757150435728 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150435216
            __attrs_135757150435216 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title> Login Form </title>\n  </head>\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150435152
            __attrs_135757150435152 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150436496
            __attrs_135757150436496 = _static_135757327983760

            # <h3 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h3> Please log in </h3>\n\n    ')

            # <Static value=<_ast.Dict object at 0x7b786bfa5ad0> name=None at 7b786bfa59d0> -> __attrs_135757137859152
            __attrs_135757137859152 = _static_135757137861328

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form method="post"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137859280
            __default_135757137859280 = _DEFAULT_MARKER

            # <Substitution u'string:${here/absolute_url}/login' (11:33)> -> __attr_action
            __token = 166
            try:
                __zt_tmp = __attrs_135757137859152
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_135757244280656('string', u'${here/absolute_url}/login', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u'>\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b786bfa5790> name=None at 7b786bfa5890> -> __attrs_135757137862352
            __attrs_135757137862352 = _static_135757137860496

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden" name="came_from"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137858896
            __default_135757137858896 = _DEFAULT_MARKER

            # <Substitution u'request/came_from | string:' (14:35)> -> __attr_value
            __token = 291
            try:
                __zt_tmp = __attrs_135757137862352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('path', u'request/came_from | string:', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\n      ')

            # <Static value=<_ast.Dict object at 0x7b786bfa5610> name=None at 7b786bfa5750> -> __attrs_135757159507920
            __attrs_135757159507920 = _static_135757137860112

            # <table ... (0:0)
            # --------------------------------------------------------
            __append(u'<table cellpadding="2">\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159507536
            __attrs_135757159507536 = _static_135757327983760

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159509968
            __attrs_135757159509968 = _static_135757327983760

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159506384
            __attrs_135757159506384 = _static_135757327983760

            # <b ... (0:0)
            # --------------------------------------------------------
            __append(u'<b>Login:</b> </td>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159506832
            __attrs_135757159506832 = _static_135757327983760

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>')

            # <Static value=<_ast.Dict object at 0x7b786d44ae90> name=None at 7b786d44aed0> -> __attrs_135757159487312
            __attrs_135757159487312 = _static_135757159509648

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="text" name="__ac_name" size="30" /></td>\n        </tr>\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159506256
            __attrs_135757159506256 = _static_135757327983760

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159486352
            __attrs_135757159486352 = _static_135757327983760

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159486416
            __attrs_135757159486416 = _static_135757327983760

            # <b ... (0:0)
            # --------------------------------------------------------
            __append(u'<b>Password:</b></td>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159489424
            __attrs_135757159489424 = _static_135757327983760

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td>')

            # <Static value=<_ast.Dict object at 0x7b786d4457d0> name=None at 7b786d4452d0> -> __attrs_135757137725008
            __attrs_135757137725008 = _static_135757159487440

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="password" name="__ac_password" size="30" /></td>\n        </tr>\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159487504
            __attrs_135757159487504 = _static_135757327983760

            # <tr ... (0:0)
            # --------------------------------------------------------
            __append(u'<tr>\n          ')

            # <Static value=<_ast.Dict object at 0x7b786bf84b90> name=None at 7b786bf84290> -> __attrs_135757137723984
            __attrs_135757137723984 = _static_135757137726352

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td colspan="2">\n            ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757137724560
            __attrs_135757137724560 = _static_135757327983760

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n            ')

            # <Static value=<_ast.Dict object at 0x7b786bf84590> name=None at 7b786bf84d90> -> __attrs_135757237313168
            __attrs_135757237313168 = _static_135757137724816

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="submit" value=" Log In " />\n          </td>\n        </tr>\n      </table>\n\n    </form>\n\n  </body>\n\n</html>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }