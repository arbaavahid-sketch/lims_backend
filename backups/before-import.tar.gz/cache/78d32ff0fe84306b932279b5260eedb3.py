# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/widget.pt'

__tokens = {90: (u'nocall:context', 3, 24), 135: (u' python:widget.__class__.__name_', 4, 29), 202: (u"s python:'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ", 5, 32), 312: (u"en python:widget.mode == 'hidd", 6, 21), 366: (u'ror widget/e', 7, 19), 408: (u"lass python:error and ' error' ", 8, 24), 470: (u"alues python: (None, '', [], ('', '', '', '00', '00', ''), ('', ''", 9, 24), 566: (u"_class python: (widget.value in empty_values) and ' empty", 10, 22), 660: (u'_class  widget/wrapper_css_class', 11, 28), 726: (u'me_class string:kssattr-fieldname-${wid', 12, 24), 804: (u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', 13, 27), 942: (u' widget/nam', 14, 35), 978: (u'd string:formfield-${widget/i', 15, 22), 1063: (u'python:view.is_input_mode()', 18, 28), 1218: (u'python: not hidden and widget.label', 22, 24), 1183: (u'widget/id', 21, 29), 1299: (u'widget/label', 23, 43), 1411: (u"python:widget.required and widget.mode == 'input'", 26, 27), 1603: (u'error/render|nothing', 31, 32), 1737: (u"python: getattr(widget, 'description', widget.field.description)", 36, 34), 1902: (u'python:description and not hidden', 39, 25), 1864: (u'description', 38, 33), 2138: (u'python:view.get_prepend_text()', 46, 28), 2194: (u' python:view.get_append_text(', 47, 24), 2085: (u'python:widget_css_class', 45, 31), 2253: (u'python:prefix', 48, 26), 2359: (u'python:prefix', 49, 62), 2450: (u'widget/render', 52, 36), 2534: (u'python:appendix', 54, 26), 2641: (u'python:appendix', 55, 62), 2754: (u'python:view.is_view_mode()', 62, 28), 3144: (u'python: not hidden and widget.label', 74, 30), 3103: (u'widget/id', 73, 35), 3225: (u"python: getattr(widget, 'description', widget.field.description)", 76, 42), 3331: (u'python:description', 77, 40), 3480: (u'widget/label', 80, 53), 3625: (u"python:widget.required and widget.mode == 'input'", 85, 33), 3827: (u'python:view.get_prepend_text()', 91, 34), 3894: (u' python:view.get_append_text(', 92, 35), 4002: (u'python:prefix', 94, 41), 4119: (u'widget/render', 96, 42), 4260: (u'python:appendix', 99, 41)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948308667856 = {u'class': u'required horizontal', u'title': u'Required', }
_static_136948308677136 = {u'data-toggle': u'tooltip', u'title': u'python:description', u'data-html': u'true', }
_static_136948308632208 = {u'class': u'input-group-prepend', }
_static_136948309644048 = {u'data-fieldname': u'widget/name', u'class': u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', u'id': u'string:formfield-${widget/id}', }
_static_136948308596624 = {u'class': u'required horizontal', u'title': u'Required', }
_static_136948325573648 = {u'class': u'input-group-append', }
_static_136948325575888 = {u'class': u'input-group-text', }
_static_136948308635024 = {u'class': u'input-group-text', }
_static_136948308539664 = {u'class': u'fieldErrorBox', }
_static_136948308583568 = {u'class': u'field-prefix', }
_static_136948323884368 = {u'style': u'min-width:150px;max-width:200px;', }
_static_136948418207568 = __compile_zt_expr
_static_136948308627280 = {u'class': u'horizontal font-weight-bold', u'for': u'', }
_static_136948309628304 = {u'type': u'text', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948323881424 = {u'style': u'width:100%', }
_static_136948308518416 = {u'class': u'horizontal font-weight-bold', u'for': u'', }
_static_136948323881616 = {u'class': u'table table-borderless table-hover table-sm', }
_static_136948309627216 = {u'class': u'field-prefix', }
_static_136948308540240 = {u'style': u'width:auto', u'class': u'input-group input-group-sm d-flex', }
_static_136948501914768 = {}
_static_136948308541008 = {u'class': u'formHelp text-secondary text-muted', }
_static_136948325574928 = {u'type': u'text', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_wrapper(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_widget = econtext[u'__slot_widget'].pop()
        except:
            __slot_widget = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc3595310> name=None at 7c8dc3595910> -> __attrs_136948309643984
            __attrs_136948309643984 = _static_136948309644048
            __backup_widget_136948309649936 = get('widget', __marker)

            # <Value u'nocall:context' (3:24)> -> __value
            __token = 90
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('nocall', u'context', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['widget'] = __value
            __backup_widget_clazz_136948309577360 = get('widget_clazz', __marker)

            # <Value u'python:widget.__class__.__name__' (4:29)> -> __value
            __token = 135
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u'widget.__class__.__name__', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['widget_clazz'] = __value
            __backup_widget_css_class_136948323768784 = get('widget_css_class', __marker)

            # <Value u"python:'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ''" (5:32)> -> __value
            __token = 202
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ''", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['widget_css_class'] = __value
            __backup_hidden_136948308595088 = get('hidden', __marker)

            # <Value u"python:widget.mode == 'hidden'" (6:21)> -> __value
            __token = 312
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"widget.mode == 'hidden'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['hidden'] = __value
            __backup_error_136948323769872 = get('error', __marker)

            # <Value u'widget/error' (7:19)> -> __value
            __token = 366
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'widget/error', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['error'] = __value
            __backup_error_class_136948328025808 = get('error_class', __marker)

            # <Value u"python:error and ' error' or ''" (8:24)> -> __value
            __token = 408
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"error and ' error' or ''", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['error_class'] = __value
            __backup_empty_values_136948309575696 = get('empty_values', __marker)

            # <Value u"python: (None, '', [], ('', '', '', '00', '00', ''), ('', '', ''))" (9:24)> -> __value
            __token = 470
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u" (None, '', [], ('', '', '', '00', '00', ''), ('', '', ''))", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['empty_values'] = __value
            __backup_empty_class_136948328712016 = get('empty_class', __marker)

            # <Value u"python: (widget.value in empty_values) and ' empty' or ''" (10:22)> -> __value
            __token = 566
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u" (widget.value in empty_values) and ' empty' or ''", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['empty_class'] = __value
            __backup_wrapper_css_class_136948309627152 = get('wrapper_css_class', __marker)

            # <Value u'widget/wrapper_css_class|nothing' (11:28)> -> __value
            __token = 660
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'widget/wrapper_css_class|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['wrapper_css_class'] = __value
            __backup_fieldname_class_136948327205584 = get('fieldname_class', __marker)

            # <Value u'string:kssattr-fieldname-${widget/name}' (12:24)> -> __value
            __token = 726
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('string', u'kssattr-fieldname-${widget/name}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['fieldname_class'] = __value
            __previous_i18n_domain_136948308624720 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309644560
            __default_136948309644560 = _DEFAULT_MARKER

            # <Substitution u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}' (13:27)> -> __attr_class
            __token = 804
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_136948418207568('string', u'field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309645648
            __default_136948309645648 = _DEFAULT_MARKER

            # <Substitution u'widget/name' (14:35)> -> __attr_data_fieldname
            __token = 942
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_fieldname = _static_136948418207568('path', u'widget/name', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_data_fieldname = __quote(__attr_data_fieldname, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_fieldname is not None):
                __append((u' data-fieldname="%s"' % __attr_data_fieldname))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309643536
            __default_136948309643536 = _DEFAULT_MARKER

            # <Substitution u'string:formfield-${widget/id}' (15:22)> -> __attr_id
            __token = 978
            try:
                __zt_tmp = __attrs_136948309643984
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('string', u'formfield-${widget/id}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n\n  <!-- EDIT MODE -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308625040
            __attrs_136948308625040 = _static_136948501914768

            # <Value u'python:view.is_input_mode()' (18:28)> -> __condition
            __token = 1063
            try:
                __zt_tmp = __attrs_136948308625040
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('python', u'view.is_input_mode()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc349cf50> name=None at 7c8dc349c4d0> -> __attrs_136948308667920
                __attrs_136948308667920 = _static_136948308627280

                # <Value u'python: not hidden and widget.label' (22:24)> -> __condition
                __token = 1218
                try:
                    __zt_tmp = __attrs_136948308667920
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u' not hidden and widget.label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308624656
                    __default_136948308624656 = _DEFAULT_MARKER

                    # <Substitution u'widget/id' (21:29)> -> __attr_for
                    __token = 1183
                    try:
                        __zt_tmp = __attrs_136948308667920
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_136948418207568('path', u'widget/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u' class="horizontal font-weight-bold">\n      ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308664848
                    __attrs_136948308664848 = _static_136948501914768

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308665552
                    __default_136948308665552 = _DEFAULT_MARKER

                    # <Value u'widget/label' (23:43)> -> __cache_136948308666064
                    __token = 1299
                    try:
                        __zt_tmp = __attrs_136948308664848
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308666064 = _static_136948418207568('path', u'widget/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/label' (23:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34a6310> -> __condition
                    __expression = __cache_136948308666064

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>label</span>')
                    else:
                        __content = __cache_136948308666064
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n\n      ')

                    # <Static value=<_ast.Dict object at 0x7c8dc34a6dd0> name=None at 7c8dc34a6f50> -> __attrs_136948308666192
                    __attrs_136948308666192 = _static_136948308667856

                    # <Value u"python:widget.required and widget.mode == 'input'" (26:27)> -> __condition
                    __token = 1411
                    try:
                        __zt_tmp = __attrs_136948308666192
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('python', u"widget.required and widget.mode == 'input'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required horizontal"')

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308667984
                        __default_136948308667984 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7c8dc34a6ed0> at 7c8dc34a6e90> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\n    </div>')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3487910> name=None at 7c8dc34879d0> -> __attrs_136948308537680
                __attrs_136948308537680 = _static_136948308539664

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="fieldErrorBox">')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308665488
                __default_136948308665488 = _DEFAULT_MARKER

                # <Value u'error/render|nothing' (31:32)> -> __cache_136948308667088
                __token = 1603
                try:
                    __zt_tmp = __attrs_136948308537680
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948308667088 = _static_136948418207568('path', u'error/render|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'error/render|nothing' (31:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34a6590> -> __condition
                __expression = __cache_136948308667088

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n      Error\n    ')
                else:
                    __content = __cache_136948308667088
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3487e50> name=None at 7c8dc3487dd0> -> __attrs_136948308539216
                __attrs_136948308539216 = _static_136948308541008
                __backup_description_136948309666960 = get('description', __marker)

                # <Value u"python: getattr(widget, 'description', widget.field.description)" (36:34)> -> __value
                __token = 1737
                try:
                    __zt_tmp = __attrs_136948308539216
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u" getattr(widget, 'description', widget.field.description)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['description'] = __value

                # <Value u'python:description and not hidden' (39:25)> -> __condition
                __token = 1902
                try:
                    __zt_tmp = __attrs_136948308539216
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u'description and not hidden', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp text-secondary text-muted">')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308539600
                    __default_136948308539600 = _DEFAULT_MARKER

                    # <Value u'description' (38:33)> -> __cache_136948308537744
                    __token = 1864
                    try:
                        __zt_tmp = __attrs_136948308539216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308537744 = _static_136948418207568('path', u'description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description' (38:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3487f50> -> __condition
                    __expression = __cache_136948308537744

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n      field description\n    ')
                    else:
                        __content = __cache_136948308537744
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                if (__backup_description_136948309666960 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_136948309666960
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc3487b50> name=None at 7c8dc3487ad0> -> __attrs_136948308631760
                __attrs_136948308631760 = _static_136948308540240
                __backup_prefix_136948328000272 = get('prefix', __marker)

                # <Value u'python:view.get_prepend_text()' (46:28)> -> __value
                __token = 2138
                try:
                    __zt_tmp = __attrs_136948308631760
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u'view.get_prepend_text()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['prefix'] = __value
                __backup_appendix_136948309679312 = get('appendix', __marker)

                # <Value u'python:view.get_append_text()' (47:24)> -> __value
                __token = 2194
                try:
                    __zt_tmp = __attrs_136948308631760
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u'view.get_append_text()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['appendix'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308537936
                __default_136948308537936 = _DEFAULT_MARKER

                # <Substitution u'python:widget_css_class' (45:31)> -> __attr_class
                __token = 2085
                try:
                    __zt_tmp = __attrs_136948308631760
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_136948418207568('python', u'widget_css_class', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', u'input-group input-group-sm d-flex', _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u' style="width:auto">\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc349e290> name=None at 7c8dc349e150> -> __attrs_136948308634512
                __attrs_136948308634512 = _static_136948308632208

                # <Value u'python:prefix' (48:26)> -> __condition
                __token = 2253
                try:
                    __zt_tmp = __attrs_136948308634512
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u'prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dc349ed90> name=None at 7c8dc349ec10> -> __attrs_136948325573840
                    __attrs_136948325573840 = _static_136948308635024

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308635280
                    __default_136948308635280 = _DEFAULT_MARKER

                    # <Value u'python:prefix' (49:62)> -> __cache_136948308634896
                    __token = 2359
                    try:
                        __zt_tmp = __attrs_136948325573840
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308634896 = _static_136948418207568('python', u'prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:prefix' (49:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc349e310> -> __condition
                    __expression = __cache_136948308634896

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_136948308634896
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\n      </div>')
                __append(u'\n      ')
                if (__slot_widget is None):

                    # <Static value=<_ast.Dict object at 0x7c8dc44c6910> name=None at 7c8dc349e110> -> __attrs_136948325574352
                    __attrs_136948325574352 = _static_136948325574928

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325574480
                    __default_136948325574480 = _DEFAULT_MARKER

                    # <Value u'widget/render' (52:36)> -> __cache_136948325572688
                    __token = 2450
                    try:
                        __zt_tmp = __attrs_136948325574352
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948325572688 = _static_136948418207568('path', u'widget/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (52:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc44c6190> -> __condition
                    __expression = __cache_136948325572688

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_136948325572688
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                else:
                    __slot_widget(__stream, econtext.copy(), rcontext)
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc44c6410> name=None at 7c8dc44c6310> -> __attrs_136948325574800
                __attrs_136948325574800 = _static_136948325573648

                # <Value u'python:appendix' (54:26)> -> __condition
                __token = 2534
                try:
                    __zt_tmp = __attrs_136948325574800
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u'appendix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-append">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dc44c6cd0> name=None at 7c8dc44c6c90> -> __attrs_136948323882640
                    __attrs_136948323882640 = _static_136948325575888

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325575696
                    __default_136948325575696 = _DEFAULT_MARKER

                    # <Value u'python:appendix' (55:62)> -> __cache_136948325576272
                    __token = 2641
                    try:
                        __zt_tmp = __attrs_136948323882640
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948325576272 = _static_136948418207568('python', u'appendix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:appendix' (55:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc44c6f50> -> __condition
                    __expression = __cache_136948325576272

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_136948325576272
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\n      </div>')
                __append(u'\n    </div>')
                if (__backup_appendix_136948309679312 is __marker):
                    del econtext['appendix']
                else:
                    econtext['appendix'] = __backup_appendix_136948309679312
                if (__backup_prefix_136948328000272 is __marker):
                    del econtext['prefix']
                else:
                    econtext['prefix'] = __backup_prefix_136948328000272
                __append(u'\n  ')
            __append(u'\n\n\n  <!-- VIEW MODE -->\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325575568
            __attrs_136948325575568 = _static_136948501914768

            # <Value u'python:view.is_view_mode()' (62:28)> -> __condition
            __token = 2754
            try:
                __zt_tmp = __attrs_136948325575568
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('python', u'view.is_view_mode()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc4329290> name=None at 7c8dc4329950> -> __attrs_136948323882896
                __attrs_136948323882896 = _static_136948323881616

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="table table-borderless table-hover table-sm">\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323884432
                __attrs_136948323884432 = _static_136948501914768

                # <colgroup ... (0:0)
                # --------------------------------------------------------
                __append(u'<colgroup>\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dc4329d50> name=None at 7c8dc4329a90> -> __attrs_136948323883792
                __attrs_136948323883792 = _static_136948323884368

                # <col ... (0:0)
                # --------------------------------------------------------
                __append(u'<col style="min-width:150px;max-width:200px;">\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dc43291d0> name=None at 7c8dc4329450> -> __attrs_136948310543888
                __attrs_136948310543888 = _static_136948323881424

                # <col ... (0:0)
                # --------------------------------------------------------
                __append(u'<col style="width:100%">\n      </colgroup>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308517200
                __attrs_136948308517200 = _static_136948501914768

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308517712
                __attrs_136948308517712 = _static_136948501914768

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dc3482610> name=None at 7c8dc3482090> -> __attrs_136948308676688
                __attrs_136948308676688 = _static_136948308518416

                # <Value u'python: not hidden and widget.label' (74:30)> -> __condition
                __token = 3144
                try:
                    __zt_tmp = __attrs_136948308676688
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u' not hidden and widget.label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308518608
                    __default_136948308518608 = _DEFAULT_MARKER

                    # <Substitution u'widget/id' (73:35)> -> __attr_for
                    __token = 3103
                    try:
                        __zt_tmp = __attrs_136948308676688
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_136948418207568('path', u'widget/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u' class="horizontal font-weight-bold">\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dc34a9210> name=None at 7c8dc34a9890> -> __attrs_136948308677904
                    __attrs_136948308677904 = _static_136948308677136
                    __backup_description_136948400694800 = get('description', __marker)

                    # <Value u"python: getattr(widget, 'description', widget.field.description)" (76:42)> -> __value
                    __token = 3225
                    try:
                        __zt_tmp = __attrs_136948308677904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u" getattr(widget, 'description', widget.field.description)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span data-toggle="tooltip" data-html="true"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308678736
                    __default_136948308678736 = _DEFAULT_MARKER

                    # <Substitution u'python:description' (77:40)> -> __attr_title
                    __token = 3331
                    try:
                        __zt_tmp = __attrs_136948308677904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_136948418207568('python', u'description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\n                ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948305493648
                    __attrs_136948305493648 = _static_136948501914768

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948305493968
                    __default_136948305493968 = _DEFAULT_MARKER

                    # <Value u'widget/label' (80:53)> -> __cache_136948308680144
                    __token = 3480
                    try:
                        __zt_tmp = __attrs_136948305493648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308680144 = _static_136948418207568('path', u'widget/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/label' (80:53)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34a9190> -> __condition
                    __expression = __cache_136948308680144

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>label</span>')
                    else:
                        __content = __cache_136948308680144
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n            </span>')
                    if (__backup_description_136948400694800 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_136948400694800
                    __append(u'\n\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dc3495790> name=None at 7c8dc319ff10> -> __attrs_136948308596560
                    __attrs_136948308596560 = _static_136948308596624

                    # <Value u"python:widget.required and widget.mode == 'input'" (85:33)> -> __condition
                    __token = 3625
                    try:
                        __zt_tmp = __attrs_136948308596560
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('python', u"widget.required and widget.mode == 'input'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required horizontal"')

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308597840
                        __default_136948308597840 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7c8dc3495050> at 7c8dc3495d10> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\n          </div>')
                __append(u'\n\n        </td>\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308677968
                __attrs_136948308677968 = _static_136948501914768

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308597904
                __attrs_136948308597904 = _static_136948501914768
                __backup_prefix_136948309576656 = get('prefix', __marker)

                # <Value u'python:view.get_prepend_text()' (91:34)> -> __value
                __token = 3827
                try:
                    __zt_tmp = __attrs_136948308597904
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u'view.get_prepend_text()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['prefix'] = __value
                __backup_appendix_136948323768656 = get('appendix', __marker)

                # <Value u'python:view.get_append_text()' (92:35)> -> __value
                __token = 3894
                try:
                    __zt_tmp = __attrs_136948308597904
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u'view.get_append_text()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['appendix'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n            <!-- field prefix -->\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc3591150> name=None at 7c8dc3591d10> -> __attrs_136948309629200
                __attrs_136948309629200 = _static_136948309627216

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="field-prefix">')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309630480
                __default_136948309630480 = _DEFAULT_MARKER

                # <Value u'python:prefix' (94:41)> -> __cache_136948308595216
                __token = 4002
                try:
                    __zt_tmp = __attrs_136948309629200
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948308595216 = _static_136948418207568('python', u'prefix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:prefix' (94:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc35914d0> -> __condition
                __expression = __cache_136948308595216

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136948308595216
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n            ')
                if (__slot_widget is None):

                    # <Static value=<_ast.Dict object at 0x7c8dc3591590> name=None at 7c8dc3591710> -> __attrs_136948309629392
                    __attrs_136948309629392 = _static_136948309628304

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309629520
                    __default_136948309629520 = _DEFAULT_MARKER

                    # <Value u'widget/render' (96:42)> -> __cache_136948309628176
                    __token = 4119
                    try:
                        __zt_tmp = __attrs_136948309629392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948309628176 = _static_136948418207568('path', u'widget/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (96:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3591210> -> __condition
                    __expression = __cache_136948309628176

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_136948309628176
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                else:
                    __slot_widget(__stream, econtext.copy(), rcontext)
                __append(u'\n            <!-- field appendix -->\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc3492490> name=None at 7c8dc94ffbd0> -> __attrs_136948308585424
                __attrs_136948308585424 = _static_136948308583568

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="field-prefix">')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309628624
                __default_136948309628624 = _DEFAULT_MARKER

                # <Value u'python:appendix' (99:41)> -> __cache_136948309628048
                __token = 4260
                try:
                    __zt_tmp = __attrs_136948308585424
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948309628048 = _static_136948418207568('python', u'appendix', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:appendix' (99:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3591f10> -> __condition
                __expression = __cache_136948309628048

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136948309628048
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n          </div>')
                if (__backup_appendix_136948323768656 is __marker):
                    del econtext['appendix']
                else:
                    econtext['appendix'] = __backup_appendix_136948323768656
                if (__backup_prefix_136948309576656 is __marker):
                    del econtext['prefix']
                else:
                    econtext['prefix'] = __backup_prefix_136948309576656
                __append(u'\n\n        </td>\n      </tr>\n    </table>\n  ')
            __append(u'\n\n</div>')
            __i18n_domain = __previous_i18n_domain_136948308624720
            if (__backup_fieldname_class_136948327205584 is __marker):
                del econtext['fieldname_class']
            else:
                econtext['fieldname_class'] = __backup_fieldname_class_136948327205584
            if (__backup_wrapper_css_class_136948309627152 is __marker):
                del econtext['wrapper_css_class']
            else:
                econtext['wrapper_css_class'] = __backup_wrapper_css_class_136948309627152
            if (__backup_empty_class_136948328712016 is __marker):
                del econtext['empty_class']
            else:
                econtext['empty_class'] = __backup_empty_class_136948328712016
            if (__backup_empty_values_136948309575696 is __marker):
                del econtext['empty_values']
            else:
                econtext['empty_values'] = __backup_empty_values_136948309575696
            if (__backup_error_class_136948328025808 is __marker):
                del econtext['error_class']
            else:
                econtext['error_class'] = __backup_error_class_136948328025808
            if (__backup_error_136948323769872 is __marker):
                del econtext['error']
            else:
                econtext['error'] = __backup_error_136948323769872
            if (__backup_hidden_136948308595088 is __marker):
                del econtext['hidden']
            else:
                econtext['hidden'] = __backup_hidden_136948308595088
            if (__backup_widget_css_class_136948323768784 is __marker):
                del econtext['widget_css_class']
            else:
                econtext['widget_css_class'] = __backup_widget_css_class_136948323768784
            if (__backup_widget_clazz_136948309577360 is __marker):
                del econtext['widget_clazz']
            else:
                econtext['widget_clazz'] = __backup_widget_clazz_136948309577360
            if (__backup_widget_136948309649936 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_136948309649936
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_widget_wrapper(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_wrapper': render_widget_wrapper, 'render': render, }