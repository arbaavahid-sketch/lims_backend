# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/login/templates/login.pt'

__tokens = {1024: (u'python:view.show_lab_name', 28, 46), 1104: (u'python:view.lab_name', 29, 52), 1345: (u'view/action', 36, 43), 1365: (u' view/enctyp', 36, 63), 1426: (u'view/widgets/values', 38, 44), 1497: (u"python:widget.mode == 'hidden'", 40, 48), 1583: (u'not:hidden', 41, 53), 1694: (u'widget/error', 44, 45), 1757: (u"python:'field' + (error and ' error' or '')", 45, 49), 1950: (u'not:hidden', 49, 46), 1893: (u'widget/id', 48, 51), 2058: (u'widget/label', 51, 45), 2209: (u'python:widget.required and not hidden', 53, 47), 2488: (u'widget/field/description', 58, 53), 2660: (u'description', 61, 44), 2603: (u'description', 60, 42), 2993: (u'python:view.get_icon_class_for(widget)', 68, 55), 3174: (u'python:widget.render()', 71, 68), 3342: (u'error', 75, 44), 3401: (u'error/render', 76, 52), 3621: (u'hidden', 85, 42), 3679: (u'widget/render', 86, 50), 3805: (u'context/@@authenticator/authenticator', 90, 45), 3940: (u'view/actions/values|nothing', 93, 50), 4034: (u'action/render', 94, 64), 4235: (u'context/@@plone_portal_state', 101, 42), 4299: (u' portal_state/portal_ur', 102, 34), 4534: (u'string:${portal_url}/@@login-help', 105, 60), 4724: (u'python:view.self_registration_enabled()', 108, 32), 4919: (u'string:${portal_url}/@@register', 110, 58), 287: (u'here/main_template/macros/master', 7, 23), 287: (u'here/main_template/macros/master', 7, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136289649948048 = {u'href': u'@@login-help', }
_static_136289649941968 = {u'class': u'formControls', }
_static_136289649929296 = {u'class': u'widget input-group flex-nowrap', }
_static_136289649918928 = {u'for': u'', }
_static_136289649881616 = {u'class': u'card-body', }
_static_136289649955024 = {u'href': u'@@register', u'class': u'emph', }
_static_136289649912848 = {u'class': u'field form-group', }
_static_136289649941456 = {u'class': u'card-footer small', }
_static_136289649911376 = {u'class': u'mb-3', }
_static_136289649918544 = {u'type': u'hidden', }
_static_136289649933200 = {u'class': u'python:view.get_icon_class_for(widget)', }
_static_136289649868944 = {u'id': u'login-form', u'class': u'card my-4', }
_static_136289649921744 = {u'class': u'required horizontal', u'title': u'Required', }
_static_136289649952336 = {u'type': u'submit', }
_static_136289649932880 = {u'type': u'text', }
_static_136289829229712 = {}
_static_136289649928016 = {u'class': u'formHelp form-text text-muted', }
_static_136289649855376 = {u'class': u'col-sm-4 offset-sm-4', }
_static_136289649948816 = {u'class': u'form-text text-muted', }
_static_136289653616016 = u'master'
_static_136289649889616 = {u'action': u'.', u'enctype': u'view/enctype', u'method': u'post', u'class': u'loginform', }
_static_136289649931856 = {u'class': u'input-group-text', }
_static_136289649889744 = {u'class': u'dashed', }
_static_136289745497936 = __compile_zt_expr
_static_136289649870800 = {u'style': u'display:none', u'class': u'portalMessage error pat-cookietrigger alert alert-danger m-1', }
_static_136289745510672 = __C2ZContextWrapper
_static_136289649954320 = {u'class': u'form-text text-muted', }
_static_136289649930640 = {u'class': u'input-group-prepend', }
_static_136289649884624 = {u'class': u'card-title', }
_static_136289649939600 = {u'class': u'form-text small text-danger', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_main(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649854608
            __attrs_136289649854608 = _static_136289829229712
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7bf4682a8b90> name=None at 7bf4682a8b50> -> __attrs_136289649855888
            __attrs_136289649855888 = _static_136289649855376

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-4 offset-sm-4">\n          ')

            # <Static value=<_ast.Dict object at 0x7bf4682ac090> name=None at 7bf4682ac050> -> __attrs_136289649869904
            __attrs_136289649869904 = _static_136289649868944

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="login-form" class="card my-4">\n\n            ')

            # <Static value=<_ast.Dict object at 0x7bf4682ac7d0> name=None at 7bf4682ac750> -> __attrs_136289649871760
            __attrs_136289649871760 = _static_136289649870800

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portalMessage error pat-cookietrigger alert alert-danger m-1" style="display:none">\n              ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649872848
            __attrs_136289649872848 = _static_136289829229712

            # <strong ... (0:0)
            # --------------------------------------------------------
            __append(u'<strong>')
            __stream_136289649872528 = []
            __append_136289649872528 = __stream_136289649872528.append
            __append_136289649872528(u'\n                Error\n              ')
            __msgid_136289649872528 = __re_whitespace(''.join(__stream_136289649872528)).strip()
            if __msgid_136289649872528:
                __append(translate(__msgid_136289649872528, mapping=None, default=__msgid_136289649872528, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</strong>\n              ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649881808
            __attrs_136289649881808 = _static_136289829229712
            __stream_136289649881552 = []
            __append_136289649881552 = __stream_136289649881552.append
            __append_136289649881552(u'\n                Cookies are not enabled. You must enable cookies before you can log in.\n              ')
            __msgid_136289649881552 = __re_whitespace(''.join(__stream_136289649881552)).strip()
            if u'enable_cookies_message_before_login':
                __append(translate(u'enable_cookies_message_before_login', mapping=None, default=__msgid_136289649881552, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n            </div>\n\n            ')

            # <Static value=<_ast.Dict object at 0x7bf4682af210> name=None at 7bf4682af290> -> __attrs_136289649882512
            __attrs_136289649882512 = _static_136289649881616

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="card-body">\n\n              ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649883280
            __attrs_136289649883280 = _static_136289829229712

            # <Value u'python:view.show_lab_name' (28:46)> -> __condition
            __token = 1024
            try:
                __zt_tmp = __attrs_136289649883280
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136289745497936('python', u'view.show_lab_name', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            if __condition:
                __append(u'\n                ')

                # <Static value=<_ast.Dict object at 0x7bf4682afdd0> name=None at 7bf4682afd50> -> __attrs_136289649889360
                __attrs_136289649889360 = _static_136289649884624

                # <h5 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h5 class="card-title">')

                # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649884368
                __default_136289649884368 = _DEFAULT_MARKER

                # <Value u'python:view.lab_name' (29:52)> -> __cache_136289649884048
                __token = 1104
                try:
                    __zt_tmp = __attrs_136289649889360
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136289649884048 = _static_136289745497936('python', u'view.lab_name', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.lab_name' (29:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682afc10> -> __condition
                __expression = __cache_136289649884048

                # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136289649884048
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</h5>\n                ')

                # <Static value=<_ast.Dict object at 0x7bf4682b11d0> name=None at 7bf4682b1190> -> __attrs_136289649890256
                __attrs_136289649890256 = _static_136289649889744

                # <hr ... (0:0)
                # --------------------------------------------------------
                __append(u'<hr class="dashed"/>\n              ')
            __append(u'\n\n              ')

            # <Static value=<_ast.Dict object at 0x7bf4682b1150> name=None at 7bf4682af790> -> __attrs_136289649892176
            __attrs_136289649892176 = _static_136289649889616

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form')

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649891152
            __default_136289649891152 = _DEFAULT_MARKER

            # <Substitution u'view/action' (36:43)> -> __attr_action
            __token = 1345
            try:
                __zt_tmp = __attrs_136289649892176
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_136289745497936('path', u'view/action', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'.', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u' method="post" class="loginform"')

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649891856
            __default_136289649891856 = _DEFAULT_MARKER

            # <Substitution u'view/enctype' (36:63)> -> __attr_enctype
            __token = 1365
            try:
                __zt_tmp = __attrs_136289649892176
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_enctype = _static_136289745497936('path', u'view/enctype', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_enctype = __quote(__attr_enctype, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_enctype is not None):
                __append((u' enctype="%s"' % __attr_enctype))
            __append(u'>\n\n                ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649892944
            __attrs_136289649892944 = _static_136289829229712
            __backup_widget_136289649870224 = get('widget', __marker)

            # <Value u'view/widgets/values' (38:44)> -> __iterator
            __token = 1426
            try:
                __zt_tmp = __attrs_136289649892944
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136289745497936('path', u'view/widgets/values', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            (__iterator, ____index_136289649893200, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\n\n                  ')

                # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649910352
                __attrs_136289649910352 = _static_136289829229712
                __backup_hidden_136289649881360 = get('hidden', __marker)

                # <Value u"python:widget.mode == 'hidden'" (40:48)> -> __value
                __token = 1497
                try:
                    __zt_tmp = __attrs_136289649910352
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136289745497936('python', u"widget.mode == 'hidden'", econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                econtext['hidden'] = __value
                __append(u'\n                    ')

                # <Static value=<_ast.Dict object at 0x7bf4682b6650> name=None at 7bf4682b6610> -> __attrs_136289649911952
                __attrs_136289649911952 = _static_136289649911376

                # <Value u'not:hidden' (41:53)> -> __condition
                __token = 1583
                try:
                    __zt_tmp = __attrs_136289649911952
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136289745497936('not', u'hidden', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="mb-3">\n\n                      ')

                    # <Static value=<_ast.Dict object at 0x7bf4682b6c10> name=None at 7bf4682b6c50> -> __attrs_136289649913680
                    __attrs_136289649913680 = _static_136289649912848
                    __backup_error_136289649910480 = get('error', __marker)

                    # <Value u'widget/error' (44:45)> -> __value
                    __token = 1694
                    try:
                        __zt_tmp = __attrs_136289649913680
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136289745497936('path', u'widget/error', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    econtext['error'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649913360
                    __default_136289649913360 = _DEFAULT_MARKER

                    # <Substitution u"python:'field' + (error and ' error' or '')" (45:49)> -> __attr_class
                    __token = 1757
                    try:
                        __zt_tmp = __attrs_136289649913680
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136289745497936('python', u"'field' + (error and ' error' or '')", econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'field form-group', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7bf4682b83d0> name=None at 7bf4682b8450> -> __attrs_136289649919696
                    __attrs_136289649919696 = _static_136289649918928

                    # <Value u'not:hidden' (49:46)> -> __condition
                    __token = 1950
                    try:
                        __zt_tmp = __attrs_136289649919696
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136289745497936('not', u'hidden', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    if __condition:

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label')

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649919376
                        __default_136289649919376 = _DEFAULT_MARKER

                        # <Substitution u'widget/id' (48:51)> -> __attr_for
                        __token = 1893
                        try:
                            __zt_tmp = __attrs_136289649919696
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_136289745497936('path', u'widget/id', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>\n                          ')

                        # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649921424
                        __attrs_136289649921424 = _static_136289829229712

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649921040
                        __default_136289649921040 = _DEFAULT_MARKER

                        # <Value u'widget/label' (51:45)> -> __cache_136289649920656
                        __token = 2058
                        try:
                            __zt_tmp = __attrs_136289649921424
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136289649920656 = _static_136289745497936('path', u'widget/label', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                        # <BinOp left=<Value u'widget/label' (51:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682b8b50> -> __condition
                        __expression = __cache_136289649920656

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'label')
                        else:
                            __content = __cache_136289649920656
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n                          ')

                        # <Static value=<_ast.Dict object at 0x7bf4682b8ed0> name=None at 7bf4682b8f50> -> __attrs_136289649927248
                        __attrs_136289649927248 = _static_136289649921744

                        # <Value u'python:widget.required and not hidden' (53:47)> -> __condition
                        __token = 2209
                        try:
                            __zt_tmp = __attrs_136289649927248
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_136289745497936('python', u'widget.required and not hidden', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="required horizontal"')

                            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649926928
                            __default_136289649926928 = _DEFAULT_MARKER

                            # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7bf4682ba250> at 7bf4682ba290> -> __attr_title
                            __attr_title = u'Required'
                            __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u' title="%s"' % __attr_title))
                            __append(u'>&nbsp;</span>')
                        __append(u'\n                        </label>')
                    __append(u'\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7bf4682ba750> name=None at 7bf4682ba710> -> __attrs_136289649928656
                    __attrs_136289649928656 = _static_136289649928016
                    __backup_description_136289649913808 = get('description', __marker)

                    # <Value u'widget/field/description' (58:53)> -> __value
                    __token = 2488
                    try:
                        __zt_tmp = __attrs_136289649928656
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136289745497936('path', u'widget/field/description', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <Value u'description' (61:44)> -> __condition
                    __token = 2660
                    try:
                        __zt_tmp = __attrs_136289649928656
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136289745497936('path', u'description', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="formHelp form-text text-muted">')

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649927824
                        __default_136289649927824 = _DEFAULT_MARKER

                        # <Value u'description' (60:42)> -> __cache_136289649919888
                        __token = 2603
                        try:
                            __zt_tmp = __attrs_136289649928656
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136289649919888 = _static_136289745497936('path', u'description', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                        # <BinOp left=<Value u'description' (60:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682ba4d0> -> __condition
                        __expression = __cache_136289649919888

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                          field description\n                        ')
                        else:
                            __content = __cache_136289649919888
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    if (__backup_description_136289649913808 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_136289649913808
                    __append(u'\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bac50> name=None at 7bf4682babd0> -> __attrs_136289649929936
                    __attrs_136289649929936 = _static_136289649929296

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="widget input-group flex-nowrap">\n                          ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bb190> name=None at 7bf4682bb150> -> __attrs_136289649931280
                    __attrs_136289649931280 = _static_136289649930640

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\n                            ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bb650> name=None at 7bf4682bb610> -> __attrs_136289649932496
                    __attrs_136289649932496 = _static_136289649931856

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-text">\n                              ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bbb90> name=None at 7bf4682bbb50> -> __attrs_136289649933904
                    __attrs_136289649933904 = _static_136289649933200

                    # <i ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<i')

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649933584
                    __default_136289649933584 = _DEFAULT_MARKER

                    # <Substitution u'python:view.get_icon_class_for(widget)' (68:55)> -> __attr_class
                    __token = 2993
                    try:
                        __zt_tmp = __attrs_136289649933904
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136289745497936('python', u'view.get_icon_class_for(widget)', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'></i>\n                            </div>\n                          </div>\n                          ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bba50> name=None at 7bf4682bb910> -> __attrs_136289649939024
                    __attrs_136289649939024 = _static_136289649932880

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649938896
                    __default_136289649938896 = _DEFAULT_MARKER

                    # <Value u'python:widget.render()' (71:68)> -> __cache_136289649938576
                    __token = 3174
                    try:
                        __zt_tmp = __attrs_136289649939024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136289649938576 = _static_136289745497936('python', u'widget.render()', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:widget.render()' (71:68)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682bd110> -> __condition
                    __expression = __cache_136289649938576

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_136289649938576
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n                        </div>\n\n                        ')

                    # <Static value=<_ast.Dict object at 0x7bf4682bd490> name=None at 7bf4682bd450> -> __attrs_136289649940240
                    __attrs_136289649940240 = _static_136289649939600

                    # <Value u'error' (75:44)> -> __condition
                    __token = 3342
                    try:
                        __zt_tmp = __attrs_136289649940240
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136289745497936('path', u'error', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="form-text small text-danger">')

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649939408
                        __default_136289649939408 = _DEFAULT_MARKER

                        # <Value u'error/render' (76:52)> -> __cache_136289649930384
                        __token = 3401
                        try:
                            __zt_tmp = __attrs_136289649940240
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136289649930384 = _static_136289745497936('path', u'error/render', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                        # <BinOp left=<Value u'error/render' (76:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682bd310> -> __condition
                        __expression = __cache_136289649930384

                        # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                          Error\n                        ')
                        else:
                            __content = __cache_136289649930384
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    __append(u'\n\n                      </div>')
                    if (__backup_error_136289649910480 is __marker):
                        del econtext['error']
                    else:
                        econtext['error'] = __backup_error_136289649910480
                    __append(u'\n\n                    </div>')
                __append(u'\n\n                    ')

                # <Static value=<_ast.Dict object at 0x7bf4682b8250> name=None at 7bf4682b6b90> -> __attrs_136289649941328
                __attrs_136289649941328 = _static_136289649918544

                # <Value u'hidden' (85:42)> -> __condition
                __token = 3621
                try:
                    __zt_tmp = __attrs_136289649941328
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136289745497936('path', u'hidden', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                if __condition:

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649941200
                    __default_136289649941200 = _DEFAULT_MARKER

                    # <Value u'widget/render' (86:50)> -> __cache_136289649940816
                    __token = 3679
                    try:
                        __zt_tmp = __attrs_136289649941328
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136289649940816 = _static_136289745497936('path', u'widget/render', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (86:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682bda10> -> __condition
                    __expression = __cache_136289649940816

                    # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden" />')
                    else:
                        __content = __cache_136289649940816
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                __append(u'\n                  ')
                if (__backup_hidden_136289649881360 is __marker):
                    del econtext['hidden']
                else:
                    econtext['hidden'] = __backup_hidden_136289649881360
                __append(u'\n\n                ')
                ____index_136289649893200 -= 1
                if (____index_136289649893200 > 0):
                    __append('')
            if (__backup_widget_136289649870224 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_136289649870224
            __append(u'\n                ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649909840
            __attrs_136289649909840 = _static_136289829229712

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649910608
            __default_136289649910608 = _DEFAULT_MARKER

            # <Value u'context/@@authenticator/authenticator' (90:45)> -> __cache_136289649909904
            __token = 3805
            try:
                __zt_tmp = __attrs_136289649909840
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_136289649909904 = _static_136289745497936('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

            # <BinOp left=<Value u'context/@@authenticator/authenticator' (90:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682b61d0> -> __condition
            __expression = __cache_136289649909904

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span/>')
            else:
                __content = __cache_136289649909904
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n\n                ')

            # <Static value=<_ast.Dict object at 0x7bf4682bddd0> name=None at 7bf4682bdd90> -> __attrs_136289649950800
            __attrs_136289649950800 = _static_136289649941968

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="formControls">\n                  ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649951568
            __attrs_136289649951568 = _static_136289829229712
            __backup_action_136289649870608 = get('action', __marker)

            # <Value u'view/actions/values|nothing' (93:50)> -> __iterator
            __token = 3940
            try:
                __zt_tmp = __attrs_136289649951568
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136289745497936('path', u'view/actions/values|nothing', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            (__iterator, ____index_136289649951760, ) = getitem('repeat')(u'action', __iterator)
            econtext['action'] = None
            for __item in __iterator:
                econtext['action'] = __item
                __append(u'\n                    ')

                # <Static value=<_ast.Dict object at 0x7bf4682c0650> name=None at 7bf4682c0610> -> __attrs_136289649953360
                __attrs_136289649953360 = _static_136289649952336

                # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649953232
                __default_136289649953232 = _DEFAULT_MARKER

                # <Value u'action/render' (94:64)> -> __cache_136289649952848
                __token = 4034
                try:
                    __zt_tmp = __attrs_136289649953360
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136289649952848 = _static_136289745497936('path', u'action/render', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))

                # <BinOp left=<Value u'action/render' (94:64)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7bf472dce110> at 7bf4682c0910> -> __condition
                __expression = __cache_136289649952848

                # <Symbol value=<DEFAULT> at 7bf472dce110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="submit" />')
                else:
                    __content = __cache_136289649952848
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n                  ')
                ____index_136289649951760 -= 1
                if (____index_136289649951760 > 0):
                    __append('')
            if (__backup_action_136289649870608 is __marker):
                del econtext['action']
            else:
                econtext['action'] = __backup_action_136289649870608
            __append(u'\n                </div>\n              </form>\n            </div>\n\n            ')

            # <Static value=<_ast.Dict object at 0x7bf4682bdbd0> name=None at 7bf4682b1b90> -> __attrs_136289649951312
            __attrs_136289649951312 = _static_136289649941456
            __backup_portal_state_136289649856144 = get('portal_state', __marker)

            # <Value u'context/@@plone_portal_state' (101:42)> -> __value
            __token = 4235
            try:
                __zt_tmp = __attrs_136289649951312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136289745497936('path', u'context/@@plone_portal_state', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_portal_url_136289649856464 = get('portal_url', __marker)

            # <Value u'portal_state/portal_url' (102:34)> -> __value
            __token = 4299
            try:
                __zt_tmp = __attrs_136289649951312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136289745497936('path', u'portal_state/portal_url', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            econtext['portal_url'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="card-footer small">\n              ')

            # <Static value=<_ast.Dict object at 0x7bf4682c0e10> name=None at 7bf4682c0dd0> -> __attrs_136289649946832
            __attrs_136289649946832 = _static_136289649954320

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p class="form-text text-muted">\n                ')

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649947664
            __attrs_136289649947664 = _static_136289829229712
            __stream_136289649947408 = []
            __append_136289649947408 = __stream_136289649947408.append
            __append_136289649947408(u'Trouble logging in?')
            __msgid_136289649947408 = __re_whitespace(''.join(__stream_136289649947408)).strip()
            if u'trouble_logging_in':
                __append(translate(u'trouble_logging_in', mapping=None, default=__msgid_136289649947408, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n                ')

            # <Static value=<_ast.Dict object at 0x7bf4682bf590> name=None at 7bf4682bf550> -> __attrs_136289649948752
            __attrs_136289649948752 = _static_136289649948048

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a')

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649948432
            __default_136289649948432 = _DEFAULT_MARKER

            # <Substitution u'string:${portal_url}/@@login-help' (105:60)> -> __attr_href
            __token = 4534
            try:
                __zt_tmp = __attrs_136289649948752
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_136289745497936('string', u'${portal_url}/@@login-help', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'@@login-help', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_136289649947536 = []
            __append_136289649947536 = __stream_136289649947536.append
            __append_136289649947536(u'Get help')
            __msgid_136289649947536 = __re_whitespace(''.join(__stream_136289649947536)).strip()
            if u'footer_login_link_get_help':
                __append(translate(u'footer_login_link_get_help', mapping=None, default=__msgid_136289649947536, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>.\n              </p>\n              ')

            # <Static value=<_ast.Dict object at 0x7bf4682bf890> name=None at 7bf4682bf1d0> -> __attrs_136289649949584
            __attrs_136289649949584 = _static_136289649948816

            # <Value u'python:view.self_registration_enabled()' (108:32)> -> __condition
            __token = 4724
            try:
                __zt_tmp = __attrs_136289649949584
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136289745497936('python', u'view.self_registration_enabled()', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            if __condition:

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="form-text text-muted">\n                ')

                # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649950544
                __attrs_136289649950544 = _static_136289829229712
                __stream_136289649950288 = []
                __append_136289649950288 = __stream_136289649950288.append
                __append_136289649950288(u'Need an account?')
                __msgid_136289649950288 = __re_whitespace(''.join(__stream_136289649950288)).strip()
                if u'need_an_account':
                    __append(translate(u'need_an_account', mapping=None, default=__msgid_136289649950288, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n                ')

                # <Static value=<_ast.Dict object at 0x7bf4682c10d0> name=None at 7bf4682bff90> -> __attrs_136289649956048
                __attrs_136289649956048 = _static_136289649955024

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289649955536
                __default_136289649955536 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/@@register' (110:58)> -> __attr_href
                __token = 4919
                try:
                    __zt_tmp = __attrs_136289649956048
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_136289745497936('string', u'${portal_url}/@@register', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'@@register', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' class="emph">')
                __stream_136289649950416 = []
                __append_136289649950416 = __stream_136289649950416.append
                __append_136289649950416(u'Sign up here')
                __msgid_136289649950416 = __re_whitespace(''.join(__stream_136289649950416)).strip()
                if u'footer_login_link_signup':
                    __append(translate(u'footer_login_link_signup', mapping=None, default=__msgid_136289649950416, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</a>.\n              </p>')
            __append(u'\n            </div>')
            if (__backup_portal_url_136289649856464 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_136289649856464
            if (__backup_portal_state_136289649856144 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_136289649856144
            __append(u'\n\n          </div>\n        </div>\n\n      ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289653616208
            __attrs_136289653616208 = _static_136289829229712
            __previous_i18n_domain_136289653616336 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_136289654607216 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7bf46863ed90> name=None at 7bf46863edd0> -> __value
            __value = _static_136289653616016
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7bf472db9490> name=None at 7bf472db9ed0> -> __attrs_136289649853776
                __attrs_136289649853776 = _static_136289829229712
                __append(u'\n      ')
                __token = None
                render_main(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n    ')
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'here/main_template/macros/master' (7:23)> -> __macro
            __token = 287
            try:
                __zt_tmp = __attrs_136289653616208
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_136289745497936('path', u'here/main_template/macros/master', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __token = 287
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_136289654607216 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_136289654607216
            __i18n_domain = __previous_i18n_domain_136289653616336
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_main': render_main, 'render': render, }