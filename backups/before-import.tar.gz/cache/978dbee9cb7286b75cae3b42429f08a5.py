# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFPlone-5.2.15-py2.7.egg/Products/CMFPlone/skins/plone_templates/index_html.pt'

__tokens = {515: (u'context/Title', 14, 64), 609: (u'context/description', 17, 48), 261: (u'context/@@main_template/macros/master', 6, 23), 261: (u'context/@@main_template/macros/master', 6, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_138366756623184 = u'master'
_static_138366756544720 = {u'class': u'documentFirstHeading', }
_static_138366930725008 = __compile_zt_expr
_static_138366756130256 = {u'class': u'documentDescription', }
_static_138366930725392 = __C2ZContextWrapper
_static_138367014417552 = {}

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756625872
            __attrs_138366756625872 = _static_138367014417552
            __previous_i18n_domain_138366756626256 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_138366801545808 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7dd805609350> name=None at 7dd805609a10> -> __value
            __value = _static_138366756623184
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756548112
                __attrs_138366756548112 = _static_138367014417552
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7dd8055f60d0> name=None at 7dd8055f6dd0> -> __attrs_138366756126800
                __attrs_138366756126800 = _static_138366756544720

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')
                __stream_138366756598080_sitename = ''
                __stream_138366756547664 = []
                __append_138366756547664 = __stream_138366756547664.append
                __append_138366756547664(u'Welcome to\n        ')
                __stream_138366756598080_sitename = []
                __append_138366756598080_sitename = __stream_138366756598080_sitename.append

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756129488
                __attrs_138366756129488 = _static_138367014417552

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756128656
                __default_138366756128656 = _DEFAULT_MARKER

                # <Value u'context/Title' (14:64)> -> __cache_138366756128848
                __token = 515
                try:
                    __zt_tmp = __attrs_138366756129488
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_138366756128848 = _static_138366930725008('path', u'context/Title', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/Title' (14:64)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd805590750> -> __condition
                __expression = __cache_138366756128848

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append_138366756598080_sitename(u'Portal title')
                else:
                    __content = __cache_138366756128848
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append_138366756598080_sitename(__content)
                __append_138366756547664(u'${sitename}')
                __stream_138366756598080_sitename = ''.join(__stream_138366756598080_sitename)
                __append_138366756547664(u'\n    ')
                __msgid_138366756547664 = __re_whitespace(''.join(__stream_138366756547664)).strip()
                if u'heading_welcome_to':
                    __append(translate(u'heading_welcome_to', mapping={u'sitename': __stream_138366756598080_sitename, }, default=__msgid_138366756547664, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h1>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7dd805590dd0> name=None at 7dd805590b50> -> __attrs_138366756135248
                __attrs_138366756135248 = _static_138366756130256

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="documentDescription">')

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756127504
                __default_138366756127504 = _DEFAULT_MARKER

                # <Value u'context/description' (17:48)> -> __cache_138366756130064
                __token = 609
                try:
                    __zt_tmp = __attrs_138366756135248
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_138366756130064 = _static_138366930725008('path', u'context/description', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/description' (17:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd805590250> -> __condition
                __expression = __cache_138366756130064

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n        Portal description\n    ')
                else:
                    __content = __cache_138366756130064
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</p>\n\n')
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/@@main_template/macros/master' (6:23)> -> __macro
            __token = 261
            try:
                __zt_tmp = __attrs_138366756625872
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_138366930725008('path', u'context/@@main_template/macros/master', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __token = 261
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_138366801545808 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_138366801545808
            __i18n_domain = __previous_i18n_domain_138366756626256
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }