# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/contentmenu/templates/contentmenu.pt'

__tokens = {68: (u'view/menu', 3, 15), 37: (u'view/available', 2, 13), 141: (u'menu', 6, 30), 393: (u"python:menuItem.get('action', '').endswith(\n                            'content_status_history')", 12, 23), 588: (u'menuItem/extra/id', 16, 15), 627: (u' context/UI', 17, 20), 668: (u"e python:view.translate_workflow_msg(\n                menuItem['extra'].get('stateTitle', ''", 18, 27), 790: (u'ss menuItem/extra/class | noth', 20, 26), 848: (u'url string:${context/absolute_url}/@@workflow_menu_', 21, 23), 1113: (u'string:${menuItem/extra/class} tb-state', 25, 36), 1181: (u'menuItem/extra/stateTitle', 26, 27), 1586: (u'menuItem/submenu', 36, 28), 1636: (u' not:menuItem/extra/hideChildren | not:submenu | nothin', 37, 32), 1723: (u'r menuItem/extra/', 38, 29), 1295: (u"python:not menuItem.get('action', '').endswith(\n                            'content_status_history')", 31, 23), 1498: (u" python:has_dropdown and 'nav-item dropdown' or 'nav-item", 35, 29), 1450: (u'menuItem/extra/id', 34, 27), 2078: (u'menuItem/action', 46, 32), 2127: (u' menuItem/extra/class | nothin', 47, 32), 2191: (u's python:state_class and state_class or ', 48, 31), 1846: (u'not:has_dropdown', 42, 24), 2258: (u'not:has_action', 49, 23), 1894: (u'string:#${menuItem/extra/id}', 43, 30), 1954: (u' menuItem/descriptio', 44, 30), 2006: (u's string:label-${state_class} nav-li', 45, 29), 2348: (u'string:${menuItem/extra/class} tb-state', 52, 32), 2506: (u'menuItem/extra/stateTitle | nothing', 54, 25), 2421: (u"python:has_action and css_class or css_class + ' nav-link'", 53, 32), 2566: (u'menuItem/extra/stateTitle', 55, 23), 2765: (u'not:menuItem/extra/hideChildren | not:submenu | nothing', 63, 26), 3082: (u'not:menuItem/extra/stateTitle | nothing', 69, 29), 3150: (u'menuItem/title', 70, 27), 3424: (u'menuItem/extra/stateTitle | nothing', 78, 29), 3354: (u'string:${menuItem/extra/class} tb-state', 77, 36), 3488: (u'menuItem/extra/stateTitle', 79, 27), 3786: (u'submenu', 86, 41), 3655: (u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', 85, 39), 4209: (u'subMenuItem/action', 94, 45), 3929: (u'subMenuItem/action', 90, 35), 3984: (u' subMenuItem/descriptio', 91, 35), 4041: (u'd subMenuItem/extra/id | nothi', 92, 31), 4108: (u'ss string:${subMenuItem/extra/class|nothing} nav-l', 93, 33), 4290: (u'subMenuItem/title', 96, 35), 4593: (u'not:subMenuItem/action', 104, 29), 4461: (u'subMenuItem/extra/id | nothing', 102, 33), 4528: (u' subMenuItem/extra/class | nothin', 103, 35), 4711: (u'subMenuItem/title', 107, 39)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757073174800 = {u'id': u'subMenuItem/extra/id | nothing', u'class': u'subMenuItem/extra/class | nothing', }
_static_135757074240016 = {u'href': u'#', u'class': u'string:label-${state_class} nav-link', u'title': u'menuItem/description', }
_static_135757235272080 = {u'class': u"python:has_action and css_class or css_class + ' nav-link'", }
_static_135757071748112 = {u'href': u'#', u'role': u'button', u'class': u'nav-link dropdown-toggle workflow-menu-toggle', u'aria-expanded': u'false', u'aria-haspopup': u'true', }
_static_135757074113552 = {u'class': u'nav-item', u'id': u'menuItem/extra/id', }
_static_135757152280464 = {u'class': u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', }
_static_135757074115408 = {u'class': u'dropdown-menu', }
_static_135757244280656 = __compile_zt_expr
_static_135757073556240 = {u'class': u'nav-item dropdown', u'aria-hidden': u'true', }
_static_135757148640272 = {u'class': u'', }
_static_135757073131216 = {u'id': u'menuItem/extra/id', u'data-state-class': u'menuItem/extra/class | nothing', u'data-state-title': u"python:view.translate_workflow_msg(\n                menuItem['extra'].get('stateTitle', ''))", u'data-fetch-url': u'string:${context/absolute_url}/@@workflow_menu_data', u'data-uid': u'context/UID', u'class': u'nav-item dropdown senaite-workflow-menu', }
_static_135757148643216 = {u'class': u'', }
_static_135757074114384 = {u'class': u'string:${menuItem/extra/class} tb-state', }
_static_135757148736784 = {u'class': u'string:${subMenuItem/extra/class|nothing} nav-link', u'href': u'#', u'id': u'subMenuItem/extra/id | nothing', u'aria-expanded': u'false', u'title': u'subMenuItem/description', }
_static_135757327983760 = {}
_static_135757073556048 = {u'aria-haspopup': u'true', u'aria-expanded': u'false', u'id': u'navbarDropdown', u'href': u'#', u'role': u'button', u'data-toggle': u'dropdown', u'class': u'nav-link dropdown-toggle', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757148641808 = {u'class': u'dropdown-menu', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152975952
            __attrs_135757152975952 = _static_135757327983760
            __backup_menu_135757153653968 = get('menu', __marker)

            # <Value u'view/menu' (3:15)> -> __value
            __token = 68
            try:
                __zt_tmp = __attrs_135757152975952
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view/menu', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['menu'] = __value

            # <Value u'view/available' (2:13)> -> __condition
            __token = 37
            try:
                __zt_tmp = __attrs_135757152975952
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'view/available', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_135757166674256 = __i18n_domain
                __i18n_domain = u'senaite.core'
                __append(u'\n\n  ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073133456
                __attrs_135757073133456 = _static_135757327983760
                __backup_menuItem_135757163048528 = get('menuItem', __marker)

                # <Value u'menu' (6:30)> -> __iterator
                __token = 141
                try:
                    __zt_tmp = __attrs_135757073133456
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'menu', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757073133136, ) = getitem('repeat')(u'menuItem', __iterator)
                econtext['menuItem'] = None
                for __item in __iterator:
                    econtext['menuItem'] = __item
                    __append(u'\n\n    <!-- Workflow menu: React mount point. The current state pill is\n         rendered server-side so the menu is visible immediately;\n         transitions are fetched on first open via\n         @@workflow_menu_data. -->\n    ')

                    # <Static value=<_ast.Dict object at 0x7b78681ea6d0> name=None at 7b78681ea910> -> __attrs_135757163434896
                    __attrs_135757163434896 = _static_135757073131216

                    # <Value u"python:menuItem.get('action', '').endswith(\n                            'content_status_history')" (12:23)> -> __condition
                    __token = 393
                    try:
                        __zt_tmp = __attrs_135757163434896
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"menuItem.get('action', '').endswith(\n                            'content_status_history')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li class="nav-item dropdown senaite-workflow-menu"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073131408
                        __default_135757073131408 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/id' (16:15)> -> __attr_id
                        __token = 588
                        try:
                            __zt_tmp = __attrs_135757163434896
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('path', u'menuItem/extra/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073133520
                        __default_135757073133520 = _DEFAULT_MARKER

                        # <Substitution u'context/UID' (17:20)> -> __attr_data_uid
                        __token = 627
                        try:
                            __zt_tmp = __attrs_135757163434896
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_uid = _static_135757244280656('path', u'context/UID', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_data_uid = __quote(__attr_data_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_uid is not None):
                            __append((u' data-uid="%s"' % __attr_data_uid))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073130768
                        __default_135757073130768 = _DEFAULT_MARKER

                        # <Substitution u"python:view.translate_workflow_msg(\n                menuItem['extra'].get('stateTitle', ''))" (18:27)> -> __attr_data_state_title
                        __token = 668
                        try:
                            __zt_tmp = __attrs_135757163434896
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_state_title = _static_135757244280656('python', u"view.translate_workflow_msg(\n                menuItem['extra'].get('stateTitle', ''))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_data_state_title = __quote(__attr_data_state_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_state_title is not None):
                            __append((u' data-state-title="%s"' % __attr_data_state_title))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073130576
                        __default_135757073130576 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/class | nothing' (20:26)> -> __attr_data_state_class
                        __token = 790
                        try:
                            __zt_tmp = __attrs_135757163434896
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_state_class = _static_135757244280656('path', u'menuItem/extra/class | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_data_state_class = __quote(__attr_data_state_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_state_class is not None):
                            __append((u' data-state-class="%s"' % __attr_data_state_class))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757163435984
                        __default_135757163435984 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/@@workflow_menu_data' (21:23)> -> __attr_data_fetch_url
                        __token = 848
                        try:
                            __zt_tmp = __attrs_135757163434896
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_data_fetch_url = _static_135757244280656('string', u'${context/absolute_url}/@@workflow_menu_data', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_data_fetch_url = __quote(__attr_data_fetch_url, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_data_fetch_url is not None):
                            __append((u' data-fetch-url="%s"' % __attr_data_fetch_url))
                        __append(u'>\n      ')

                        # <Static value=<_ast.Dict object at 0x7b7868098c10> name=None at 7b7868098e50> -> __attrs_135757071747664
                        __attrs_135757071747664 = _static_135757071748112

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a class="nav-link dropdown-toggle workflow-menu-toggle" href="#" role="button" aria-haspopup="true" aria-expanded="false">\n        ')

                        # <Static value=<_ast.Dict object at 0x7b78682da750> name=None at 7b78682daa10> -> __attrs_135757074115536
                        __attrs_135757074115536 = _static_135757074114384

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074114704
                        __default_135757074114704 = _DEFAULT_MARKER

                        # <Substitution u'string:${menuItem/extra/class} tb-state' (25:36)> -> __attr_class
                        __token = 1113
                        try:
                            __zt_tmp = __attrs_135757074115536
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_135757244280656('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074115600
                        __default_135757074115600 = _DEFAULT_MARKER

                        # <Value u'menuItem/extra/stateTitle' (26:27)> -> __cache_135757071748048
                        __token = 1181
                        try:
                            __zt_tmp = __attrs_135757074115536
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757071748048 = _static_135757244280656('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'menuItem/extra/stateTitle' (26:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868098810> -> __condition
                        __expression = __cache_135757071748048

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757071748048
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n      </a>\n      ')

                        # <Static value=<_ast.Dict object at 0x7b78682dab50> name=None at 7b78682da610> -> __attrs_135757074113360
                        __attrs_135757074113360 = _static_135757074115408

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="dropdown-menu"></div>\n    </li>')
                    __append(u'\n\n    ')

                    # <Static value=<_ast.Dict object at 0x7b78682da410> name=None at 7b7868098f10> -> __attrs_135757150462288
                    __attrs_135757150462288 = _static_135757074113552
                    __backup_submenu_135757153655376 = get('submenu', __marker)

                    # <Value u'menuItem/submenu' (36:28)> -> __value
                    __token = 1586
                    try:
                        __zt_tmp = __attrs_135757150462288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'menuItem/submenu', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['submenu'] = __value
                    __backup_has_dropdown_135757074313744 = get('has_dropdown', __marker)

                    # <Value u'not:menuItem/extra/hideChildren | not:submenu | nothing' (37:32)> -> __value
                    __token = 1636
                    try:
                        __zt_tmp = __attrs_135757150462288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('not', u'menuItem/extra/hideChildren | not:submenu | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['has_dropdown'] = __value
                    __backup_identifier_135757074239824 = get('identifier', __marker)

                    # <Value u'menuItem/extra/id' (38:29)> -> __value
                    __token = 1723
                    try:
                        __zt_tmp = __attrs_135757150462288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'menuItem/extra/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['identifier'] = __value

                    # <Value u"python:not menuItem.get('action', '').endswith(\n                            'content_status_history')" (31:23)> -> __condition
                    __token = 1295
                    try:
                        __zt_tmp = __attrs_135757150462288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"not menuItem.get('action', '').endswith(\n                            'content_status_history')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <li ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<li')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074114192
                        __default_135757074114192 = _DEFAULT_MARKER

                        # <Substitution u"python:has_dropdown and 'nav-item dropdown' or 'nav-item'" (35:29)> -> __attr_class
                        __token = 1498
                        try:
                            __zt_tmp = __attrs_135757150462288
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_135757244280656('python', u"has_dropdown and 'nav-item dropdown' or 'nav-item'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-item', _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757150463440
                        __default_135757150463440 = _DEFAULT_MARKER

                        # <Substitution u'menuItem/extra/id' (34:27)> -> __attr_id
                        __token = 1450
                        try:
                            __zt_tmp = __attrs_135757150462288
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('path', u'menuItem/extra/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>\n      <!-- Menu Item -->\n      ')

                        # <Static value=<_ast.Dict object at 0x7b78682f9210> name=None at 7b78682f9950> -> __attrs_135757136195920
                        __attrs_135757136195920 = _static_135757074240016
                        __backup_has_action_135757166292752 = get('has_action', __marker)

                        # <Value u'menuItem/action' (46:32)> -> __value
                        __token = 2078
                        try:
                            __zt_tmp = __attrs_135757136195920
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'menuItem/action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['has_action'] = __value
                        __backup_state_class_135757074251152 = get('state_class', __marker)

                        # <Value u'menuItem/extra/class | nothing' (47:32)> -> __value
                        __token = 2127
                        try:
                            __zt_tmp = __attrs_135757136195920
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'menuItem/extra/class | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['state_class'] = __value
                        __backup_state_class_135757154876240 = get('state_class', __marker)

                        # <Value u"python:state_class and state_class or ''" (48:31)> -> __value
                        __token = 2191
                        try:
                            __zt_tmp = __attrs_135757136195920
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u"state_class and state_class or ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['state_class'] = __value

                        # <Value u'not:has_dropdown' (42:24)> -> __condition
                        __token = 1846
                        try:
                            __zt_tmp = __attrs_135757136195920
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('not', u'has_dropdown', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <Negate value=<Value u'not:has_action' (49:23)> at 7b786be0fed0> -> __cache_135757136199376

                            # <Value u'not:has_action' (49:23)> -> __cache_135757136199376
                            __token = 2258
                            try:
                                __zt_tmp = __attrs_135757136195920
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757136199376 = _static_135757244280656('not', u'has_action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __cache_135757136199376 = not __cache_135757136199376
                            __condition = __cache_135757136199376
                            if __condition:

                                # <a ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<a')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074241488
                                __default_135757074241488 = _DEFAULT_MARKER

                                # <Substitution u'string:#${menuItem/extra/id}' (43:30)> -> __attr_href
                                __token = 1894
                                try:
                                    __zt_tmp = __attrs_135757136195920
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_href = _static_135757244280656('string', u'#${menuItem/extra/id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                if (__attr_href is not None):
                                    __append((u' href="%s"' % __attr_href))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136196368
                                __default_135757136196368 = _DEFAULT_MARKER

                                # <Translate msgid=None node=<Substitution u'menuItem/description' (44:30)> at 7b786be0f510> -> __attr_title

                                # <Substitution u'menuItem/description' (44:30)> -> __attr_title
                                __token = 1954
                                try:
                                    __zt_tmp = __attrs_135757136195920
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_title = _static_135757244280656('path', u'menuItem/description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                if (__attr_title is not None):
                                    __append((u' title="%s"' % __attr_title))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136196624
                                __default_135757136196624 = _DEFAULT_MARKER

                                # <Substitution u'string:label-${state_class} nav-link' (45:29)> -> __attr_class
                                __token = 2006
                                try:
                                    __zt_tmp = __attrs_135757136195920
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('string', u'label-${state_class} nav-link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')
                            __append(u'\n        ')

                            # <Static value=<_ast.Dict object at 0x7b7871c8b990> name=None at 7b7871c8b2d0> -> __attrs_135757235269904
                            __attrs_135757235269904 = _static_135757235272080
                            __backup_css_class_135757237112592 = get('css_class', __marker)

                            # <Value u'string:${menuItem/extra/class} tb-state' (52:32)> -> __value
                            __token = 2348
                            try:
                                __zt_tmp = __attrs_135757235269904
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['css_class'] = __value

                            # <Value u'menuItem/extra/stateTitle | nothing' (54:25)> -> __condition
                            __token = 2506
                            try:
                                __zt_tmp = __attrs_135757235269904
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235272784
                                __default_135757235272784 = _DEFAULT_MARKER

                                # <Substitution u"python:has_action and css_class or css_class + ' nav-link'" (53:32)> -> __attr_class
                                __token = 2421
                                try:
                                    __zt_tmp = __attrs_135757235269904
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('python', u"has_action and css_class or css_class + ' nav-link'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757235270160
                                __default_135757235270160 = _DEFAULT_MARKER

                                # <Value u'menuItem/extra/stateTitle' (55:23)> -> __cache_135757136198736
                                __token = 2566
                                try:
                                    __zt_tmp = __attrs_135757235269904
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757136198736 = _static_135757244280656('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/extra/stateTitle' (55:23)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786be0ff10> -> __condition
                                __expression = __cache_135757136198736

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\n          State title\n        ')
                                else:
                                    __content = __cache_135757136198736
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            if (__backup_css_class_135757237112592 is __marker):
                                del econtext['css_class']
                            else:
                                econtext['css_class'] = __backup_css_class_135757237112592
                            __append(u'\n      ')
                            __condition = __cache_135757136199376
                            if __condition:
                                __append(u'</a>')
                        if (__backup_state_class_135757154876240 is __marker):
                            del econtext['state_class']
                        else:
                            econtext['state_class'] = __backup_state_class_135757154876240
                        if (__backup_state_class_135757074251152 is __marker):
                            del econtext['state_class']
                        else:
                            econtext['state_class'] = __backup_state_class_135757074251152
                        if (__backup_has_action_135757166292752 is __marker):
                            del econtext['has_action']
                        else:
                            econtext['has_action'] = __backup_has_action_135757166292752
                        __append(u'\n\n      <!-- dropdown menu -->\n      ')

                        # <Static value=<_ast.Dict object at 0x7b7868252310> name=None at 7b7868252150> -> __attrs_135757073559184
                        __attrs_135757073559184 = _static_135757073556240

                        # <Value u'not:menuItem/extra/hideChildren | not:submenu | nothing' (63:26)> -> __condition
                        __token = 2765
                        try:
                            __zt_tmp = __attrs_135757073559184
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('not', u'menuItem/extra/hideChildren | not:submenu | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="nav-item dropdown" aria-hidden="true">\n\n          ')

                            # <Static value=<_ast.Dict object at 0x7b7868252250> name=None at 7b78682524d0> -> __attrs_135757072274000
                            __attrs_135757072274000 = _static_135757073556048

                            # <a ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\n            ')

                            # <Static value=<_ast.Dict object at 0x7b786c9ed410> name=None at 7b786c9edc50> -> __attrs_135757148640784
                            __attrs_135757148640784 = _static_135757148640272

                            # <Value u'not:menuItem/extra/stateTitle | nothing' (69:29)> -> __condition
                            __token = 3082
                            try:
                                __zt_tmp = __attrs_135757148640784
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('not', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span class="">')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074138192
                                __default_135757074138192 = _DEFAULT_MARKER

                                # <Value u'menuItem/title' (70:27)> -> __cache_135757072277264
                                __token = 3150
                                try:
                                    __zt_tmp = __attrs_135757148640784
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757072277264 = _static_135757244280656('path', u'menuItem/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/title' (70:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78682e0c10> -> __condition
                                __expression = __cache_135757072277264

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\n              Menu Title\n            ')
                                else:
                                    __content = __cache_135757072277264
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>')
                            __append(u'\n            <!-- State Title -->\n            ')

                            # <Static value=<_ast.Dict object at 0x7b786c9edf90> name=None at 7b786c9ed550> -> __attrs_135757148641104
                            __attrs_135757148641104 = _static_135757148643216

                            # <Value u'menuItem/extra/stateTitle | nothing' (78:29)> -> __condition
                            __token = 3424
                            try:
                                __zt_tmp = __attrs_135757148641104
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'menuItem/extra/stateTitle | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148642768
                                __default_135757148642768 = _DEFAULT_MARKER

                                # <Substitution u'string:${menuItem/extra/class} tb-state' (77:36)> -> __attr_class
                                __token = 3354
                                try:
                                    __zt_tmp = __attrs_135757148641104
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('string', u'${menuItem/extra/class} tb-state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148640656
                                __default_135757148640656 = _DEFAULT_MARKER

                                # <Value u'menuItem/extra/stateTitle' (79:27)> -> __cache_135757148641552
                                __token = 3488
                                try:
                                    __zt_tmp = __attrs_135757148641104
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757148641552 = _static_135757244280656('path', u'menuItem/extra/stateTitle', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'menuItem/extra/stateTitle' (79:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786c9eda90> -> __condition
                                __expression = __cache_135757148641552

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u'\n              State title\n            ')
                                else:
                                    __content = __cache_135757148641552
                                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>')
                            __append(u'\n          </a>\n\n          ')

                            # <Static value=<_ast.Dict object at 0x7b786c9eda10> name=None at 7b786c9ed250> -> __attrs_135757152276624
                            __attrs_135757152276624 = _static_135757148641808

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="dropdown-menu">\n            ')

                            # <Static value=<_ast.Dict object at 0x7b786cd65f90> name=None at 7b786cd65790> -> __attrs_135757152279632
                            __attrs_135757152279632 = _static_135757152280464
                            __backup_subMenuItem_135757166284432 = get('subMenuItem', __marker)

                            # <Value u'submenu' (86:41)> -> __iterator
                            __token = 3786
                            try:
                                __zt_tmp = __attrs_135757152279632
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __iterator = _static_135757244280656('path', u'submenu', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            (__iterator, ____index_135757152277648, ) = getitem('repeat')(u'subMenuItem', __iterator)
                            econtext['subMenuItem'] = None
                            for __item in __iterator:
                                econtext['subMenuItem'] = __item

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152277776
                                __default_135757152277776 = _DEFAULT_MARKER

                                # <Substitution u'string:${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item' (85:39)> -> __attr_class
                                __token = 3655
                                try:
                                    __zt_tmp = __attrs_135757152279632
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('string', u'${menuItem/extra/li_class | nothing} ${subMenuItem/extra/separator} dropdown-item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>\n            ')

                                # <Static value=<_ast.Dict object at 0x7b786ca04d10> name=None at 7b786ca04fd0> -> __attrs_135757073175824
                                __attrs_135757073175824 = _static_135757148736784

                                # <Value u'subMenuItem/action' (94:45)> -> __condition
                                __token = 4209
                                try:
                                    __zt_tmp = __attrs_135757073175824
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('path', u'subMenuItem/action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <a ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<a')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148736656
                                    __default_135757148736656 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/action' (90:35)> -> __attr_href
                                    __token = 3929
                                    try:
                                        __zt_tmp = __attrs_135757073175824
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_href = _static_135757244280656('path', u'subMenuItem/action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                    if (__attr_href is not None):
                                        __append((u' href="%s"' % __attr_href))
                                    __append(u' aria-expanded="false"')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073178448
                                    __default_135757073178448 = _DEFAULT_MARKER

                                    # <Translate msgid=None node=<Substitution u'subMenuItem/description' (91:35)> at 7b78681f54d0> -> __attr_title

                                    # <Substitution u'subMenuItem/description' (91:35)> -> __attr_title
                                    __token = 3984
                                    try:
                                        __zt_tmp = __attrs_135757073175824
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_title = _static_135757244280656('path', u'subMenuItem/description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                    if (__attr_title is not None):
                                        __append((u' title="%s"' % __attr_title))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073176336
                                    __default_135757073176336 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/id | nothing' (92:31)> -> __attr_id
                                    __token = 4041
                                    try:
                                        __zt_tmp = __attrs_135757073175824
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('path', u'subMenuItem/extra/id | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073176272
                                    __default_135757073176272 = _DEFAULT_MARKER

                                    # <Substitution u'string:${subMenuItem/extra/class|nothing} nav-link' (93:33)> -> __attr_class
                                    __token = 4108
                                    try:
                                        __zt_tmp = __attrs_135757073175824
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_class = _static_135757244280656('string', u'${subMenuItem/extra/class|nothing} nav-link', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_class is not None):
                                        __append((u' class="%s"' % __attr_class))
                                    __append(u'>\n              ')

                                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073176592
                                    __attrs_135757073176592 = _static_135757327983760

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073178320
                                    __default_135757073178320 = _DEFAULT_MARKER

                                    # <Value u'subMenuItem/title' (96:35)> -> __cache_135757073175184
                                    __token = 4290
                                    try:
                                        __zt_tmp = __attrs_135757073176592
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __cache_135757073175184 = _static_135757244280656('path', u'subMenuItem/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                    # <BinOp left=<Value u'subMenuItem/title' (96:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78681f5690> -> __condition
                                    __expression = __cache_135757073175184

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                    __value = _DEFAULT_MARKER
                                    __condition = (__expression is __value)
                                    if __condition:
                                        __append(u'\n                Title\n              ')
                                    else:
                                        __content = __cache_135757073175184
                                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        __content = __convert(__content)
                                        if (__content is not None):
                                            __append(__content)
                                    __append(u'\n            </a>')
                                __append(u'\n            ')

                                # <Static value=<_ast.Dict object at 0x7b78681f5110> name=None at 7b78681f5d90> -> __attrs_135757148768720
                                __attrs_135757148768720 = _static_135757073174800

                                # <Value u'not:subMenuItem/action' (104:29)> -> __condition
                                __token = 4593
                                try:
                                    __zt_tmp = __attrs_135757148768720
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __condition = _static_135757244280656('not', u'subMenuItem/action', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                if __condition:

                                    # <span ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<span')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073174672
                                    __default_135757073174672 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/id | nothing' (102:33)> -> __attr_id
                                    __token = 4461
                                    try:
                                        __zt_tmp = __attrs_135757148768720
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_id = _static_135757244280656('path', u'subMenuItem/extra/id | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_id is not None):
                                        __append((u' id="%s"' % __attr_id))

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148768784
                                    __default_135757148768784 = _DEFAULT_MARKER

                                    # <Substitution u'subMenuItem/extra/class | nothing' (103:35)> -> __attr_class
                                    __token = 4528
                                    try:
                                        __zt_tmp = __attrs_135757148768720
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __attr_class = _static_135757244280656('path', u'subMenuItem/extra/class | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                    if (__attr_class is not None):
                                        __append((u' class="%s"' % __attr_class))
                                    __append(u'>\n              ')

                                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148781968
                                    __attrs_135757148781968 = _static_135757327983760

                                    # <span ... (0:0)
                                    # --------------------------------------------------------
                                    __append(u'<span>')

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148779152
                                    __default_135757148779152 = _DEFAULT_MARKER

                                    # <Value u'subMenuItem/title' (107:39)> -> __cache_135757148768656
                                    __token = 4711
                                    try:
                                        __zt_tmp = __attrs_135757148781968
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __cache_135757148768656 = _static_135757244280656('path', u'subMenuItem/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                    # <BinOp left=<Value u'subMenuItem/title' (107:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ca0c950> -> __condition
                                    __expression = __cache_135757148768656

                                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                    __value = _DEFAULT_MARKER
                                    __condition = (__expression is __value)
                                    if __condition:
                                        __append(u'\n                Title\n              ')
                                    else:
                                        __content = __cache_135757148768656
                                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                        __content = __convert(__content)
                                        if (__content is not None):
                                            __append(__content)
                                    __append(u'</span>\n            </span>')
                                __append(u'\n          </div>')
                                ____index_135757152277648 -= 1
                                if (____index_135757152277648 > 0):
                                    __append('\n            ')
                            if (__backup_subMenuItem_135757166284432 is __marker):
                                del econtext['subMenuItem']
                            else:
                                econtext['subMenuItem'] = __backup_subMenuItem_135757166284432
                            __append(u'\n        </div>\n      </div>')
                        __append(u'\n\n    </li>')
                    if (__backup_identifier_135757074239824 is __marker):
                        del econtext['identifier']
                    else:
                        econtext['identifier'] = __backup_identifier_135757074239824
                    if (__backup_has_dropdown_135757074313744 is __marker):
                        del econtext['has_dropdown']
                    else:
                        econtext['has_dropdown'] = __backup_has_dropdown_135757074313744
                    if (__backup_submenu_135757153655376 is __marker):
                        del econtext['submenu']
                    else:
                        econtext['submenu'] = __backup_submenu_135757153655376
                    __append(u'\n  ')
                    ____index_135757073133136 -= 1
                    if (____index_135757073133136 > 0):
                        __append('')
                if (__backup_menuItem_135757163048528 is __marker):
                    del econtext['menuItem']
                else:
                    econtext['menuItem'] = __backup_menuItem_135757163048528
                __append(u'\n')
                __i18n_domain = __previous_i18n_domain_135757166674256
            if (__backup_menu_135757153653968 is __marker):
                del econtext['menu']
            else:
                econtext['menu'] = __backup_menu_135757153653968
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }