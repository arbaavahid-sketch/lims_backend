# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.portlets-4.4.9-py2.7.egg/plone/app/portlets/browser/templates/topbar-manage-portlets.pt'

__tokens = {356: (u'context/@@plone', 9, 53), 469: (u'context/absolute_url', 13, 33), 616: (u'context/@@view_get_menu/plone_contentmenu_portletmanager', 15, 37), 719: (u'context/absolute_url', 16, 45), 782: (u"python:request['ACTUAL_URL']", 17, 40), 964: (u'portlet_menu', 19, 33), 1019: (u"python:item['title'].lower().replace(' ', '.')", 20, 40), 1109: (u' python:item_id == view.manager_nam', 21, 42), 1269: (u'is_current', 24, 30), 1185: (u'item/action', 22, 38), 1227: (u'item/title', 23, 29), 1665: (u'context/Title', 34, 48), 1757: (u'context/absolute_url', 38, 29), 1926: (u'plone_view/isDefaultPageInFolder|nothing', 45, 24), 2447: (u'string:${context/aq_inner/aq_parent/absolute_url}/@@topbar-manage-portlets/${view/manager_name}', 56, 33), 2603: (u'view/manager_name', 60, 21), 2661: (u'view/render_edit_manager_portlets', 61, 33), 231: (u'context/main_template/macros/master', 5, 23), 231: (u'context/main_template/macros/master', 5, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_131357843145488 = {u'value': u"python:request['ACTUAL_URL']", }
_static_131358013585936 = __C2ZContextWrapper
_static_131357841637648 = {u'href': u'', u'class': u'portlets-link-to-parent', }
_static_131357841602896 = {u'class': u'sr-only', u'for': u'quicknav', }
_static_131357841603920 = {u'value': u'item/action', }
_static_131357841597648 = {u'class': u'quicknav-wrapper', }
_static_131357841598288 = {u'class': u'documentFirstHeading', }
_static_131357841633040 = {u'href': u'context/absolute_url', u'class': u'link-parent', }
_static_131358013585552 = __compile_zt_expr
_static_131357922231568 = u'master'
_static_131357841634448 = {u'role': u'status', u'class': u'portalMessage info', }
_static_131357841599312 = {u'action': u'context/absolute_url', u'method': u'post', }
_static_131358097278096 = {}
_static_131357843077584 = {u'data-context-url': u'context/absolute_url', u'id': u'quicknav', u'name': u':action', u'class': u'switch-portlet-manager pull-right', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357922325776
            __attrs_131357922325776 = _static_131358097278096
            __previous_i18n_domain_131357922325712 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_131357891834576 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7778264b0510> name=None at 7778264b0a90> -> __value
            __value = _static_131357922231568
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357843133840
                __attrs_131357843133840 = _static_131358097278096
                __backup_plone_view_131357843043216 = get('plone_view', __marker)

                # <Value u'context/@@plone' (9:53)> -> __value
                __token = 356
                try:
                    __zt_tmp = __attrs_131357843133840
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_131358013585552('path', u'context/@@plone', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                econtext['plone_view'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7778217ca4d0> name=None at 77782184bd50> -> __attrs_131357841596688
                __attrs_131357841596688 = _static_131357841597648

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="quicknav-wrapper">\n      ')

                # <Static value=<_ast.Dict object at 0x7778217cab50> name=None at 7778217ca390> -> __attrs_131357841598480
                __attrs_131357841598480 = _static_131357841599312

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form method="post"')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841597712
                __default_131357841597712 = _DEFAULT_MARKER

                # <Substitution u'context/absolute_url' (13:33)> -> __attr_action
                __token = 469
                try:
                    __zt_tmp = __attrs_131357841598480
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_action = _static_131358013585552('path', u'context/absolute_url', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_action is not None):
                    __append((u' action="%s"' % __attr_action))
                __append(u'>\n        ')

                # <Static value=<_ast.Dict object at 0x7778219339d0> name=None at 777821933a10> -> __attrs_131357843148624
                __attrs_131357843148624 = _static_131357843077584
                __backup_portlet_menu_131357841597008 = get('portlet_menu', __marker)

                # <Value u'context/@@view_get_menu/plone_contentmenu_portletmanager' (15:37)> -> __value
                __token = 616
                try:
                    __zt_tmp = __attrs_131357843148624
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_131358013585552('path', u'context/@@view_get_menu/plone_contentmenu_portletmanager', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                econtext['portlet_menu'] = __value

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select id="quicknav" class="switch-portlet-manager pull-right" name=":action"')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357843147792
                __default_131357843147792 = _DEFAULT_MARKER

                # <Substitution u'context/absolute_url' (16:45)> -> __attr_data_context_url
                __token = 719
                try:
                    __zt_tmp = __attrs_131357843148624
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_context_url = _static_131358013585552('path', u'context/absolute_url', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_data_context_url = __quote(__attr_data_context_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_context_url is not None):
                    __append((u' data-context-url="%s"' % __attr_data_context_url))
                __append(u'>\n          ')

                # <Static value=<_ast.Dict object at 0x777821944310> name=None at 777821944b90> -> __attrs_131357841602256
                __attrs_131357841602256 = _static_131357843145488

                # <option ... (0:0)
                # --------------------------------------------------------
                __append(u'<option')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357843145232
                __default_131357843145232 = _DEFAULT_MARKER

                # <Substitution u"python:request['ACTUAL_URL']" (17:40)> -> __attr_value
                __token = 782
                try:
                    __zt_tmp = __attrs_131357841602256
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_131358013585552('python', u"request['ACTUAL_URL']", econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' >')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841600656
                __attrs_131357841600656 = _static_131358097278096
                __stream_131357841603024 = []
                __append_131357841603024 = __stream_131357841603024.append
                __append_131357841603024(u'Other portlet managers')
                __msgid_131357841603024 = __re_whitespace(''.join(__stream_131357841603024)).strip()
                if u'title_switch_portlet_managers':
                    __append(translate(u'title_switch_portlet_managers', mapping=None, default=__msgid_131357841603024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'&hellip;</option>\n          ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841602960
                __attrs_131357841602960 = _static_131358097278096
                __backup_item_131357843147920 = get('item', __marker)

                # <Value u'portlet_menu' (19:33)> -> __iterator
                __token = 964
                try:
                    __zt_tmp = __attrs_131357841602960
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_131358013585552('path', u'portlet_menu', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                (__iterator, ____index_131357841601680, ) = getitem('repeat')(u'item', __iterator)
                econtext['item'] = None
                for __item in __iterator:
                    econtext['item'] = __item
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7778217cbd50> name=None at 7778217cbcd0> -> __attrs_131357841629584
                    __attrs_131357841629584 = _static_131357841603920
                    __backup_item_id_131357841603216 = get('item_id', __marker)

                    # <Value u"python:item['title'].lower().replace(' ', '.')" (20:40)> -> __value
                    __token = 1019
                    try:
                        __zt_tmp = __attrs_131357841629584
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_131358013585552('python', u"item['title'].lower().replace(' ', '.')", econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                    econtext['item_id'] = __value
                    __backup_is_current_131357843148752 = get('is_current', __marker)

                    # <Value u'python:item_id == view.manager_name' (21:42)> -> __value
                    __token = 1109
                    try:
                        __zt_tmp = __attrs_131357841629584
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_131358013585552('python', u'item_id == view.manager_name', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                    econtext['is_current'] = __value

                    # <Negate value=<Value u'is_current' (24:30)> at 7778217cbfd0> -> __cache_131357841604560

                    # <Value u'is_current' (24:30)> -> __cache_131357841604560
                    __token = 1269
                    try:
                        __zt_tmp = __attrs_131357841629584
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_131357841604560 = _static_131358013585552('path', u'is_current', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                    __cache_131357841604560 = not __cache_131357841604560
                    __condition = __cache_131357841604560
                    if __condition:

                        # <option ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<option')

                        # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841604240
                        __default_131357841604240 = _DEFAULT_MARKER

                        # <Substitution u'item/action' (22:38)> -> __attr_value
                        __token = 1185
                        try:
                            __zt_tmp = __attrs_131357841629584
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_131358013585552('path', u'item/action', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u'>')

                    # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841603664
                    __default_131357841603664 = _DEFAULT_MARKER

                    # <Value u'item/title' (23:29)> -> __cache_131357841602000
                    __token = 1227
                    try:
                        __zt_tmp = __attrs_131357841629584
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_131357841602000 = _static_131358013585552('path', u'item/title', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                    # <BinOp left=<Value u'item/title' (23:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778217cbb90> -> __condition
                    __expression = __cache_131357841602000

                    # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Plone Leftcolumn')
                    else:
                        __content = __cache_131357841602000
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __condition = __cache_131357841604560
                    if __condition:
                        __append(u'</option>')
                    if (__backup_is_current_131357843148752 is __marker):
                        del econtext['is_current']
                    else:
                        econtext['is_current'] = __backup_is_current_131357843148752
                    if (__backup_item_id_131357841603216 is __marker):
                        del econtext['item_id']
                    else:
                        econtext['item_id'] = __backup_item_id_131357841603216
                    __append(u'\n          ')
                    ____index_131357841601680 -= 1
                    if (____index_131357841601680 > 0):
                        __append('')
                if (__backup_item_131357843147920 is __marker):
                    del econtext['item']
                else:
                    econtext['item'] = __backup_item_131357843147920
                __append(u'\n        </select>')
                if (__backup_portlet_menu_131357841597008 is __marker):
                    del econtext['portlet_menu']
                else:
                    econtext['portlet_menu'] = __backup_portlet_menu_131357841597008
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7778217cb950> name=None at 7778217cbb10> -> __attrs_131357841630736
                __attrs_131357841630736 = _static_131357841602896

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label for="quicknav" class="sr-only">')
                __stream_131357841603408 = []
                __append_131357841603408 = __stream_131357841603408.append
                __append_131357841603408(u'Other portlet managers')
                __msgid_131357841603408 = __re_whitespace(''.join(__stream_131357841603408)).strip()
                if u'title_switch_portlet_managers':
                    __append(translate(u'title_switch_portlet_managers', mapping=None, default=__msgid_131357841603408, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n      </form>\n    </div>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7778217ca750> name=None at 7778217ca8d0> -> __attrs_131357841631440
                __attrs_131357841631440 = _static_131357841598288

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')
                __stream_131357842986960_context_title = ''
                __stream_131357841597200 = []
                __append_131357841597200 = __stream_131357841597200.append
                __append_131357841597200(u'\n      Manage portlets for\n      ')
                __stream_131357842986960_context_title = []
                __append_131357842986960_context_title = __stream_131357842986960_context_title.append

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841632784
                __attrs_131357841632784 = _static_131358097278096

                # <q ... (0:0)
                # --------------------------------------------------------
                __append_131357842986960_context_title(u'<q>')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841632400
                __default_131357841632400 = _DEFAULT_MARKER

                # <Value u'context/Title' (34:48)> -> __cache_131357841632016
                __token = 1665
                try:
                    __zt_tmp = __attrs_131357841632784
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357841632016 = _static_131358013585552('path', u'context/Title', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/Title' (34:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778217d2bd0> -> __condition
                __expression = __cache_131357841632016

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append_131357842986960_context_title(u'title')
                else:
                    __content = __cache_131357841632016
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append_131357842986960_context_title(__content)
                __append_131357842986960_context_title(u'</q>')
                __append_131357841597200(u'${context_title}')
                __stream_131357842986960_context_title = ''.join(__stream_131357842986960_context_title)
                __append_131357841597200(u'\n    ')
                __msgid_131357841597200 = __re_whitespace(''.join(__stream_131357841597200)).strip()
                if u'title_manage_contextual_portlets':
                    __append(translate(u'title_manage_contextual_portlets', mapping={u'context_title': __stream_131357842986960_context_title, }, default=__msgid_131357841597200, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h1>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7778217d2f10> name=None at 7778217d2a10> -> __attrs_131357841634128
                __attrs_131357841634128 = _static_131357841633040

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a class="link-parent"')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841633808
                __default_131357841633808 = _DEFAULT_MARKER

                # <Substitution u'context/absolute_url' (38:29)> -> __attr_href
                __token = 1757
                try:
                    __zt_tmp = __attrs_131357841634128
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_131358013585552('path', u'context/absolute_url', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>')
                __stream_131357841631824 = []
                __append_131357841631824 = __stream_131357841631824.append
                __append_131357841631824(u'\n      Return\n    ')
                __msgid_131357841631824 = __re_whitespace(''.join(__stream_131357841631824)).strip()
                if u'return_to_view':
                    __append(translate(u'return_to_view', mapping=None, default=__msgid_131357841631824, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</a>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7778217d3490> name=None at 7778217d34d0> -> __attrs_131357841635472
                __attrs_131357841635472 = _static_131357841634448

                # <Value u'plone_view/isDefaultPageInFolder|nothing' (45:24)> -> __condition
                __token = 1926
                try:
                    __zt_tmp = __attrs_131357841635472
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_131358013585552('path', u'plone_view/isDefaultPageInFolder|nothing', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage info" role="status">\n      ')

                    # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841636368
                    __attrs_131357841636368 = _static_131358097278096

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>\n          Info\n      </strong>\n      ')

                    # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841637008
                    __attrs_131357841637008 = _static_131358097278096

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div>')
                    __stream_131357895424192_go_here = ''
                    __stream_131357841636688 = []
                    __append_131357841636688 = __stream_131357841636688.append
                    __append_131357841636688(u'\n          You are managing the portlets of the default view of a container. If\n          you wanted to manage the portlets of the container itself,\n        ')
                    __stream_131357895424192_go_here = []
                    __append_131357895424192_go_here = __stream_131357895424192_go_here.append

                    # <Static value=<_ast.Dict object at 0x7778217d4110> name=None at 77782645d990> -> __attrs_131357841638736
                    __attrs_131357841638736 = _static_131357841637648

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_131357895424192_go_here(u'<a')

                    # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841638224
                    __default_131357841638224 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/aq_inner/aq_parent/absolute_url}/@@topbar-manage-portlets/${view/manager_name}' (56:33)> -> __attr_href
                    __token = 2447
                    try:
                        __zt_tmp = __attrs_131357841638736
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_131358013585552('string', u'${context/aq_inner/aq_parent/absolute_url}/@@topbar-manage-portlets/${view/manager_name}', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_131357895424192_go_here((u' href="%s"' % __attr_href))
                    __append_131357895424192_go_here(u' class="portlets-link-to-parent">')
                    __stream_131357841637584 = []
                    __append_131357841637584 = __stream_131357841637584.append
                    __append_131357841637584(u'go here')
                    __msgid_131357841637584 = __re_whitespace(''.join(__stream_131357841637584)).strip()
                    if u'label_manage_portlets_default_view_container_go_here':
                        __append_131357895424192_go_here(translate(u'label_manage_portlets_default_view_container_go_here', mapping=None, default=__msgid_131357841637584, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_131357895424192_go_here(u'</a>')
                    __append_131357841636688(u'${go_here}')
                    __stream_131357895424192_go_here = ''.join(__stream_131357895424192_go_here)
                    __append_131357841636688(u'.\n      ')
                    __msgid_131357841636688 = __re_whitespace(''.join(__stream_131357841636688)).strip()
                    if u'label_manage_portlets_default_view_container':
                        __append(translate(u'label_manage_portlets_default_view_container', mapping={u'go_here': __stream_131357895424192_go_here, }, default=__msgid_131357841636688, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</div>\n    </div>')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841639440
                __attrs_131357841639440 = _static_131358097278096

                # <h2 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h2>')

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841639056
                __default_131357841639056 = _DEFAULT_MARKER

                # <Value u'view/manager_name' (60:21)> -> __cache_131357841635856
                __token = 2603
                try:
                    __zt_tmp = __attrs_131357841639440
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357841635856 = _static_131358013585552('path', u'view/manager_name', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/manager_name' (60:21)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778217d3a90> -> __condition
                __expression = __cache_131357841635856

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_131357841635856
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</h2>\n    ')

                # <Static value=<_ast.Dict object at 0x777830ba0490> name=None at 777830ba0ed0> -> __attrs_131357841640336
                __attrs_131357841640336 = _static_131358097278096

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __default_131357841640208
                __default_131357841640208 = _DEFAULT_MARKER

                # <Value u'view/render_edit_manager_portlets' (61:33)> -> __cache_131357841639888
                __token = 2661
                try:
                    __zt_tmp = __attrs_131357841640336
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_131357841639888 = _static_131358013585552('path', u'view/render_edit_manager_portlets', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/render_edit_manager_portlets' (61:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 777830bb5110> at 7778217d4a50> -> __condition
                __expression = __cache_131357841639888

                # <Symbol value=<DEFAULT> at 777830bb5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_131357841639888
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n\n  </div>')
                if (__backup_plone_view_131357843043216 is __marker):
                    del econtext['plone_view']
                else:
                    econtext['plone_view'] = __backup_plone_view_131357843043216
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/main_template/macros/master' (5:23)> -> __macro
            __token = 231
            try:
                __zt_tmp = __attrs_131357922325776
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_131358013585552('path', u'context/main_template/macros/master', econtext=econtext)(_static_131358013585936(econtext, __zt_tmp))
            __token = 231
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_131357891834576 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_131357891834576
            __i18n_domain = __previous_i18n_domain_131357922325712
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }