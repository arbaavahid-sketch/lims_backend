# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.Archetypes-1.16.6-py2.7.egg/Products/Archetypes/skins/archetypes/widgets/field.pt'

__tokens = {2968: (u'python:widget.isVisible(here, mode)', 66, 29), 3038: (u' python:field.getEditAccessor(here', 67, 33), 3103: (u'd python:(widget.populate and (edit_accessor or accessor)) or No', 68, 28), 3194: (u'ue python:getMethod and getMetho', 69, 23), 3253: (u'lue python:request.get(fieldName, value) if widget.postback else v', 70, 22), 3347: (u'rtal python:context.portal_url.getPortalObj', 71, 22), 3424: (u'ition python:field.widget.testCondition(context.aq_inner.getParentNode(), portal, co', 72, 27), 3538: (u'ror_id python:errors.get(fie', 73, 22), 3618: (u"python:visState == 'visible' and visCondition", 75, 21), 3733: (u'context/@@kss_field_decorator_view', 77, 40), 3807: (u' nocall:kssClassesView/getKssClasse', 78, 38), 3878: (u's python:getKssClasses(fieldNam', 79, 33), 3942: (u"python:('edit' in widget.modes and 'w' in field.mode and field.checkPermission('w',here))\n                                    or (mode=='search' and field.checkPermission('r',here))", 80, 28), 4160: (u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + kss_class", 82, 35), 4327: (u" python: 'archetypes-fieldname-' + fieldNam", 83, 31), 4409: (u'd context/UID|nothi', 84, 36), 4473: (u'me fieldN', 85, 41), 4596: (u'nothing', 87, 38), 4926: (u'not: widget/render_own_label | nothing', 92, 38), 5046: (u'python:fieldName', 94, 39), 5100: (u'python:widget.Label(here)', 95, 35), 5247: (u'field/required', 98, 37), 5462: (u'python:widget.Description(here)', 102, 45), 5592: (u'string:${fieldName}_help', 104, 40), 5539: (u'description', 103, 44), 5782: (u'field/workflowable | nothing', 110, 31), 5923: (u'context/portal_workflow', 114, 35), 5978: (u' python:accessor(', 115, 30), 6036: (u"e python:wf_tool.getInfoFor(obj, 'review_state', '", 116, 38), 6126: (u'string:${obj/absolute_url}/content_status_history', 117, 36), 6213: (u" python:test(review_state, review_state, 'private'", 118, 36), 6294: (u'review_state', 119, 28), 6436: (u'error_id', 124, 28), 6612: (u"python: visState == 'hidden'", 129, 32), 6707: (u"python:path('context/%s/macros' % widget.macro)", 131, 37), 6800: (u' context/widgets/field/macros/hidde', 132, 44), 6873: (u'o widget_macro/hidden | default_hidden_mac', 133, 35), 6978: (u'hidden_macro', 135, 32), 6978: (u'hidden_macro', 135, 32), 436: (u'python:context.widget(field.getName(), mode=mode, use_label=1)', 14, 32), 532: (u' context/widgets/field/macro', 15, 32), 593: (u'o view_macros/label | label_macro | field_macros/lab', 16, 30), 677: (u'ro view_macros/data | data_macro | field_macros/d', 17, 28), 756: (u'ate python:widget.isVisible(here, m', 18, 25), 819: (u'rtal python:context.portal_url.getPortalObj', 19, 22), 896: (u'ition python:field.widget.testCondition(context.aq_inner.getParentNode(), portal, co', 20, 27), 1032: (u"python:visState == 'visible' and visCondition", 22, 21), 1124: (u"python:'view' in widget.modes and 'r' in field.mode and field.checkPermission('r',here)", 24, 23), 1253: (u'use_label | nothing', 25, 39), 1315: (u'label_macro', 26, 40), 1315: (u'label_macro', 26, 40), 1398: (u'data_macro|default', 28, 37), 1398: (u'data_macro|default', 28, 37), 1613: (u'python:widget.Label(here)', 34, 71), 1689: (u'field/workflowable | nothing', 35, 27), 1809: (u'context/portal_workflow', 39, 31), 1860: (u' python:accessor(', 40, 26), 1914: (u"e python:wf_tool.getInfoFor(obj, 'review_state', '", 41, 34), 2000: (u'string:${obj/absolute_url}/content_status_history', 42, 32), 2083: (u" python:test(review_state, review_state, 'private'", 43, 32), 2160: (u'review_state', 44, 24), 7220: (u'fieldName', 145, 34), 7265: (u' valu', 146, 34), 2347: (u'widget_view', 53, 30), 2347: (u'widget_view', 53, 30), 2445: (u'fieldName|field/getName', 56, 57), 2530: (u" python:field.getType().split('.')[-1", 57, 60), 2619: (u'd context/UID|nothi', 58, 49), 2672: (u'string:field ArchetypesField-${fieldtypename}', 59, 30), 2745: (u' string:archetypes-fieldname-${fieldName}-${uid', 60, 26), 2838: (u'context/widgets/field/macros/base_view', 61, 42), 2838: (u'context/widgets/field/macros/base_view', 61, 42)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756868963600 = u'hidden_macro'
_static_135757075223120 = u'label_macro'
_static_135757072723856 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135756868961232 = {u'type': u'hidden', u'name': u'', u'value': u'', }
_static_135757075191888 = {u'class': u'fieldErrorBox', }
_static_135757071432528 = {u'href': u'#', u'class': u"python:test(review_state, review_state, 'private')", }
_static_135757071438544 = {u'class': u'string:field ArchetypesField-${fieldtypename}', u'id': u'string:archetypes-fieldname-${fieldName}-${uid}', }
_static_135757244280656 = __compile_zt_expr
_static_135757150054928 = {u'class': u'required', u'title': u'Required', }
_static_135757071441488 = {u'href': u'#', u'class': u"python:test(review_state, review_state, 'private')", }
_static_135756869325200 = {u'class': u'formQuestion', u'for': u'python:fieldName', }
_static_135757072613456 = u'base_view'
_static_135757075277392 = {u'class': u'formQuestion', }
_static_135757073581328 = {u'data-fieldname': u'fieldName', u'data-uid': u'context/UID|nothing', u'class': u'field', u'id': u"python: 'archetypes-fieldname-' + fieldName", }
_static_135757075713744 = u'data_macro|default'
_static_135757327983760 = {}
_static_135757075920144 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_135757071438096 = u'widget_view'
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_widget_body_label_prefix = econtext[u'__slot_widget_body_label_prefix'].pop()
        except:
            __slot_widget_body_label_prefix = None

        try:
            __slot_widget_body = econtext[u'__slot_widget_body'].pop()
        except:
            __slot_widget_body = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072614672
            __attrs_135757072614672 = _static_135757327983760
            __backup_visState_135756867144528 = get('visState', __marker)

            # <Value u'python:widget.isVisible(here, mode)' (66:29)> -> __value
            __token = 2968
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'widget.isVisible(here, mode)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['visState'] = __value
            __backup_edit_accessor_135757075711696 = get('edit_accessor', __marker)

            # <Value u'python:field.getEditAccessor(here)' (67:33)> -> __value
            __token = 3038
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.getEditAccessor(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['edit_accessor'] = __value
            __backup_getMethod_135757075712656 = get('getMethod', __marker)

            # <Value u'python:(widget.populate and (edit_accessor or accessor)) or None' (68:28)> -> __value
            __token = 3103
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'(widget.populate and (edit_accessor or accessor)) or None', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['getMethod'] = __value
            __backup_value_135757075712912 = get('value', __marker)

            # <Value u'python:getMethod and getMethod()' (69:23)> -> __value
            __token = 3194
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'getMethod and getMethod()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_value_135757075710608 = get('value', __marker)

            # <Value u'python:request.get(fieldName, value) if widget.postback else value' (70:22)> -> __value
            __token = 3253
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'request.get(fieldName, value) if widget.postback else value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_portal_135756867144144 = get('portal', __marker)

            # <Value u'python:context.portal_url.getPortalObject()' (71:22)> -> __value
            __token = 3347
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.portal_url.getPortalObject()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal'] = __value
            __backup_visCondition_135757075713168 = get('visCondition', __marker)

            # <Value u'python:field.widget.testCondition(context.aq_inner.getParentNode(), portal, context)' (72:27)> -> __value
            __token = 3424
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.widget.testCondition(context.aq_inner.getParentNode(), portal, context)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['visCondition'] = __value
            __backup_error_id_135757075226448 = get('error_id', __marker)

            # <Value u'python:errors.get(fieldName)' (73:22)> -> __value
            __token = 3538
            try:
                __zt_tmp = __attrs_135757072614672
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'errors.get(fieldName)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['error_id'] = __value
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073581264
            __attrs_135757073581264 = _static_135757327983760

            # <Value u"python:visState == 'visible' and visCondition" (75:21)> -> __condition
            __token = 3618
            try:
                __zt_tmp = __attrs_135757073581264
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u"visState == 'visible' and visCondition", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b7868258510> name=None at 7b7868258a50> -> __attrs_135757075857744
                __attrs_135757075857744 = _static_135757073581328
                __backup_kssClassesView_135757072615248 = get('kssClassesView', __marker)

                # <Value u'context/@@kss_field_decorator_view' (77:40)> -> __value
                __token = 3733
                try:
                    __zt_tmp = __attrs_135757075857744
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/@@kss_field_decorator_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['kssClassesView'] = __value
                __backup_getKssClasses_135757073582480 = get('getKssClasses', __marker)

                # <Value u'nocall:kssClassesView/getKssClasses' (78:38)> -> __value
                __token = 3807
                try:
                    __zt_tmp = __attrs_135757075857744
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('nocall', u'kssClassesView/getKssClasses', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['getKssClasses'] = __value
                __backup_kss_class_135757073581904 = get('kss_class', __marker)

                # <Value u'python:getKssClasses(fieldName)' (79:33)> -> __value
                __token = 3878
                try:
                    __zt_tmp = __attrs_135757075857744
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'getKssClasses(fieldName)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['kss_class'] = __value

                # <Value u"python:('edit' in widget.modes and 'w' in field.mode and field.checkPermission('w',here))\n                                    or (mode=='search' and field.checkPermission('r',here))" (80:28)> -> __condition
                __token = 3942
                try:
                    __zt_tmp = __attrs_135757075857744
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u"('edit' in widget.modes and 'w' in field.mode and field.checkPermission('w',here))\n                                    or (mode=='search' and field.checkPermission('r',here))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075858512
                    __default_135757075858512 = _DEFAULT_MARKER

                    # <Substitution u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + kss_class" (82:35)> -> __attr_class
                    __token = 4160
                    try:
                        __zt_tmp = __attrs_135757075857744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_135757244280656('python', u" test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + kss_class", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'field', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075858320
                    __default_135757075858320 = _DEFAULT_MARKER

                    # <Substitution u"python: 'archetypes-fieldname-' + fieldName" (83:31)> -> __attr_id
                    __token = 4327
                    try:
                        __zt_tmp = __attrs_135757075857744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_135757244280656('python', u" 'archetypes-fieldname-' + fieldName", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075858832
                    __default_135757075858832 = _DEFAULT_MARKER

                    # <Substitution u'context/UID|nothing' (84:36)> -> __attr_data_uid
                    __token = 4409
                    try:
                        __zt_tmp = __attrs_135757075857744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_uid = _static_135757244280656('path', u'context/UID|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_data_uid = __quote(__attr_data_uid, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_uid is not None):
                        __append((u' data-uid="%s"' % __attr_data_uid))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075860816
                    __default_135757075860816 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (85:41)> -> __attr_data_fieldname
                    __token = 4473
                    try:
                        __zt_tmp = __attrs_135757075857744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_fieldname = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_data_fieldname = __quote(__attr_data_fieldname, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_fieldname is not None):
                        __append((u' data-fieldname="%s"' % __attr_data_fieldname))
                    __append(u'>\n          ')
                    if (__slot_widget_body_label_prefix is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075860944
                        __attrs_135757075860944 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span></span>')
                    else:
                        __slot_widget_body_label_prefix(__stream, econtext.copy(), rcontext)
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757163057488
                    __attrs_135757163057488 = _static_135757327983760

                    # <Value u'nothing' (87:38)> -> __condition
                    __token = 4596
                    try:
                        __zt_tmp = __attrs_135757163057488
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            Label insertion for the selection and multi-selection widgets is deferred to the widget, as they must\n            consider their format (checkbox, radio, select box ...) to correctly format the label to meet\n            accessibility standards.\n          ')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869327888
                    __attrs_135756869327888 = _static_135757327983760

                    # <Value u'not: widget/render_own_label | nothing' (92:38)> -> __condition
                    __token = 4926
                    try:
                        __zt_tmp = __attrs_135756869327888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('not', u' widget/render_own_label | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            ')

                        # <Static value=<_ast.Dict object at 0x7b785bf8d190> name=None at 7b785bf8d350> -> __attrs_135756869327952
                        __attrs_135756869327952 = _static_135756869325200

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label class="formQuestion"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869326800
                        __default_135756869326800 = _DEFAULT_MARKER

                        # <Substitution u'python:fieldName' (94:39)> -> __attr_for
                        __token = 5046
                        try:
                            __zt_tmp = __attrs_135756869327952
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869328848
                        __attrs_135756869328848 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869326480
                        __default_135756869326480 = _DEFAULT_MARKER

                        # <Value u'python:widget.Label(here)' (95:35)> -> __cache_135756869326864
                        __token = 5100
                        try:
                            __zt_tmp = __attrs_135756869328848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135756869326864 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'python:widget.Label(here)' (95:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf8d1d0> -> __condition
                        __expression = __cache_135756869326864

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span />')
                        else:
                            __content = __cache_135756869326864
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b786cb46a10> name=None at 7b785bf8d5d0> -> __attrs_135757166253008
                        __attrs_135757166253008 = _static_135757150054928

                        # <Value u'field/required' (98:37)> -> __condition
                        __token = 5247
                        try:
                            __zt_tmp = __attrs_135757166253008
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('path', u'field/required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="required"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073558224
                            __default_135757073558224 = _DEFAULT_MARKER

                            # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7b786d0398d0> at 7b786d039f50> -> __attr_title
                            __attr_title = u'Required'
                            __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u' title="%s"' % __attr_title))
                            __append(u'>&nbsp;</span>')
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b7868493510> name=None at 7b7868119650> -> __attrs_135757071431888
                        __attrs_135757071431888 = _static_135757075920144
                        __backup_description_135757075857488 = get('description', __marker)

                        # <Value u'python:widget.Description(here)' (102:45)> -> __value
                        __token = 5462
                        try:
                            __zt_tmp = __attrs_135757071431888
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'widget.Description(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['description'] = __value

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="formHelp"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757155062416
                        __default_135757155062416 = _DEFAULT_MARKER

                        # <Substitution u'string:${fieldName}_help' (104:40)> -> __attr_id
                        __token = 5592
                        try:
                            __zt_tmp = __attrs_135757071431888
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('string', u'${fieldName}_help', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075472272
                        __default_135757075472272 = _DEFAULT_MARKER

                        # <Value u'description' (103:44)> -> __cache_135757136568016
                        __token = 5539
                        try:
                            __zt_tmp = __attrs_135757071431888
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757136568016 = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'description' (103:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cbaa610> -> __condition
                        __expression = __cache_135757136568016

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                  Help\n                ')
                        else:
                            __content = __cache_135757136568016
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>')
                        if (__backup_description_135757075857488 is __marker):
                            del econtext['description']
                        else:
                            econtext['description'] = __backup_description_135757075857488
                        __append(u'\n            </label>\n          ')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869325072
                    __attrs_135756869325072 = _static_135757327983760

                    # <Value u'field/workflowable | nothing' (110:31)> -> __condition
                    __token = 5782
                    try:
                        __zt_tmp = __attrs_135756869325072
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'field/workflowable | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            State:\n            ')

                        # <Static value=<_ast.Dict object at 0x7b786804bb50> name=None at 7b786804b5d0> -> __attrs_135757074213520
                        __attrs_135757074213520 = _static_135757071432528
                        __backup_wf_tool_135756869326992 = get('wf_tool', __marker)

                        # <Value u'context/portal_workflow' (114:35)> -> __value
                        __token = 5923
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'context/portal_workflow', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['wf_tool'] = __value
                        __backup_obj_135757075860240 = get('obj', __marker)

                        # <Value u'python:accessor()' (115:30)> -> __value
                        __token = 5978
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['obj'] = __value
                        __backup_review_state_135756869325584 = get('review_state', __marker)

                        # <Value u"python:wf_tool.getInfoFor(obj, 'review_state', '')" (116:38)> -> __value
                        __token = 6036
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('python', u"wf_tool.getInfoFor(obj, 'review_state', '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['review_state'] = __value

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136195856
                        __default_135757136195856 = _DEFAULT_MARKER

                        # <Substitution u'string:${obj/absolute_url}/content_status_history' (117:36)> -> __attr_href
                        __token = 6126
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('string', u'${obj/absolute_url}/content_status_history', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074210896
                        __default_135757074210896 = _DEFAULT_MARKER

                        # <Substitution u"python:test(review_state, review_state, 'private')" (118:36)> -> __attr_class
                        __token = 6213
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_class = _static_135757244280656('python', u"test(review_state, review_state, 'private')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_class is not None):
                            __append((u' class="%s"' % __attr_class))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071430800
                        __default_135757071430800 = _DEFAULT_MARKER

                        # <Value u'review_state' (119:28)> -> __cache_135757071433680
                        __token = 6294
                        try:
                            __zt_tmp = __attrs_135757074213520
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757071433680 = _static_135757244280656('path', u'review_state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'review_state' (119:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786804b2d0> -> __condition
                        __expression = __cache_135757071433680

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n              review_state\n            ')
                        else:
                            __content = __cache_135757071433680
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</a>')
                        if (__backup_review_state_135756869325584 is __marker):
                            del econtext['review_state']
                        else:
                            econtext['review_state'] = __backup_review_state_135756869325584
                        if (__backup_obj_135757075860240 is __marker):
                            del econtext['obj']
                        else:
                            econtext['obj'] = __backup_obj_135757075860240
                        if (__backup_wf_tool_135756869326992 is __marker):
                            del econtext['wf_tool']
                        else:
                            econtext['wf_tool'] = __backup_wf_tool_135756869326992
                        __append(u'\n          ')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78683e1850> name=None at 7b78683e1410> -> __attrs_135757074493840
                    __attrs_135757074493840 = _static_135757075191888

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="fieldErrorBox">')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075192016
                    __default_135757075192016 = _DEFAULT_MARKER

                    # <Value u'error_id' (124:28)> -> __cache_135757071430096
                    __token = 6436
                    try:
                        __zt_tmp = __attrs_135757074493840
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757071430096 = _static_135757244280656('path', u'error_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'error_id' (124:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868484610> -> __condition
                    __expression = __cache_135757071430096

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Validation Error')
                    else:
                        __content = __cache_135757071430096
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\n          ')
                    if (__slot_widget_body is None):

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071550800
                        __attrs_135757071550800 = _static_135757327983760

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div></div>')
                    else:
                        __slot_widget_body(__stream, econtext.copy(), rcontext)
                    __append(u'\n        </div>')
                if (__backup_kss_class_135757073581904 is __marker):
                    del econtext['kss_class']
                else:
                    econtext['kss_class'] = __backup_kss_class_135757073581904
                if (__backup_getKssClasses_135757073582480 is __marker):
                    del econtext['getKssClasses']
                else:
                    econtext['getKssClasses'] = __backup_getKssClasses_135757073582480
                if (__backup_kssClassesView_135757072615248 is __marker):
                    del econtext['kssClassesView']
                else:
                    econtext['kssClassesView'] = __backup_kssClassesView_135757072615248
                __append(u'\n      ')
            __append(u'\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075857936
            __attrs_135757075857936 = _static_135757327983760

            # <Value u"python: visState == 'hidden'" (129:32)> -> __condition
            __token = 6612
            try:
                __zt_tmp = __attrs_135757075857936
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u" visState == 'hidden'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868963984
                __attrs_135756868963984 = _static_135757327983760
                __backup_widget_macro_135757073582032 = get('widget_macro', __marker)

                # <Value u"python:path('context/%s/macros' % widget.macro)" (131:37)> -> __value
                __token = 6707
                try:
                    __zt_tmp = __attrs_135756868963984
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"path('context/%s/macros' % widget.macro)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['widget_macro'] = __value
                __backup_default_hidden_macro_135757073583952 = get('default_hidden_macro', __marker)

                # <Value u'context/widgets/field/macros/hidden' (132:44)> -> __value
                __token = 6800
                try:
                    __zt_tmp = __attrs_135756868963984
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/widgets/field/macros/hidden', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['default_hidden_macro'] = __value
                __backup_hidden_macro_135757075857680 = get('hidden_macro', __marker)

                # <Value u'widget_macro/hidden | default_hidden_macro' (133:35)> -> __value
                __token = 6873
                try:
                    __zt_tmp = __attrs_135756868963984
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'widget_macro/hidden | default_hidden_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['hidden_macro'] = __value
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868964304
                __attrs_135756868964304 = _static_135757327983760
                __backup_macroname_135757116605536 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x7b785bf34d10> name=None at 7b785bf347d0> -> __value
                __value = _static_135756868963600
                econtext['macroname'] = __value

                # <Value u'hidden_macro' (135:32)> -> __macro
                __token = 6978
                try:
                    __zt_tmp = __attrs_135756868964304
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_135757244280656('path', u'hidden_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __token = 6978
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_135757116605536 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_135757116605536
                __append(u'\n        ')
                if (__backup_hidden_macro_135757075857680 is __marker):
                    del econtext['hidden_macro']
                else:
                    econtext['hidden_macro'] = __backup_hidden_macro_135757075857680
                if (__backup_default_hidden_macro_135757073583952 is __marker):
                    del econtext['default_hidden_macro']
                else:
                    econtext['default_hidden_macro'] = __backup_default_hidden_macro_135757073583952
                if (__backup_widget_macro_135757073582032 is __marker):
                    del econtext['widget_macro']
                else:
                    econtext['widget_macro'] = __backup_widget_macro_135757073582032
                __append(u'\n      ')
            __append(u'\n\n    ')
            if (__backup_error_id_135757075226448 is __marker):
                del econtext['error_id']
            else:
                econtext['error_id'] = __backup_error_id_135757075226448
            if (__backup_visCondition_135757075713168 is __marker):
                del econtext['visCondition']
            else:
                econtext['visCondition'] = __backup_visCondition_135757075713168
            if (__backup_portal_135756867144144 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_135756867144144
            if (__backup_value_135757075710608 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757075710608
            if (__backup_value_135757075712912 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757075712912
            if (__backup_getMethod_135757075712656 is __marker):
                del econtext['getMethod']
            else:
                econtext['getMethod'] = __backup_getMethod_135757075712656
            if (__backup_edit_accessor_135757075711696 is __marker):
                del econtext['edit_accessor']
            else:
                econtext['edit_accessor'] = __backup_edit_accessor_135757075711696
            if (__backup_visState_135756867144528 is __marker):
                del econtext['visState']
            else:
                econtext['visState'] = __backup_visState_135756867144528
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_base_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867144400
            __attrs_135756867144400 = _static_135757327983760
            __backup_widget_view_135757075215312 = get('widget_view', __marker)

            # <Value u'python:context.widget(field.getName(), mode=mode, use_label=1)' (14:32)> -> __value
            __token = 436
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.widget(field.getName(), mode=mode, use_label=1)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['widget_view'] = __value
            __backup_field_macros_135757151840336 = get('field_macros', __marker)

            # <Value u'context/widgets/field/macros' (15:32)> -> __value
            __token = 532
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/widgets/field/macros', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['field_macros'] = __value
            __backup_label_macro_135756867143568 = get('label_macro', __marker)

            # <Value u'view_macros/label | label_macro | field_macros/label' (16:30)> -> __value
            __token = 593
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view_macros/label | label_macro | field_macros/label', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['label_macro'] = __value
            __backup_data_macro_135756867142864 = get('data_macro', __marker)

            # <Value u'view_macros/data | data_macro | field_macros/data' (17:28)> -> __value
            __token = 677
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'view_macros/data | data_macro | field_macros/data', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['data_macro'] = __value
            __backup_visState_135756867142608 = get('visState', __marker)

            # <Value u'python:widget.isVisible(here, mode)' (18:25)> -> __value
            __token = 756
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'widget.isVisible(here, mode)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['visState'] = __value
            __backup_portal_135756867142736 = get('portal', __marker)

            # <Value u'python:context.portal_url.getPortalObject()' (19:22)> -> __value
            __token = 819
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.portal_url.getPortalObject()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal'] = __value
            __backup_visCondition_135756867145488 = get('visCondition', __marker)

            # <Value u'python:field.widget.testCondition(context.aq_inner.getParentNode(), portal, context)' (20:27)> -> __value
            __token = 896
            try:
                __zt_tmp = __attrs_135756867144400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.widget.testCondition(context.aq_inner.getParentNode(), portal, context)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['visCondition'] = __value
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867143824
            __attrs_135756867143824 = _static_135757327983760

            # <Value u"python:visState == 'visible' and visCondition" (22:21)> -> __condition
            __token = 1032
            try:
                __zt_tmp = __attrs_135756867143824
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u"visState == 'visible' and visCondition", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075713936
                __attrs_135757075713936 = _static_135757327983760

                # <Value u"python:'view' in widget.modes and 'r' in field.mode and field.checkPermission('r',here)" (24:23)> -> __condition
                __token = 1124
                try:
                    __zt_tmp = __attrs_135757075713936
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u"'view' in widget.modes and 'r' in field.mode and field.checkPermission('r',here)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075712208
                    __attrs_135757075712208 = _static_135757327983760

                    # <Value u'use_label | nothing' (25:39)> -> __condition
                    __token = 1253
                    try:
                        __zt_tmp = __attrs_135757075712208
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'use_label | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075225552
                        __attrs_135757075225552 = _static_135757327983760
                        __backup_macroname_135757118670160 = get('macroname', __marker)

                        # <Static value=<_ast.Str object at 0x7b78683e9250> name=None at 7b78683e9810> -> __value
                        __value = _static_135757075223120
                        econtext['macroname'] = __value

                        # <Value u'label_macro' (26:40)> -> __macro
                        __token = 1315
                        try:
                            __zt_tmp = __attrs_135757075225552
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __macro = _static_135757244280656('path', u'label_macro', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __token = 1315
                        __m = __macro.include
                        __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                        econtext.update(rcontext)
                        if (__backup_macroname_135757118670160 is __marker):
                            del econtext['macroname']
                        else:
                            econtext['macroname'] = __backup_macroname_135757118670160
                        __append(u'\n          ')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075223824
                    __attrs_135757075223824 = _static_135757327983760
                    __backup_macroname_135757118669840 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7b7868460ed0> name=None at 7b78683e9c50> -> __value
                    __value = _static_135757075713744
                    econtext['macroname'] = __value

                    # <Value u'data_macro|default' (28:37)> -> __macro
                    __token = 1398
                    try:
                        __zt_tmp = __attrs_135757075223824
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_135757244280656('path', u'data_macro|default', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __token = 1398
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_135757118669840 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_135757118669840
                    __append(u'\n        ')
                __append(u'\n      ')
            __append(u'\n    ')
            if (__backup_visCondition_135756867145488 is __marker):
                del econtext['visCondition']
            else:
                econtext['visCondition'] = __backup_visCondition_135756867145488
            if (__backup_portal_135756867142736 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_135756867142736
            if (__backup_visState_135756867142608 is __marker):
                del econtext['visState']
            else:
                econtext['visState'] = __backup_visState_135756867142608
            if (__backup_data_macro_135756867142864 is __marker):
                del econtext['data_macro']
            else:
                econtext['data_macro'] = __backup_data_macro_135756867142864
            if (__backup_label_macro_135756867143568 is __marker):
                del econtext['label_macro']
            else:
                econtext['label_macro'] = __backup_label_macro_135756867143568
            if (__backup_field_macros_135757151840336 is __marker):
                del econtext['field_macros']
            else:
                econtext['field_macros'] = __backup_field_macros_135757151840336
            if (__backup_widget_view_135757075215312 is __marker):
                del econtext['widget_view']
            else:
                econtext['widget_view'] = __backup_widget_view_135757075215312
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_label(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867142032
            __attrs_135756867142032 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78683f6650> name=None at 7b7868460850> -> __attrs_135757075226000
            __attrs_135757075226000 = _static_135757075277392

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label class="formQuestion">')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075226320
            __attrs_135757075226320 = _static_135757327983760

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span>')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075224080
            __default_135757075224080 = _DEFAULT_MARKER

            # <Value u'python:widget.Label(here)' (34:71)> -> __cache_135757075222992
            __token = 1613
            try:
                __zt_tmp = __attrs_135757075226320
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757075222992 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'python:widget.Label(here)' (34:71)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683e9050> -> __condition
            __expression = __cache_135757075222992

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'Field')
            else:
                __content = __cache_135757075222992
                __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</span>:</label>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075223568
            __attrs_135757075223568 = _static_135757327983760

            # <Value u'field/workflowable | nothing' (35:27)> -> __condition
            __token = 1689
            try:
                __zt_tmp = __attrs_135757075223568
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'field/workflowable | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n        (\n        ')

                # <Static value=<_ast.Dict object at 0x7b786804de50> name=None at 7b786804d450> -> __attrs_135757071439312
                __attrs_135757071439312 = _static_135757071441488
                __backup_wf_tool_135757075713616 = get('wf_tool', __marker)

                # <Value u'context/portal_workflow' (39:31)> -> __value
                __token = 1809
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/portal_workflow', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['wf_tool'] = __value
                __backup_obj_135756867144976 = get('obj', __marker)

                # <Value u'python:accessor()' (40:26)> -> __value
                __token = 1860
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['obj'] = __value
                __backup_review_state_135757075711504 = get('review_state', __marker)

                # <Value u"python:wf_tool.getInfoFor(obj, 'review_state', '')" (41:34)> -> __value
                __token = 1914
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"wf_tool.getInfoFor(obj, 'review_state', '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['review_state'] = __value

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071438288
                __default_135757071438288 = _DEFAULT_MARKER

                # <Substitution u'string:${obj/absolute_url}/content_status_history' (42:32)> -> __attr_href
                __token = 2000
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_135757244280656('string', u'${obj/absolute_url}/content_status_history', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071441296
                __default_135757071441296 = _DEFAULT_MARKER

                # <Substitution u"python:test(review_state, review_state, 'private')" (43:32)> -> __attr_class
                __token = 2083
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_135757244280656('python', u"test(review_state, review_state, 'private')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071440784
                __default_135757071440784 = _DEFAULT_MARKER

                # <Value u'review_state' (44:24)> -> __cache_135757071441616
                __token = 2160
                try:
                    __zt_tmp = __attrs_135757071439312
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757071441616 = _static_135757244280656('path', u'review_state', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'review_state' (44:24)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786804d9d0> -> __condition
                __expression = __cache_135757071441616

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n          review_state\n        ')
                else:
                    __content = __cache_135757071441616
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</a>')
                if (__backup_review_state_135757075711504 is __marker):
                    del econtext['review_state']
                else:
                    econtext['review_state'] = __backup_review_state_135757075711504
                if (__backup_obj_135756867144976 is __marker):
                    del econtext['obj']
                else:
                    econtext['obj'] = __backup_obj_135756867144976
                if (__backup_wf_tool_135757075713616 is __marker):
                    del econtext['wf_tool']
                else:
                    econtext['wf_tool'] = __backup_wf_tool_135757075713616
                __append(u'\n        )\n      ')
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075712976
            __attrs_135757075712976 = _static_135757327983760

            # <br ... (0:0)
            # --------------------------------------------------------
            __append(u'<br />\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_hidden(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072616784
            __attrs_135757072616784 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b785bf343d0> name=None at 7b785bf34e50> -> __attrs_135757073609680
            __attrs_135757073609680 = _static_135756868961232

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075931600
            __default_135757075931600 = _DEFAULT_MARKER

            # <Substitution u'fieldName' (145:34)> -> __attr_name
            __token = 7220
            try:
                __zt_tmp = __attrs_135757073609680
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_135757244280656('path', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073610320
            __default_135757073610320 = _DEFAULT_MARKER

            # <Substitution u'value' (146:34)> -> __attr_value
            __token = 7265
            try:
                __zt_tmp = __attrs_135757073609680
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_data(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075225296
            __attrs_135757075225296 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757071440272
            __attrs_135757071440272 = _static_135757327983760
            __backup_macroname_135757114467424 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786804d110> name=None at 7b786804d590> -> __value
            __value = _static_135757071438096
            econtext['macroname'] = __value

            # <Value u'widget_view' (53:30)> -> __macro
            __token = 2347
            try:
                __zt_tmp = __attrs_135757071440272
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'widget_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 2347
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757114467424 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757114467424
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b786804d2d0> name=None at 7b786804d090> -> __attrs_135757072614224
            __attrs_135757072614224 = _static_135757071438544
            __backup_fieldName_135756867144912 = get('fieldName', __marker)

            # <Value u'fieldName|field/getName' (56:57)> -> __value
            __token = 2445
            try:
                __zt_tmp = __attrs_135757072614224
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'fieldName|field/getName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fieldName'] = __value
            __backup_fieldtypename_135756867143504 = get('fieldtypename', __marker)

            # <Value u"python:field.getType().split('.')[-1]" (57:60)> -> __value
            __token = 2530
            try:
                __zt_tmp = __attrs_135757072614224
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u"field.getType().split('.')[-1]", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fieldtypename'] = __value
            __backup_uid_135757075714000 = get('uid', __marker)

            # <Value u'context/UID|nothing' (58:49)> -> __value
            __token = 2619
            try:
                __zt_tmp = __attrs_135757072614224
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'context/UID|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['uid'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073543056
            __default_135757073543056 = _DEFAULT_MARKER

            # <Substitution u'string:field ArchetypesField-${fieldtypename}' (59:30)> -> __attr_class
            __token = 2672
            try:
                __zt_tmp = __attrs_135757072614224
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('string', u'field ArchetypesField-${fieldtypename}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072613776
            __default_135757072613776 = _DEFAULT_MARKER

            # <Substitution u'string:archetypes-fieldname-${fieldName}-${uid}' (60:26)> -> __attr_id
            __token = 2745
            try:
                __zt_tmp = __attrs_135757072614224
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('string', u'archetypes-fieldname-${fieldName}-${uid}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072616720
            __attrs_135757072616720 = _static_135757327983760
            __backup_macroname_135757119192832 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786816c050> name=None at 7b786816c610> -> __value
            __value = _static_135757072613456
            econtext['macroname'] = __value

            # <Value u'context/widgets/field/macros/base_view' (61:42)> -> __macro
            __token = 2838
            try:
                __zt_tmp = __attrs_135757072616720
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/field/macros/base_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 2838
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757119192832 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757119192832
            __append(u'\n    </div>')
            if (__backup_uid_135757075714000 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_135757075714000
            if (__backup_fieldtypename_135756867143504 is __marker):
                del econtext['fieldtypename']
            else:
                econtext['fieldtypename'] = __backup_fieldtypename_135756867143504
            if (__backup_fieldName_135756867144912 is __marker):
                del econtext['fieldName']
            else:
                econtext['fieldName'] = __backup_fieldName_135756867144912
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b7868186f90> name=None at 7b7868186fd0> -> __attrs_135757072720528
            __attrs_135757072720528 = _static_135757072723856
            __previous_i18n_domain_135757072723344 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149861648
            __attrs_135757149861648 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867141968
            __attrs_135756867141968 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867144848
            __attrs_135756867144848 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    <!-- Base Field Widgets -->\n    ')
            __token = None
            render_base_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_label(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_data(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_hidden(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135757072723344
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_base_view': render_base_view, u'render_label': render_label, u'render_hidden': render_hidden, u'render_data': render_data, u'render_view': render_view, 'render': render, }