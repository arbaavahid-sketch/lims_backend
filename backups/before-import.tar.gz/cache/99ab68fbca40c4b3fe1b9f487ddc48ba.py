# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/uidreference/display.pt'

__tokens = {229: (u'view/get_value', 7, 24), 302: (u'python:view.render_reference(uid)', 8, 32), 367: (u'python:rendered', 9, 28), 484: (u'rendered', 11, 39), 541: (u'python:not rendered', 13, 28), 613: (u'uid', 14, 29)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402101813712 = {u'class': u'd-inline-block', }
_static_140402101715344 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402356200592 = {}
_static_140402272508048 = __compile_zt_expr
_static_140402101449104 = {u'class': u'text-danger', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402101716176 = {u'class': u'list-unstyled d-table-row', }
_static_140402101449360 = {u'class': u'p-1 mb-1 mr-1 bg-light border rounded', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e9660190> name=None at 7fb1e9660ed0> -> __attrs_140402101716752
            __attrs_140402101716752 = _static_140402101715344
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e96604d0> name=None at 7fb1e96601d0> -> __attrs_140402101813456
            __attrs_140402101813456 = _static_140402101716176

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-unstyled d-table-row">\r\n    <!-- list all referenced UIDs -->\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e96781d0> name=None at 7fb1e96783d0> -> __attrs_140402101815888
            __attrs_140402101815888 = _static_140402101813712
            __backup_uid_140402101378640 = get('uid', __marker)

            # <Value u'view/get_value' (7:24)> -> __iterator
            __token = 229
            try:
                __zt_tmp = __attrs_140402101815888
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_140402272508048('path', u'view/get_value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            (__iterator, ____index_140402101814544, ) = getitem('repeat')(u'uid', __iterator)
            econtext['uid'] = None
            for __item in __iterator:
                econtext['uid'] = __item

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li class="d-inline-block">\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101815440
                __attrs_140402101815440 = _static_140402356200592
                __backup_rendered_140402101075088 = get('rendered', __marker)

                # <Value u'python:view.render_reference(uid)' (8:32)> -> __value
                __token = 302
                try:
                    __zt_tmp = __attrs_140402101815440
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_140402272508048('python', u'view.render_reference(uid)', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                econtext['rendered'] = __value
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e961f290> name=None at 7fb1e961f110> -> __attrs_140402101449296
                __attrs_140402101449296 = _static_140402101449360

                # <Value u'python:rendered' (9:28)> -> __condition
                __token = 367
                try:
                    __zt_tmp = __attrs_140402101449296
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('python', u'rendered', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div             class="p-1 mb-1 mr-1 bg-light border rounded">\r\n          ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101449680
                    __attrs_140402101449680 = _static_140402356200592

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101449168
                    __default_140402101449168 = _DEFAULT_MARKER

                    # <Value u'rendered' (11:39)> -> __cache_140402101451792
                    __token = 484
                    try:
                        __zt_tmp = __attrs_140402101449680
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101451792 = _static_140402272508048('path', u'rendered', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'rendered' (11:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e961f5d0> -> __condition
                    __expression = __cache_140402101451792

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span/>')
                    else:
                        __content = __cache_140402101451792
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n        </div>')
                __append(u'\r\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e961f190> name=None at 7fb1e961f550> -> __attrs_140402101754832
                __attrs_140402101754832 = _static_140402101449104

                # <Value u'python:not rendered' (13:28)> -> __condition
                __token = 541
                try:
                    __zt_tmp = __attrs_140402101754832
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('python', u'not rendered', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="text-danger">\r\n          ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101753424
                    __attrs_140402101753424 = _static_140402356200592

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101753552
                    __default_140402101753552 = _DEFAULT_MARKER

                    # <Value u'uid' (14:29)> -> __cache_140402101755088
                    __token = 613
                    try:
                        __zt_tmp = __attrs_140402101753424
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402101755088 = _static_140402272508048('path', u'uid', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'uid' (14:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9669c10> -> __condition
                    __expression = __cache_140402101755088

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_140402101755088
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n        </div>')
                __append(u'\r\n      ')
                if (__backup_rendered_140402101075088 is __marker):
                    del econtext['rendered']
                else:
                    econtext['rendered'] = __backup_rendered_140402101075088
                __append(u'\r\n    </li>')
                ____index_140402101814544 -= 1
                if (____index_140402101814544 > 0):
                    __append('\n    ')
            if (__backup_uid_140402101378640 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_140402101378640
            __append(u'\r\n  </ul>\r\n\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }