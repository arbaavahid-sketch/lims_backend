# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/add_samples.pt'

__tokens = {82: (u'python:view.available()', 2, 20), 251: (u'python:view.get_add_url()', 8, 31), 501: (u'python:view.get_sample_add_number()', 15, 35), 768: (u'view/theme_view/icon_url/plus', 21, 35), 832: (u'python:1', 22, 30)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525979686032 = {}
_static_124525520894864 = {u'class': u'input-group', }
_static_124525732251664 = {u'name': u'ar_count', u'min': u'1', u'max': u'99', u'value': u'python:view.get_sample_add_number()', u'type': u'number', u'class': u'form-control form-control-sm', }
_static_124525520881040 = {u'class': u'input-group-append', }
_static_124525521580816 = {u'class': u'add-samples-viewlet d-inline-block align-middle', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525896001680 = __compile_zt_expr
_static_124525732599568 = {u'src': u'#', u'style': u'height:16px;', }
_static_124525732870928 = {u'action': u'ar_add', u'method': u'GET', u'class': u'form-inline', }
_static_124525521566096 = {u'type': u'submit', u'class': u'btn btn-outline-secondary btn-sm', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x71415b7ab310> name=None at 71415b7abbd0> -> __attrs_124525734086480
            __attrs_124525734086480 = _static_124525521580816

            # <Value u'python:view.available()' (2:20)> -> __condition
            __token = 82
            try:
                __zt_tmp = __attrs_124525734086480
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u'view.available()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_124525521522064 = __i18n_domain
                __i18n_domain = u'senaite.core'

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="add-samples-viewlet d-inline-block align-middle">\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x71416812bb10> name=None at 71416812b050> -> __attrs_124525520894224
                __attrs_124525520894224 = _static_124525732870928

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form method="GET"         class="form-inline"')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525806958608
                __default_124525806958608 = _DEFAULT_MARKER

                # <Substitution u'python:view.get_add_url()' (8:31)> -> __attr_action
                __token = 251
                try:
                    __zt_tmp = __attrs_124525520894224
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_action = _static_124525896001680('python', u'view.get_add_url()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_action = __quote(__attr_action, '"', '&quot;', u'ar_add', _DEFAULT_MARKER)
                if (__attr_action is not None):
                    __append((u'         action="%s"' % __attr_action))
                __append(u'>\r\n    ')

                # <Static value=<_ast.Dict object at 0x71415b703b90> name=None at 71415b703e50> -> __attrs_124525520893392
                __attrs_124525520893392 = _static_124525520894864

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="input-group">\r\n      ')

                # <Static value=<_ast.Dict object at 0x714168094810> name=None at 714168094e90> -> __attrs_124525521824592
                __attrs_124525521824592 = _static_124525732251664

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="number"              name="ar_count"              min="1"              max="99"              class="form-control form-control-sm"')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521822160
                __default_124525521822160 = _DEFAULT_MARKER

                # <Substitution u'python:view.get_sample_add_number()' (15:35)> -> __attr_value
                __token = 501
                try:
                    __zt_tmp = __attrs_124525521824592
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_124525896001680('python', u'view.get_sample_add_number()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\r\n      ')

                # <Static value=<_ast.Dict object at 0x71415b700590> name=None at 71415b7002d0> -> __attrs_124525521565392
                __attrs_124525521565392 = _static_124525520881040

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="input-group-append">\r\n        ')

                # <Static value=<_ast.Dict object at 0x71415b7a7990> name=None at 71415b7a78d0> -> __attrs_124525521566864
                __attrs_124525521566864 = _static_124525521566096

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button type="submit"                 class="btn btn-outline-secondary btn-sm">\r\n          ')

                # <Static value=<_ast.Dict object at 0x7141680e9710> name=None at 7141680e9cd0> -> __attrs_124525521772048
                __attrs_124525521772048 = _static_124525732599568

                # <img ... (0:0)
                # --------------------------------------------------------
                __append(u'<img')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732598672
                __default_124525732598672 = _DEFAULT_MARKER

                # <Substitution u'view/theme_view/icon_url/plus' (21:35)> -> __attr_src
                __token = 768
                try:
                    __zt_tmp = __attrs_124525521772048
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_124525896001680('path', u'view/theme_view/icon_url/plus', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', u'#', _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'                style="height:16px;"/>\r\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521822736
                __attrs_124525521822736 = _static_124525979686032

                # <Negate value=<Value u'python:1' (22:30)> at 71415b7e64d0> -> __cache_124525521822928

                # <Value u'python:1' (22:30)> -> __cache_124525521822928
                __token = 832
                try:
                    __zt_tmp = __attrs_124525521822736
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521822928 = _static_124525896001680('python', u'1', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __cache_124525521822928 = not __cache_124525521822928
                __condition = __cache_124525521822928
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                __stream_124525732342160 = []
                __append_124525732342160 = __stream_124525732342160.append
                __append_124525732342160(u'Add Samples')
                __msgid_124525732342160 = __re_whitespace(''.join(__stream_124525732342160)).strip()
                if __msgid_124525732342160:
                    __append(translate(__msgid_124525732342160, mapping=None, default=__msgid_124525732342160, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __condition = __cache_124525521822928
                if __condition:
                    __append(u'</span>')
                __append(u'\r\n        </button>\r\n      </span>\r\n    </span>\r\n  </form>\r\n\r\n</div>')
                __i18n_domain = __previous_i18n_domain_124525521522064
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }