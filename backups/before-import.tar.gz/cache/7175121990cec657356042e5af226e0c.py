# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.formwidget.namedfile-2.1.3-py2.7.egg/plone/formwidget/namedfile/file_input.pt'

__tokens = {972: (u'view/download_url', 24, 29), 1013: (u' python: view.value is not Non', 25, 22), 1067: (u'n view/acti', 26, 21), 1110: (u'ge view/allow_nocha', 27, 28), 1155: (u'ype view/file_content_', 28, 21), 1199: (u'icon view/file', 29, 16), 1239: (u'ename view/fi', 30, 19), 53: (u'view/id', 3, 23), 87: (u' view/klas', 4, 25), 124: (u'e view/sty', 5, 24), 161: (u'le view/ti', 6, 23), 197: (u'ang view/', 7, 21), 235: (u'lick view/on', 8, 23), 279: (u'click view/ondb', 9, 25), 327: (u'sedown view/onmo', 10, 25), 374: (u'mouseup view/o', 11, 22), 421: (u'ouseover view/on', 12, 23), 470: (u'mousemove view/o', 13, 22), 518: (u'onmouseout view', 14, 20), 565: (u' onkeypress vie', 15, 19), 611: (u'   onkeydown v', 16, 17), 654: (u'      onkeyu', 17, 14), 695: (u'       onfoc', 18, 13), 735: (u'         on', 19, 11), 776: (u'        oncha', 20, 12), 819: (u'         read', 21, 11), 863: (u'         acces', 22, 11), 907: (u'           on', 23, 9), 1292: (u'view/file_upload_id', 31, 30), 1328: (u'up_id', 31, 66), 1369: (u'${view/name}.file_upload_id', 32, 33), 1371: (u'view/name', 32, 35), 1405: (u'${up_id}', 32, 69), 1407: (u'up_id', 32, 71), 1529: (u'${view/value/filename}', 35, 8), 1531: (u'view/value/filename', 35, 10), 1605: (u"python:exists and download_url and action=='nochange'", 38, 25), 1689: (u'icon', 39, 28), 1742: (u'icon', 40, 33), 1780: (u' doc_typ', 41, 32), 1824: (u'e filena', 42, 33), 1918: (u'download_url', 45, 33), 1875: (u'filename', 44, 25), 2022: (u'doc_type', 47, 64), 2064: (u'doc_type', 48, 31), 2182: (u'view/file_size', 50, 37), 2211: (u'sizekb', 50, 66), 2318: (u'allow_nochange', 54, 24), 2492: (u'string:${view/name}.action', 59, 33), 2550: (u' string:${view/id}-nochang', 60, 30), 2613: (u"k string:document.getElementById('${view/id}-input').disabled=tr", 61, 34), 2714: (u"ed python:'checked' if action == 'nochange' else N", 62, 33), 2831: (u'string:${view/id}-nochange', 65, 32), 2943: (u'not:view/field/required', 66, 30), 3137: (u'string:${view/name}.action', 72, 37), 3199: (u' string:${view/id}-remov', 73, 34), 3264: (u"k string:document.getElementById('${view/id}-input').disabled=tr", 74, 38), 3369: (u"ed python:'checked' if action == 'remove' else N", 75, 37), 3496: (u'string:${view/id}-remove', 78, 36), 3746: (u'string:${view/name}.action', 85, 33), 3804: (u' string:${view/id}-replac', 86, 30), 3866: (u"k string:document.getElementById('${view/id}-input').disabled=fal", 87, 34), 3968: (u"ed python:'checked' if action == 'replace' else N", 88, 33), 4084: (u'string:${view/id}-replace', 91, 32), 4205: (u'not:allow_nochange', 93, 23), 4345: (u'string:${view/id}-input', 96, 31), 4402: (u' view/nam', 97, 32), 4445: (u'e view/si', 98, 31), 4492: (u'ed view/disab', 99, 34), 4544: (u'gth view/maxle', 100, 34), 4611: (u"python:allow_nochange and action != 'replace'", 102, 31), 4706: (u"string:document.getElementById('${view/id}-input').disabled=true;", 103, 25)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_140402099531984 = {u'for': u'string:${view/id}-remove', }
_static_140402100216528 = {u'checked': u"python:'checked' if action == 'remove' else None", u'name': u'string:${view/name}.action', u'value': u'remove', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=true", u'type': u'radio', u'id': u'string:${view/id}-remove', }
_static_140402100047440 = {u'style': u'padding-top: 1em;', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402356200592 = {}
_static_140402099518416 = {u'for': u'string:${view/id}-nochange', }
_static_140402272508048 = __compile_zt_expr
_static_140402100044688 = {u'href': u'download_url', }
_static_140402100046160 = {u'class': u'discreet', }
_static_140402100385232 = {u'type': u'hidden', u'name': u'${view/name}.file_upload_id', u'value': u'${up_id}', }
_static_140402100101328 = {u'checked': u"python:'checked' if action == 'nochange' else None", u'name': u'string:${view/name}.action', u'value': u'nochange', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=true", u'type': u'radio', u'id': u'string:${view/id}-nochange', }
_static_140402100246224 = {u'lang': u'view/lang', u'style': u'view/style', u'onchange': u'view/onchange', u'onmousedown': u'view/onmousedown', u'onmouseup': u'view/onmouseup', u'onmouseout': u'view/onmouseout', u'title': u'view/title', u'accesskey': u'view/accesskey', u'onkeypress': u'view/onkeypress', u'onblur': u'view/onblur', u'onkeydown': u'view/onkeydown', u'class': u'view/klass', u'readonly': u'view/readonly', u'onselect': u'view/onselect', u'onmousemove': u'view/onmousemove', u'onmouseover': u'view/onmouseover', u'onclick': u'view/onclick', u'onkeyup': u'view/onkeyup', u'onfocus': u'view/onfocus', u'ondblclick': u'view/ondblclick', u'id': u'view/id', }
_static_140402099602704 = {u'style': u'padding-left: 1.5em; padding-top: 0.5em;', }
_static_140402100479056 = {u'src': u'', u'alt': u'', u'title': u'filename', }
_static_140402099492240 = {u'type': u'text/javascript', }
_static_140402099604048 = {u'name': u'view/name', u'disabled': u'view/disabled', u'maxlength': u'view/maxlength', u'type': u'file', u'id': u'string:${view/id}-input', u'size': u'view/size', }
_static_140402099601744 = {u'for': u'string:${view/id}-replace', }
_static_140402099534096 = {u'checked': u"python:'checked' if action == 'replace' else None", u'name': u'string:${view/name}.action', u'value': u'replace', u'class': u'noborder', u'onclick': u"string:document.getElementById('${view/id}-input').disabled=false", u'type': u'radio', u'id': u'string:${view/id}-replace', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e94f96d0> name=None at 7fb1e94f9f50> -> __attrs_140402100130960
            __attrs_140402100130960 = _static_140402100246224
            __backup_download_url_140402100048912 = get('download_url', __marker)

            # <Value u'view/download_url' (24:29)> -> __value
            __token = 972
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/download_url', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['download_url'] = __value
            __backup_exists_140402100086672 = get('exists', __marker)

            # <Value u'python: view.value is not None' (25:22)> -> __value
            __token = 1013
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u' view.value is not None', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['exists'] = __value
            __backup_action_140402099991696 = get('action', __marker)

            # <Value u'view/action' (26:21)> -> __value
            __token = 1067
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/action', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['action'] = __value
            __backup_allow_nochange_140402100087056 = get('allow_nochange', __marker)

            # <Value u'view/allow_nochange' (27:28)> -> __value
            __token = 1110
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/allow_nochange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['allow_nochange'] = __value
            __backup_doc_type_140402100085008 = get('doc_type', __marker)

            # <Value u'view/file_content_type' (28:21)> -> __value
            __token = 1155
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/file_content_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['doc_type'] = __value
            __backup_icon_140402100132944 = get('icon', __marker)

            # <Value u'view/file_icon' (29:16)> -> __value
            __token = 1199
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/file_icon', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['icon'] = __value
            __backup_filename_140402100132880 = get('filename', __marker)

            # <Value u'view/filename' (30:19)> -> __value
            __token = 1239
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/filename', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['filename'] = __value
            __previous_i18n_domain_140402100130256 = __i18n_domain
            __i18n_domain = u'plone'

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100247504
            __default_140402100247504 = _DEFAULT_MARKER

            # <Substitution u'view/id' (3:23)> -> __attr_id
            __token = 53
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'view/id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100247440
            __default_140402100247440 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (4:25)> -> __attr_class
            __token = 87
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'view/klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100244560
            __default_140402100244560 = _DEFAULT_MARKER

            # <Substitution u'view/style' (5:24)> -> __attr_style
            __token = 124
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_140402272508048('path', u'view/style', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100000336
            __default_140402100000336 = _DEFAULT_MARKER

            # <Substitution u'view/title' (6:23)> -> __attr_title
            __token = 161
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_140402272508048('path', u'view/title', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100001808
            __default_140402100001808 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (7:21)> -> __attr_lang
            __token = 197
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_140402272508048('path', u'view/lang', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100002768
            __default_140402100002768 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (8:23)> -> __attr_onclick
            __token = 235
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_140402272508048('path', u'view/onclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100000080
            __default_140402100000080 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (9:25)> -> __attr_ondblclick
            __token = 279
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_140402272508048('path', u'view/ondblclick', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099999632
            __default_140402099999632 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (10:25)> -> __attr_onmousedown
            __token = 327
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_140402272508048('path', u'view/onmousedown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100001424
            __default_140402100001424 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (11:22)> -> __attr_onmouseup
            __token = 374
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_140402272508048('path', u'view/onmouseup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100002640
            __default_140402100002640 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (12:23)> -> __attr_onmouseover
            __token = 421
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_140402272508048('path', u'view/onmouseover', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099999312
            __default_140402099999312 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (13:22)> -> __attr_onmousemove
            __token = 470
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_140402272508048('path', u'view/onmousemove', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099999056
            __default_140402099999056 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (14:20)> -> __attr_onmouseout
            __token = 518
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_140402272508048('path', u'view/onmouseout', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100000400
            __default_140402100000400 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (15:19)> -> __attr_onkeypress
            __token = 565
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_140402272508048('path', u'view/onkeypress', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100002384
            __default_140402100002384 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (16:17)> -> __attr_onkeydown
            __token = 611
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_140402272508048('path', u'view/onkeydown', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100000976
            __default_140402100000976 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (17:14)> -> __attr_onkeyup
            __token = 654
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_140402272508048('path', u'view/onkeyup', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099998992
            __default_140402099998992 = _DEFAULT_MARKER

            # <Substitution u'view/onfocus' (18:13)> -> __attr_onfocus
            __token = 695
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onfocus = _static_140402272508048('path', u'view/onfocus', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onfocus = __quote(__attr_onfocus, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onfocus is not None):
                __append((u' onfocus="%s"' % __attr_onfocus))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100132368
            __default_140402100132368 = _DEFAULT_MARKER

            # <Substitution u'view/onblur' (19:11)> -> __attr_onblur
            __token = 735
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onblur = _static_140402272508048('path', u'view/onblur', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onblur = __quote(__attr_onblur, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onblur is not None):
                __append((u' onblur="%s"' % __attr_onblur))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100131152
            __default_140402100131152 = _DEFAULT_MARKER

            # <Substitution u'view/onchange' (20:12)> -> __attr_onchange
            __token = 776
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onchange = _static_140402272508048('path', u'view/onchange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onchange = __quote(__attr_onchange, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onchange is not None):
                __append((u' onchange="%s"' % __attr_onchange))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100132432
            __default_140402100132432 = _DEFAULT_MARKER

            # <Boolean u'view/readonly' (21:11)> -> __attr_readonly
            __token = 819
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_readonly = _static_140402272508048('path', u'view/readonly', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if (__attr_readonly is _DEFAULT_MARKER):
                __attr_readonly = None
            else:
                if __attr_readonly:
                    __attr_readonly = u'readonly'
                else:
                    __attr_readonly = None
            if (__attr_readonly is not None):
                __append((u' readonly="%s"' % __attr_readonly))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100132752
            __default_140402100132752 = _DEFAULT_MARKER

            # <Substitution u'view/accesskey' (22:11)> -> __attr_accesskey
            __token = 863
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_accesskey = _static_140402272508048('path', u'view/accesskey', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_accesskey = __quote(__attr_accesskey, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_accesskey is not None):
                __append((u' accesskey="%s"' % __attr_accesskey))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100133328
            __default_140402100133328 = _DEFAULT_MARKER

            # <Substitution u'view/onselect' (23:9)> -> __attr_onselect
            __token = 907
            try:
                __zt_tmp = __attrs_140402100130960
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onselect = _static_140402272508048('path', u'view/onselect', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_onselect = __quote(__attr_onselect, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onselect is not None):
                __append((u' onselect="%s"' % __attr_onselect))
            __append(u'>\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100384208
            __attrs_140402100384208 = _static_140402356200592
            __backup_up_id_140402100132176 = get('up_id', __marker)

            # <Value u'view/file_upload_id' (31:30)> -> __value
            __token = 1292
            try:
                __zt_tmp = __attrs_140402100384208
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/file_upload_id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['up_id'] = __value

            # <Value u'up_id' (31:66)> -> __condition
            __token = 1328
            try:
                __zt_tmp = __attrs_140402100384208
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'up_id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:
                __append(u'\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e951b5d0> name=None at 7fb1e951b610> -> __attrs_140402100384912
                __attrs_140402100384912 = _static_140402100385232

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100384848
                __default_140402100384848 = _DEFAULT_MARKER

                # <Interpolation value=<Substitution u'${view/name}.file_upload_id' (32:33)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7fb1e951b710> -> __attr_name
                __token = 1369
                __token = 1371
                try:
                    __zt_tmp = __attrs_140402100384912
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_140402272508048('path', u'view/name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_name = ('%s%s' % ((__attr_name if (__attr_name is not None) else ''), u'.file_upload_id', ))
                if (__attr_name is None):
                    pass
                else:
                    if (__attr_name is _DEFAULT_MARKER):
                        __attr_name = None
                    else:
                        __tt = type(__attr_name)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __attr_name = unicode(__attr_name)
                        else:
                            if (__tt is str):
                                __attr_name = decode(__attr_name)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __attr_name = __attr_name.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__attr_name)
                                        __attr_name = (unicode(__attr_name) if (__attr_name is __converted) else __converted)
                                    else:
                                        __attr_name = __attr_name()
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100385936
                __default_140402100385936 = _DEFAULT_MARKER

                # <Interpolation value=<Substitution u'${up_id}' (32:69)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7fb1e951b950> -> __attr_value
                __token = 1405
                __token = 1407
                try:
                    __zt_tmp = __attrs_140402100384912
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_140402272508048('path', u'up_id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                __attr_value = __attr_value
                if (__attr_value is None):
                    pass
                else:
                    if (__attr_value is _DEFAULT_MARKER):
                        __attr_value = None
                    else:
                        __tt = type(__attr_value)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __attr_value = unicode(__attr_value)
                        else:
                            if (__tt is str):
                                __attr_value = decode(__attr_value)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __attr_value = __attr_value.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__attr_value)
                                        __attr_value = (unicode(__attr_value) if (__attr_value is __converted) else __converted)
                                    else:
                                        __attr_value = __attr_value()
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100479888
                __attrs_140402100479888 = _static_140402356200592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100479312
                __attrs_140402100479312 = _static_140402356200592
                __stream_140402100480272 = []
                __append_140402100480272 = __stream_140402100480272.append
                __append_140402100480272(u'File already uploaded:')
                __msgid_140402100480272 = __re_whitespace(''.join(__stream_140402100480272)).strip()
                if u'file_already_uploaded':
                    __append(translate(u'file_already_uploaded', mapping=None, default=__msgid_140402100480272, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))

                # <Interpolation value=<Substitution u'\n        ${view/value/filename}\n      ' (34:90)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7fb1e9532d10> -> __content_140402425414880
                __token = 1529
                __token = 1531
                try:
                    __zt_tmp = __attrs_140402100479888
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_140402425414880 = _static_140402272508048('path', u'view/value/filename', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __content_140402425414880 = __quote(__content_140402425414880, '\x00', '&#0;', None, None)
                __content_140402425414880 = ('%s%s%s' % (u'\n        ', (__content_140402425414880 if (__content_140402425414880 is not None) else ''), u'\n      ', ))
                if (__content_140402425414880 is None):
                    pass
                else:
                    if (__content_140402425414880 is None):
                        __content_140402425414880 = None
                    else:
                        __tt = type(__content_140402425414880)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_140402425414880 = unicode(__content_140402425414880)
                        else:
                            if (__tt is str):
                                __content_140402425414880 = decode(__content_140402425414880)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_140402425414880 = __content_140402425414880.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_140402425414880)
                                        __content_140402425414880 = (unicode(__content_140402425414880) if (__content_140402425414880 is __converted) else __converted)
                                    else:
                                        __content_140402425414880 = __content_140402425414880()
                if (__content_140402425414880 is not None):
                    __append(__content_140402425414880)
                __append(u'</span>\n    ')
            if (__backup_up_id_140402100132176 is __marker):
                del econtext['up_id']
            else:
                econtext['up_id'] = __backup_up_id_140402100132176
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100482000
            __attrs_140402100482000 = _static_140402356200592

            # <Value u"python:exists and download_url and action=='nochange'" (38:25)> -> __condition
            __token = 1605
            try:
                __zt_tmp = __attrs_140402100482000
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u"exists and download_url and action=='nochange'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e9532450> name=None at 7fb1e95320d0> -> __attrs_140402100481488
                __attrs_140402100481488 = _static_140402100479056

                # <Value u'icon' (39:28)> -> __condition
                __token = 1689
                try:
                    __zt_tmp = __attrs_140402100481488
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'icon', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <img ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<img')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100478032
                    __default_140402100478032 = _DEFAULT_MARKER

                    # <Substitution u'icon' (40:33)> -> __attr_src
                    __token = 1742
                    try:
                        __zt_tmp = __attrs_140402100481488
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_src = _static_140402272508048('path', u'icon', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_src = __quote(__attr_src, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_src is not None):
                        __append((u' src="%s"' % __attr_src))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100479440
                    __default_140402100479440 = _DEFAULT_MARKER

                    # <Substitution u'doc_type' (41:32)> -> __attr_alt
                    __token = 1780
                    try:
                        __zt_tmp = __attrs_140402100481488
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_alt = _static_140402272508048('path', u'doc_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_alt is not None):
                        __append((u' alt="%s"' % __attr_alt))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100480400
                    __default_140402100480400 = _DEFAULT_MARKER

                    # <Substitution u'filename' (42:33)> -> __attr_title
                    __token = 1824
                    try:
                        __zt_tmp = __attrs_140402100481488
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_140402272508048('path', u'filename', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'/>')
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e94c8390> name=None at 7fb1e94c8b10> -> __attrs_140402100045456
                __attrs_140402100045456 = _static_140402100044688

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100045776
                __default_140402100045776 = _DEFAULT_MARKER

                # <Substitution u'download_url' (45:33)> -> __attr_href
                __token = 1918
                try:
                    __zt_tmp = __attrs_140402100045456
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_140402272508048('path', u'download_url', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' >')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100480784
                __default_140402100480784 = _DEFAULT_MARKER

                # <Value u'filename' (44:25)> -> __cache_140402100480016
                __token = 1875
                try:
                    __zt_tmp = __attrs_140402100045456
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402100480016 = _static_140402272508048('path', u'filename', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'filename' (44:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9532510> -> __condition
                __expression = __cache_140402100480016

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Filename')
                else:
                    __content = __cache_140402100480016
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</a>\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e94c8950> name=None at 7fb1e94c8a50> -> __attrs_140402100047376
                __attrs_140402100047376 = _static_140402100046160

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="discreet"> &mdash;')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100047760
                __attrs_140402100047760 = _static_140402356200592

                # <Value u'doc_type' (47:64)> -> __condition
                __token = 2022
                try:
                    __zt_tmp = __attrs_140402100047760
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'doc_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100101264
                    __attrs_140402100101264 = _static_140402356200592

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100103760
                    __default_140402100103760 = _DEFAULT_MARKER

                    # <Value u'doc_type' (48:31)> -> __cache_140402100104208
                    __token = 2064
                    try:
                        __zt_tmp = __attrs_140402100101264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402100104208 = _static_140402272508048('path', u'doc_type', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'doc_type' (48:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e94d6250> -> __condition
                    __expression = __cache_140402100104208

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>ContentType</span>')
                    else:
                        __content = __cache_140402100104208
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u',')
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100101840
                __attrs_140402100101840 = _static_140402356200592
                __backup_sizekb_140402100386256 = get('sizekb', __marker)

                # <Value u'view/file_size' (50:37)> -> __value
                __token = 2182
                try:
                    __zt_tmp = __attrs_140402100101840
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_140402272508048('path', u'view/file_size', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                econtext['sizekb'] = __value

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100101520
                __default_140402100101520 = _DEFAULT_MARKER

                # <Value u'sizekb' (50:66)> -> __cache_140402100102288
                __token = 2211
                try:
                    __zt_tmp = __attrs_140402100101840
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402100102288 = _static_140402272508048('path', u'sizekb', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'sizekb' (50:66)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e94d6a10> -> __condition
                __expression = __cache_140402100102288

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>100</span>')
                else:
                    __content = __cache_140402100102288
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                if (__backup_sizekb_140402100386256 is __marker):
                    del econtext['sizekb']
                else:
                    econtext['sizekb'] = __backup_sizekb_140402100386256
                __append(u'\n        </span>\n    </span>')
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e94c8e50> name=None at 7fb1e94c8d10> -> __attrs_140402100104080
            __attrs_140402100104080 = _static_140402100047440

            # <Value u'allow_nochange' (54:24)> -> __condition
            __token = 2318
            try:
                __zt_tmp = __attrs_140402100104080
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'allow_nochange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-top: 1em;">\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e94d60d0> name=None at 7fb1e94d6ed0> -> __attrs_140402099515600
                __attrs_140402099515600 = _static_140402100101328

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="radio" value="nochange" class="noborder"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099517776
                __default_140402099517776 = _DEFAULT_MARKER

                # <Substitution u'string:${view/name}.action' (59:33)> -> __attr_name
                __token = 2492
                try:
                    __zt_tmp = __attrs_140402099515600
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_140402272508048('string', u'${view/name}.action', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099516304
                __default_140402099516304 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-nochange' (60:30)> -> __attr_id
                __token = 2550
                try:
                    __zt_tmp = __attrs_140402099515600
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_140402272508048('string', u'${view/id}-nochange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099519248
                __default_140402099519248 = _DEFAULT_MARKER

                # <Substitution u"string:document.getElementById('${view/id}-input').disabled=true" (61:34)> -> __attr_onclick
                __token = 2613
                try:
                    __zt_tmp = __attrs_140402099515600
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onclick = _static_140402272508048('string', u"document.getElementById('${view/id}-input').disabled=true", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onclick is not None):
                    __append((u' onclick="%s"' % __attr_onclick))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099519312
                __default_140402099519312 = _DEFAULT_MARKER

                # <Boolean u"python:'checked' if action == 'nochange' else None" (62:33)> -> __attr_checked
                __token = 2714
                try:
                    __zt_tmp = __attrs_140402099515600
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_checked = _static_140402272508048('python', u"'checked' if action == 'nochange' else None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if (__attr_checked is _DEFAULT_MARKER):
                    __attr_checked = None
                else:
                    if __attr_checked:
                        __attr_checked = u'checked'
                    else:
                        __attr_checked = None
                if (__attr_checked is not None):
                    __append((u' checked="%s"' % __attr_checked))
                __append(u' />\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e9447bd0> name=None at 7fb1e9447090> -> __attrs_140402099517584
                __attrs_140402099517584 = _static_140402099518416

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099518672
                __default_140402099518672 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-nochange' (65:32)> -> __attr_for
                __token = 2831
                try:
                    __zt_tmp = __attrs_140402099517584
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_140402272508048('string', u'${view/id}-nochange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_140402099516048 = []
                __append_140402099516048 = __stream_140402099516048.append
                __append_140402099516048(u'Keep existing file')
                __msgid_140402099516048 = __re_whitespace(''.join(__stream_140402099516048)).strip()
                if u'file_keep':
                    __append(translate(u'file_keep', mapping=None, default=__msgid_140402099516048, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100451728
                __attrs_140402100451728 = _static_140402356200592

                # <Value u'not:view/field/required' (66:30)> -> __condition
                __token = 2943
                try:
                    __zt_tmp = __attrs_140402100451728
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('not', u'view/field/required', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100216272
                    __attrs_140402100216272 = _static_140402356200592

                    # <br ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<br />\n            ')

                    # <Static value=<_ast.Dict object at 0x7fb1e94f22d0> name=None at 7fb1e94f2310> -> __attrs_140402100219152
                    __attrs_140402100219152 = _static_140402100216528

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="radio" value="remove" class="noborder"')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100219792
                    __default_140402100219792 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/name}.action' (72:37)> -> __attr_name
                    __token = 3137
                    try:
                        __zt_tmp = __attrs_140402100219152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_140402272508048('string', u'${view/name}.action', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100219536
                    __default_140402100219536 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/id}-remove' (73:34)> -> __attr_id
                    __token = 3199
                    try:
                        __zt_tmp = __attrs_140402100219152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_140402272508048('string', u'${view/id}-remove', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100216912
                    __default_140402100216912 = _DEFAULT_MARKER

                    # <Substitution u"string:document.getElementById('${view/id}-input').disabled=true" (74:38)> -> __attr_onclick
                    __token = 3264
                    try:
                        __zt_tmp = __attrs_140402100219152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_onclick = _static_140402272508048('string', u"document.getElementById('${view/id}-input').disabled=true", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_onclick is not None):
                        __append((u' onclick="%s"' % __attr_onclick))

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100218704
                    __default_140402100218704 = _DEFAULT_MARKER

                    # <Boolean u"python:'checked' if action == 'remove' else None" (75:37)> -> __attr_checked
                    __token = 3369
                    try:
                        __zt_tmp = __attrs_140402100219152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_checked = _static_140402272508048('python', u"'checked' if action == 'remove' else None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    if (__attr_checked is _DEFAULT_MARKER):
                        __attr_checked = None
                    else:
                        if __attr_checked:
                            __attr_checked = u'checked'
                        else:
                            __attr_checked = None
                    if (__attr_checked is not None):
                        __append((u' checked="%s"' % __attr_checked))
                    __append(u' />\n            ')

                    # <Static value=<_ast.Dict object at 0x7fb1e944b0d0> name=None at 7fb1e944b090> -> __attrs_140402099533008
                    __attrs_140402099533008 = _static_140402099531984

                    # <label ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<label')

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099534288
                    __default_140402099534288 = _DEFAULT_MARKER

                    # <Substitution u'string:${view/id}-remove' (78:36)> -> __attr_for
                    __token = 3496
                    try:
                        __zt_tmp = __attrs_140402099533008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_140402272508048('string', u'${view/id}-remove', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'>')
                    __stream_140402100219472 = []
                    __append_140402100219472 = __stream_140402100219472.append
                    __append_140402100219472(u'Remove existing file')
                    __msgid_140402100219472 = __re_whitespace(''.join(__stream_140402100219472)).strip()
                    if u'file_remove':
                        __append(translate(u'file_remove', mapping=None, default=__msgid_140402100219472, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</label>\n        ')
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402100216016
                __attrs_140402100216016 = _static_140402356200592

                # <br ... (0:0)
                # --------------------------------------------------------
                __append(u'<br />\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e944b910> name=None at 7fb1e944b5d0> -> __attrs_140402099601616
                __attrs_140402099601616 = _static_140402099534096

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="radio" value="replace" class="noborder"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099532240
                __default_140402099532240 = _DEFAULT_MARKER

                # <Substitution u'string:${view/name}.action' (85:33)> -> __attr_name
                __token = 3746
                try:
                    __zt_tmp = __attrs_140402099601616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_140402272508048('string', u'${view/name}.action', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099535696
                __default_140402099535696 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-replace' (86:30)> -> __attr_id
                __token = 3804
                try:
                    __zt_tmp = __attrs_140402099601616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_140402272508048('string', u'${view/id}-replace', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099532368
                __default_140402099532368 = _DEFAULT_MARKER

                # <Substitution u"string:document.getElementById('${view/id}-input').disabled=false" (87:34)> -> __attr_onclick
                __token = 3866
                try:
                    __zt_tmp = __attrs_140402099601616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onclick = _static_140402272508048('string', u"document.getElementById('${view/id}-input').disabled=false", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onclick is not None):
                    __append((u' onclick="%s"' % __attr_onclick))

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099532624
                __default_140402099532624 = _DEFAULT_MARKER

                # <Boolean u"python:'checked' if action == 'replace' else None" (88:33)> -> __attr_checked
                __token = 3968
                try:
                    __zt_tmp = __attrs_140402099601616
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_checked = _static_140402272508048('python', u"'checked' if action == 'replace' else None", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if (__attr_checked is _DEFAULT_MARKER):
                    __attr_checked = None
                else:
                    if __attr_checked:
                        __attr_checked = u'checked'
                    else:
                        __attr_checked = None
                if (__attr_checked is not None):
                    __append((u' checked="%s"' % __attr_checked))
                __append(u' />\n        ')

                # <Static value=<_ast.Dict object at 0x7fb1e945c150> name=None at 7fb1e945c990> -> __attrs_140402099602960
                __attrs_140402099602960 = _static_140402099601744

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099602640
                __default_140402099602640 = _DEFAULT_MARKER

                # <Substitution u'string:${view/id}-replace' (91:32)> -> __attr_for
                __token = 4084
                try:
                    __zt_tmp = __attrs_140402099602960
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_140402272508048('string', u'${view/id}-replace', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>')
                __stream_140402099603792 = []
                __append_140402099603792 = __stream_140402099603792.append
                __append_140402099603792(u'Replace with new file')
                __msgid_140402099603792 = __re_whitespace(''.join(__stream_140402099603792)).strip()
                if u'file_replace':
                    __append(translate(u'file_replace', mapping=None, default=__msgid_140402099603792, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</label>\n    </div>')
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e945c510> name=None at 7fb1e945c6d0> -> __attrs_140402099604944
            __attrs_140402099604944 = _static_140402099602704

            # <Negate value=<Value u'not:allow_nochange' (93:23)> at 7fb1e945c350> -> __cache_140402099602256

            # <Value u'not:allow_nochange' (93:23)> -> __cache_140402099602256
            __token = 4205
            try:
                __zt_tmp = __attrs_140402099604944
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_140402099602256 = _static_140402272508048('not', u'allow_nochange', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __cache_140402099602256 = not __cache_140402099602256
            __condition = __cache_140402099602256
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div style="padding-left: 1.5em; padding-top: 0.5em;">')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e945ca50> name=None at 7fb1e945cc90> -> __attrs_140402099493392
            __attrs_140402099493392 = _static_140402099604048

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="file"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099491088
            __default_140402099491088 = _DEFAULT_MARKER

            # <Substitution u'string:${view/id}-input' (96:31)> -> __attr_id
            __token = 4345
            try:
                __zt_tmp = __attrs_140402099493392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('string', u'${view/id}-input', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099491536
            __default_140402099491536 = _DEFAULT_MARKER

            # <Substitution u'view/name' (97:32)> -> __attr_name
            __token = 4402
            try:
                __zt_tmp = __attrs_140402099493392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'view/name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099491984
            __default_140402099491984 = _DEFAULT_MARKER

            # <Substitution u'view/size' (98:31)> -> __attr_size
            __token = 4445
            try:
                __zt_tmp = __attrs_140402099493392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_size = _static_140402272508048('path', u'view/size', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_size = __quote(__attr_size, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_size is not None):
                __append((u' size="%s"' % __attr_size))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099493776
            __default_140402099493776 = _DEFAULT_MARKER

            # <Boolean u'view/disabled' (99:34)> -> __attr_disabled
            __token = 4492
            try:
                __zt_tmp = __attrs_140402099493392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_disabled = _static_140402272508048('path', u'view/disabled', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if (__attr_disabled is _DEFAULT_MARKER):
                __attr_disabled = None
            else:
                if __attr_disabled:
                    __attr_disabled = u'disabled'
                else:
                    __attr_disabled = None
            if (__attr_disabled is not None):
                __append((u' disabled="%s"' % __attr_disabled))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099494864
            __default_140402099494864 = _DEFAULT_MARKER

            # <Substitution u'view/maxlength' (100:34)> -> __attr_maxlength
            __token = 4544
            try:
                __zt_tmp = __attrs_140402099493392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_maxlength = _static_140402272508048('path', u'view/maxlength', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_maxlength is not None):
                __append((u' maxlength="%s"' % __attr_maxlength))
            __append(u' />\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9441590> name=None at 7fb1e9441290> -> __attrs_140402099491664
            __attrs_140402099491664 = _static_140402099492240

            # <Value u"python:allow_nochange and action != 'replace'" (102:31)> -> __condition
            __token = 4611
            try:
                __zt_tmp = __attrs_140402099491664
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('python', u"allow_nochange and action != 'replace'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script type="text/javascript">')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099494608
                __default_140402099494608 = _DEFAULT_MARKER

                # <Value u"string:document.getElementById('${view/id}-input').disabled=true;" (103:25)> -> __cache_140402099494352
                __token = 4706
                try:
                    __zt_tmp = __attrs_140402099491664
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402099494352 = _static_140402272508048('string', u"document.getElementById('${view/id}-input').disabled=true;", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u"string:document.getElementById('${view/id}-input').disabled=true;" (103:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9441e50> -> __condition
                __expression = __cache_140402099494352

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n        ')
                else:
                    __content = __cache_140402099494352
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</script>')
            __append(u'\n    ')
            __condition = __cache_140402099602256
            if __condition:
                __append(u'</div>')
            __append(u'\n</span>')
            __i18n_domain = __previous_i18n_domain_140402100130256
            if (__backup_filename_140402100132880 is __marker):
                del econtext['filename']
            else:
                econtext['filename'] = __backup_filename_140402100132880
            if (__backup_icon_140402100132944 is __marker):
                del econtext['icon']
            else:
                econtext['icon'] = __backup_icon_140402100132944
            if (__backup_doc_type_140402100085008 is __marker):
                del econtext['doc_type']
            else:
                econtext['doc_type'] = __backup_doc_type_140402100085008
            if (__backup_allow_nochange_140402100087056 is __marker):
                del econtext['allow_nochange']
            else:
                econtext['allow_nochange'] = __backup_allow_nochange_140402100087056
            if (__backup_action_140402099991696 is __marker):
                del econtext['action']
            else:
                econtext['action'] = __backup_action_140402099991696
            if (__backup_exists_140402100086672 is __marker):
                del econtext['exists']
            else:
                econtext['exists'] = __backup_exists_140402100086672
            if (__backup_download_url_140402100048912 is __marker):
                del econtext['download_url']
            else:
                econtext['download_url'] = __backup_download_url_140402100048912
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }