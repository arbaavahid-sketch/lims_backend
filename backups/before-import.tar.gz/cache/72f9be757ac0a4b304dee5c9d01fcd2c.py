# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.Archetypes-1.16.6-py2.7.egg/Products/Archetypes/skins/archetypes/widgets/picklist.pt'

__tokens = {756: (u'python:field.Vocabulary(here)', 20, 38), 832: (u' context/@@at_selection_widge', 21, 45), 904: (u'n python:selectionview.getSelected(vocab, valu', 22, 40), 988: (u'en python:len(voc', 23, 34), 1101: (u'not:field/required|nothing', 27, 32), 1167: (u'string:$fieldName:default:list', 28, 38), 1376: (u'string:${fieldName}_options', 36, 39), 1441: (u' string:${fieldName}_option', 37, 36), 1508: (u'e widget/si', 38, 37), 1565: (u"ck string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName", 39, 42), 1723: (u'vocab', 41, 37), 1772: (u'item', 42, 42), 1812: (u'python:vocab.getValue(item)', 43, 33), 2112: (u"string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')", 52, 47), 2369: (u"string:javascript:pick_removeKeywords('${fieldName}','${fieldName}')", 56, 47), 2606: (u'string:${fieldName}:list', 63, 39), 2668: (u' string:${fieldName', 64, 36), 2727: (u'e widget/si', 65, 37), 2784: (u"ck string:javascript:pick_removeKeywords('${fieldName}','${fieldName", 66, 42), 2913: (u'selection', 68, 54), 2997: (u'single_value', 70, 44), 3047: (u'python:vocab.getValue(single_value)', 71, 35), 638: (u'context/widgets/field/macros/edit', 18, 28), 638: (u'context/widgets/field/macros/edit', 18, 28), 3470: (u'context/widgets/multiselection/macros/edit', 87, 28), 3470: (u'context/widgets/multiselection/macros/edit', 87, 28), 371: (u'python:field.Vocabulary(here)', 12, 26), 427: (u' python:accessor(', 13, 25), 473: (u'y python:context.displayValue(vocab, value, widge', 14, 26), 558: (u'display', 15, 31)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756866245904 = {u'type': u'hidden', u'name': u'string:$fieldName:default:list', u'value': u'', }
_static_135757072743184 = {u'onDblClick': u"string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')", u'size': u'widget/size', u'multiple': u'multiple', u'name': u'string:${fieldName}_options', u'id': u'string:${fieldName}_options', }
_static_135756869381072 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_135757244280656 = __compile_zt_expr
_static_135756866562384 = {u'onDblClick': u"string:javascript:pick_removeKeywords('${fieldName}','${fieldName}')", u'size': u'widget/size', u'multiple': u'multiple', u'name': u'string:${fieldName}:list', u'id': u'string:${fieldName}', }
_static_135756868293392 = {u'value': u'item', }
_static_135756868296656 = {u'onClick': u"string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')", u'type': u'button', u'class': u'context', u'value': u'>>', }
_static_135757072720272 = u'edit'
_static_135756864637840 = {u'onClick': u"string:javascript:pick_removeKeywords('${fieldName}','${fieldName}')", u'type': u'button', u'class': u'context', u'value': u'&lt;&lt;', }
_static_135757327983760 = {}
_static_135756866246096 = u'edit'
_static_135757244301584 = __C2ZContextWrapper
_static_135757151736784 = {u'selected': u'selected', u'value': u'single_value', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072720144
            __attrs_135757072720144 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072722128
            __attrs_135757072722128 = _static_135757327983760
            __backup_macroname_135757132489824 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868186190> name=None at 7b7868186750> -> __value
            __value = _static_135757072720272
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072722192
                __attrs_135757072722192 = _static_135757327983760
                __backup_vocab_135756869493328 = get('vocab', __marker)

                # <Value u'python:field.Vocabulary(here)' (20:38)> -> __value
                __token = 756
                try:
                    __zt_tmp = __attrs_135757072722192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'field.Vocabulary(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['vocab'] = __value
                __backup_selectionview_135756865700112 = get('selectionview', __marker)

                # <Value u'context/@@at_selection_widget' (21:45)> -> __value
                __token = 832
                try:
                    __zt_tmp = __attrs_135757072722192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'context/@@at_selection_widget', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['selectionview'] = __value
                __backup_selection_135756864689168 = get('selection', __marker)

                # <Value u'python:selectionview.getSelected(vocab, value)' (22:40)> -> __value
                __token = 904
                try:
                    __zt_tmp = __attrs_135757072722192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'selectionview.getSelected(vocab, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['selection'] = __value
                __backup_vlen_135757074797328 = get('vlen', __marker)

                # <Value u'python:len(vocab)' (23:34)> -> __value
                __token = 988
                try:
                    __zt_tmp = __attrs_135757072722192
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'len(vocab)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['vlen'] = __value
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b785bc9d510> name=None at 7b785bc9d490> -> __attrs_135756866247312
                __attrs_135756866247312 = _static_135756866245904

                # <Value u'not:field/required|nothing' (27:32)> -> __condition
                __token = 1101
                try:
                    __zt_tmp = __attrs_135756866247312
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('not', u'field/required|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" value=""')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866246608
                    __default_135756866246608 = _DEFAULT_MARKER

                    # <Substitution u'string:$fieldName:default:list' (28:38)> -> __attr_name
                    __token = 1167
                    try:
                        __zt_tmp = __attrs_135756866247312
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_135757244280656('string', u'$fieldName:default:list', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))
                    __append(u' />')
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866247440
                __attrs_135756866247440 = _static_135757327983760

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table>\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866246160
                __attrs_135756866246160 = _static_135757327983760

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\n              ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072743248
                __attrs_135757072743248 = _static_135757327983760

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\n                ')

                # <Static value=<_ast.Dict object at 0x7b786818bb10> name=None at 7b786818b810> -> __attrs_135757151809360
                __attrs_135757151809360 = _static_135757072743184

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select multiple="multiple"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109937296
                __default_135757109937296 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_options' (36:39)> -> __attr_name
                __token = 1376
                try:
                    __zt_tmp = __attrs_135757151809360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('string', u'${fieldName}_options', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109938768
                __default_135757109938768 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_options' (37:36)> -> __attr_id
                __token = 1441
                try:
                    __zt_tmp = __attrs_135757151809360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}_options', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109936592
                __default_135757109936592 = _DEFAULT_MARKER

                # <Substitution u'widget/size' (38:37)> -> __attr_size
                __token = 1508
                try:
                    __zt_tmp = __attrs_135757151809360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_size = _static_135757244280656('path', u'widget/size', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_size = __quote(__attr_size, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_size is not None):
                    __append((u' size="%s"' % __attr_size))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757109940048
                __default_135757109940048 = _DEFAULT_MARKER

                # <Substitution u"string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')" (39:42)> -> __attr_onDblClick
                __token = 1565
                try:
                    __zt_tmp = __attrs_135757151809360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onDblClick = _static_135757244280656('string', u"javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_onDblClick = __quote(__attr_onDblClick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onDblClick is not None):
                    __append((u' onDblClick="%s"' % __attr_onDblClick))
                __append(u'>\n                  ')

                # <Static value=<_ast.Dict object at 0x7b785be91310> name=None at 7b785be91b50> -> __attrs_135756868293648
                __attrs_135756868293648 = _static_135756868293392
                __backup_item_135756868115344 = get('item', __marker)

                # <Value u'vocab' (41:37)> -> __iterator
                __token = 1723
                try:
                    __zt_tmp = __attrs_135756868293648
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'vocab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756868295376, ) = getitem('repeat')(u'item', __iterator)
                econtext['item'] = None
                for __item in __iterator:
                    econtext['item'] = __item

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868293456
                    __default_135756868293456 = _DEFAULT_MARKER

                    # <Substitution u'item' (42:42)> -> __attr_value
                    __token = 1772
                    try:
                        __zt_tmp = __attrs_135756868293648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868294864
                    __default_135756868294864 = _DEFAULT_MARKER

                    # <Value u'python:vocab.getValue(item)' (43:33)> -> __cache_135756868296208
                    __token = 1812
                    try:
                        __zt_tmp = __attrs_135756868293648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135756868296208 = _static_135757244280656('python', u'vocab.getValue(item)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:vocab.getValue(item)' (43:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785be91f90> -> __condition
                    __expression = __cache_135756868296208

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                    option\n                  ')
                    else:
                        __content = __cache_135756868296208
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>')
                    ____index_135756868295376 -= 1
                    if (____index_135756868295376 > 0):
                        __append('\n                  ')
                if (__backup_item_135756868115344 is __marker):
                    del econtext['item']
                else:
                    econtext['item'] = __backup_item_135756868115344
                __append(u'\n                </select>\n              </td>\n\n              ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756868295952
                __attrs_135756868295952 = _static_135757327983760

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\n                ')

                # <Static value=<_ast.Dict object at 0x7b785be91fd0> name=None at 7b785be91890> -> __attrs_135756864638416
                __attrs_135756864638416 = _static_135756868296656

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="button" class="context" value=">>"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864638352
                __default_135756864638352 = _DEFAULT_MARKER

                # <Substitution u"string:javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')" (52:47)> -> __attr_onClick
                __token = 2112
                try:
                    __zt_tmp = __attrs_135756864638416
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onClick = _static_135757244280656('string', u"javascript:pick_moveKeywords('${fieldName}_options','${fieldName}','${fieldName}')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_onClick = __quote(__attr_onClick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onClick is not None):
                    __append((u' onClick="%s"' % __attr_onClick))
                __append(u' />\n                ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756864636432
                __attrs_135756864636432 = _static_135757327983760

                # <br ... (0:0)
                # --------------------------------------------------------
                __append(u'<br />\n                ')

                # <Static value=<_ast.Dict object at 0x7b785bb14b90> name=None at 7b785bb14510> -> __attrs_135756864637968
                __attrs_135756864637968 = _static_135756864637840

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="button" class="context" value="&lt;&lt;"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756864637904
                __default_135756864637904 = _DEFAULT_MARKER

                # <Substitution u"string:javascript:pick_removeKeywords('${fieldName}','${fieldName}')" (56:47)> -> __attr_onClick
                __token = 2369
                try:
                    __zt_tmp = __attrs_135756864637968
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onClick = _static_135757244280656('string', u"javascript:pick_removeKeywords('${fieldName}','${fieldName}')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_onClick = __quote(__attr_onClick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onClick is not None):
                    __append((u' onClick="%s"' % __attr_onClick))
                __append(u' />\n              </td>\n\n              ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756864637008
                __attrs_135756864637008 = _static_135757327983760

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\n                ')

                # <Static value=<_ast.Dict object at 0x7b785bcea950> name=None at 7b785bcea990> -> __attrs_135756866562000
                __attrs_135756866562000 = _static_135756866562384

                # <select ... (0:0)
                # --------------------------------------------------------
                __append(u'<select multiple="multiple"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866562064
                __default_135756866562064 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}:list' (63:39)> -> __attr_name
                __token = 2606
                try:
                    __zt_tmp = __attrs_135756866562000
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_135757244280656('string', u'${fieldName}:list', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866562832
                __default_135756866562832 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}' (64:36)> -> __attr_id
                __token = 2668
                try:
                    __zt_tmp = __attrs_135756866562000
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866563664
                __default_135756866563664 = _DEFAULT_MARKER

                # <Substitution u'widget/size' (65:37)> -> __attr_size
                __token = 2727
                try:
                    __zt_tmp = __attrs_135756866562000
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_size = _static_135757244280656('path', u'widget/size', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_size = __quote(__attr_size, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_size is not None):
                    __append((u' size="%s"' % __attr_size))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866563024
                __default_135756866563024 = _DEFAULT_MARKER

                # <Substitution u"string:javascript:pick_removeKeywords('${fieldName}','${fieldName}')" (66:42)> -> __attr_onDblClick
                __token = 2784
                try:
                    __zt_tmp = __attrs_135756866562000
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_onDblClick = _static_135757244280656('string', u"javascript:pick_removeKeywords('${fieldName}','${fieldName}')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_onDblClick = __quote(__attr_onDblClick, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_onDblClick is not None):
                    __append((u' onDblClick="%s"' % __attr_onDblClick))
                __append(u'>\n\n                  ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866564048
                __attrs_135756866564048 = _static_135757327983760
                __backup_single_value_135756865896784 = get('single_value', __marker)

                # <Value u'selection' (68:54)> -> __iterator
                __token = 2913
                try:
                    __zt_tmp = __attrs_135756866564048
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'selection', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756866560208, ) = getitem('repeat')(u'single_value', __iterator)
                econtext['single_value'] = None
                for __item in __iterator:
                    econtext['single_value'] = __item
                    __append(u'\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b786cce13d0> name=None at 7b786cce19d0> -> __attrs_135757151739216
                    __attrs_135757151739216 = _static_135757151736784

                    # <option ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<option selected="selected"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151736656
                    __default_135757151736656 = _DEFAULT_MARKER

                    # <Substitution u'single_value' (70:44)> -> __attr_value
                    __token = 2997
                    try:
                        __zt_tmp = __attrs_135757151739216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'single_value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151738768
                    __default_135757151738768 = _DEFAULT_MARKER

                    # <Value u'python:vocab.getValue(single_value)' (71:35)> -> __cache_135757151736080
                    __token = 3047
                    try:
                        __zt_tmp = __attrs_135757151739216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757151736080 = _static_135757244280656('python', u'vocab.getValue(single_value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:vocab.getValue(single_value)' (71:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cce1850> -> __condition
                    __expression = __cache_135757151736080

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                       option\n                    ')
                    else:
                        __content = __cache_135757151736080
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</option>\n                  ')
                    ____index_135756866560208 -= 1
                    if (____index_135756866560208 > 0):
                        __append('')
                if (__backup_single_value_135756865896784 is __marker):
                    del econtext['single_value']
                else:
                    econtext['single_value'] = __backup_single_value_135756865896784
                __append(u'\n                </select>\n              </td>\n            </tr>\n          </table>\n\n        ')
                if (__backup_vlen_135757074797328 is __marker):
                    del econtext['vlen']
                else:
                    econtext['vlen'] = __backup_vlen_135757074797328
                if (__backup_selection_135756864689168 is __marker):
                    del econtext['selection']
                else:
                    econtext['selection'] = __backup_selection_135756864689168
                if (__backup_selectionview_135756865700112 is __marker):
                    del econtext['selectionview']
                else:
                    econtext['selectionview'] = __backup_selectionview_135756865700112
                if (__backup_vocab_135756869493328 is __marker):
                    del econtext['vocab']
                else:
                    econtext['vocab'] = __backup_vocab_135756869493328
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'context/widgets/field/macros/edit' (18:28)> -> __macro
            __token = 638
            try:
                __zt_tmp = __attrs_135757072722128
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/field/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 638
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757132489824 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757132489824
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072721936
            __attrs_135757072721936 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866248464
            __attrs_135756866248464 = _static_135757327983760
            __backup_macroname_135757132155632 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bc9d5d0> name=None at 7b785bc9dbd0> -> __value
            __value = _static_135756866246096
            econtext['macroname'] = __value

            # <Value u'context/widgets/multiselection/macros/edit' (87:28)> -> __macro
            __token = 3470
            try:
                __zt_tmp = __attrs_135756866248464
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/multiselection/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 3470
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757132155632 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757132155632
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866373456
            __attrs_135756866373456 = _static_135757327983760
            __backup_vocab_135756866522128 = get('vocab', __marker)

            # <Value u'python:field.Vocabulary(here)' (12:26)> -> __value
            __token = 371
            try:
                __zt_tmp = __attrs_135756866373456
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.Vocabulary(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['vocab'] = __value
            __backup_value_135756866582672 = get('value', __marker)

            # <Value u'python:accessor()' (13:25)> -> __value
            __token = 427
            try:
                __zt_tmp = __attrs_135756866373456
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_display_135757151845584 = get('display', __marker)

            # <Value u'python:context.displayValue(vocab, value, widget)' (14:26)> -> __value
            __token = 473
            try:
                __zt_tmp = __attrs_135756866373456
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.displayValue(vocab, value, widget)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['display'] = __value

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756866375440
            __default_135756866375440 = _DEFAULT_MARKER

            # <Value u'display' (15:31)> -> __cache_135756866374032
            __token = 558
            try:
                __zt_tmp = __attrs_135756866373456
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135756866374032 = _static_135757244280656('path', u'display', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'display' (15:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bcbcb50> -> __condition
            __expression = __cache_135756866374032

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135756866374032
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            if (__backup_display_135757151845584 is __marker):
                del econtext['display']
            else:
                econtext['display'] = __backup_display_135757151845584
            if (__backup_value_135756866582672 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135756866582672
            if (__backup_vocab_135756866522128 is __marker):
                del econtext['vocab']
            else:
                econtext['vocab'] = __backup_vocab_135756866522128
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b785bf9abd0> name=None at 7b785bf9ad50> -> __attrs_135757071490576
            __attrs_135757071490576 = _static_135756869381072
            __previous_i18n_domain_135756866374992 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866373008
            __attrs_135756866373008 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866375056
            __attrs_135756866375056 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866372368
            __attrs_135756866372368 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n<!-- Picklist Widgets -->\n\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135756866374992
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_view': render_view, 'render': render, }