# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/referencewidget.pt'

__tokens = {1347: (u'python:field.getEditAccessor(here)() or []', 33, 32), 1430: (u' python:here.session_restore_value(fieldName, value', 34, 39), 1521: (u'e python:request.get(fieldName, session_valu', 35, 37), 1598: (u'ue python:cached_value or va', 36, 29), 1662: (u'red field/required|not', 37, 31), 1720: (u"ired python: required and 'required' or", 38, 30), 1795: (u'or_id python:errors.get(fiel', 39, 29), 1862: (u'domain field/widget/i18n_domain|context/i18n_domain|strin', 40, 31), 1967: (u'not: widget/render_own_label | nothing', 42, 36), 2083: (u'python:fieldName', 44, 37), 2133: (u'python:widget.Label(here)', 45, 31), 2267: (u'field/required', 48, 33), 2467: (u'python:widget.Description(here)', 52, 42), 2591: (u'string:${fieldName}_help', 54, 37), 2541: (u'description', 53, 41), 2801: (u'python:field.widget.get_input_widget_attributes(context, field, value)', 62, 38), 3199: (u'   python:widget_at', 66, 26), 2906: (u'python:fieldName', 63, 32), 2958: (u" python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klas", 64, 34), 3139: (u"d python:required and '1' or '", 65, 41), 3537: (u'python:fieldName', 72, 38), 3593: (u" python:'\\r\\n'.join(field.widget.get_value(context, field, value)", 73, 38), 3730: (u'required', 76, 50), 3795: (u'error_id', 77, 48), 3951: (u'context/widgets/string/macros/edit', 83, 28), 3951: (u'context/widgets/string/macros/edit', 83, 28), 443: (u'python:accessor()', 12, 29), 489: (u' python:widget.get_value(context, field, value', 13, 27), 616: (u'refs', 15, 30), 688: (u'python:widget.render_reference(context, field, ref)', 16, 42), 776: (u'python:rendered', 17, 34), 903: (u'rendered', 19, 45), 970: (u'python:not rendered', 21, 34), 1056: (u'string:broken reference ${ref}', 22, 44), 1123: (u'ref', 23, 35), 231: (u'here/main_template/macros/master', 5, 23), 231: (u'here/main_template/macros/master', 5, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135756866914512 = u'master'
_static_135756869516432 = {u'class': u'required', u'title': u'Required', }
_static_135756869381840 = {u'class': u'fieldErrorBox', }
_static_135756869380944 = {u'type': u'hidden', u'name': u'python:fieldName', u'value': u"python:'\\r\\n'.join(field.widget.get_value(context, field, value))", }
_static_135756869515472 = {u'data-required': u"python:required and '1' or '0'", u'id': u'python:fieldName', u'class': u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass", }
_static_135756869494992 = {u'title': u'string:broken reference ${ref}', }
_static_135756867114192 = {u'class': u'd-inline-block', }
_static_135757244280656 = __compile_zt_expr
_static_135756869458832 = {u'class': u'formHelp', u'id': u'string:${fieldName}_help', }
_static_135756867115792 = {u'class': u'list-unstyled d-table-row', }
_static_135757072778320 = u'edit'
_static_135757072779728 = {u'class': u'fieldErrorBox', }
_static_135756869419152 = {u'class': u'text-danger', }
_static_135756869515920 = {u'class': u'formQuestion', u'for': u'python:fieldName', }
_static_135757074901392 = set([])
_static_135757327983760 = {}
_static_135756869420048 = {u'class': u'p-1 mb-1 mr-1 bg-light border rounded', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867113104
            __attrs_135756867113104 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869422416
            __attrs_135756869422416 = _static_135757327983760
            __backup_value_135757154386384 = get('value', __marker)

            # <Value u'python:field.getEditAccessor(here)() or []' (33:32)> -> __value
            __token = 1347
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.getEditAccessor(here)() or []', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_session_value_135757151715600 = get('session_value', __marker)

            # <Value u'python:here.session_restore_value(fieldName, value)' (34:39)> -> __value
            __token = 1430
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'here.session_restore_value(fieldName, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['session_value'] = __value
            __backup_cached_value_135757072799760 = get('cached_value', __marker)

            # <Value u'python:request.get(fieldName, session_value)' (35:37)> -> __value
            __token = 1521
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'request.get(fieldName, session_value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['cached_value'] = __value
            __backup_value_135757072708944 = get('value', __marker)

            # <Value u'python:cached_value or value' (36:29)> -> __value
            __token = 1598
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'cached_value or value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_required_135756868774480 = get('required', __marker)

            # <Value u'field/required|nothing' (37:31)> -> __value
            __token = 1662
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/required|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['required'] = __value
            __backup_required_135757073222480 = get('required', __marker)

            # <Value u"python: required and 'required' or None" (38:30)> -> __value
            __token = 1720
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u" required and 'required' or None", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['required'] = __value
            __backup_error_id_135757109779984 = get('error_id', __marker)

            # <Value u'python:errors.get(fieldName)' (39:29)> -> __value
            __token = 1795
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'errors.get(fieldName)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['error_id'] = __value
            __backup_i18n_domain_135756868961744 = get('i18n_domain', __marker)

            # <Value u'field/widget/i18n_domain|context/i18n_domain|string:plone' (40:31)> -> __value
            __token = 1862
            try:
                __zt_tmp = __attrs_135756869422416
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'field/widget/i18n_domain|context/i18n_domain|string:plone', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['i18n_domain'] = __value
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869492944
            __attrs_135756869492944 = _static_135757327983760

            # <Value u'not: widget/render_own_label | nothing' (42:36)> -> __condition
            __token = 1967
            try:
                __zt_tmp = __attrs_135756869492944
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u' widget/render_own_label | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b785bfbba90> name=None at 7b785bfbbf10> -> __attrs_135756869513360
                __attrs_135756869513360 = _static_135756869515920

                # <label ... (0:0)
                # --------------------------------------------------------
                __append(u'<label class="formQuestion"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869514320
                __default_135756869514320 = _DEFAULT_MARKER

                # <Substitution u'python:fieldName' (44:37)> -> __attr_for
                __token = 2083
                try:
                    __zt_tmp = __attrs_135756869513360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_for = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_for is not None):
                    __append((u' for="%s"' % __attr_for))
                __append(u'>\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869515600
                __attrs_135756869515600 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869513744
                __default_135756869513744 = _DEFAULT_MARKER

                # <Value u'python:widget.Label(here)' (45:31)> -> __cache_135756869515216
                __token = 2133
                try:
                    __zt_tmp = __attrs_135756869515600
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135756869515216 = _static_135757244280656('python', u'widget.Label(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:widget.Label(here)' (45:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfbbc10> -> __condition
                __expression = __cache_135756869515216

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_135756869515216
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b785bfbbc90> name=None at 7b785bfbbcd0> -> __attrs_135756869456976
                __attrs_135756869456976 = _static_135756869516432

                # <Value u'field/required' (48:33)> -> __condition
                __token = 2267
                try:
                    __zt_tmp = __attrs_135756869456976
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'field/required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="required"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869456016
                    __default_135756869456016 = _DEFAULT_MARKER

                    # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7b785bfad510> at 7b785bfad990> -> __attr_title
                    __attr_title = u'Required'
                    __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>&nbsp;</span>')
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b785bfadb90> name=None at 7b785bfada10> -> __attrs_135756869457872
                __attrs_135756869457872 = _static_135756869458832
                __backup_description_135757071403216 = get('description', __marker)

                # <Value u'python:widget.Description(here)' (52:42)> -> __value
                __token = 2467
                try:
                    __zt_tmp = __attrs_135756869457872
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.Description(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['description'] = __value

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="formHelp"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869459472
                __default_135756869459472 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}_help' (54:37)> -> __attr_id
                __token = 2591
                try:
                    __zt_tmp = __attrs_135756869457872
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${fieldName}_help', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869458768
                __default_135756869458768 = _DEFAULT_MARKER

                # <Value u'description' (53:41)> -> __cache_135756869458640
                __token = 2541
                try:
                    __zt_tmp = __attrs_135756869457872
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135756869458640 = _static_135757244280656('path', u'description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'description' (53:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfadf50> -> __condition
                __expression = __cache_135756869458640

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n              Help\n            ')
                else:
                    __content = __cache_135756869458640
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>')
                if (__backup_description_135757071403216 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_135757071403216
                __append(u'\n          </label>\n        ')
            __append(u'\n\n        <!-- Reference -->\n        ')

            # <Static value=<_ast.Dict object at 0x7b785bfbb8d0> name=None at 7b785bfbbf50> -> __attrs_135756869382032
            __attrs_135756869382032 = _static_135756869515472
            __backup_widget_attrs_135757149930832 = get('widget_attrs', __marker)

            # <Value u'python:field.widget.get_input_widget_attributes(context, field, value)' (62:38)> -> __value
            __token = 2801
            try:
                __zt_tmp = __attrs_135756869382032
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'field.widget.get_input_widget_attributes(context, field, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['widget_attrs'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Value u'python:widget_attrs' (66:26)> -> __cache_135756869378832
            __token = 3199
            try:
                __zt_tmp = __attrs_135756869382032
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135756869378832 = _static_135757244280656('python', u'widget_attrs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869456528
            __default_135756869456528 = _DEFAULT_MARKER

            # <Substitution u'python:fieldName' (63:32)> -> __attr_id
            __token = 2906
            try:
                __zt_tmp = __attrs_135756869382032
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_id is not None) and (u'id' not in __chain(__cache_135756869378832))):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869455952
            __default_135756869455952 = _DEFAULT_MARKER

            # <Substitution u"python: test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass" (64:34)> -> __attr_class
            __token = 2958
            try:
                __zt_tmp = __attrs_135756869382032
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_135757244280656('python', u" test(error_id, 'field error ' + 'Archetypes' + widget.getName(), 'field ' + 'Archetypes' + widget.getName()) + ' ' + widget.klass", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_135756869378832))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869380176
            __default_135756869380176 = _DEFAULT_MARKER

            # <Substitution u"python:required and '1' or '0'" (65:41)> -> __attr_data_required
            __token = 3139
            try:
                __zt_tmp = __attrs_135756869382032
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_required = _static_135757244280656('python', u"required and '1' or '0'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_data_required = __quote(__attr_data_required, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_data_required is not None) and (u'data-required' not in __chain(__cache_135756869378832))):
                __append((u' data-required="%s"' % __attr_data_required))
            __attr_135756869380624 = __cache_135756869378832
            for (name, value, ) in __attr_135756869380624.items():
                if ((name not in _static_135757074901392) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\n          <!-- ReactJS controlled component -->\n\n          <!-- The hidden input field provides the field value before the widget is rendered.\n              This is necessary if e.g. a JS requires the value directly after DOM loaded event -->\n          ')

            # <Static value=<_ast.Dict object at 0x7b785bf9ab50> name=None at 7b785bf9a5d0> -> __attrs_135756869381584
            __attrs_135756869381584 = _static_135756869380944

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="hidden"')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869381200
            __default_135756869381200 = _DEFAULT_MARKER

            # <Substitution u'python:fieldName' (72:38)> -> __attr_name
            __token = 3537
            try:
                __zt_tmp = __attrs_135756869381584
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_135757244280656('python', u'fieldName', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869381712
            __default_135756869381712 = _DEFAULT_MARKER

            # <Substitution u"python:'\\r\\n'.join(field.widget.get_value(context, field, value))" (73:38)> -> __attr_value
            __token = 3593
            try:
                __zt_tmp = __attrs_135756869381584
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_135757244280656('python', u"'\\r\\n'.join(field.widget.get_value(context, field, value))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u' />\n        </div>')
            if (__backup_widget_attrs_135757149930832 is __marker):
                del econtext['widget_attrs']
            else:
                econtext['widget_attrs'] = __backup_widget_attrs_135757149930832
            __append(u'\n\n        ')

            # <Static value=<_ast.Dict object at 0x7b785bf9aed0> name=None at 7b785bf9a890> -> __attrs_135757072781008
            __attrs_135757072781008 = _static_135756869381840

            # <Value u'required' (76:50)> -> __condition
            __token = 3730
            try:
                __zt_tmp = __attrs_135757072781008
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'required', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="fieldErrorBox"></div>')
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78681949d0> name=None at 7b78681948d0> -> __attrs_135757072777872
            __attrs_135757072777872 = _static_135757072779728

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="fieldErrorBox">')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757072779856
            __default_135757072779856 = _DEFAULT_MARKER

            # <Value u'error_id' (77:48)> -> __cache_135757072781072
            __token = 3795
            try:
                __zt_tmp = __attrs_135757072777872
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757072781072 = _static_135757244280656('path', u'error_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'error_id' (77:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868194250> -> __condition
            __expression = __cache_135757072781072

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757072781072
                __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\n\n      ')
            if (__backup_i18n_domain_135756868961744 is __marker):
                del econtext['i18n_domain']
            else:
                econtext['i18n_domain'] = __backup_i18n_domain_135756868961744
            if (__backup_error_id_135757109779984 is __marker):
                del econtext['error_id']
            else:
                econtext['error_id'] = __backup_error_id_135757109779984
            if (__backup_required_135757073222480 is __marker):
                del econtext['required']
            else:
                econtext['required'] = __backup_required_135757073222480
            if (__backup_required_135756868774480 is __marker):
                del econtext['required']
            else:
                econtext['required'] = __backup_required_135756868774480
            if (__backup_value_135757072708944 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757072708944
            if (__backup_cached_value_135757072799760 is __marker):
                del econtext['cached_value']
            else:
                econtext['cached_value'] = __backup_cached_value_135757072799760
            if (__backup_session_value_135757151715600 is __marker):
                del econtext['session_value']
            else:
                econtext['session_value'] = __backup_session_value_135757151715600
            if (__backup_value_135757154386384 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_135757154386384
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867116816
            __attrs_135756867116816 = _static_135757327983760
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757072778064
            __attrs_135757072778064 = _static_135757327983760
            __backup_macroname_135757117665440 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7868194450> name=None at 7b7868194490> -> __value
            __value = _static_135757072778320
            econtext['macroname'] = __value

            # <Value u'context/widgets/string/macros/edit' (83:28)> -> __macro
            __token = 3951
            try:
                __zt_tmp = __attrs_135757072778064
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/widgets/string/macros/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 3951
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757117665440 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757117665440
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866915792
            __attrs_135756866915792 = _static_135757327983760
            __append(u'\n      ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866913104
                __attrs_135756866913104 = _static_135757327983760
                __backup_value_135757074926672 = get('value', __marker)

                # <Value u'python:accessor()' (12:29)> -> __value
                __token = 443
                try:
                    __zt_tmp = __attrs_135756866913104
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'accessor()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['value'] = __value
                __backup_refs_135757072799184 = get('refs', __marker)

                # <Value u'python:widget.get_value(context, field, value)' (13:27)> -> __value
                __token = 489
                try:
                    __zt_tmp = __attrs_135756866913104
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u'widget.get_value(context, field, value)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['refs'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n        ')

                # <Static value=<_ast.Dict object at 0x7b785bd71b10> name=None at 7b785bd71d10> -> __attrs_135756867114512
                __attrs_135756867114512 = _static_135756867115792

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="list-unstyled d-table-row">\n          ')

                # <Static value=<_ast.Dict object at 0x7b785bd714d0> name=None at 7b785bd71490> -> __attrs_135756867115152
                __attrs_135756867115152 = _static_135756867114192
                __backup_ref_135757071558288 = get('ref', __marker)

                # <Value u'refs' (15:30)> -> __iterator
                __token = 616
                try:
                    __zt_tmp = __attrs_135756867115152
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'refs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135756867115344, ) = getitem('repeat')(u'ref', __iterator)
                econtext['ref'] = None
                for __item in __iterator:
                    econtext['ref'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="d-inline-block">\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756867116880
                    __attrs_135756867116880 = _static_135757327983760
                    __backup_rendered_135757073222928 = get('rendered', __marker)

                    # <Value u'python:widget.render_reference(context, field, ref)' (16:42)> -> __value
                    __token = 688
                    try:
                        __zt_tmp = __attrs_135756867116880
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'widget.render_reference(context, field, ref)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['rendered'] = __value
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b785bfa4410> name=None at 7b785bfa43d0> -> __attrs_135756869421136
                    __attrs_135756869421136 = _static_135756869420048

                    # <Value u'python:rendered' (17:34)> -> __condition
                    __token = 776
                    try:
                        __zt_tmp = __attrs_135756869421136
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="p-1 mb-1 mr-1 bg-light border rounded">\n                ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756869421648
                        __attrs_135756869421648 = _static_135757327983760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869421520
                        __default_135756869421520 = _DEFAULT_MARKER

                        # <Value u'rendered' (19:45)> -> __cache_135756869421904
                        __token = 903
                        try:
                            __zt_tmp = __attrs_135756869421648
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135756869421904 = _static_135757244280656('path', u'rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'rendered' (19:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfa4990> -> __condition
                        __expression = __cache_135756869421904

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span/>')
                        else:
                            __content = __cache_135756869421904
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\n              </div>')
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b785bfa4090> name=None at 7b785bfa4a90> -> __attrs_135756869422864
                    __attrs_135756869422864 = _static_135756869419152

                    # <Value u'python:not rendered' (21:34)> -> __condition
                    __token = 970
                    try:
                        __zt_tmp = __attrs_135756869422864
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'not rendered', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-danger">\n                ')

                        # <Static value=<_ast.Dict object at 0x7b785bfb68d0> name=None at 7b785bfb6f50> -> __attrs_135756869496464
                        __attrs_135756869496464 = _static_135756869494992

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869496784
                        __default_135756869496784 = _DEFAULT_MARKER

                        # <Substitution u'string:broken reference ${ref}' (22:44)> -> __attr_title
                        __token = 1056
                        try:
                            __zt_tmp = __attrs_135756869496464
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_title = _static_135757244280656('string', u'broken reference ${ref}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756869495120
                        __default_135756869495120 = _DEFAULT_MARKER

                        # <Value u'ref' (23:35)> -> __cache_135756869493072
                        __token = 1123
                        try:
                            __zt_tmp = __attrs_135756869496464
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135756869493072 = _static_135757244280656('path', u'ref', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'ref' (23:35)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bfb6350> -> __condition
                        __expression = __cache_135756869493072

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135756869493072
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\n              </div>')
                    __append(u'\n            ')
                    if (__backup_rendered_135757073222928 is __marker):
                        del econtext['rendered']
                    else:
                        econtext['rendered'] = __backup_rendered_135757073222928
                    __append(u'\n          </li>')
                    ____index_135756867115344 -= 1
                    if (____index_135756867115344 > 0):
                        __append('\n          ')
                if (__backup_ref_135757071558288 is __marker):
                    del econtext['ref']
                else:
                    econtext['ref'] = __backup_ref_135757071558288
                __append(u'\n        </ul>\n      </div>')
                if (__backup_refs_135757072799184 is __marker):
                    del econtext['refs']
                else:
                    econtext['refs'] = __backup_refs_135757072799184
                if (__backup_value_135757074926672 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_135757074926672
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135756866914448
            __attrs_135756866914448 = _static_135757327983760
            __previous_i18n_domain_135756866913488 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_135757114943280 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b785bd408d0> name=None at 7b785bd40850> -> __value
            __value = _static_135756866914512
            econtext['macroname'] = __value

            # <Value u'here/main_template/macros/master' (5:23)> -> __macro
            __token = 231
            try:
                __zt_tmp = __attrs_135756866914448
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 231
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757114943280 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757114943280
            __i18n_domain = __previous_i18n_domain_135756866913488
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_view': render_view, 'render': render, }