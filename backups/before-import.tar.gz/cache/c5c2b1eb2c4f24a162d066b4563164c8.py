# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/setup_legacy_link.pt'

__tokens = {74: (u'view/get_target_url | nothing', 2, 28), 132: (u' view/get_link_text | nothin', 3, 26), 184: (u'target_url', 4, 20), 224: (u'target_url', 5, 26), 332: (u'link_text', 8, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402356200592 = {}
_static_140402272508048 = __compile_zt_expr
_static_140402099494672 = {u'class': u'mb-2', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402101355920 = {u'class': u'fas fa-arrow-right', }
_static_140402100087568 = {u'href': u'target_url', u'class': u'text-muted small', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e9441f10> name=None at 7fb1e9441d10> -> __attrs_140402100088336
            __attrs_140402100088336 = _static_140402099494672
            __backup_target_url_140402099854352 = get('target_url', __marker)

            # <Value u'view/get_target_url | nothing' (2:28)> -> __value
            __token = 74
            try:
                __zt_tmp = __attrs_140402100088336
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/get_target_url | nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['target_url'] = __value
            __backup_link_text_140402098730960 = get('link_text', __marker)

            # <Value u'view/get_link_text | nothing' (3:26)> -> __value
            __token = 132
            try:
                __zt_tmp = __attrs_140402100088336
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('path', u'view/get_link_text | nothing', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['link_text'] = __value

            # <Value u'target_url' (4:20)> -> __condition
            __token = 184
            try:
                __zt_tmp = __attrs_140402100088336
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'target_url', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:
                __previous_i18n_domain_140402100085392 = __i18n_domain
                __i18n_domain = u'senaite.core'

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="mb-2">\r\n  ')

                # <Static value=<_ast.Dict object at 0x7fb1e94d2b10> name=None at 7fb1e94d2310> -> __attrs_140402100088272
                __attrs_140402100088272 = _static_140402100087568

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a      class="text-muted small"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100087248
                __default_140402100087248 = _DEFAULT_MARKER

                # <Substitution u'target_url' (5:26)> -> __attr_href
                __token = 224
                try:
                    __zt_tmp = __attrs_140402100088272
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_140402272508048('path', u'target_url', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e9608590> name=None at 7fb1e9608510> -> __attrs_140402101356560
                __attrs_140402101356560 = _static_140402101355920

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-arrow-right"></i>\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402098802960
                __attrs_140402098802960 = _static_140402356200592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101355984
                __default_140402101355984 = _DEFAULT_MARKER

                # <Value u'link_text' (8:23)> -> __cache_140402101355472
                __token = 332
                try:
                    __zt_tmp = __attrs_140402098802960
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402101355472 = _static_140402272508048('path', u'link_text', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'link_text' (8:23)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e9608f90> -> __condition
                __expression = __cache_140402101355472

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Link text')
                else:
                    __content = __cache_140402101355472
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n  </a>\r\n</div>')
                __i18n_domain = __previous_i18n_domain_140402100085392
            if (__backup_link_text_140402098730960 is __marker):
                del econtext['link_text']
            else:
                econtext['link_text'] = __backup_link_text_140402098730960
            if (__backup_target_url_140402099854352 is __marker):
                del econtext['target_url']
            else:
                econtext['target_url'] = __backup_target_url_140402099854352
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }