# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/duration/input.pt'

__tokens = {188: (u'python:view.name', 6, 30), 236: (u' python:view.valu', 7, 29), 285: (u"  python:value.get('days', ", 8, 28), 344: (u"   python:value.get('hours',", 9, 27), 404: (u"    python:value.get('minutes'", 10, 26), 466: (u"s    python:value.get('seconds", 11, 25), 528: (u'      python:view', 12, 24), 577: (u"_klass python:'{}-input'.format", 13, 23), 640: (u"ss      python:' '.join([klass, mode", 14, 22), 717: (u'klass', 15, 29), 782: (u'string:${name}.days:record:int', 18, 26), 848: (u"python:'col-auto' if view.show_days else 'd-none'", 19, 33), 996: (u'id', 21, 35), 1087: (u'id', 23, 34), 1127: (u' i', 24, 35), 1168: (u'e da', 25, 35), 1249: (u'string:${name}.hours:record:int', 28, 26), 1316: (u"python:'col-auto' if view.show_hours else 'd-none'", 29, 33), 1466: (u'id', 31, 35), 1558: (u'id', 33, 34), 1598: (u' i', 34, 35), 1639: (u'e hou', 35, 35), 1720: (u'string:${name}.minutes:record:int', 38, 26), 1789: (u"python:'col-auto' if view.show_minutes else 'd-none'", 39, 33), 1943: (u'id', 41, 35), 2037: (u'id', 43, 34), 2077: (u' i', 44, 35), 2118: (u'e minut', 45, 35), 2201: (u'string:${name}.seconds:record:int', 48, 26), 2270: (u"python:'col-auto' if view.show_seconds else 'd-none'", 49, 33), 2424: (u'id', 51, 35), 2518: (u'id', 53, 34), 2558: (u' i', 54, 35), 2599: (u'e secon', 55, 35)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402099471120 = {u'class': u'form-row', }
_static_140402099573392 = {u'value': u'seconds', u'type': u'number', u'id': u'id', u'name': u'id', u'size': u'5', }
_static_140402100086544 = {u'value': u'minutes', u'type': u'number', u'id': u'id', u'name': u'id', u'size': u'5', }
_static_140402272508048 = __compile_zt_expr
_static_140402097893840 = {u'value': u'days', u'type': u'number', u'id': u'id', u'name': u'id', u'size': u'5', }
_static_140402100086416 = {u'for': u'id', }
_static_140402099816144 = {u'value': u'hours', u'type': u'number', u'id': u'id', u'name': u'id', u'size': u'5', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402100149968 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402099573840 = {u'class': u'col-auto', }
_static_140402099815376 = {u'for': u'id', }
_static_140402099576464 = {u'for': u'id', }
_static_140402099816016 = {u'class': u'col-auto', }
_static_140402099473040 = {u'class': u"python:'col-auto' if view.show_days else 'd-none'", }
_static_140402100149584 = {u'class': u'klass', }
_static_140402097894928 = {u'class': u'col-auto', }
_static_140402099472592 = {u'for': u'id', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e94e1ed0> name=None at 7fb1e94e1150> -> __attrs_140402099492240
            __attrs_140402099492240 = _static_140402100149968
            __previous_i18n_domain_140402100149520 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e94e1d50> name=None at 7fb1e94e1f10> -> __attrs_140402100149392
            __attrs_140402100149392 = _static_140402100149584
            __backup_name_140402101654096 = get('name', __marker)

            # <Value u'python:view.name' (6:30)> -> __value
            __token = 188
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.name', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['name'] = __value
            __backup_value_140402101902352 = get('value', __marker)

            # <Value u'python:view.value' (7:29)> -> __value
            __token = 236
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.value', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['value'] = __value
            __backup_days_140402101070032 = get('days', __marker)

            # <Value u"python:value.get('days', 0)" (8:28)> -> __value
            __token = 285
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"value.get('days', 0)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['days'] = __value
            __backup_hours_140402102472912 = get('hours', __marker)

            # <Value u"python:value.get('hours', 0)" (9:27)> -> __value
            __token = 344
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"value.get('hours', 0)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['hours'] = __value
            __backup_minutes_140402101089360 = get('minutes', __marker)

            # <Value u"python:value.get('minutes', 0)" (10:26)> -> __value
            __token = 404
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"value.get('minutes', 0)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['minutes'] = __value
            __backup_seconds_140402102461904 = get('seconds', __marker)

            # <Value u"python:value.get('seconds', 0)" (11:25)> -> __value
            __token = 466
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"value.get('seconds', 0)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['seconds'] = __value
            __backup_klass_140402101337488 = get('klass', __marker)

            # <Value u'python:view.klass' (12:24)> -> __value
            __token = 528
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u'view.klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['klass'] = __value
            __backup_mode_klass_140402102064144 = get('mode_klass', __marker)

            # <Value u"python:'{}-input'.format(klass)" (13:23)> -> __value
            __token = 577
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"'{}-input'.format(klass)", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['mode_klass'] = __value
            __backup_klass_140402101931344 = get('klass', __marker)

            # <Value u"python:' '.join([klass, mode_klass])" (14:22)> -> __value
            __token = 640
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('python', u"' '.join([klass, mode_klass])", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['klass'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100146640
            __default_140402100146640 = _DEFAULT_MARKER

            # <Substitution u'klass' (15:29)> -> __attr_class
            __token = 717
            try:
                __zt_tmp = __attrs_140402100149392
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('path', u'klass', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e943c310> name=None at 7fb1e943c490> -> __attrs_140402099472912
            __attrs_140402099472912 = _static_140402099471120

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form-row">\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1e943ca90> name=None at 7fb1e943cb10> -> __attrs_140402099471184
            __attrs_140402099471184 = _static_140402099473040
            __backup_id_140402101747664 = get('id', __marker)

            # <Value u'string:${name}.days:record:int' (18:26)> -> __value
            __token = 782
            try:
                __zt_tmp = __attrs_140402099471184
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('string', u'${name}.days:record:int', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['id'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099473744
            __default_140402099473744 = _DEFAULT_MARKER

            # <Substitution u"python:'col-auto' if view.show_days else 'd-none'" (19:33)> -> __attr_class
            __token = 848
            try:
                __zt_tmp = __attrs_140402099471184
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('python', u"'col-auto' if view.show_days else 'd-none'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e943c8d0> name=None at 7fb1e943c510> -> __attrs_140402099472784
            __attrs_140402099472784 = _static_140402099472592

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099470864
            __default_140402099470864 = _DEFAULT_MARKER

            # <Substitution u'id' (21:35)> -> __attr_for
            __token = 996
            try:
                __zt_tmp = __attrs_140402099472784
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_for = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_for is not None):
                __append((u' for="%s"' % __attr_for))
            __append(u'>')
            __stream_140402099471888 = []
            __append_140402099471888 = __stream_140402099471888.append
            __append_140402099471888(u'Days')
            __msgid_140402099471888 = __re_whitespace(''.join(__stream_140402099471888)).strip()
            if u'duration_widget_label_days':
                __append(translate(u'duration_widget_label_days', mapping=None, default=__msgid_140402099471888, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e92bb1d0> name=None at 7fb1e92bb710> -> __attrs_140402097894480
            __attrs_140402097894480 = _static_140402097893840

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="number" size="5"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402097893456
            __default_140402097893456 = _DEFAULT_MARKER

            # <Substitution u'id' (23:34)> -> __attr_id
            __token = 1087
            try:
                __zt_tmp = __attrs_140402097894480
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402097895824
            __default_140402097895824 = _DEFAULT_MARKER

            # <Substitution u'id' (24:35)> -> __attr_name
            __token = 1127
            try:
                __zt_tmp = __attrs_140402097894480
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402097895120
            __default_140402097895120 = _DEFAULT_MARKER

            # <Substitution u'days' (25:35)> -> __attr_value
            __token = 1168
            try:
                __zt_tmp = __attrs_140402097894480
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_140402272508048('path', u'days', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\r\n      </div>')
            if (__backup_id_140402101747664 is __marker):
                del econtext['id']
            else:
                econtext['id'] = __backup_id_140402101747664
            __append(u'\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1e92bb610> name=None at 7fb1e943c190> -> __attrs_140402097893904
            __attrs_140402097893904 = _static_140402097894928
            __backup_id_140402100218256 = get('id', __marker)

            # <Value u'string:${name}.hours:record:int' (28:26)> -> __value
            __token = 1249
            try:
                __zt_tmp = __attrs_140402097893904
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('string', u'${name}.hours:record:int', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['id'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402097895056
            __default_140402097895056 = _DEFAULT_MARKER

            # <Substitution u"python:'col-auto' if view.show_hours else 'd-none'" (29:33)> -> __attr_class
            __token = 1316
            try:
                __zt_tmp = __attrs_140402097893904
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('python', u"'col-auto' if view.show_hours else 'd-none'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'col-auto', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e94903d0> name=None at 7fb1e9490f90> -> __attrs_140402099816912
            __attrs_140402099816912 = _static_140402099815376

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099817360
            __default_140402099817360 = _DEFAULT_MARKER

            # <Substitution u'id' (31:35)> -> __attr_for
            __token = 1466
            try:
                __zt_tmp = __attrs_140402099816912
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_for = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_for is not None):
                __append((u' for="%s"' % __attr_for))
            __append(u'>')
            __stream_140402100057040 = []
            __append_140402100057040 = __stream_140402100057040.append
            __append_140402100057040(u'Hours')
            __msgid_140402100057040 = __re_whitespace(''.join(__stream_140402100057040)).strip()
            if u'duration_widget_label_hours':
                __append(translate(u'duration_widget_label_hours', mapping=None, default=__msgid_140402100057040, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e94906d0> name=None at 7fb1e9490350> -> __attrs_140402099814864
            __attrs_140402099814864 = _static_140402099816144

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="number" size="5"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099817424
            __default_140402099817424 = _DEFAULT_MARKER

            # <Substitution u'id' (33:34)> -> __attr_id
            __token = 1558
            try:
                __zt_tmp = __attrs_140402099814864
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099815696
            __default_140402099815696 = _DEFAULT_MARKER

            # <Substitution u'id' (34:35)> -> __attr_name
            __token = 1598
            try:
                __zt_tmp = __attrs_140402099814864
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099817168
            __default_140402099817168 = _DEFAULT_MARKER

            # <Substitution u'hours' (35:35)> -> __attr_value
            __token = 1639
            try:
                __zt_tmp = __attrs_140402099814864
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_140402272508048('path', u'hours', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\r\n      </div>')
            if (__backup_id_140402100218256 is __marker):
                del econtext['id']
            else:
                econtext['id'] = __backup_id_140402100218256
            __append(u'\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1e9490650> name=None at 7fb1e94904d0> -> __attrs_140402100088400
            __attrs_140402100088400 = _static_140402099816016
            __backup_id_140402100338256 = get('id', __marker)

            # <Value u'string:${name}.minutes:record:int' (38:26)> -> __value
            __token = 1720
            try:
                __zt_tmp = __attrs_140402100088400
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('string', u'${name}.minutes:record:int', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['id'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099818192
            __default_140402099818192 = _DEFAULT_MARKER

            # <Substitution u"python:'col-auto' if view.show_minutes else 'd-none'" (39:33)> -> __attr_class
            __token = 1789
            try:
                __zt_tmp = __attrs_140402100088400
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('python', u"'col-auto' if view.show_minutes else 'd-none'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'col-auto', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e94d2690> name=None at 7fb1e94d2850> -> __attrs_140402100087760
            __attrs_140402100087760 = _static_140402100086416

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100087504
            __default_140402100087504 = _DEFAULT_MARKER

            # <Substitution u'id' (41:35)> -> __attr_for
            __token = 1943
            try:
                __zt_tmp = __attrs_140402100087760
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_for = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_for is not None):
                __append((u' for="%s"' % __attr_for))
            __append(u'>')
            __stream_140402100085520 = []
            __append_140402100085520 = __stream_140402100085520.append
            __append_140402100085520(u'Minutes')
            __msgid_140402100085520 = __re_whitespace(''.join(__stream_140402100085520)).strip()
            if u'duration_widget_label_minutes':
                __append(translate(u'duration_widget_label_minutes', mapping=None, default=__msgid_140402100085520, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e94d2710> name=None at 7fb1e94d2f10> -> __attrs_140402099573008
            __attrs_140402099573008 = _static_140402100086544

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="number" size="5"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100084880
            __default_140402100084880 = _DEFAULT_MARKER

            # <Substitution u'id' (43:34)> -> __attr_id
            __token = 2037
            try:
                __zt_tmp = __attrs_140402099573008
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402100087952
            __default_140402100087952 = _DEFAULT_MARKER

            # <Substitution u'id' (44:35)> -> __attr_name
            __token = 2077
            try:
                __zt_tmp = __attrs_140402099573008
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099575440
            __default_140402099575440 = _DEFAULT_MARKER

            # <Substitution u'minutes' (45:35)> -> __attr_value
            __token = 2118
            try:
                __zt_tmp = __attrs_140402099573008
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_140402272508048('path', u'minutes', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\r\n      </div>')
            if (__backup_id_140402100338256 is __marker):
                del econtext['id']
            else:
                econtext['id'] = __backup_id_140402100338256
            __append(u'\r\n      ')

            # <Static value=<_ast.Dict object at 0x7fb1e9455450> name=None at 7fb1e94d2390> -> __attrs_140402099576016
            __attrs_140402099576016 = _static_140402099573840
            __backup_id_140402101091792 = get('id', __marker)

            # <Value u'string:${name}.seconds:record:int' (48:26)> -> __value
            __token = 2201
            try:
                __zt_tmp = __attrs_140402099576016
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_140402272508048('string', u'${name}.seconds:record:int', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            econtext['id'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099573584
            __default_140402099573584 = _DEFAULT_MARKER

            # <Substitution u"python:'col-auto' if view.show_seconds else 'd-none'" (49:33)> -> __attr_class
            __token = 2270
            try:
                __zt_tmp = __attrs_140402099576016
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_140402272508048('python', u"'col-auto' if view.show_seconds else 'd-none'", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'col-auto', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9455e90> name=None at 7fb1e9455f90> -> __attrs_140402099574416
            __attrs_140402099574416 = _static_140402099576464

            # <label ... (0:0)
            # --------------------------------------------------------
            __append(u'<label')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099574352
            __default_140402099574352 = _DEFAULT_MARKER

            # <Substitution u'id' (51:35)> -> __attr_for
            __token = 2424
            try:
                __zt_tmp = __attrs_140402099574416
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_for = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_for = __quote(__attr_for, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_for is not None):
                __append((u' for="%s"' % __attr_for))
            __append(u'>')
            __stream_140402099575888 = []
            __append_140402099575888 = __stream_140402099575888.append
            __append_140402099575888(u'Seconds')
            __msgid_140402099575888 = __re_whitespace(''.join(__stream_140402099575888)).strip()
            if u'duration_widget_label_seconds':
                __append(translate(u'duration_widget_label_seconds', mapping=None, default=__msgid_140402099575888, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</label>\r\n        ')

            # <Static value=<_ast.Dict object at 0x7fb1e9455290> name=None at 7fb1e9455490> -> __attrs_140402099206544
            __attrs_140402099206544 = _static_140402099573392

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input type="number" size="5"')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099207248
            __default_140402099207248 = _DEFAULT_MARKER

            # <Substitution u'id' (53:34)> -> __attr_id
            __token = 2518
            try:
                __zt_tmp = __attrs_140402099206544
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099206736
            __default_140402099206736 = _DEFAULT_MARKER

            # <Substitution u'id' (54:35)> -> __attr_name
            __token = 2558
            try:
                __zt_tmp = __attrs_140402099206544
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('path', u'id', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099205712
            __default_140402099205712 = _DEFAULT_MARKER

            # <Substitution u'seconds' (55:35)> -> __attr_value
            __token = 2599
            try:
                __zt_tmp = __attrs_140402099206544
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_value = _static_140402272508048('path', u'seconds', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_value is not None):
                __append((u' value="%s"' % __attr_value))
            __append(u'/>\r\n      </div>')
            if (__backup_id_140402101091792 is __marker):
                del econtext['id']
            else:
                econtext['id'] = __backup_id_140402101091792
            __append(u'\r\n\r\n    </div>\r\n  </div>')
            if (__backup_klass_140402101931344 is __marker):
                del econtext['klass']
            else:
                econtext['klass'] = __backup_klass_140402101931344
            if (__backup_mode_klass_140402102064144 is __marker):
                del econtext['mode_klass']
            else:
                econtext['mode_klass'] = __backup_mode_klass_140402102064144
            if (__backup_klass_140402101337488 is __marker):
                del econtext['klass']
            else:
                econtext['klass'] = __backup_klass_140402101337488
            if (__backup_seconds_140402102461904 is __marker):
                del econtext['seconds']
            else:
                econtext['seconds'] = __backup_seconds_140402102461904
            if (__backup_minutes_140402101089360 is __marker):
                del econtext['minutes']
            else:
                econtext['minutes'] = __backup_minutes_140402101089360
            if (__backup_hours_140402102472912 is __marker):
                del econtext['hours']
            else:
                econtext['hours'] = __backup_hours_140402102472912
            if (__backup_days_140402101070032 is __marker):
                del econtext['days']
            else:
                econtext['days'] = __backup_days_140402101070032
            if (__backup_value_140402101902352 is __marker):
                del econtext['value']
            else:
                econtext['value'] = __backup_value_140402101902352
            if (__backup_name_140402101654096 is __marker):
                del econtext['name']
            else:
                econtext['name'] = __backup_name_140402101654096
            __append(u'\r\n\r\n')
            __i18n_domain = __previous_i18n_domain_140402100149520
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }