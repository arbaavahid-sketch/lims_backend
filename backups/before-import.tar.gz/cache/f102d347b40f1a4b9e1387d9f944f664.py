# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/Products.CMFPlone-5.2.15-py2.7.egg/Products/CMFPlone/browser/templates/error_message.pt'

__tokens = {390: (u'options/error_type|nothing', 11, 26), 441: (u' options/error_tb|nothin', 12, 23), 494: (u'd options/error_log_id|nothi', 13, 26), 567: (u"python:err_type == 'NotFound'", 15, 39), 651: (u'nocall:view/@@plone_redirector_view', 17, 51), 1690: (u'string:${context/portal_url}/contact-info', 35, 48), 2046: (u'redirection_view/find_first_parent', 43, 58), 2140: (u' redirection_view/search_for_simila', 44, 58), 2232: (u'w context/@@plo', 45, 54), 2302: (u'ry context/portal_regis', 46, 51), 2387: (u"ion python:registry['plone.types_use_view_action_in_listin", 47, 57), 2503: (u"ngth python:registry['plone.search_results_description_len", 48, 52), 2623: (u'tring nocall:plone_view/normalize', 49, 55), 2713: (u'python:first_parent is not None or similar_items', 50, 48), 3022: (u'first_parent/absolute_url | nothing', 56, 52), 3115: (u'first_parent/absolute_url', 57, 55), 3197: (u" python:hasattr(first_parent, 'getTypeInfo') and first_parent.getTypeInfo().getId(", 58, 55), 3328: (u"l python:result_url + '/view' if result_type in use_view_action else result_u", 59, 46), 3457: (u'result_type', 60, 47), 3587: (u"python:' state-' + context.portal_workflow.getInfoFor(first_parent, 'review_state', '')", 62, 67), 3512: (u'${url}', 61, 41), 3514: (u'url', 61, 43), 3734: (u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class", 63, 57), 3810: (u'${first_parent/Title}', 63, 133), 3812: (u'first_parent/Title', 63, 135), 3887: (u'python:plone_view.cropText(first_parent.Description(), desc_length)', 64, 51), 4125: (u'similar_items', 68, 53), 4196: (u'similar/getURL', 69, 55), 4267: (u' similar/portal_typ', 70, 55), 4335: (u"l python:result_url + '/view' if result_type in use_view_action else result_u", 71, 46), 4534: (u'string: state-${similar/review_state}', 73, 67), 4459: (u'${url}', 72, 41), 4461: (u'url', 72, 43), 4631: (u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class", 74, 57), 4707: (u'${similar/pretty_title_or_id}', 74, 133), 4709: (u'similar/pretty_title_or_id', 74, 135), 4792: (u"python:plone_view.cropText(similar.Description or '', desc_length)", 75, 51), 5260: (u'view/is_manager', 89, 35), 5193: (u"python: err_type != 'NotFound'", 88, 41), 5548: (u'isManager', 97, 36), 5747: (u'err_tb', 102, 37), 5821: (u'not:isManager', 105, 40), 6222: (u'string:${context/portal_url}/contact-info', 111, 44), 261: (u'context/@@main_template/macros/master', 6, 23), 261: (u'context/@@main_template/macros/master', 6, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757232035984 = {u'class': u'discreet', }
_static_135757226772240 = {u'id': u'content-core', }
_static_135757226826960 = {u'class': u'documentFirstHeading', }
_static_135757226679440 = {u'class': u'description', }
_static_135757231986128 = {u'href': u'#', }
_static_135757244280656 = __compile_zt_expr
_static_135757226746896 = {u'class': u'documentFirstHeading', }
_static_135757226770640 = {u'class': u'discreet', }
_static_135757226607824 = {u'href': u'${url}', u'class': u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class", }
_static_135757231988112 = {u'class': u'discreet', }
_static_135757226824784 = {u'id': u'content-core', }
_static_135757134640848 = {u'href': u'#', }
_static_135757305627344 = u'master'
_static_135757327983760 = {}
_static_135757226773712 = {u'href': u'${url}', u'class': u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class", }
_static_135757226747664 = {u'id': u'page-not-found-list', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757305630416
            __attrs_135757305630416 = _static_135757327983760
            __previous_i18n_domain_135757305630352 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_135757115635664 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b7875fa42d0> name=None at 7b7875fa4e50> -> __value
            __value = _static_135757305627344
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757305628560
                __attrs_135757305628560 = _static_135757327983760
                __backup_err_type_135757226678480 = get('err_type', __marker)

                # <Value u'options/error_type|nothing' (11:26)> -> __value
                __token = 390
                try:
                    __zt_tmp = __attrs_135757305628560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'options/error_type|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['err_type'] = __value
                __backup_err_tb_135757232020688 = get('err_tb', __marker)

                # <Value u'options/error_tb|nothing' (12:23)> -> __value
                __token = 441
                try:
                    __zt_tmp = __attrs_135757305628560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'options/error_tb|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['err_tb'] = __value
                __backup_err_log_id_135757226680272 = get('err_log_id', __marker)

                # <Value u'options/error_log_id|nothing' (13:26)> -> __value
                __token = 494
                try:
                    __zt_tmp = __attrs_135757305628560
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'options/error_log_id|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['err_log_id'] = __value
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757305629840
                __attrs_135757305629840 = _static_135757327983760

                # <Value u"python:err_type == 'NotFound'" (15:39)> -> __condition
                __token = 567
                try:
                    __zt_tmp = __attrs_135757305629840
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u"err_type == 'NotFound'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226823888
                    __attrs_135757226823888 = _static_135757327983760
                    __backup_redirection_view_135757232019152 = get('redirection_view', __marker)

                    # <Value u'nocall:view/@@plone_redirector_view' (17:51)> -> __value
                    __token = 651
                    try:
                        __zt_tmp = __attrs_135757226823888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('nocall', u'view/@@plone_redirector_view', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['redirection_view'] = __value
                    __append(u'\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b787147dcd0> name=None at 7b787147dad0> -> __attrs_135757226826256
                    __attrs_135757226826256 = _static_135757226826960

                    # <h1 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h1 class="documentFirstHeading">')
                    __stream_135757226827664 = []
                    __append_135757226827664 = __stream_135757226827664.append
                    __append_135757226827664(u'\n                    This page does not seem to exist&hellip;\n                ')
                    __msgid_135757226827664 = __re_whitespace(''.join(__stream_135757226827664)).strip()
                    if u'heading_site_there_seems_to_be_an_error':
                        __append(translate(u'heading_site_there_seems_to_be_an_error', mapping=None, default=__msgid_135757226827664, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h1>\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b787147d450> name=None at 7b787147da90> -> __attrs_135757226678352
                    __attrs_135757226678352 = _static_135757226824784

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b7871459c90> name=None at 7b7871459450> -> __attrs_135757132717776
                    __attrs_135757132717776 = _static_135757226679440

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="description">')
                    __stream_135757226678672 = []
                    __append_135757226678672 = __stream_135757226678672.append
                    __append_135757226678672(u'\n \t                    We apologize for the inconvenience, but the page you were trying to access is not at this address.\n                        You can use the links below to help you find what you are looking for.\n                     ')
                    __msgid_135757226678672 = __re_whitespace(''.join(__stream_135757226678672)).strip()
                    if u'description_site_error':
                        __append(translate(u'description_site_error', mapping=None, default=__msgid_135757226678672, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b7871969d90> name=None at 7b7871969d10> -> __attrs_135757231986768
                    __attrs_135757231986768 = _static_135757231988112

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="discreet">')
                    __stream_135757151979232_site_admin = ''
                    __stream_135757132715792 = []
                    __append_135757132715792 = __stream_135757132715792.append
                    __append_135757132715792(u'\n                        If you are certain you have the correct web address but are encountering an error, please\n                        contact the ')
                    __stream_135757151979232_site_admin = []
                    __append_135757151979232_site_admin = __stream_135757151979232_site_admin.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757231987408
                    __attrs_135757231987408 = _static_135757327983760

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757151979232_site_admin(u'<span>\n                        ')

                    # <Static value=<_ast.Dict object at 0x7b78719695d0> name=None at 7b7871969f50> -> __attrs_135757231982800
                    __attrs_135757231982800 = _static_135757231986128

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_135757151979232_site_admin(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757231981008
                    __default_135757231981008 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/portal_url}/contact-info' (35:48)> -> __attr_href
                    __token = 1690
                    try:
                        __zt_tmp = __attrs_135757231982800
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('string', u'${context/portal_url}/contact-info', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_135757151979232_site_admin((u' href="%s"' % __attr_href))
                    __append_135757151979232_site_admin(u'>')
                    __stream_135757231985680 = []
                    __append_135757231985680 = __stream_135757231985680.append
                    __append_135757231985680(u'site administration')
                    __msgid_135757231985680 = __re_whitespace(''.join(__stream_135757231985680)).strip()
                    if u'label_site_admin':
                        __append_135757151979232_site_admin(translate(u'label_site_admin', mapping=None, default=__msgid_135757231985680, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_135757151979232_site_admin(u'</a></span>')
                    __append_135757132715792(u'${site_admin}')
                    __stream_135757151979232_site_admin = ''.join(__stream_135757151979232_site_admin)
                    __append_135757132715792(u'.\n                    ')
                    __msgid_135757132715792 = __re_whitespace(''.join(__stream_135757132715792)).strip()
                    if u'description_site_error_mail_site_admin':
                        __append(translate(u'description_site_error_mail_site_admin', mapping={u'site_admin': __stream_135757151979232_site_admin, }, default=__msgid_135757132715792, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757231987856
                    __attrs_135757231987856 = _static_135757327983760

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p>')
                    __stream_135757231986832 = []
                    __append_135757231986832 = __stream_135757231986832.append
                    __append_135757231986832(u'\n                    Thank you.\n                    ')
                    __msgid_135757231986832 = __re_whitespace(''.join(__stream_135757231986832)).strip()
                    if u'description_site_error_thank_you':
                        __append(translate(u'description_site_error_thank_you', mapping=None, default=__msgid_135757231986832, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>\n\n                    <!-- Offer search results for suggestions -->\n                    ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138291216
                    __attrs_135757138291216 = _static_135757327983760
                    __backup_first_parent_135757132503184 = get('first_parent', __marker)

                    # <Value u'redirection_view/find_first_parent' (43:58)> -> __value
                    __token = 2046
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'redirection_view/find_first_parent', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['first_parent'] = __value
                    __backup_similar_items_135757226826512 = get('similar_items', __marker)

                    # <Value u'redirection_view/search_for_similar' (44:58)> -> __value
                    __token = 2140
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'redirection_view/search_for_similar', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['similar_items'] = __value
                    __backup_plone_view_135757232018768 = get('plone_view', __marker)

                    # <Value u'context/@@plone' (45:54)> -> __value
                    __token = 2232
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'context/@@plone', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['plone_view'] = __value
                    __backup_registry_135757232034448 = get('registry', __marker)

                    # <Value u'context/portal_registry' (46:51)> -> __value
                    __token = 2302
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'context/portal_registry', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['registry'] = __value
                    __backup_use_view_action_135757132572560 = get('use_view_action', __marker)

                    # <Value u"python:registry['plone.types_use_view_action_in_listings']" (47:57)> -> __value
                    __token = 2387
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u"registry['plone.types_use_view_action_in_listings']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['use_view_action'] = __value
                    __backup_desc_length_135757226697104 = get('desc_length', __marker)

                    # <Value u"python:registry['plone.search_results_description_length']" (48:52)> -> __value
                    __token = 2503
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u"registry['plone.search_results_description_length']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['desc_length'] = __value
                    __backup_normalizeString_135757132503504 = get('normalizeString', __marker)

                    # <Value u'nocall:plone_view/normalizeString' (49:55)> -> __value
                    __token = 2623
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('nocall', u'plone_view/normalizeString', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value

                    # <Value u'python:first_parent is not None or similar_items' (50:48)> -> __condition
                    __token = 2713
                    try:
                        __zt_tmp = __attrs_135757138291216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'first_parent is not None or similar_items', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226746448
                        __attrs_135757226746448 = _static_135757327983760

                        # <h2 ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<h2>')
                        __stream_135757132661328 = []
                        __append_135757132661328 = __stream_135757132661328.append
                        __append_135757132661328(u'You might have been looking for&hellip;')
                        __msgid_135757132661328 = __re_whitespace(''.join(__stream_135757132661328)).strip()
                        if u'heading_not_found_suggestions':
                            __append(translate(u'heading_not_found_suggestions', mapping=None, default=__msgid_135757132661328, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</h2>\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226746000
                        __attrs_135757226746000 = _static_135757327983760

                        # <nav ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<nav>\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b787146a710> name=None at 7b787146a750> -> __attrs_135757226748432
                        __attrs_135757226748432 = _static_135757226747664

                        # <ul ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<ul id="page-not-found-list">\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226748880
                        __attrs_135757226748880 = _static_135757327983760

                        # <Value u'first_parent/absolute_url | nothing' (56:52)> -> __condition
                        __token = 3022
                        try:
                            __zt_tmp = __attrs_135757226748880
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_135757244280656('path', u'first_parent/absolute_url | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if __condition:
                            __append(u'\n                            ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226606928
                            __attrs_135757226606928 = _static_135757327983760
                            __backup_result_url_135757226748752 = get('result_url', __marker)

                            # <Value u'first_parent/absolute_url' (57:55)> -> __value
                            __token = 3115
                            try:
                                __zt_tmp = __attrs_135757226606928
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('path', u'first_parent/absolute_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['result_url'] = __value
                            __backup_result_type_135757226676496 = get('result_type', __marker)

                            # <Value u"python:hasattr(first_parent, 'getTypeInfo') and first_parent.getTypeInfo().getId()" (58:55)> -> __value
                            __token = 3197
                            try:
                                __zt_tmp = __attrs_135757226606928
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"hasattr(first_parent, 'getTypeInfo') and first_parent.getTypeInfo().getId()", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['result_type'] = __value
                            __backup_url_135757226606864 = get('url', __marker)

                            # <Value u"python:result_url + '/view' if result_type in use_view_action else result_url" (59:46)> -> __value
                            __token = 3328
                            try:
                                __zt_tmp = __attrs_135757226606928
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"result_url + '/view' if result_type in use_view_action else result_url", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['url'] = __value

                            # <Value u'result_type' (60:47)> -> __condition
                            __token = 3457
                            try:
                                __zt_tmp = __attrs_135757226606928
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_135757244280656('path', u'result_type', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            if __condition:

                                # <li ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<li>\n                                ')

                                # <Static value=<_ast.Dict object at 0x7b78714484d0> name=None at 7b7871448490> -> __attrs_135757226610192
                                __attrs_135757226610192 = _static_135757226607824
                                __backup_item_wf_state_class_135757226607888 = get('item_wf_state_class', __marker)

                                # <Value u"python:' state-' + context.portal_workflow.getInfoFor(first_parent, 'review_state', '')" (62:67)> -> __value
                                __token = 3587
                                try:
                                    __zt_tmp = __attrs_135757226610192
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __value = _static_135757244280656('python', u"' state-' + context.portal_workflow.getInfoFor(first_parent, 'review_state', '')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                econtext['item_wf_state_class'] = __value

                                # <a ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<a')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226609616
                                __default_135757226609616 = _DEFAULT_MARKER

                                # <Interpolation value=<Substitution u'${url}' (61:41)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b7871448050> -> __attr_href
                                __token = 3512
                                __token = 3514
                                try:
                                    __zt_tmp = __attrs_135757226610192
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_href = _static_135757244280656('path', u'url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                                __attr_href = __attr_href
                                if (__attr_href is None):
                                    pass
                                else:
                                    if (__attr_href is _DEFAULT_MARKER):
                                        __attr_href = None
                                    else:
                                        __tt = type(__attr_href)
                                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                                            __attr_href = unicode(__attr_href)
                                        else:
                                            if (__tt is str):
                                                __attr_href = decode(__attr_href)
                                            else:
                                                if (__tt is not unicode):
                                                    try:
                                                        __attr_href = __attr_href.__html__
                                                    except get('AttributeError', AttributeError):
                                                        __converted = convert(__attr_href)
                                                        __attr_href = (unicode(__attr_href) if (__attr_href is __converted) else __converted)
                                                    else:
                                                        __attr_href = __attr_href()
                                if (__attr_href is not None):
                                    __append((u' href="%s"' % __attr_href))

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226610640
                                __default_135757226610640 = _DEFAULT_MARKER

                                # <Substitution u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class" (63:57)> -> __attr_class
                                __token = 3734
                                try:
                                    __zt_tmp = __attrs_135757226610192
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __attr_class = _static_135757244280656('python', u"'contenttype-' + normalizeString(result_type) + item_wf_state_class", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                if (__attr_class is not None):
                                    __append((u' class="%s"' % __attr_class))
                                __append(u'>')

                                # <Interpolation value=<Substitution u'${first_parent/Title}' (63:133)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b7871975e90> -> __content_135757397202144
                                __token = 3810
                                __token = 3812
                                try:
                                    __zt_tmp = __attrs_135757226610192
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __content_135757397202144 = _static_135757244280656('path', u'first_parent/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __content_135757397202144 = __quote(__content_135757397202144, '\x00', '&#0;', None, None)
                                __content_135757397202144 = __content_135757397202144
                                if (__content_135757397202144 is None):
                                    pass
                                else:
                                    if (__content_135757397202144 is None):
                                        __content_135757397202144 = None
                                    else:
                                        __tt = type(__content_135757397202144)
                                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                                            __content_135757397202144 = unicode(__content_135757397202144)
                                        else:
                                            if (__tt is str):
                                                __content_135757397202144 = decode(__content_135757397202144)
                                            else:
                                                if (__tt is not unicode):
                                                    try:
                                                        __content_135757397202144 = __content_135757397202144.__html__
                                                    except get('AttributeError', AttributeError):
                                                        __converted = convert(__content_135757397202144)
                                                        __content_135757397202144 = (unicode(__content_135757397202144) if (__content_135757397202144 is __converted) else __converted)
                                                    else:
                                                        __content_135757397202144 = __content_135757397202144()
                                if (__content_135757397202144 is not None):
                                    __append(__content_135757397202144)
                                __append(u'</a>')
                                if (__backup_item_wf_state_class_135757226607888 is __marker):
                                    del econtext['item_wf_state_class']
                                else:
                                    econtext['item_wf_state_class'] = __backup_item_wf_state_class_135757226607888
                                __append(u'\n                                ')

                                # <Static value=<_ast.Dict object at 0x7b7871975890> name=None at 7b7871975090> -> __attrs_135757232035792
                                __attrs_135757232035792 = _static_135757232035984

                                # <span ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<span class="discreet">')

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232036880
                                __default_135757232036880 = _DEFAULT_MARKER

                                # <Value u'python:plone_view.cropText(first_parent.Description(), desc_length)' (64:51)> -> __cache_135757232036112
                                __token = 3887
                                try:
                                    __zt_tmp = __attrs_135757232035792
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_135757232036112 = _static_135757244280656('python', u'plone_view.cropText(first_parent.Description(), desc_length)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                                # <BinOp left=<Value u'python:plone_view.cropText(first_parent.Description(), desc_length)' (64:51)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871975510> -> __condition
                                __expression = __cache_135757232036112

                                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    __append(u' Description ')
                                else:
                                    __content = __cache_135757232036112
                                    __content = __quote(__content, None, '\xad', None, None)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</span>\n                            </li>')
                            if (__backup_url_135757226606864 is __marker):
                                del econtext['url']
                            else:
                                econtext['url'] = __backup_url_135757226606864
                            if (__backup_result_type_135757226676496 is __marker):
                                del econtext['result_type']
                            else:
                                econtext['result_type'] = __backup_result_type_135757226676496
                            if (__backup_result_url_135757226748752 is __marker):
                                del econtext['result_url']
                            else:
                                econtext['result_url'] = __backup_result_url_135757226748752
                            __append(u'\n                        ')
                        __append(u'\n\n                        ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226607120
                        __attrs_135757226607120 = _static_135757327983760
                        __backup_similar_135757237165136 = get('similar', __marker)

                        # <Value u'similar_items' (68:53)> -> __iterator
                        __token = 4125
                        try:
                            __zt_tmp = __attrs_135757226607120
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_135757244280656('path', u'similar_items', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        (__iterator, ____index_135757226608848, ) = getitem('repeat')(u'similar', __iterator)
                        econtext['similar'] = None
                        for __item in __iterator:
                            econtext['similar'] = __item
                            __append(u'\n                            ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232035536
                            __attrs_135757232035536 = _static_135757327983760
                            __backup_result_url_135757226608912 = get('result_url', __marker)

                            # <Value u'similar/getURL' (69:55)> -> __value
                            __token = 4196
                            try:
                                __zt_tmp = __attrs_135757232035536
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('path', u'similar/getURL', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['result_url'] = __value
                            __backup_result_type_135757232020496 = get('result_type', __marker)

                            # <Value u'similar/portal_type' (70:55)> -> __value
                            __token = 4267
                            try:
                                __zt_tmp = __attrs_135757232035536
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('path', u'similar/portal_type', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['result_type'] = __value
                            __backup_url_135757226608336 = get('url', __marker)

                            # <Value u"python:result_url + '/view' if result_type in use_view_action else result_url" (71:46)> -> __value
                            __token = 4335
                            try:
                                __zt_tmp = __attrs_135757232035536
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"result_url + '/view' if result_type in use_view_action else result_url", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['url'] = __value

                            # <li ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<li>\n                                ')

                            # <Static value=<_ast.Dict object at 0x7b7871470cd0> name=None at 7b7871975310> -> __attrs_135757226774224
                            __attrs_135757226774224 = _static_135757226773712
                            __backup_item_wf_state_class_135757226610064 = get('item_wf_state_class', __marker)

                            # <Value u'string: state-${similar/review_state}' (73:67)> -> __value
                            __token = 4534
                            try:
                                __zt_tmp = __attrs_135757226774224
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('string', u' state-${similar/review_state}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['item_wf_state_class'] = __value

                            # <a ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<a')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226773520
                            __default_135757226773520 = _DEFAULT_MARKER

                            # <Interpolation value=<Substitution u'${url}' (72:41)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b7871470810> -> __attr_href
                            __token = 4459
                            __token = 4461
                            try:
                                __zt_tmp = __attrs_135757226774224
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_href = _static_135757244280656('path', u'url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                            __attr_href = __attr_href
                            if (__attr_href is None):
                                pass
                            else:
                                if (__attr_href is _DEFAULT_MARKER):
                                    __attr_href = None
                                else:
                                    __tt = type(__attr_href)
                                    if ((__tt is int) or (__tt is float) or (__tt is long)):
                                        __attr_href = unicode(__attr_href)
                                    else:
                                        if (__tt is str):
                                            __attr_href = decode(__attr_href)
                                        else:
                                            if (__tt is not unicode):
                                                try:
                                                    __attr_href = __attr_href.__html__
                                                except get('AttributeError', AttributeError):
                                                    __converted = convert(__attr_href)
                                                    __attr_href = (unicode(__attr_href) if (__attr_href is __converted) else __converted)
                                                else:
                                                    __attr_href = __attr_href()
                            if (__attr_href is not None):
                                __append((u' href="%s"' % __attr_href))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226773840
                            __default_135757226773840 = _DEFAULT_MARKER

                            # <Substitution u"python:'contenttype-' + normalizeString(result_type) + item_wf_state_class" (74:57)> -> __attr_class
                            __token = 4631
                            try:
                                __zt_tmp = __attrs_135757226774224
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_class = _static_135757244280656('python', u"'contenttype-' + normalizeString(result_type) + item_wf_state_class", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_class is not None):
                                __append((u' class="%s"' % __attr_class))
                            __append(u'>')

                            # <Interpolation value=<Substitution u'${similar/pretty_title_or_id}' (74:133)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7b7871470910> -> __content_135757397202144
                            __token = 4707
                            __token = 4709
                            try:
                                __zt_tmp = __attrs_135757226774224
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __content_135757397202144 = _static_135757244280656('path', u'similar/pretty_title_or_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __content_135757397202144 = __quote(__content_135757397202144, '\x00', '&#0;', None, None)
                            __content_135757397202144 = __content_135757397202144
                            if (__content_135757397202144 is None):
                                pass
                            else:
                                if (__content_135757397202144 is None):
                                    __content_135757397202144 = None
                                else:
                                    __tt = type(__content_135757397202144)
                                    if ((__tt is int) or (__tt is float) or (__tt is long)):
                                        __content_135757397202144 = unicode(__content_135757397202144)
                                    else:
                                        if (__tt is str):
                                            __content_135757397202144 = decode(__content_135757397202144)
                                        else:
                                            if (__tt is not unicode):
                                                try:
                                                    __content_135757397202144 = __content_135757397202144.__html__
                                                except get('AttributeError', AttributeError):
                                                    __converted = convert(__content_135757397202144)
                                                    __content_135757397202144 = (unicode(__content_135757397202144) if (__content_135757397202144 is __converted) else __converted)
                                                else:
                                                    __content_135757397202144 = __content_135757397202144()
                            if (__content_135757397202144 is not None):
                                __append(__content_135757397202144)
                            __append(u'</a>')
                            if (__backup_item_wf_state_class_135757226610064 is __marker):
                                del econtext['item_wf_state_class']
                            else:
                                econtext['item_wf_state_class'] = __backup_item_wf_state_class_135757226610064
                            __append(u'\n                                ')

                            # <Static value=<_ast.Dict object at 0x7b78714700d0> name=None at 7b7871470850> -> __attrs_135757226773968
                            __attrs_135757226773968 = _static_135757226770640

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="discreet">')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757226773264
                            __default_135757226773264 = _DEFAULT_MARKER

                            # <Value u"python:plone_view.cropText(similar.Description or '', desc_length)" (75:51)> -> __cache_135757226772368
                            __token = 4792
                            try:
                                __zt_tmp = __attrs_135757226773968
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135757226772368 = _static_135757244280656('python', u"plone_view.cropText(similar.Description or '', desc_length)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u"python:plone_view.cropText(similar.Description or '', desc_length)" (75:51)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871470a10> -> __condition
                            __expression = __cache_135757226772368

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u' Description ')
                            else:
                                __content = __cache_135757226772368
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</span>\n                            </li>')
                            if (__backup_url_135757226608336 is __marker):
                                del econtext['url']
                            else:
                                econtext['url'] = __backup_url_135757226608336
                            if (__backup_result_type_135757232020496 is __marker):
                                del econtext['result_type']
                            else:
                                econtext['result_type'] = __backup_result_type_135757232020496
                            if (__backup_result_url_135757226608912 is __marker):
                                del econtext['result_url']
                            else:
                                econtext['result_url'] = __backup_result_url_135757226608912
                            __append(u'\n                        ')
                            ____index_135757226608848 -= 1
                            if (____index_135757226608848 > 0):
                                __append('')
                        if (__backup_similar_135757237165136 is __marker):
                            del econtext['similar']
                        else:
                            econtext['similar'] = __backup_similar_135757237165136
                        __append(u'\n\n                        </ul>\n                        </nav>\n\n                    ')
                    if (__backup_normalizeString_135757132503504 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_135757132503504
                    if (__backup_desc_length_135757226697104 is __marker):
                        del econtext['desc_length']
                    else:
                        econtext['desc_length'] = __backup_desc_length_135757226697104
                    if (__backup_use_view_action_135757132572560 is __marker):
                        del econtext['use_view_action']
                    else:
                        econtext['use_view_action'] = __backup_use_view_action_135757132572560
                    if (__backup_registry_135757232034448 is __marker):
                        del econtext['registry']
                    else:
                        econtext['registry'] = __backup_registry_135757232034448
                    if (__backup_plone_view_135757232018768 is __marker):
                        del econtext['plone_view']
                    else:
                        econtext['plone_view'] = __backup_plone_view_135757232018768
                    if (__backup_similar_items_135757226826512 is __marker):
                        del econtext['similar_items']
                    else:
                        econtext['similar_items'] = __backup_similar_items_135757226826512
                    if (__backup_first_parent_135757132503184 is __marker):
                        del econtext['first_parent']
                    else:
                        econtext['first_parent'] = __backup_first_parent_135757132503184
                    __append(u'\n                </div>\n            ')
                    if (__backup_redirection_view_135757232019152 is __marker):
                        del econtext['redirection_view']
                    else:
                        econtext['redirection_view'] = __backup_redirection_view_135757232019152
                    __append(u'\n\n        ')
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757226826576
                __attrs_135757226826576 = _static_135757327983760
                __backup_isManager_135757226610000 = get('isManager', __marker)

                # <Value u'view/is_manager' (89:35)> -> __value
                __token = 5260
                try:
                    __zt_tmp = __attrs_135757226826576
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'view/is_manager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['isManager'] = __value

                # <Value u"python: err_type != 'NotFound'" (88:41)> -> __condition
                __token = 5193
                try:
                    __zt_tmp = __attrs_135757226826576
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u" err_type != 'NotFound'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7b787146a410> name=None at 7b7871448410> -> __attrs_135757226748240
                    __attrs_135757226748240 = _static_135757226746896

                    # <h1 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h1 class="documentFirstHeading">')
                    __stream_135757132663504 = []
                    __append_135757132663504 = __stream_135757132663504.append
                    __append_135757132663504(u'\n                We&#8217;re sorry, but there seems to be an error&hellip;\n            ')
                    __msgid_135757132663504 = __re_whitespace(''.join(__stream_135757132663504)).strip()
                    if u'heading_site_error_sorry':
                        __append(translate(u'heading_site_error_sorry', mapping=None, default=__msgid_135757132663504, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h1>\n\n            ')

                    # <Static value=<_ast.Dict object at 0x7b7871470710> name=None at 7b7871470110> -> __attrs_135757138340432
                    __attrs_135757138340432 = _static_135757226772240

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159721104
                    __attrs_135757159721104 = _static_135757327983760

                    # <Value u'isManager' (97:36)> -> __condition
                    __token = 5548
                    try:
                        __zt_tmp = __attrs_135757159721104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>\n                   ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159720656
                        __attrs_135757159720656 = _static_135757327983760

                        # <p ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<p>')
                        __stream_135757159719952 = []
                        __append_135757159719952 = __stream_135757159719952.append
                        __append_135757159719952(u'\n                   Here is the full error message:\n                   ')
                        __msgid_135757159719952 = __re_whitespace(''.join(__stream_135757159719952)).strip()
                        if u'description_site_admin_full_error':
                            __append(translate(u'description_site_admin_full_error', mapping=None, default=__msgid_135757159719952, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</p>\n\n                   ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159722384
                        __attrs_135757159722384 = _static_135757327983760

                        # <pre ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<pre>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757159720336
                        __default_135757159720336 = _DEFAULT_MARKER

                        # <Value u'err_tb' (102:37)> -> __cache_135757159722064
                        __token = 5747
                        try:
                            __zt_tmp = __attrs_135757159722384
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757159722064 = _static_135757244280656('path', u'err_tb', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'err_tb' (102:37)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786d47ee10> -> __condition
                        __expression = __cache_135757159722064

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757159722064
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</pre>\n                </div>')
                    __append(u'\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159719312
                    __attrs_135757159719312 = _static_135757327983760

                    # <Value u'not:isManager' (105:40)> -> __condition
                    __token = 5821
                    try:
                        __zt_tmp = __attrs_135757159719312
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('not', u'isManager', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757159720976
                        __attrs_135757159720976 = _static_135757327983760

                        # <p ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<p>')
                        __stream_135757151979232_site_admin = ''
                        __stream_135757159722768 = []
                        __append_135757159722768 = __stream_135757159722768.append
                        __append_135757159722768(u'\n                    If you are certain you have the correct web address but are encountering an error, please\n                    contact the ')
                        __stream_135757151979232_site_admin = []
                        __append_135757151979232_site_admin = __stream_135757151979232_site_admin.append

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757134639632
                        __attrs_135757134639632 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append_135757151979232_site_admin(u'<span>\n                    ')

                        # <Static value=<_ast.Dict object at 0x7b786bc936d0> name=None at 7b786bc93690> -> __attrs_135757134641808
                        __attrs_135757134641808 = _static_135757134640848

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append_135757151979232_site_admin(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757134643152
                        __default_135757134643152 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/portal_url}/contact-info' (111:44)> -> __attr_href
                        __token = 6222
                        try:
                            __zt_tmp = __attrs_135757134641808
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('string', u'${context/portal_url}/contact-info', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append_135757151979232_site_admin((u' href="%s"' % __attr_href))
                        __append_135757151979232_site_admin(u'>')
                        __stream_135757134639312 = []
                        __append_135757134639312 = __stream_135757134639312.append
                        __append_135757134639312(u'site administration')
                        __msgid_135757134639312 = __re_whitespace(''.join(__stream_135757134639312)).strip()
                        if u'label_site_admin':
                            __append_135757151979232_site_admin(translate(u'label_site_admin', mapping=None, default=__msgid_135757134639312, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append_135757151979232_site_admin(u'</a></span>')
                        __append_135757159722768(u'${site_admin}')
                        __stream_135757151979232_site_admin = ''.join(__stream_135757151979232_site_admin)
                        __append_135757159722768(u'.\n                    ')
                        __msgid_135757159722768 = __re_whitespace(''.join(__stream_135757159722768)).strip()
                        if u'description_site_error_mail_site_admin':
                            __append(translate(u'description_site_error_mail_site_admin', mapping={u'site_admin': __stream_135757151979232_site_admin, }, default=__msgid_135757159722768, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</p>\n                ')
                    __append(u'\n            </div>\n\n        ')
                if (__backup_isManager_135757226610000 is __marker):
                    del econtext['isManager']
                else:
                    econtext['isManager'] = __backup_isManager_135757226610000
                __append(u'\n\n')
                if (__backup_err_log_id_135757226680272 is __marker):
                    del econtext['err_log_id']
                else:
                    econtext['err_log_id'] = __backup_err_log_id_135757226680272
                if (__backup_err_tb_135757232020688 is __marker):
                    del econtext['err_tb']
                else:
                    econtext['err_tb'] = __backup_err_tb_135757232020688
                if (__backup_err_type_135757226678480 is __marker):
                    del econtext['err_type']
                else:
                    econtext['err_type'] = __backup_err_type_135757226678480
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/@@main_template/macros/master' (6:23)> -> __macro
            __token = 261
            try:
                __zt_tmp = __attrs_135757305630416
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'context/@@main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 261
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757115635664 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757115635664
            __i18n_domain = __previous_i18n_domain_135757305630352
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }