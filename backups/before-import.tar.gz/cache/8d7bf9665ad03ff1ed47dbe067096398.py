# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/footer.pt'

__tokens = {213: (u'view/render_footer_portlets', 8, 57), 181: (u'nothing', 8, 25), 520: (u'view/year', 12, 63)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from chameleon.tal import ErrorInfo as _ErrorInfo

_static_135757073557136 = {u'href': u'https://gitter.im/senaite', u'target': u'_blank', u'class': u'nav-link', u'title': u'Talk with us on Gitter', }
_static_135757075301520 = {u'href': u'https://www.senaite.com/docs/quickstart.html', u'target': u'_blank', u'class': u'nav-link', u'title': u'Browse the Docs', }
_static_135757073176400 = {u'class': u'nav nav-pills', }
_static_135757148695312 = {u'class': u'fas fa-globe', }
_static_135757074403856 = {u'class': u'float-left', }
_static_135757149860688 = {u'class': u'float-right', }
_static_135757244280656 = __compile_zt_expr
_static_135757149861328 = {u'title': u'Copyright', }
_static_135757075355664 = {u'id': u'senaite-footer', }
_static_135757073558224 = {u'class': u'fa fa-hashtag', }
_static_135757075426320 = {u'class': u'fas fa-book', }
_static_135757149893200 = {u'class': u'fas fa-comments', }
_static_135757074496336 = {u'class': u'fa fa-code-branch', }
_static_135757075425104 = {u'href': u'https://github.com/senaite/senaite.lims', u'target': u'_blank', u'class': u'nav-link', u'title': u'Browse the code on GitHub', }
_static_135757073178256 = {u'href': u'https://www.senaite.com', u'target': u'_blank', }
_static_135757148779152 = {u'class': u'col-md-12', }
_static_135757074255120 = {u'href': u'https://www.senaite.com', u'target': u'_blank', u'class': u'nav-link', u'title': u'Visit the Website', }
_static_135757327983760 = {}
_static_135757148781776 = {u'class': u'row', }
_static_135757074493840 = {u'href': u'https://twitter.com/senaitelims', u'target': u'_blank', u'class': u'nav-link', u'title': u'Spread the word on Twitter', }
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b7868409810> name=None at 7b78684099d0> -> __attrs_135757075354960
            __attrs_135757075354960 = _static_135757075355664
            __previous_i18n_domain_135757075354448 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer id="senaite-footer">\n\n  ')

            # <Static value=<_ast.Dict object at 0x7b786ca0fcd0> name=None at 7b7868409950> -> __attrs_135757148779728
            __attrs_135757148779728 = _static_135757148781776

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\n    ')

            # <Static value=<_ast.Dict object at 0x7b786ca0f290> name=None at 7b786ca0f9d0> -> __attrs_135757148779024
            __attrs_135757148779024 = _static_135757148779152

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148779984
            __attrs_135757148779984 = _static_135757327983760

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\n      <!-- footer portlets -->\n      ')
            ____fallback_135757327876240 = len(__stream)
            try:

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074407056
                __attrs_135757074407056 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074405584
                __default_135757074405584 = _DEFAULT_MARKER

                # <Value u'view/render_footer_portlets' (8:57)> -> __cache_135757074405904
                __token = 213
                try:
                    __zt_tmp = __attrs_135757074407056
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074405904 = _static_135757244280656('path', u'view/render_footer_portlets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/render_footer_portlets' (8:57)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868321490> -> __condition
                __expression = __cache_135757074405904

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_135757074405904
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            except (Exception, ) as __exc:
                econtext['error'] = _ErrorInfo(__exc, __tokens[__token][1:3])
                if (on_error_handler is not None):
                    on_error_handler(__exc)
                del __stream[____fallback_135757327876240:]

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>')

                # <Value u'nothing' (8:25)> -> __content
                __token = 181
                try:
                    __zt_tmp = __attrs_135757148779024
                except get('NameError', NameError):
                    __zt_tmp = None

                __content = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
                __append(u'</div>')

            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x7b7868321210> name=None at 7b7868321d10> -> __attrs_135757074405008
            __attrs_135757074405008 = _static_135757074403856

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-left">\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149862032
            __attrs_135757149862032 = _static_135757327983760
            __stream_135757149803296_senaitelims = ''
            __stream_135757149803296_copyright = ''
            __stream_135757149803296_current_year = ''
            __stream_135757149861712 = []
            __append_135757149861712 = __stream_135757149861712.append
            __append_135757149861712(u'\n          ')
            __stream_135757149803296_copyright = []
            __append_135757149803296_copyright = __stream_135757149803296_copyright.append

            # <Static value=<_ast.Dict object at 0x7b786cb175d0> name=None at 7b786cb17c10> -> __attrs_135757149861456
            __attrs_135757149861456 = _static_135757149861328

            # <abbr ... (0:0)
            # --------------------------------------------------------
            __append_135757149803296_copyright(u'<abbr')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757149860880
            __default_135757149860880 = _DEFAULT_MARKER

            # <Translate msgid=u'title_copyright' node=<_ast.Str object at 0x7b786cb17b90> at 7b786cb17d90> -> __attr_title
            __attr_title = u'Copyright'
            __attr_title = translate(u'title_copyright', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_title is not None):
                __append_135757149803296_copyright((u' title="%s"' % __attr_title))
            __append_135757149803296_copyright(u'>&copy;</abbr>')
            __append_135757149861712(u'${copyright}')
            __stream_135757149803296_copyright = ''.join(__stream_135757149803296_copyright)
            __append_135757149861712(u'\n          2017-')
            __stream_135757149803296_current_year = []
            __append_135757149803296_current_year = __stream_135757149803296_current_year.append

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757149862288
            __attrs_135757149862288 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757149863184
            __default_135757149863184 = _DEFAULT_MARKER

            # <Value u'view/year' (12:63)> -> __cache_135757149863248
            __token = 520
            try:
                __zt_tmp = __attrs_135757149862288
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757149863248 = _static_135757244280656('path', u'view/year', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/year' (12:63)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786cb17310> -> __condition
            __expression = __cache_135757149863248

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_135757149863248
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append_135757149803296_current_year(__content)
            __append_135757149861712(u'${current_year}')
            __stream_135757149803296_current_year = ''.join(__stream_135757149803296_current_year)
            __append_135757149861712(u'\n          ')
            __stream_135757149803296_senaitelims = []
            __append_135757149803296_senaitelims = __stream_135757149803296_senaitelims.append

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073177296
            __attrs_135757073177296 = _static_135757327983760
            __append_135757149803296_senaitelims(u'\n            ')

            # <Static value=<_ast.Dict object at 0x7b78681f5e90> name=None at 7b78681f5810> -> __attrs_135757073176144
            __attrs_135757073176144 = _static_135757073178256

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_135757149803296_senaitelims(u'<a href="https://www.senaite.com" target="_blank">')
            __stream_135757073175696 = []
            __append_135757073175696 = __stream_135757073175696.append
            __append_135757073175696(u'SENAITE LIMS')
            __msgid_135757073175696 = __re_whitespace(''.join(__stream_135757073175696)).strip()
            if u'label_senaite':
                __append_135757149803296_senaitelims(translate(u'label_senaite', mapping=None, default=__msgid_135757073175696, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append_135757149803296_senaitelims(u'</a>\n          ')
            __append_135757149861712(u'${senaitelims}')
            __stream_135757149803296_senaitelims = ''.join(__stream_135757149803296_senaitelims)
            __append_135757149861712(u'\n        ')
            __msgid_135757149861712 = __re_whitespace(''.join(__stream_135757149861712)).strip()
            if u'description_copyright':
                __append(translate(u'description_copyright', mapping={u'current_year': __stream_135757149803296_current_year, u'copyright': __stream_135757149803296_copyright, u'senaitelims': __stream_135757149803296_senaitelims, }, default=__msgid_135757149861712, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\n      </div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b786cb17350> name=None at 7b786cb17910> -> __attrs_135757073178512
            __attrs_135757073178512 = _static_135757149860688

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-right">\n        ')

            # <Static value=<_ast.Dict object at 0x7b78681f5750> name=None at 7b78681f5790> -> __attrs_135757148768592
            __attrs_135757148768592 = _static_135757073176400

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="nav nav-pills">\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074254224
            __attrs_135757074254224 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b78682fcd10> name=None at 7b78682fcf10> -> __attrs_135757148694416
            __attrs_135757148694416 = _static_135757074255120

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://www.senaite.com" title="Visit the Website" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7b786c9fab10> name=None at 7b786c9fac10> -> __attrs_135757075301392
            __attrs_135757075301392 = _static_135757148695312

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-globe"></i></a></li>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074253264
            __attrs_135757074253264 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b78683fc490> name=None at 7b78683fc910> -> __attrs_135757075300688
            __attrs_135757075300688 = _static_135757075301520

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://www.senaite.com/docs/quickstart.html" title="Browse the Docs" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7b786841ac10> name=None at 7b78683fc8d0> -> __attrs_135757075424464
            __attrs_135757075424464 = _static_135757075426320

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-book"></i></a></li>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075301776
            __attrs_135757075301776 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b786841a750> name=None at 7b786841a8d0> -> __attrs_135757074496976
            __attrs_135757074496976 = _static_135757075425104

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://github.com/senaite/senaite.lims" title="Browse the code on GitHub" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7b7868337b50> name=None at 7b7868337590> -> __attrs_135757074495376
            __attrs_135757074495376 = _static_135757074496336

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fa fa-code-branch"></i></a></li>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074497424
            __attrs_135757074497424 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b7868337190> name=None at 7b78683374d0> -> __attrs_135757073557328
            __attrs_135757073557328 = _static_135757074493840

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://twitter.com/senaitelims" title="Spread the word on Twitter" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7b7868252ad0> name=None at 7b7868252c50> -> __attrs_135757073558736
            __attrs_135757073558736 = _static_135757073558224

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fa fa-hashtag"></i></a></li>\n          ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073558288
            __attrs_135757073558288 = _static_135757327983760

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7b7868252690> name=None at 7b78682522d0> -> __attrs_135757149896400
            __attrs_135757149896400 = _static_135757073557136

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://gitter.im/senaite" title="Talk with us on Gitter" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7b786cb1f250> name=None at 7b786cb1fa10> -> __attrs_135757149893968
            __attrs_135757149893968 = _static_135757149893200

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-comments"></i></a></li>\n        </ul>\n      </div>\n    </div>\n  </div>\n</footer>')
            __i18n_domain = __previous_i18n_domain_135757075354448
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }