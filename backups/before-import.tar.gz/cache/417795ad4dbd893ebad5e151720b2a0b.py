# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/main_template/templates/main_template.pt'

__tokens = {5487: (u'provider:plone.abovecontenttitle', 121, 87), 5649: (u'context/@@title', 123, 55), 5799: (u'provider:plone.belowcontenttitle', 125, 87), 5974: (u'context/@@description', 128, 54), 6170: (u'provider:plone.abovecontentbody', 132, 84), 6334: (u'nothing', 134, 78), 6546: (u'provider:plone.belowcontentbody', 138, 84), 74: (u'string:&lt;!DOCTYPE ht', 2, 38), 364: (u"python:context.restrictedTraverse('@@senaite_theme')", 8, 34), 451: (u" python:context.restrictedTraverse('@@senaite_view'", 9, 32), 529: (u't nocall:senaite_view/te', 10, 23), 588: (u"te python:context.restrictedTraverse('@@plone_portal_stat", 11, 30), 681: (u"ate python:context.restrictedTraverse('@@plone_context_sta", 12, 30), 772: (u"view python:context.restrictedTraverse('@@pl", 13, 26), 851: (u"ayout python:context.restrictedTraverse('@@plone_la", 14, 27), 938: (u"apview python:context.restrictedTraverse('@@bootstra", 15, 27), 1017: (u'   lang python:portal_state.la', 16, 17), 1074: (u'    view nocall:view | nocall: p', 17, 16), 1134: (u'    dummy python: plone_layout.mark_', 18, 16), 1203: (u'portal_url python:portal_state.p', 19, 20), 1273: (u"kPermission python:context.restrictedTraverse('portal_membership').che", 20, 24), 1381: (u"e_properties python:context.restrictedTraverse('portal_properties').si", 21, 23), 1491: (u"_include_head python:request.get('ajax_include", 22, 24), 1569: (u'     ajax_lo', 23, 15), 1658: (u'lang', 25, 29), 1709: (u'provider:plone.httpheaders', 27, 40), 1781: (u'provider:plone.htmlhead', 29, 38), 1840: (u'nothing', 31, 28), 2618: (u'bootstrapview/get_viewport_values', 49, 39), 2690: (u'viewportvalues', 50, 36), 2858: (u'portal_state/is_rtl', 54, 28), 2904: (u" python:plone_layout.have_portlets('plone.leftcolumn', view", 55, 24), 2990: (u"r python:plone_layout.have_portlets('plone.rightcolumn', vie", 56, 23), 3085: (u'ss python:plone_layout.bodyClass(template, vi', 57, 30), 3158: (u'cls python:bootstrapview.get_columns_classes(v', 58, 22), 3367: (u'  python:bootstrapview.get_data_settings', 61, 24), 3243: (u'string:${body_class} senaite-body', 59, 32), 3308: (u" python:isRTL and 'rtl' or 'ltr", 60, 29), 3628: (u'provider:plone.toolbar', 69, 36), 3765: (u'provider:senaite.sidebar', 75, 36), 4034: (u'provider:plone.portaltop', 83, 44), 4264: (u'provider:plone.mainnavigation', 90, 69), 4563: (u'provider:plone.globalstatusmessage', 99, 52), 4889: (u'provider:plone.abovecontent', 108, 69), 5094: (u'cls/content', 114, 70), 6844: (u'provider:plone.belowcontent', 148, 71), 7092: (u'sl', 155, 34), 7138: (u'cls/one', 156, 41), 7259: (u'provider:plone.leftcolumn', 158, 46), 7511: (u'sr', 165, 34), 7557: (u'cls/two', 166, 41), 7678: (u'provider:plone.rightcolumn', 168, 46), 7894: (u'provider:plone.portalfooter', 175, 40), 8773: (u'string:${portal_url}/++plone++senaite.core.static/css/senaite.rtl.css', 198, 33)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_138366819790032 = {u'id': u'viewlet-below-content-title', }
_static_138366819680592 = {u'content': u'SENAITE - https://www.senaite.com', u'name': u'generator', }
_static_138366819730128 = {u'id': u'global_statusmessage', }
_static_138366819725968 = {u'class': u'row', }
_static_138366819681936 = {u'id': u'visual-portal-wrapper', u'dir': u"python:isRTL and 'rtl' or 'ltr'", u'class': u'string:${body_class} senaite-body', }
_static_138366819717264 = {u'class': u'row', }
_static_138366819716240 = {u'class': u'col-sm-12', }
_static_138366819744464 = {u'class': u'row', }
_static_138366819710736 = {u'class': u'wrapper', }
_static_138366819680016 = {u'class': u'mb-2', }
_static_138366819797712 = {u'id': u'content-core', }
_static_138366819585488 = {u'lang': u'lang', u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_138366819763984 = {u'id': u'viewlet-below-content', }
_static_138366819726736 = {u'id': u'portal-mainnavigation', }
_static_138366819762704 = {u'id': u'content', }
_static_138366819717712 = {u'id': u'portal-top', }
_static_138366930725392 = __C2ZContextWrapper
_static_138366819787024 = {u'id': u'viewlet-above-content-title', }
_static_138367014417552 = {}
_static_138366819808272 = {u'id': u'viewlet-below-content-body', }
_static_138366819741904 = {u'class': u'col-sm-12', }
_static_138366819745744 = {u'id': u'portal-column-content', u'class': u'cls/content', }
_static_138366819743568 = {u'id': u'viewlet-above-content', }
_static_138366819678288 = {u'id': u'loader', u'i18n-translate': u'', }
_static_138366760088400 = set([])
_static_138366819729808 = {u'class': u'row', }
_static_138366819681808 = {u'content': u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', u'name': u'viewport', }
_static_138366930725008 = __compile_zt_expr
_static_138366841363664 = {u'href': u'string:${portal_url}/++plone++senaite.core.static/css/senaite.rtl.css', u'type': u'text/css', u'rel': u'stylesheet', }
_static_138366819809680 = {u'id': u'portal-column-one', u'class': u'cls/one', }
_static_138366819728848 = {u'class': u'col-sm-12', }
_static_138366819714768 = {u'class': u'row', }
_static_138366819820368 = {u'id': u'portal-column-two', u'class': u'cls/two', }
_static_138366819796560 = {u'id': u'viewlet-above-content-body', }
_static_138366819720912 = {u'class': u'col-sm-12', }
_static_138366819821968 = {u'id': u'portal-footer-wrapper', }
_static_138366819713296 = {u'class': u'container-fluid', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_content(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_content_description = econtext[u'__slot_content_description'].pop()
        except:
            __slot_content_description = None

        try:
            __slot_main = econtext[u'__slot_main'].pop()
        except:
            __slot_main = None

        try:
            __slot_body = econtext[u'__slot_body'].pop()
        except:
            __slot_body = None

        try:
            __slot_content_core = econtext[u'__slot_content_core'].pop()
        except:
            __slot_content_core = None

        try:
            __slot_content_title = econtext[u'__slot_content_title'].pop()
        except:
            __slot_content_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819752592
            __attrs_138366819752592 = _static_138367014417552

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\r\n                  ')
            if (__slot_body is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819753488
                __attrs_138366819753488 = _static_138367014417552
                __append(u'\r\n                    ')

                # <Static value=<_ast.Dict object at 0x7dd809240210> name=None at 7dd8092401d0> -> __attrs_138366819763280
                __attrs_138366819763280 = _static_138366819762704

                # <article ... (0:0)
                # --------------------------------------------------------
                __append(u'<article id="content">\r\n                      ')
                if (__slot_main is None):

                    # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819764176
                    __attrs_138366819764176 = _static_138367014417552
                    __append(u'\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819765264
                    __attrs_138366819765264 = _static_138367014417552

                    # <header ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<header>\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x7dd809246110> name=None at 7dd8092460d0> -> __attrs_138366819787664
                    __attrs_138366819787664 = _static_138366819787024

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-title">')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819786832
                    __default_138366819786832 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontenttitle' (121:87)> -> __cache_138366819765968
                    __token = 5487
                    try:
                        __zt_tmp = __attrs_138366819787664
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366819765968 = _static_138366930725008('provider', u'plone.abovecontenttitle', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontenttitle' (121:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809240f50> -> __condition
                    __expression = __cache_138366819765968

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_138366819765968
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n                          ')
                    if (__slot_content_title is None):

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819788176
                        __attrs_138366819788176 = _static_138367014417552
                        __append(u'\r\n                            ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819789648
                        __attrs_138366819789648 = _static_138367014417552

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819789520
                        __default_138366819789520 = _DEFAULT_MARKER

                        # <Value u'context/@@title' (123:55)> -> __cache_138366819789136
                        __token = 5649
                        try:
                            __zt_tmp = __attrs_138366819789648
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366819789136 = _static_138366930725008('path', u'context/@@title', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@title' (123:55)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809246a10> -> __condition
                        __expression = __cache_138366819789136

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <h1 ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<h1 />')
                        else:
                            __content = __cache_138366819789136
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n                          ')
                    else:
                        __slot_content_title(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x7dd809246cd0> name=None at 7dd809246c90> -> __attrs_138366819790672
                    __attrs_138366819790672 = _static_138366819790032

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-title">')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819789840
                    __default_138366819789840 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontenttitle' (125:87)> -> __cache_138366819787984
                    __token = 5799
                    try:
                        __zt_tmp = __attrs_138366819790672
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366819787984 = _static_138366930725008('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontenttitle' (125:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8092467d0> -> __condition
                    __expression = __cache_138366819787984

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_138366819787984
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n\r\n                          ')
                    if (__slot_content_description is None):

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819795280
                        __attrs_138366819795280 = _static_138367014417552
                        __append(u'\r\n                            ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819796496
                        __attrs_138366819796496 = _static_138367014417552

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819796368
                        __default_138366819796368 = _DEFAULT_MARKER

                        # <Value u'context/@@description' (128:54)> -> __cache_138366819796048
                        __token = 5974
                        try:
                            __zt_tmp = __attrs_138366819796496
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366819796048 = _static_138366930725008('path', u'context/@@description', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@description' (128:54)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8092484d0> -> __condition
                        __expression = __cache_138366819796048

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <p ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<p />')
                        else:
                            __content = __cache_138366819796048
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n                          ')
                    else:
                        __slot_content_description(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                        </header>\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd809248650> name=None at 7dd8092482d0> -> __attrs_138366819797264
                    __attrs_138366819797264 = _static_138366819796560

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-body">')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819795344
                    __default_138366819795344 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontentbody' (132:84)> -> __cache_138366819795600
                    __token = 6170
                    try:
                        __zt_tmp = __attrs_138366819797264
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366819795600 = _static_138366930725008('provider', u'plone.abovecontentbody', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontentbody' (132:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8092480d0> -> __condition
                    __expression = __cache_138366819795600

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_138366819795600
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd809248ad0> name=None at 7dd809248a90> -> __attrs_138366819798288
                    __attrs_138366819798288 = _static_138366819797712

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\r\n                          ')
                    if (__slot_content_core is None):

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819807824
                        __attrs_138366819807824 = _static_138367014417552

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819807504
                        __default_138366819807504 = _DEFAULT_MARKER

                        # <Value u'nothing' (134:78)> -> __cache_138366819798928
                        __token = 6334
                        try:
                            __zt_tmp = __attrs_138366819807824
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366819798928 = _static_138366930725008('path', u'nothing', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'nothing' (134:78)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80924b050> -> __condition
                        __expression = __cache_138366819798928

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n                            Page body text\r\n                          ')
                        else:
                            __content = __cache_138366819798928
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                    else:
                        __slot_content_core(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                        </div>\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd80924b410> name=None at 7dd80924b3d0> -> __attrs_138366819808912
                    __attrs_138366819808912 = _static_138366819808272

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-body">')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819807888
                    __default_138366819807888 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontentbody' (138:84)> -> __cache_138366819764688
                    __token = 6546
                    try:
                        __zt_tmp = __attrs_138366819808912
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366819764688 = _static_138366930725008('provider', u'plone.belowcontentbody', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontentbody' (138:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80924b210> -> __condition
                    __expression = __cache_138366819764688

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_138366819764688
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n\r\n                      ')
                else:
                    __slot_main(__stream, econtext.copy(), rcontext)
                __append(u'\r\n                    </article>\r\n\r\n                  ')
            else:
                __slot_body(__stream, econtext.copy(), rcontext)
            __append(u'\r\n                </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_master(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_senaite_legacy_js = econtext[u'__slot_senaite_legacy_js'].pop()
        except:
            __slot_senaite_legacy_js = None

        try:
            __slot_senaite_legacy_resources = econtext[u'__slot_senaite_legacy_resources'].pop()
        except:
            __slot_senaite_legacy_resources = None

        try:
            __slot_head_slot = econtext[u'__slot_head_slot'].pop()
        except:
            __slot_head_slot = None

        try:
            __slot_column_two_slot = econtext[u'__slot_column_two_slot'].pop()
        except:
            __slot_column_two_slot = None

        try:
            __slot_column_one_slot = econtext[u'__slot_column_one_slot'].pop()
        except:
            __slot_column_one_slot = None

        try:
            __slot_global_statusmessage = econtext[u'__slot_global_statusmessage'].pop()
        except:
            __slot_global_statusmessage = None

        try:
            __slot_senaite_legacy_css = econtext[u'__slot_senaite_legacy_css'].pop()
        except:
            __slot_senaite_legacy_css = None

        try:
            __slot_top_slot = econtext[u'__slot_top_slot'].pop()
        except:
            __slot_top_slot = None

        try:
            __slot_portlets_one_slot = econtext[u'__slot_portlets_one_slot'].pop()
        except:
            __slot_portlets_one_slot = None

        try:
            __slot_portlets_two_slot = econtext[u'__slot_portlets_two_slot'].pop()
        except:
            __slot_portlets_two_slot = None

        try:
            __slot_content = econtext[u'__slot_content'].pop()
        except:
            __slot_content = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819584272
            __attrs_138366819584272 = _static_138367014417552
            __append(u'\r\n  ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819585424
            __attrs_138366819585424 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819585296
            __default_138366819585296 = _DEFAULT_MARKER

            # <Value u'string:<!DOCTYPE html>' (2:38)> -> __cache_138366819584976
            __token = 74
            try:
                __zt_tmp = __attrs_138366819585424
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819584976 = _static_138366930725008('string', u'<!DOCTYPE html>', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'string:<!DOCTYPE html>' (2:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809214c50> -> __condition
            __expression = __cache_138366819584976

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_138366819584976
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7dd809214dd0> name=None at 7dd809214e50> -> __attrs_138366819668560
            __attrs_138366819668560 = _static_138366819585488
            __backup_senaite_theme_138366820750480 = get('senaite_theme', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_theme')" (8:34)> -> __value
            __token = 364
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@senaite_theme')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['senaite_theme'] = __value
            __backup_senaite_view_138366820762320 = get('senaite_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_view')" (9:32)> -> __value
            __token = 451
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@senaite_view')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['senaite_view'] = __value
            __backup_test_138366820764880 = get('test', __marker)

            # <Value u'nocall:senaite_view/test' (10:23)> -> __value
            __token = 529
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('nocall', u'senaite_view/test', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['test'] = __value
            __backup_portal_state_138366820778896 = get('portal_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_portal_state')" (11:30)> -> __value
            __token = 588
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@plone_portal_state')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_context_state_138366820763728 = get('context_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_context_state')" (12:30)> -> __value
            __token = 681
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@plone_context_state')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_plone_view_138366820761936 = get('plone_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone')" (13:26)> -> __value
            __token = 772
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@plone')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['plone_view'] = __value
            __backup_plone_layout_138366820756368 = get('plone_layout', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_layout')" (14:27)> -> __value
            __token = 851
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@plone_layout')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['plone_layout'] = __value
            __backup_bootstrapview_138366820756688 = get('bootstrapview', __marker)

            # <Value u"python:context.restrictedTraverse('@@bootstrapview')" (15:27)> -> __value
            __token = 938
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('@@bootstrapview')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['bootstrapview'] = __value
            __backup_lang_138366820763344 = get('lang', __marker)

            # <Value u'python:portal_state.language()' (16:17)> -> __value
            __token = 1017
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u'portal_state.language()', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['lang'] = __value
            __backup_view_138366820808016 = get('view', __marker)

            # <Value u'nocall:view | nocall: plone_view' (17:16)> -> __value
            __token = 1074
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('nocall', u'view | nocall: plone_view', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['view'] = __value
            __backup_dummy_138366820765200 = get('dummy', __marker)

            # <Value u'python: plone_layout.mark_view(view)' (18:16)> -> __value
            __token = 1134
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u' plone_layout.mark_view(view)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_portal_url_138366820810064 = get('portal_url', __marker)

            # <Value u'python:portal_state.portal_url()' (19:20)> -> __value
            __token = 1203
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u'portal_state.portal_url()', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_checkPermission_138366820808720 = get('checkPermission', __marker)

            # <Value u"python:context.restrictedTraverse('portal_membership').checkPermission" (20:24)> -> __value
            __token = 1273
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('portal_membership').checkPermission", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['checkPermission'] = __value
            __backup_site_properties_138366820809744 = get('site_properties', __marker)

            # <Value u"python:context.restrictedTraverse('portal_properties').site_properties" (21:23)> -> __value
            __token = 1381
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"context.restrictedTraverse('portal_properties').site_properties", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['site_properties'] = __value
            __backup_ajax_include_head_138366820815888 = get('ajax_include_head', __marker)

            # <Value u"python:request.get('ajax_include_head', False)" (22:24)> -> __value
            __token = 1491
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"request.get('ajax_include_head', False)", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['ajax_include_head'] = __value
            __backup_ajax_load_138366820808336 = get('ajax_load', __marker)

            # <Value u'python:False' (23:15)> -> __value
            __token = 1569
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u'False', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['ajax_load'] = __value
            __previous_i18n_domain_138366819671248 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819668240
            __default_138366819668240 = _DEFAULT_MARKER

            # <Substitution u'lang' (25:29)> -> __attr_lang
            __token = 1658
            try:
                __zt_tmp = __attrs_138366819668560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_138366930725008('path', u'lang', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u'>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819672336
            __attrs_138366819672336 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819672208
            __default_138366819672208 = _DEFAULT_MARKER

            # <Value u'provider:plone.httpheaders' (27:40)> -> __cache_138366819671824
            __token = 1709
            try:
                __zt_tmp = __attrs_138366819672336
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819671824 = _static_138366930725008('provider', u'plone.httpheaders', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.httpheaders' (27:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809229f90> -> __condition
            __expression = __cache_138366819671824

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_138366819671824
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819672720
            __attrs_138366819672720 = _static_138367014417552

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819673872
            __attrs_138366819673872 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819673744
            __default_138366819673744 = _DEFAULT_MARKER

            # <Value u'provider:plone.htmlhead' (29:38)> -> __cache_138366819673424
            __token = 1781
            try:
                __zt_tmp = __attrs_138366819673872
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819673424 = _static_138366930725008('provider', u'plone.htmlhead', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.htmlhead' (29:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80922a5d0> -> __condition
            __expression = __cache_138366819673424

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_138366819673424
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819674768
            __attrs_138366819674768 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819674640
            __default_138366819674640 = _DEFAULT_MARKER

            # <Value u'nothing' (31:28)> -> __cache_138366819674320
            __token = 1840
            try:
                __zt_tmp = __attrs_138366819674768
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819674320 = _static_138366930725008('path', u'nothing', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'nothing' (31:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80922a950> -> __condition
            __expression = __cache_138366819674320

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\r\n        Various slots where you can insert elements in the header from a template.\r\n      ')
            else:
                __content = __cache_138366819674320
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n      ')
            if (__slot_top_slot is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819675088
                __attrs_138366819675088 = _static_138367014417552
            else:
                __slot_top_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      ')
            if (__slot_head_slot is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819675408
                __attrs_138366819675408 = _static_138367014417552
            else:
                __slot_head_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n      <!-- Disable all Plone JS/CSS -->\r\n      <!-- <div tal:replace="structure provider:plone.scripts" /> -->\r\n      <!-- <metal:javascriptslot define-slot="javascript_head_slot" /> -->\r\n      <!-- <link tal:replace="structure provider:plone.htmlhead.links" /> -->\r\n      <!-- <metal:styleslot define-slot="style_slot" /> -->\r\n\r\n      <!-- NOTE: All Legacy JS/CSS are rendered at the bottom of the page! -->\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd80922c150> name=None at 7dd80922c110> -> __attrs_138366819681488
            __attrs_138366819681488 = _static_138366819680592

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="generator" content="SENAITE - https://www.senaite.com" />\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd80922c610> name=None at 7dd80922c5d0> -> __attrs_138366819683024
            __attrs_138366819683024 = _static_138366819681808
            __backup_viewportvalues_138366820810448 = get('viewportvalues', __marker)

            # <Value u'bootstrapview/get_viewport_values' (49:39)> -> __value
            __token = 2618
            try:
                __zt_tmp = __attrs_138366819683024
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('path', u'bootstrapview/get_viewport_values', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['viewportvalues'] = __value

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819682768
            __default_138366819682768 = _DEFAULT_MARKER

            # <Substitution u'viewportvalues' (50:36)> -> __attr_content
            __token = 2690
            try:
                __zt_tmp = __attrs_138366819683024
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_content = _static_138366930725008('path', u'viewportvalues', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_content = __quote(__attr_content, '"', '&quot;', u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', _DEFAULT_MARKER)
            if (__attr_content is not None):
                __append((u'             content="%s"' % __attr_content))
            __append(u' />')
            if (__backup_viewportvalues_138366820810448 is __marker):
                del econtext['viewportvalues']
            else:
                econtext['viewportvalues'] = __backup_viewportvalues_138366820810448
            __append(u'\r\n    </head>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x7dd80922c690> name=None at 7dd80922c050> -> __attrs_138366819676816
            __attrs_138366819676816 = _static_138366819681936
            __backup_isRTL_138366820818064 = get('isRTL', __marker)

            # <Value u'portal_state/is_rtl' (54:28)> -> __value
            __token = 2858
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('path', u'portal_state/is_rtl', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['isRTL'] = __value
            __backup_sl_138366820815312 = get('sl', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.leftcolumn', view)" (55:24)> -> __value
            __token = 2904
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"plone_layout.have_portlets('plone.leftcolumn', view)", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['sl'] = __value
            __backup_sr_138366819673168 = get('sr', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.rightcolumn', view)" (56:23)> -> __value
            __token = 2990
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u"plone_layout.have_portlets('plone.rightcolumn', view)", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['sr'] = __value
            __backup_body_class_138366820818704 = get('body_class', __marker)

            # <Value u'python:plone_layout.bodyClass(template, view)' (57:30)> -> __value
            __token = 3085
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u'plone_layout.bodyClass(template, view)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['body_class'] = __value
            __backup_cls_138366819675024 = get('cls', __marker)

            # <Value u'python:bootstrapview.get_columns_classes(view)' (58:22)> -> __value
            __token = 3158
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('python', u'bootstrapview.get_columns_classes(view)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['cls'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body')

            # <Value u'python:bootstrapview.get_data_settings()' (61:24)> -> __cache_138366819676368
            __token = 3367
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819676368 = _static_138366930725008('python', u'bootstrapview.get_data_settings()', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if (u'id' not in __chain(__cache_138366819676368)):
                __append(u'           id="visual-portal-wrapper"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819684112
            __default_138366819684112 = _DEFAULT_MARKER

            # <Substitution u'string:${body_class} senaite-body' (59:32)> -> __attr_class
            __token = 3243
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_138366930725008('string', u'${body_class} senaite-body', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_138366819676368))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819676240
            __default_138366819676240 = _DEFAULT_MARKER

            # <Substitution u"python:isRTL and 'rtl' or 'ltr'" (60:29)> -> __attr_dir
            __token = 3308
            try:
                __zt_tmp = __attrs_138366819676816
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_138366930725008('python', u"isRTL and 'rtl' or 'ltr'", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_dir is not None) and (u'dir' not in __chain(__cache_138366819676368))):
                __append((u' dir="%s"' % __attr_dir))
            __attr_138366819676432 = __cache_138366819676368
            for (name, value, ) in __attr_138366819676432.items():
                if ((name not in _static_138366760088400) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\r\n\r\n      <!-- Ajax Loader -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd80922b850> name=None at 7dd80922b890> -> __attrs_138366819679376
            __attrs_138366819679376 = _static_138366819678288

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="loader" i18n-translate="">Loading...</div>\r\n\r\n      <!-- Toolbar -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd80922bf10> name=None at 7dd80922bed0> -> __attrs_138366819709328
            __attrs_138366819709328 = _static_138366819680016

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="mb-2">\r\n        ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819710544
            __attrs_138366819710544 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819710416
            __default_138366819710416 = _DEFAULT_MARKER

            # <Value u'provider:plone.toolbar' (69:36)> -> __cache_138366819710096
            __token = 3628
            try:
                __zt_tmp = __attrs_138366819710544
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819710096 = _static_138366930725008('provider', u'plone.toolbar', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.toolbar' (69:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809233510> -> __condition
            __expression = __cache_138366819710096

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_138366819710096
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n      </div>\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd809233710> name=None at 7dd809233690> -> __attrs_138366819711312
            __attrs_138366819711312 = _static_138366819710736

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="wrapper">\r\n\r\n        <!-- Sidebar -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819712656
            __attrs_138366819712656 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819712528
            __default_138366819712528 = _DEFAULT_MARKER

            # <Value u'provider:senaite.sidebar' (75:36)> -> __cache_138366819712208
            __token = 3765
            try:
                __zt_tmp = __attrs_138366819712656
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819712208 = _static_138366930725008('provider', u'senaite.sidebar', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:senaite.sidebar' (75:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809233d50> -> __condition
            __expression = __cache_138366819712208

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_138366819712208
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n        <!-- Content -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x7dd809234110> name=None at 7dd8092340d0> -> __attrs_138366819713936
            __attrs_138366819713936 = _static_138366819713296

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd8092346d0> name=None at 7dd809234690> -> __attrs_138366819715344
            __attrs_138366819715344 = _static_138366819714768

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd809234c90> name=None at 7dd809234c10> -> __attrs_138366819716816
            __attrs_138366819716816 = _static_138366819716240

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd809235250> name=None at 7dd8092351d0> -> __attrs_138366819718288
            __attrs_138366819718288 = _static_138366819717712
            __previous_i18n_domain_138366819718480 = __i18n_domain
            __i18n_domain = u'plone'

            # <header ... (0:0)
            # --------------------------------------------------------
            __append(u'<header id="portal-top">\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819719760
            __attrs_138366819719760 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819719632
            __default_138366819719632 = _DEFAULT_MARKER

            # <Value u'provider:plone.portaltop' (83:44)> -> __cache_138366819719312
            __token = 4034
            try:
                __zt_tmp = __attrs_138366819719760
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819719312 = _static_138366930725008('provider', u'plone.portaltop', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portaltop' (83:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809235910> -> __condition
            __expression = __cache_138366819719312

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_138366819719312
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n              </header>')
            __i18n_domain = __previous_i18n_domain_138366819718480
            __append(u'\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd809235090> name=None at 7dd809235650> -> __attrs_138366819720144
            __attrs_138366819720144 = _static_138366819717264

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd809235ed0> name=None at 7dd809235e50> -> __attrs_138366819725648
            __attrs_138366819725648 = _static_138366819720912

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd809237590> name=None at 7dd809237550> -> __attrs_138366819727376
            __attrs_138366819727376 = _static_138366819726736

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="portal-mainnavigation">')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819726544
            __default_138366819726544 = _DEFAULT_MARKER

            # <Value u'provider:plone.mainnavigation' (90:69)> -> __cache_138366819726224
            __token = 4264
            try:
                __zt_tmp = __attrs_138366819727376
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819726224 = _static_138366930725008('provider', u'plone.mainnavigation', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.mainnavigation' (90:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809237410> -> __condition
            __expression = __cache_138366819726224

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\r\n                The main navigation\r\n              ')
            else:
                __content = __cache_138366819726224
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd809237290> name=None at 7dd809237190> -> __attrs_138366819728080
            __attrs_138366819728080 = _static_138366819725968

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd809237dd0> name=None at 7dd809237d50> -> __attrs_138366819729488
            __attrs_138366819729488 = _static_138366819728848

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd8092382d0> name=None at 7dd809238290> -> __attrs_138366819730768
            __attrs_138366819730768 = _static_138366819730128

            # <aside ... (0:0)
            # --------------------------------------------------------
            __append(u'<aside id="global_statusmessage">\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819731984
            __attrs_138366819731984 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819731664
            __default_138366819731664 = _DEFAULT_MARKER

            # <Value u'provider:plone.globalstatusmessage' (99:52)> -> __cache_138366819731344
            __token = 4563
            try:
                __zt_tmp = __attrs_138366819731984
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819731344 = _static_138366930725008('provider', u'plone.globalstatusmessage', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.globalstatusmessage' (99:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809238810> -> __condition
            __expression = __cache_138366819731344

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_138366819731344
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n                ')
            if (__slot_global_statusmessage is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819732304
                __attrs_138366819732304 = _static_138367014417552

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\r\n                </div>')
            else:
                __slot_global_statusmessage(__stream, econtext.copy(), rcontext)
            __append(u'\r\n              </aside>\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd809238190> name=None at 7dd809238090> -> __attrs_138366819732880
            __attrs_138366819732880 = _static_138366819729808

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80923b0d0> name=None at 7dd80923b050> -> __attrs_138366819742480
            __attrs_138366819742480 = _static_138366819741904

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd80923b750> name=None at 7dd80923b710> -> __attrs_138366819744208
            __attrs_138366819744208 = _static_138366819743568

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-above-content">')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819743376
            __default_138366819743376 = _DEFAULT_MARKER

            # <Value u'provider:plone.abovecontent' (108:69)> -> __cache_138366819743056
            __token = 4889
            try:
                __zt_tmp = __attrs_138366819744208
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819743056 = _static_138366930725008('provider', u'plone.abovecontent', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.abovecontent' (108:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80923b5d0> -> __condition
            __expression = __cache_138366819743056

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_138366819743056
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n            </div>\r\n          </div>\r\n\r\n          <!-- Main content -->\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd80923bad0> name=None at 7dd80923ba90> -> __attrs_138366819745040
            __attrs_138366819745040 = _static_138366819744464

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80923bfd0> name=None at 7dd80923bf90> -> __attrs_138366819750928
            __attrs_138366819750928 = _static_138366819745744

            # <article ... (0:0)
            # --------------------------------------------------------
            __append(u'<article id="portal-column-content"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819750608
            __default_138366819750608 = _DEFAULT_MARKER

            # <Substitution u'cls/content' (114:70)> -> __attr_class
            __token = 5094
            try:
                __zt_tmp = __attrs_138366819750928
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_138366930725008('path', u'cls/content', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n              ')
            if (__slot_content is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819751696
                __attrs_138366819751696 = _static_138367014417552
                __append(u'\r\n                ')
                __token = None
                render_content(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n\r\n              ')
            else:
                __slot_content(__stream, econtext.copy(), rcontext)
            __append(u'\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819752848
            __attrs_138366819752848 = _static_138367014417552

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer>\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd809240710> name=None at 7dd809240750> -> __attrs_138366819809296
            __attrs_138366819809296 = _static_138366819763984

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-below-content">')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819763664
            __default_138366819763664 = _DEFAULT_MARKER

            # <Value u'provider:plone.belowcontent' (148:71)> -> __cache_138366819762320
            __token = 6844
            try:
                __zt_tmp = __attrs_138366819809296
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366819762320 = _static_138366930725008('provider', u'plone.belowcontent', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.belowcontent' (148:71)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd809240110> -> __condition
            __expression = __cache_138366819762320

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_138366819762320
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n              </footer>\r\n            </article>\r\n\r\n            <!-- Column 1 -->\r\n            ')
            if (__slot_column_one_slot is None):

                # <Static value=<_ast.Dict object at 0x7dd80924b990> name=None at 7dd80923dc10> -> __attrs_138366819810512
                __attrs_138366819810512 = _static_138366819809680

                # <Value u'sl' (155:34)> -> __condition
                __token = 7092
                try:
                    __zt_tmp = __attrs_138366819810512
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('path', u'sl', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-one"')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819810192
                    __default_138366819810192 = _DEFAULT_MARKER

                    # <Substitution u'cls/one' (156:41)> -> __attr_class
                    __token = 7138
                    try:
                        __zt_tmp = __attrs_138366819810512
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_138366930725008('path', u'cls/one', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')
                    if (__slot_portlets_one_slot is None):

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819819728
                        __attrs_138366819819728 = _static_138367014417552
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819820944
                        __attrs_138366819820944 = _static_138367014417552

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819820816
                        __default_138366819820816 = _DEFAULT_MARKER

                        # <Value u'provider:plone.leftcolumn' (158:46)> -> __cache_138366819820496
                        __token = 7259
                        try:
                            __zt_tmp = __attrs_138366819820944
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366819820496 = _static_138366930725008('provider', u'plone.leftcolumn', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.leftcolumn' (158:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80924e450> -> __condition
                        __expression = __cache_138366819820496

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_138366819820496
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n              ')
                    else:
                        __slot_portlets_one_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n            </aside>')
            else:
                __slot_column_one_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n            <!-- Column 2 -->\r\n            ')
            if (__slot_column_two_slot is None):

                # <Static value=<_ast.Dict object at 0x7dd80924e350> name=None at 7dd80924e390> -> __attrs_138366819821840
                __attrs_138366819821840 = _static_138366819820368

                # <Value u'sr' (165:34)> -> __condition
                __token = 7511
                try:
                    __zt_tmp = __attrs_138366819821840
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('path', u'sr', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-two"')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366819821520
                    __default_138366819821520 = _DEFAULT_MARKER

                    # <Substitution u'cls/two' (166:41)> -> __attr_class
                    __token = 7557
                    try:
                        __zt_tmp = __attrs_138366819821840
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_138366930725008('path', u'cls/two', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')
                    if (__slot_portlets_two_slot is None):

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366819822800
                        __attrs_138366819822800 = _static_138367014417552
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366841360848
                        __attrs_138366841360848 = _static_138367014417552

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366841360720
                        __default_138366841360720 = _DEFAULT_MARKER

                        # <Value u'provider:plone.rightcolumn' (168:46)> -> __cache_138366819823568
                        __token = 7678
                        try:
                            __zt_tmp = __attrs_138366841360848
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366819823568 = _static_138366930725008('provider', u'plone.rightcolumn', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.rightcolumn' (168:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80a6d9090> -> __condition
                        __expression = __cache_138366819823568

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_138366819823568
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n              ')
                    else:
                        __slot_portlets_two_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n            </aside>')
            else:
                __slot_column_two_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd80924e990> name=None at 7dd80924e210> -> __attrs_138366819823440
            __attrs_138366819823440 = _static_138366819821968
            __previous_i18n_domain_138366841361040 = __i18n_domain
            __i18n_domain = u'plone'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer id="portal-footer-wrapper">\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366841362256
            __attrs_138366841362256 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366841362128
            __default_138366841362128 = _DEFAULT_MARKER

            # <Value u'provider:plone.portalfooter' (175:40)> -> __cache_138366841361808
            __token = 7894
            try:
                __zt_tmp = __attrs_138366841362256
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366841361808 = _static_138366930725008('provider', u'plone.portalfooter', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portalfooter' (175:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80a6d9610> -> __condition
            __expression = __cache_138366841361808

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_138366841361808
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n          </footer>')
            __i18n_domain = __previous_i18n_domain_138366841361040
            __append(u'\r\n\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <!-- NOTE:\r\n           We define all legacy resource slots at the bottom to ensure these are\r\n           loaded *after* the JS/CSS from the resources viewlet (rendered in the\r\n           IHtmlHead viewlet manager) and the HTML is completely loaded.\r\n      -->\r\n\r\n      <!-- SENAITE legacy resouces -->\r\n      ')
            if (__slot_senaite_legacy_resources is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366841362320
                __attrs_138366841362320 = _static_138367014417552
            else:
                __slot_senaite_legacy_resources(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      <!-- SENAITE legacy JS -->\r\n      ')
            if (__slot_senaite_legacy_js is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366841362832
                __attrs_138366841362832 = _static_138367014417552
            else:
                __slot_senaite_legacy_js(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      <!-- SENAITE legacy CSS -->\r\n      ')
            if (__slot_senaite_legacy_css is None):

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366841363280
                __attrs_138366841363280 = _static_138367014417552
            else:
                __slot_senaite_legacy_css(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n      <!-- RTL overrides (Tandis) \u2014 loaded last so it wins the cascade;\r\n           rules are scoped to [dir=rtl] so they are inert in LTR. -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x7dd80a6d9cd0> name=None at 7dd80a6d9c90> -> __attrs_138366841328144
            __attrs_138366841328144 = _static_138366841363664

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet" type="text/css"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366841327888
            __default_138366841327888 = _DEFAULT_MARKER

            # <Substitution u'string:${portal_url}/++plone++senaite.core.static/css/senaite.rtl.css' (198:33)> -> __attr_href
            __token = 8773
            try:
                __zt_tmp = __attrs_138366841328144
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_138366930725008('string', u'${portal_url}/++plone++senaite.core.static/css/senaite.rtl.css', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u' />\r\n\r\n    </body>')
            if (__backup_cls_138366819675024 is __marker):
                del econtext['cls']
            else:
                econtext['cls'] = __backup_cls_138366819675024
            if (__backup_body_class_138366820818704 is __marker):
                del econtext['body_class']
            else:
                econtext['body_class'] = __backup_body_class_138366820818704
            if (__backup_sr_138366819673168 is __marker):
                del econtext['sr']
            else:
                econtext['sr'] = __backup_sr_138366819673168
            if (__backup_sl_138366820815312 is __marker):
                del econtext['sl']
            else:
                econtext['sl'] = __backup_sl_138366820815312
            if (__backup_isRTL_138366820818064 is __marker):
                del econtext['isRTL']
            else:
                econtext['isRTL'] = __backup_isRTL_138366820818064
            __append(u'\r\n  </html>')
            __i18n_domain = __previous_i18n_domain_138366819671248
            if (__backup_ajax_load_138366820808336 is __marker):
                del econtext['ajax_load']
            else:
                econtext['ajax_load'] = __backup_ajax_load_138366820808336
            if (__backup_ajax_include_head_138366820815888 is __marker):
                del econtext['ajax_include_head']
            else:
                econtext['ajax_include_head'] = __backup_ajax_include_head_138366820815888
            if (__backup_site_properties_138366820809744 is __marker):
                del econtext['site_properties']
            else:
                econtext['site_properties'] = __backup_site_properties_138366820809744
            if (__backup_checkPermission_138366820808720 is __marker):
                del econtext['checkPermission']
            else:
                econtext['checkPermission'] = __backup_checkPermission_138366820808720
            if (__backup_portal_url_138366820810064 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_138366820810064
            if (__backup_dummy_138366820765200 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_138366820765200
            if (__backup_view_138366820808016 is __marker):
                del econtext['view']
            else:
                econtext['view'] = __backup_view_138366820808016
            if (__backup_lang_138366820763344 is __marker):
                del econtext['lang']
            else:
                econtext['lang'] = __backup_lang_138366820763344
            if (__backup_bootstrapview_138366820756688 is __marker):
                del econtext['bootstrapview']
            else:
                econtext['bootstrapview'] = __backup_bootstrapview_138366820756688
            if (__backup_plone_layout_138366820756368 is __marker):
                del econtext['plone_layout']
            else:
                econtext['plone_layout'] = __backup_plone_layout_138366820756368
            if (__backup_plone_view_138366820761936 is __marker):
                del econtext['plone_view']
            else:
                econtext['plone_view'] = __backup_plone_view_138366820761936
            if (__backup_context_state_138366820763728 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_138366820763728
            if (__backup_portal_state_138366820778896 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_138366820778896
            if (__backup_test_138366820764880 is __marker):
                del econtext['test']
            else:
                econtext['test'] = __backup_test_138366820764880
            if (__backup_senaite_view_138366820762320 is __marker):
                del econtext['senaite_view']
            else:
                econtext['senaite_view'] = __backup_senaite_view_138366820762320
            if (__backup_senaite_theme_138366820750480 is __marker):
                del econtext['senaite_theme']
            else:
                econtext['senaite_theme'] = __backup_senaite_theme_138366820750480
            __append(u'\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_master(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_content': render_content, u'render_master': render_master, 'render': render, }