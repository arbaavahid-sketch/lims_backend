# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/controlpanel/templates/overview.pt'

__tokens = {430: (u"python:request.set('disable_plone.leftcolumn',1)", 11, 51), 530: (u" python:request.set('disable_plone.rightcolumn',1", 12, 50), 998: (u'view/upgrade_warning', 25, 26), 1285: (u'string:${context/portal_url}/@@plone-upgrade', 33, 34), 1697: (u'view/mailhost_warning', 45, 26), 2266: (u'string:${portal_url}/@@mail-controlpanel', 56, 36), 2531: (u'view/timezone_warning', 65, 26), 3062: (u'string:${portal_url}/@@dateandtime-controlpanel', 77, 36), 3352: (u'not:view/pil', 86, 26), 3649: (u'view/categories', 95, 41), 3705: (u"python:view.sublists(category.get('id'))", 96, 38), 3837: (u'sublist', 97, 89), 3917: (u'category/title', 98, 70), 4114: (u'sublist', 102, 57), 4181: (u'sublist', 103, 57), 4241: (u'sublist', 104, 50), 4316: (u'action/visible', 105, 65), 4451: (u'action/icon', 108, 42), 4510: (u'action/url', 109, 46), 4575: (u"python:'icon-controlpanel-' + action['id'].replace('.', '_')", 110, 52), 4693: (u'action/title', 111, 48), 5066: (u'not:sublist', 124, 32), 5451: (u'view/version_overview', 137, 43), 5502: (u'version', 138, 27), 5597: (u'view/server_info', 140, 44), 5655: (u' server_info/wsg', 141, 40), 5799: (u'has_wsgi', 144, 51), 5870: (u'not:has_wsgi', 145, 51), 6003: (u'${server_info/server_name}', 149, 18), 6005: (u'server_info/server_name', 149, 20), 6055: (u'${server_info/version}', 150, 18), 6057: (u'server_info/version', 150, 20), 6160: (u'not:view/is_dev_mode', 155, 24), 6777: (u'view/is_dev_mode', 167, 24), 261: (u'here/prefs_main_template/macros/master', 6, 23), 261: (u'here/prefs_main_template/macros/master', 6, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948309459600 = u'master'
_static_136948323766224 = {u'class': u'portlet portletNavigationTree portletSiteSetup', }
_static_136948309383440 = {u'class': u'discreet text-muted small', }
_static_136948325633552 = {u'class': u'documentDescription text-secondary', }
_static_136948328022608 = {u'class': u"python:'icon-controlpanel-' + action['id'].replace('.', '_')", }
_static_136948323764624 = {u'class': u'portletHeader text-secondary', }
_static_136948328105744 = {u'class': u'nav-item col-sm-3', }
_static_136948323728464 = {u'class': u'col-sm-12', }
_static_136948328089616 = {u'class': u'visualClear', }
_static_136948309648784 = {u'class': u'discreet', }
_static_136948325624656 = {u'href': u'#', u'class': u'nav-link', }
_static_136948418207568 = __compile_zt_expr
_static_136948323728976 = {u'class': u'row', }
_static_136948328115984 = {u'href': u'', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948325631696 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_136948309650064 = {u'class': u'nav nav-pills', }
_static_136948328114384 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_136948328038480 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_136948328039248 = {u'href': u'#', u'title': u'Go to the upgrade page', }
_static_136948501914768 = {}
_static_136948325595984 = {u'role': u'status', u'class': u'portalMessage warning alert alert-warning', }
_static_136948325631568 = {u'class': u'documentFirstHeading', }
_static_136948309648080 = {u'class': u'portletContent', }
_static_136948323836944 = {u'class': u'discreet text-muted small', }
_static_136948327921552 = {u'href': u'', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309462032
            __attrs_136948309462032 = _static_136948501914768
            __previous_i18n_domain_136948309459984 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_136948292558672 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7c8dc3568290> name=None at 7c8dc3568050> -> __value
            __value = _static_136948309459600
            econtext['macroname'] = __value

            def __fill_top_slot(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309461328
                __attrs_136948309461328 = _static_136948501914768
                __backup_disable_column_one_136948309460624 = get('disable_column_one', __marker)

                # <Value u"python:request.set('disable_plone.leftcolumn',1)" (11:51)> -> __value
                __token = 430
                try:
                    __zt_tmp = __attrs_136948309461328
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u"request.set('disable_plone.leftcolumn',1)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['disable_column_one'] = __value
                __backup_disable_column_two_136948309355536 = get('disable_column_two', __marker)

                # <Value u"python:request.set('disable_plone.rightcolumn',1)" (12:50)> -> __value
                __token = 530
                try:
                    __zt_tmp = __attrs_136948309461328
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('python', u"request.set('disable_plone.rightcolumn',1)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['disable_column_two'] = __value
                if (__backup_disable_column_two_136948309355536 is __marker):
                    del econtext['disable_column_two']
                else:
                    econtext['disable_column_two'] = __backup_disable_column_two_136948309355536
                if (__backup_disable_column_one_136948309460624 is __marker):
                    del econtext['disable_column_one']
                else:
                    econtext['disable_column_one'] = __backup_disable_column_one_136948309460624
            _slots = econtext[u'__slot_top_slot'] = _deque((__fill_top_slot, ))

            def __fill_prefs_configlet_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323750160
                __attrs_136948323750160 = _static_136948501914768

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc44d4650> name=None at 7c8dc44d4890> -> __attrs_136948325633616
                __attrs_136948325633616 = _static_136948325631568

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')
                __stream_136948325632976 = []
                __append_136948325632976 = __stream_136948325632976.append
                __append_136948325632976(u'Site Setup')
                __msgid_136948325632976 = __re_whitespace(''.join(__stream_136948325632976)).strip()
                if __msgid_136948325632976:
                    __append(translate(__msgid_136948325632976, mapping=None, default=__msgid_136948325632976, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h1>\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc44d4e10> name=None at 7c8dc44d4190> -> __attrs_136948325631248
                __attrs_136948325631248 = _static_136948325633552

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="documentDescription text-secondary">')
                __stream_136948325633808 = []
                __append_136948325633808 = __stream_136948325633808.append
                __append_136948325633808(u'\n        Configuration area for Plone and add-on Products.\n      ')
                __msgid_136948325633808 = __re_whitespace(''.join(__stream_136948325633808)).strip()
                if u'description_control_panel':
                    __append(translate(u'description_control_panel', mapping=None, default=__msgid_136948325633808, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc44d46d0> name=None at 7c8dc44d4410> -> __attrs_136948323746384
                __attrs_136948323746384 = _static_136948325631696

                # <Value u'view/upgrade_warning' (25:26)> -> __condition
                __token = 998
                try:
                    __zt_tmp = __attrs_136948323746384
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'view/upgrade_warning', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning" role="status">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328039952
                    __attrs_136948328039952 = _static_136948501914768

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_136948323747856 = []
                    __append_136948323747856 = __stream_136948323747856.append
                    __append_136948323747856(u'\n          Warning\n        ')
                    __msgid_136948323747856 = __re_whitespace(''.join(__stream_136948323747856)).strip()
                    if __msgid_136948323747856:
                        __append(translate(__msgid_136948323747856, mapping=None, default=__msgid_136948323747856, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328042192
                    __attrs_136948328042192 = _static_136948501914768
                    __stream_136948283578080_link_continue_with_the_upgrade = ''
                    __stream_136948328041680 = []
                    __append_136948328041680 = __stream_136948328041680.append
                    __append_136948328041680(u'\n          The site configuration is outdated and needs to be\n          upgraded. Please\n          ')
                    __stream_136948283578080_link_continue_with_the_upgrade = []
                    __append_136948283578080_link_continue_with_the_upgrade = __stream_136948283578080_link_continue_with_the_upgrade.append

                    # <Static value=<_ast.Dict object at 0x7c8dc4720350> name=None at 7c8dc4720b50> -> __attrs_136948325595472
                    __attrs_136948325595472 = _static_136948328039248

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_136948283578080_link_continue_with_the_upgrade(u'<a')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328041424
                    __default_136948328041424 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/portal_url}/@@plone-upgrade' (33:34)> -> __attr_href
                    __token = 1285
                    try:
                        __zt_tmp = __attrs_136948325595472
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_136948418207568('string', u'${context/portal_url}/@@plone-upgrade', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_136948283578080_link_continue_with_the_upgrade((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328042064
                    __default_136948328042064 = _DEFAULT_MARKER

                    # <Translate msgid=None node=<_ast.Str object at 0x7c8dc4720390> at 7c8dc4720f90> -> __attr_title
                    __attr_title = u'Go to the upgrade page'
                    __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_title is not None):
                        __append_136948283578080_link_continue_with_the_upgrade((u' title="%s"' % __attr_title))
                    __append_136948283578080_link_continue_with_the_upgrade(u'>')
                    __stream_136948328038800 = []
                    __append_136948328038800 = __stream_136948328038800.append
                    __append_136948328038800(u'\n            continue with the upgrade\n          ')
                    __msgid_136948328038800 = __re_whitespace(''.join(__stream_136948328038800)).strip()
                    if __msgid_136948328038800:
                        __append_136948283578080_link_continue_with_the_upgrade(translate(__msgid_136948328038800, mapping=None, default=__msgid_136948328038800, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_136948283578080_link_continue_with_the_upgrade(u'</a>')
                    __append_136948328041680(u'${link_continue_with_the_upgrade}')
                    __stream_136948283578080_link_continue_with_the_upgrade = ''.join(__stream_136948283578080_link_continue_with_the_upgrade)
                    __append_136948328041680(u'.\n        ')
                    __msgid_136948328041680 = __re_whitespace(''.join(__stream_136948328041680)).strip()
                    if __msgid_136948328041680:
                        __append(translate(__msgid_136948328041680, mapping={u'link_continue_with_the_upgrade': __stream_136948283578080_link_continue_with_the_upgrade, }, default=__msgid_136948328041680, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\n      </div>')
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc4720050> name=None at 7c8dc4720a50> -> __attrs_136948325595536
                __attrs_136948325595536 = _static_136948328038480

                # <Value u'view/mailhost_warning' (45:26)> -> __condition
                __token = 1697
                try:
                    __zt_tmp = __attrs_136948325595536
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'view/mailhost_warning', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning" role="status">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325594064
                    __attrs_136948325594064 = _static_136948501914768

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_136948325596752 = []
                    __append_136948325596752 = __stream_136948325596752.append
                    __append_136948325596752(u'\n          Warning\n        ')
                    __msgid_136948325596752 = __re_whitespace(''.join(__stream_136948325596752)).strip()
                    if __msgid_136948325596752:
                        __append(translate(__msgid_136948325596752, mapping=None, default=__msgid_136948325596752, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325595664
                    __attrs_136948325595664 = _static_136948501914768
                    __stream_136948283578080_label_mail_control_panel_link = ''
                    __stream_136948325594576 = []
                    __append_136948325594576 = __stream_136948325594576.append
                    __append_136948325594576(u"\n          You have not configured a mail host or a site 'From'\n          address, various features including contact forms, email\n          notification and password reset will not work. Go to the\n          ")
                    __stream_136948283578080_label_mail_control_panel_link = []
                    __append_136948283578080_label_mail_control_panel_link = __stream_136948283578080_label_mail_control_panel_link.append

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948327922384
                    __attrs_136948327922384 = _static_136948501914768
                    __append_136948283578080_label_mail_control_panel_link(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dc4703790> name=None at 7c8dc4703810> -> __attrs_136948327922064
                    __attrs_136948327922064 = _static_136948327921552

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_136948283578080_label_mail_control_panel_link(u'<a')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948327920912
                    __default_136948327920912 = _DEFAULT_MARKER

                    # <Substitution u'string:${portal_url}/@@mail-controlpanel' (56:36)> -> __attr_href
                    __token = 2266
                    try:
                        __zt_tmp = __attrs_136948327922064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_136948418207568('string', u'${portal_url}/@@mail-controlpanel', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_136948283578080_label_mail_control_panel_link((u' href="%s"' % __attr_href))
                    __append_136948283578080_label_mail_control_panel_link(u' >')
                    __stream_136948327920528 = []
                    __append_136948327920528 = __stream_136948327920528.append
                    __append_136948327920528(u'Mail control panel')
                    __msgid_136948327920528 = __re_whitespace(''.join(__stream_136948327920528)).strip()
                    if u'text_no_mailhost_configured_control_panel_link':
                        __append_136948283578080_label_mail_control_panel_link(translate(u'text_no_mailhost_configured_control_panel_link', mapping=None, default=__msgid_136948327920528, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_136948283578080_label_mail_control_panel_link(u'</a>\n          ')
                    __append_136948325594576(u'${label_mail_control_panel_link}')
                    __stream_136948283578080_label_mail_control_panel_link = ''.join(__stream_136948283578080_label_mail_control_panel_link)
                    __append_136948325594576(u'\n          to fix this.\n        ')
                    __msgid_136948325594576 = __re_whitespace(''.join(__stream_136948325594576)).strip()
                    if u'text_no_mailhost_configured':
                        __append(translate(u'text_no_mailhost_configured', mapping={u'label_mail_control_panel_link': __stream_136948283578080_label_mail_control_panel_link, }, default=__msgid_136948325594576, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\n      </div>')
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc44cbb50> name=None at 7c8dc44cb110> -> __attrs_136948537987472
                __attrs_136948537987472 = _static_136948325595984

                # <Value u'view/timezone_warning' (65:26)> -> __condition
                __token = 2531
                try:
                    __zt_tmp = __attrs_136948537987472
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'view/timezone_warning', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning" role="status">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328115152
                    __attrs_136948328115152 = _static_136948501914768

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_136948328114640 = []
                    __append_136948328114640 = __stream_136948328114640.append
                    __append_136948328114640(u'\n          Warning\n        ')
                    __msgid_136948328114640 = __re_whitespace(''.join(__stream_136948328114640)).strip()
                    if __msgid_136948328114640:
                        __append(translate(__msgid_136948328114640, mapping=None, default=__msgid_136948328114640, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328115536
                    __attrs_136948328115536 = _static_136948501914768
                    __stream_136948283578080_label_mail_event_settings_link = ''
                    __stream_136948328113488 = []
                    __append_136948328113488 = __stream_136948328113488.append
                    __append_136948328113488(u'\n\n          You have not set the portal timezone. Date/Time handling will not\n          work properly for timezone aware date/time values.\n          Go to the\n          ')
                    __stream_136948283578080_label_mail_event_settings_link = []
                    __append_136948283578080_label_mail_event_settings_link = __stream_136948283578080_label_mail_event_settings_link.append

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328112592
                    __attrs_136948328112592 = _static_136948501914768
                    __append_136948283578080_label_mail_event_settings_link(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dc4732f10> name=None at 7c8dc4732990> -> __attrs_136948309473104
                    __attrs_136948309473104 = _static_136948328115984

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_136948283578080_label_mail_event_settings_link(u'<a')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328116112
                    __default_136948328116112 = _DEFAULT_MARKER

                    # <Substitution u'string:${portal_url}/@@dateandtime-controlpanel' (77:36)> -> __attr_href
                    __token = 3062
                    try:
                        __zt_tmp = __attrs_136948309473104
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_136948418207568('string', u'${portal_url}/@@dateandtime-controlpanel', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_136948283578080_label_mail_event_settings_link((u' href="%s"' % __attr_href))
                    __append_136948283578080_label_mail_event_settings_link(u' >')
                    __stream_136948328112208 = []
                    __append_136948328112208 = __stream_136948328112208.append
                    __append_136948328112208(u'Date and Time Settings control panel')
                    __msgid_136948328112208 = __re_whitespace(''.join(__stream_136948328112208)).strip()
                    if u'text_no_timezone_configured_control_panel_link':
                        __append_136948283578080_label_mail_event_settings_link(translate(u'text_no_timezone_configured_control_panel_link', mapping=None, default=__msgid_136948328112208, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_136948283578080_label_mail_event_settings_link(u'</a>\n          ')
                    __append_136948328113488(u'${label_mail_event_settings_link}')
                    __stream_136948283578080_label_mail_event_settings_link = ''.join(__stream_136948283578080_label_mail_event_settings_link)
                    __append_136948328113488(u'\n          to fix this.\n        ')
                    __msgid_136948328113488 = __re_whitespace(''.join(__stream_136948328113488)).strip()
                    if u'text_no_timezone_configured':
                        __append(translate(u'text_no_timezone_configured', mapping={u'label_mail_event_settings_link': __stream_136948283578080_label_mail_event_settings_link, }, default=__msgid_136948328113488, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\n      </div>')
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc47328d0> name=None at 7c8dc47320d0> -> __attrs_136948309471568
                __attrs_136948309471568 = _static_136948328114384

                # <Value u'not:view/pil' (86:26)> -> __condition
                __token = 3352
                try:
                    __zt_tmp = __attrs_136948309471568
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('not', u'view/pil', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage warning alert alert-warning" role="status">\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309475216
                    __attrs_136948309475216 = _static_136948501914768

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_136948309475024 = []
                    __append_136948309475024 = __stream_136948309475024.append
                    __append_136948309475024(u'\n          Warning\n        ')
                    __msgid_136948309475024 = __re_whitespace(''.join(__stream_136948309475024)).strip()
                    if __msgid_136948309475024:
                        __append(translate(__msgid_136948309475024, mapping=None, default=__msgid_136948309475024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309471312
                    __attrs_136948309471312 = _static_136948501914768
                    __stream_136948309472144 = []
                    __append_136948309472144 = __stream_136948309472144.append
                    __append_136948309472144(u'\n          PIL is not installed properly, image scaling will not work.\n        ')
                    __msgid_136948309472144 = __re_whitespace(''.join(__stream_136948309472144)).strip()
                    if u'text_no_pil_installed':
                        __append(translate(u'text_no_pil_installed', mapping=None, default=__msgid_136948309472144, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\n      </div>')
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309473552
                __attrs_136948309473552 = _static_136948501914768
                __backup_category_136948309461392 = get('category', __marker)

                # <Value u'view/categories' (95:41)> -> __iterator
                __token = 3649
                try:
                    __zt_tmp = __attrs_136948309473552
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'view/categories', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948309388688, ) = getitem('repeat')(u'category', __iterator)
                econtext['category'] = None
                for __item in __iterator:
                    econtext['category'] = __item
                    __append(u'\n        ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328088400
                    __attrs_136948328088400 = _static_136948501914768
                    __backup_sublist_136948325632784 = get('sublist', __marker)

                    # <Value u"python:view.sublists(category.get('id'))" (96:38)> -> __value
                    __token = 3705
                    try:
                        __zt_tmp = __attrs_136948328088400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"view.sublists(category.get('id'))", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['sublist'] = __value
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7c8dc430cfd0> name=None at 7c8dc472c750> -> __attrs_136948323763152
                    __attrs_136948323763152 = _static_136948323766224

                    # <Value u'sublist' (97:89)> -> __condition
                    __token = 3837
                    try:
                        __zt_tmp = __attrs_136948323763152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('path', u'sublist', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:

                        # <section ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<section class="portlet portletNavigationTree portletSiteSetup">\n            ')

                        # <Static value=<_ast.Dict object at 0x7c8dc430c990> name=None at 7c8dc430c390> -> __attrs_136948323727184
                        __attrs_136948323727184 = _static_136948323764624

                        # <strong ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<strong class="portletHeader text-secondary">')

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323763984
                        __default_136948323763984 = _DEFAULT_MARKER

                        # <Value u'category/title' (98:70)> -> __cache_136948323764496
                        __token = 3917
                        try:
                            __zt_tmp = __attrs_136948323727184
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136948323764496 = _static_136948418207568('path', u'category/title', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                        # <BinOp left=<Value u'category/title' (98:70)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc430c850> -> __condition
                        __expression = __cache_136948323764496

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'Category')
                        else:
                            __content = __cache_136948323764496
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</strong>\n            ')

                        # <Static value=<_ast.Dict object at 0x7c8dc4303e50> name=None at 7c8dc4303f90> -> __attrs_136948323728528
                        __attrs_136948323728528 = _static_136948323728976

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="row">\n              ')

                        # <Static value=<_ast.Dict object at 0x7c8dc4303c50> name=None at 7c8dc4303a50> -> __attrs_136948323727376
                        __attrs_136948323727376 = _static_136948323728464

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="col-sm-12">\n              ')

                        # <Static value=<_ast.Dict object at 0x7c8dc35962d0> name=None at 7c8dc3596f90> -> __attrs_136948309651408
                        __attrs_136948309651408 = _static_136948309648080

                        # <Value u'sublist' (102:57)> -> __condition
                        __token = 4114
                        try:
                            __zt_tmp = __attrs_136948309651408
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_136948418207568('path', u'sublist', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                        if __condition:

                            # <nav ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<nav class="portletContent">\n                ')

                            # <Static value=<_ast.Dict object at 0x7c8dc3596a90> name=None at 7c8dc3596110> -> __attrs_136948309650960
                            __attrs_136948309650960 = _static_136948309650064

                            # <Value u'sublist' (103:57)> -> __condition
                            __token = 4181
                            try:
                                __zt_tmp = __attrs_136948309650960
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_136948418207568('path', u'sublist', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                            if __condition:

                                # <ul ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<ul class="nav nav-pills">\n                  ')

                                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948328104272
                                __attrs_136948328104272 = _static_136948501914768
                                __backup_action_136948309648912 = get('action', __marker)

                                # <Value u'sublist' (104:50)> -> __iterator
                                __token = 4241
                                try:
                                    __zt_tmp = __attrs_136948328104272
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __iterator = _static_136948418207568('path', u'sublist', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                                (__iterator, ____index_136948328106960, ) = getitem('repeat')(u'action', __iterator)
                                econtext['action'] = None
                                for __item in __iterator:
                                    econtext['action'] = __item
                                    __append(u'\n                    ')

                                    # <Static value=<_ast.Dict object at 0x7c8dc4730710> name=None at 7c8dc4730dd0> -> __attrs_136948328107408
                                    __attrs_136948328107408 = _static_136948328105744

                                    # <Value u'action/visible' (105:65)> -> __condition
                                    __token = 4316
                                    try:
                                        __zt_tmp = __attrs_136948328107408
                                    except get('NameError', NameError):
                                        __zt_tmp = None

                                    __condition = _static_136948418207568('path', u'action/visible', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                                    if __condition:

                                        # <li ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<li class="nav-item col-sm-3">\n                      ')

                                        # <Static value=<_ast.Dict object at 0x7c8dc44d2b50> name=None at 7c8dc44d2f50> -> __attrs_136948325623824
                                        __attrs_136948325623824 = _static_136948325624656
                                        __backup_icon_136948309649232 = get('icon', __marker)

                                        # <Value u'action/icon' (108:42)> -> __value
                                        __token = 4451
                                        try:
                                            __zt_tmp = __attrs_136948325623824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __value = _static_136948418207568('path', u'action/icon', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                                        econtext['icon'] = __value

                                        # <a ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<a')

                                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948325623504
                                        __default_136948325623504 = _DEFAULT_MARKER

                                        # <Substitution u'action/url' (109:46)> -> __attr_href
                                        __token = 4510
                                        try:
                                            __zt_tmp = __attrs_136948325623824
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_href = _static_136948418207568('path', u'action/url', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                                        if (__attr_href is not None):
                                            __append((u' href="%s"' % __attr_href))
                                        __append(u' class="nav-link">\n                        ')

                                        # <Static value=<_ast.Dict object at 0x7c8dc471c250> name=None at 7c8dc44d2d90> -> __attrs_136948328022928
                                        __attrs_136948328022928 = _static_136948328022608

                                        # <span ... (0:0)
                                        # --------------------------------------------------------
                                        __append(u'<span')

                                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328022736
                                        __default_136948328022736 = _DEFAULT_MARKER

                                        # <Substitution u"python:'icon-controlpanel-' + action['id'].replace('.', '_')" (110:52)> -> __attr_class
                                        __token = 4575
                                        try:
                                            __zt_tmp = __attrs_136948328022928
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __attr_class = _static_136948418207568('python', u"'icon-controlpanel-' + action['id'].replace('.', '_')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                                        __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                                        if (__attr_class is not None):
                                            __append((u' class="%s"' % __attr_class))
                                        __append(u'></span>\n                        ')

                                        # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323839056
                                        __attrs_136948323839056 = _static_136948501914768

                                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948328026000
                                        __default_136948328026000 = _DEFAULT_MARKER

                                        # <Value u'action/title' (111:48)> -> __cache_136948328025424
                                        __token = 4693
                                        try:
                                            __zt_tmp = __attrs_136948323839056
                                        except get('NameError', NameError):
                                            __zt_tmp = None

                                        __cache_136948328025424 = _static_136948418207568('path', u'action/title', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                                        # <BinOp left=<Value u'action/title' (111:48)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc471c210> -> __condition
                                        __expression = __cache_136948328025424

                                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                                        __value = _DEFAULT_MARKER
                                        __condition = (__expression is __value)
                                        if __condition:
                                            __append(u'\n                          Title\n                        ')
                                        else:
                                            __content = __cache_136948328025424
                                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                            __content = __quote(__content, None, '\xad', None, None)
                                            if (__content is not None):
                                                __append(__content)
                                        __append(u'\n                      </a>')
                                        if (__backup_icon_136948309649232 is __marker):
                                            del econtext['icon']
                                        else:
                                            econtext['icon'] = __backup_icon_136948309649232
                                        __append(u'\n                    </li>')
                                    __append(u'\n                  ')
                                    ____index_136948328106960 -= 1
                                    if (____index_136948328106960 > 0):
                                        __append('')
                                if (__backup_action_136948309648912 is __marker):
                                    del econtext['action']
                                else:
                                    econtext['action'] = __backup_action_136948309648912
                                __append(u'\n                </ul>')
                            __append(u'\n              </nav>')
                        __append(u'\n              </div>\n            </div>\n\n            ')

                        # <Static value=<_ast.Dict object at 0x7c8dc3596590> name=None at 7c8dc3596990> -> __attrs_136948328104912
                        __attrs_136948328104912 = _static_136948309648784

                        # <Value u'not:sublist' (124:32)> -> __condition
                        __token = 5066
                        try:
                            __zt_tmp = __attrs_136948328104912
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_136948418207568('not', u'sublist', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                        if __condition:

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div class="discreet">')
                            __stream_136948323729104 = []
                            __append_136948323729104 = __stream_136948323729104.append
                            __append_136948323729104(u'\n              No preference panels available.\n            ')
                            __msgid_136948323729104 = __re_whitespace(''.join(__stream_136948323729104)).strip()
                            if u'label_no_prefs_panels_available':
                                __append(translate(u'label_no_prefs_panels_available', mapping=None, default=__msgid_136948323729104, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                            __append(u'</div>')
                        __append(u'\n\n          </section>')
                    __append(u'\n        ')
                    if (__backup_sublist_136948325632784 is __marker):
                        del econtext['sublist']
                    else:
                        econtext['sublist'] = __backup_sublist_136948325632784
                    __append(u'\n      ')
                    ____index_136948309388688 -= 1
                    if (____index_136948309388688 > 0):
                        __append('')
                if (__backup_category_136948309461392 is __marker):
                    del econtext['category']
                else:
                    econtext['category'] = __backup_category_136948309461392
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc472c810> name=None at 7c8dc356b0d0> -> __attrs_136948323725520
                __attrs_136948323725520 = _static_136948328089616

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="visualClear"><!-- --></div>\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323837136
                __attrs_136948323837136 = _static_136948501914768

                # <h2 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h2>')
                __stream_136948325625104 = []
                __append_136948325625104 = __stream_136948325625104.append
                __append_136948325625104(u'Version Overview')
                __msgid_136948325625104 = __re_whitespace(''.join(__stream_136948325625104)).strip()
                if u'heading_version_overview':
                    __append(translate(u'heading_version_overview', mapping=None, default=__msgid_136948325625104, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h2>\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323837520
                __attrs_136948323837520 = _static_136948501914768

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul>\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323837840
                __attrs_136948323837840 = _static_136948501914768
                __backup_version_136948325631504 = get('version', __marker)

                # <Value u'view/version_overview' (137:43)> -> __iterator
                __token = 5451
                try:
                    __zt_tmp = __attrs_136948323837840
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'view/version_overview', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948323838160, ) = getitem('repeat')(u'version', __iterator)
                econtext['version'] = None
                for __item in __iterator:
                    econtext['version'] = __item
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323838288
                    __attrs_136948323838288 = _static_136948501914768

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948323838928
                    __default_136948323838928 = _DEFAULT_MARKER

                    # <Value u'version' (138:27)> -> __cache_136948323839184
                    __token = 5502
                    try:
                        __zt_tmp = __attrs_136948323838288
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948323839184 = _static_136948418207568('path', u'version', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'version' (138:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc431e150> -> __condition
                    __expression = __cache_136948323839184

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'Version')
                    else:
                        __content = __cache_136948323839184
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</li>\n        ')
                    ____index_136948323838160 -= 1
                    if (____index_136948323838160 > 0):
                        __append('')
                if (__backup_version_136948325631504 is __marker):
                    del econtext['version']
                else:
                    econtext['version'] = __backup_version_136948325631504
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323837584
                __attrs_136948323837584 = _static_136948501914768
                __backup_server_info_136948323746064 = get('server_info', __marker)

                # <Value u'view/server_info' (140:44)> -> __value
                __token = 5597
                try:
                    __zt_tmp = __attrs_136948323837584
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'view/server_info', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['server_info'] = __value
                __backup_has_wsgi_136948325597136 = get('has_wsgi', __marker)

                # <Value u'server_info/wsgi' (141:40)> -> __value
                __token = 5655
                try:
                    __zt_tmp = __attrs_136948323837584
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'server_info/wsgi', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['has_wsgi'] = __value
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948301939664
                __attrs_136948301939664 = _static_136948501914768

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948301939856
                __attrs_136948301939856 = _static_136948501914768
                __stream_136948301940304 = []
                __append_136948301940304 = __stream_136948301940304.append
                __append_136948301940304(u'WSGI:')
                __msgid_136948301940304 = __re_whitespace(''.join(__stream_136948301940304)).strip()
                if __msgid_136948301940304:
                    __append(translate(__msgid_136948301940304, mapping=None, default=__msgid_136948301940304, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325588560
                __attrs_136948325588560 = _static_136948501914768

                # <Value u'has_wsgi' (144:51)> -> __condition
                __token = 5799
                try:
                    __zt_tmp = __attrs_136948325588560
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'has_wsgi', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_136948301940496 = []
                    __append_136948301940496 = __stream_136948301940496.append
                    __append_136948301940496(u'On')
                    __msgid_136948301940496 = __re_whitespace(''.join(__stream_136948301940496)).strip()
                    if __msgid_136948301940496:
                        __append(translate(__msgid_136948301940496, mapping=None, default=__msgid_136948301940496, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325587792
                __attrs_136948325587792 = _static_136948501914768

                # <Value u'not:has_wsgi' (145:51)> -> __condition
                __token = 5870
                try:
                    __zt_tmp = __attrs_136948325587792
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('not', u'has_wsgi', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>')
                    __stream_136948325584976 = []
                    __append_136948325584976 = __stream_136948325584976.append
                    __append_136948325584976(u'Off')
                    __msgid_136948325584976 = __re_whitespace(''.join(__stream_136948325584976)).strip()
                    if __msgid_136948325584976:
                        __append(translate(__msgid_136948325584976, mapping=None, default=__msgid_136948325584976, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>')
                __append(u'\n          </li>\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325587344
                __attrs_136948325587344 = _static_136948501914768

                # <li ... (0:0)
                # --------------------------------------------------------
                __append(u'<li>\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948325585616
                __attrs_136948325585616 = _static_136948501914768
                __stream_136948325586384 = []
                __append_136948325586384 = __stream_136948325586384.append
                __append_136948325586384(u'Server:')
                __msgid_136948325586384 = __re_whitespace(''.join(__stream_136948325586384)).strip()
                if __msgid_136948325586384:
                    __append(translate(__msgid_136948325586384, mapping=None, default=__msgid_136948325586384, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309384720
                __attrs_136948309384720 = _static_136948501914768

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Interpolation value=<Substitution u'${server_info/server_name}' (149:18)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc35553d0> -> __content_136948571129056
                __token = 6003
                __token = 6005
                try:
                    __zt_tmp = __attrs_136948309384720
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_136948571129056 = _static_136948418207568('path', u'server_info/server_name', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __content_136948571129056 = __quote(__content_136948571129056, '\x00', '&#0;', None, None)
                __content_136948571129056 = __content_136948571129056
                if (__content_136948571129056 is None):
                    pass
                else:
                    if (__content_136948571129056 is None):
                        __content_136948571129056 = None
                    else:
                        __tt = type(__content_136948571129056)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_136948571129056 = unicode(__content_136948571129056)
                        else:
                            if (__tt is str):
                                __content_136948571129056 = decode(__content_136948571129056)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_136948571129056 = __content_136948571129056.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_136948571129056)
                                        __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                    else:
                                        __content_136948571129056 = __content_136948571129056()
                if (__content_136948571129056 is not None):
                    __append(__content_136948571129056)
                __append(u'</span>\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309384208
                __attrs_136948309384208 = _static_136948501914768

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Interpolation value=<Substitution u'${server_info/version}' (150:18)> braces_required=True translation=False default='"?"' default_marker='"?"' at 7c8dc3555210> -> __content_136948571129056
                __token = 6055
                __token = 6057
                try:
                    __zt_tmp = __attrs_136948309384208
                except get('NameError', NameError):
                    __zt_tmp = None

                __content_136948571129056 = _static_136948418207568('path', u'server_info/version', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __content_136948571129056 = __quote(__content_136948571129056, '\x00', '&#0;', None, None)
                __content_136948571129056 = __content_136948571129056
                if (__content_136948571129056 is None):
                    pass
                else:
                    if (__content_136948571129056 is None):
                        __content_136948571129056 = None
                    else:
                        __tt = type(__content_136948571129056)
                        if ((__tt is int) or (__tt is float) or (__tt is long)):
                            __content_136948571129056 = unicode(__content_136948571129056)
                        else:
                            if (__tt is str):
                                __content_136948571129056 = decode(__content_136948571129056)
                            else:
                                if (__tt is not unicode):
                                    try:
                                        __content_136948571129056 = __content_136948571129056.__html__
                                    except get('AttributeError', AttributeError):
                                        __converted = convert(__content_136948571129056)
                                        __content_136948571129056 = (unicode(__content_136948571129056) if (__content_136948571129056 is __converted) else __converted)
                                    else:
                                        __content_136948571129056 = __content_136948571129056()
                if (__content_136948571129056 is not None):
                    __append(__content_136948571129056)
                __append(u'</span>\n          </li>\n        ')
                if (__backup_has_wsgi_136948325597136 is __marker):
                    del econtext['has_wsgi']
                else:
                    econtext['has_wsgi'] = __backup_has_wsgi_136948325597136
                if (__backup_server_info_136948323746064 is __marker):
                    del econtext['server_info']
                else:
                    econtext['server_info'] = __backup_server_info_136948323746064
                __append(u'\n      </ul>\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc431e410> name=None at 7c8dc431e490> -> __attrs_136948309385168
                __attrs_136948309385168 = _static_136948323836944

                # <Value u'not:view/is_dev_mode' (155:24)> -> __condition
                __token = 6160
                try:
                    __zt_tmp = __attrs_136948309385168
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('not', u'view/is_dev_mode', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="discreet text-muted small">')
                    __stream_136948323835984 = []
                    __append_136948323835984 = __stream_136948323835984.append
                    __append_136948323835984(u'\n        You are running in "production mode". This is the preferred mode of\n        operation for a live Plone site, but means that some\n        configuration changes will not take effect until your server is\n        restarted or a product refreshed. If this is a development instance,\n        and you want to enable debug mode, stop the server, set \'debug-mode=on\'\n        in your buildout.cfg, re-run bin/buildout and then restart the server\n        process.\n      ')
                    __msgid_136948323835984 = __re_whitespace(''.join(__stream_136948323835984)).strip()
                    if u'description_production_mode':
                        __append(translate(u'description_production_mode', mapping=None, default=__msgid_136948323835984, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>')
                __append(u'\n\n      ')

                # <Static value=<_ast.Dict object at 0x7c8dc3555910> name=None at 7c8dc3555890> -> __attrs_136948309381264
                __attrs_136948309381264 = _static_136948309383440

                # <Value u'view/is_dev_mode' (167:24)> -> __condition
                __token = 6777
                try:
                    __zt_tmp = __attrs_136948309381264
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'view/is_dev_mode', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="discreet text-muted small">')
                    __stream_136948309381904 = []
                    __append_136948309381904 = __stream_136948309381904.append
                    __append_136948309381904(u'\n        You are running in "debug mode". This mode is intended for sites that\n        are under development. This allows many configuration changes to be\n        immediately visible, but will make your site run more slowly. To turn\n        off debug mode, stop the server, set \'debug-mode=off\' in your\n        buildout.cfg, re-run bin/buildout and then restart the server\n        process.\n      ')
                    __msgid_136948309381904 = __re_whitespace(''.join(__stream_136948309381904)).strip()
                    if u'description_debug_mode':
                        __append(translate(u'description_debug_mode', mapping=None, default=__msgid_136948309381904, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>')
                __append(u'\n\n    </div>')
            _slots = econtext[u'__slot_prefs_configlet_main'] = _deque((__fill_prefs_configlet_main, ))

            # <Value u'here/prefs_main_template/macros/master' (6:23)> -> __macro
            __token = 261
            try:
                __zt_tmp = __attrs_136948309462032
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_136948418207568('path', u'here/prefs_main_template/macros/master', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __token = 261
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_136948292558672 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_136948292558672
            __i18n_domain = __previous_i18n_domain_136948309459984
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }