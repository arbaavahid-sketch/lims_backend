# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/macros.pt'

__tokens = {7319: (u'view/widgets/values', 152, 48), 367: (u'view/label | nothing', 11, 27), 402: (u'view/label', 11, 62), 6868: (u'show_default_label|nothing', 142, 45), 6932: (u' has_groups|nothin', 143, 36), 7184: (u'has_default_widgets', 150, 36), 7841: (u'has_groups', 163, 64), 7822: (u'groups', 163, 45), 7984: (u'nocall:context/@@plone/normalizeString', 166, 51), 8073: (u' group/labe', 167, 49), 8134: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 168, 47), 8284: (u'me python:normalizeString(fieldset_na', 169, 46), 8366: (u"rst python:repeat['group'].s", 170, 40), 8447: (u'tive python:is_first and not has_default_wi', 171, 47), 8537: (u"class python:'tab-pane active' if should_be_active else 'tab", 172, 40), 8717: (u' pane_clas', 174, 44), 8648: (u'string:${fieldset_name}', 173, 42), 8781: (u't fieldset_na', 175, 51), 8893: (u'group/description|nothing', 178, 52), 8957: (u'group_description', 179, 37), 9021: (u'group_description', 180, 45), 9186: (u'group/widgets/errors', 185, 50), 9254: (u'python:False', 186, 46), 9317: (u'errors', 187, 49), 9429: (u'not:nocall:error/widget', 189, 42), 9504: (u'error/render', 190, 50), 9634: (u'nocall:group', 194, 44), 9696: (u'context/@@ploneform-macros/widget_rendering', 195, 46), 9696: (u'context/@@ploneform-macros/widget_rendering', 195, 46), 10125: (u'view/actions/values|nothing', 209, 55), 10197: (u'view/actions/values', 210, 42), 10281: (u'action/render', 211, 62), 7522: (u'widget/@@ploneform-render-widget', 155, 61), 562: (u'view/status', 17, 35), 612: (u" python:view.widgets.errors or status == getattr(view, 'formErrorsMessage', None", 18, 37), 706: (u'status', 18, 131), 778: (u'has_error', 19, 63), 925: (u'status', 23, 29), 1008: (u'not:has_error', 25, 56), 1159: (u'status', 29, 29), 1282: (u'view/widgets/errors', 34, 35), 1314: (u'errors', 34, 67), 1358: (u'errors', 35, 35), 1456: (u'not:nocall:error/widget', 37, 32), 1521: (u'error/render', 38, 40), 1696: (u'view/groups|nothing', 45, 35), 1748: (u'python:bool(groups)', 46, 31), 1803: (u'groups', 47, 34), 1852: (u'group/widgets/errors', 48, 40), 1909: (u'errors', 49, 35), 1955: (u'errors', 50, 38), 2052: (u'not:nocall:error/widget', 52, 31), 2116: (u'error/render', 53, 39), 2348: (u'view/description | nothing', 60, 37), 2404: (u'description', 61, 28), 2453: (u'description|default', 62, 36), 2787: (u'view/groups | nothing', 70, 33), 2845: (u' view/form_name | nothin', 71, 35), 2907: (u's view/css_class | strin', 72, 35), 2981: (u'el view/default_fieldset_label | form_n', 73, 46), 3067: (u'ing view/enable_form_tabbing | python:', 74, 42), 3157: (u'tion view/enable_unload_protection|python', 75, 46), 3243: (u"ction python:enable_unload_protection and 'pat-formunload", 76, 38), 3338: (u'groups python:bool(', 77, 30), 3397: (u"tabbing python:(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autoto", 78, 31), 3525: (u'_widgets python:view.widgets', 79, 33), 3600: (u't_widgets python:bool(defaul', 80, 36), 3674: (u'ault_label python:has_groups and default_fieldset_label and len(vi', 81, 34), 3786: (u'ew_name_raw python:view.__name__ or request.getURL().sp', 82, 33), 3883: (u"rm_view_name python:'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split", 83, 28), 4161: (u"s python:'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_nam", 87, 34), 4047: (u'view/action|request/getURL', 85, 37), 4381: (u'hod view/method|string:', 89, 33), 4112: (u' view/enctyp', 86, 37), 4336: (u'id view', 88, 30), 4575: (u'python: has_groups and enable_form_tabbing', 95, 29), 4798: (u'view/widgets/errors', 100, 39), 4738: (u'has_default_widgets', 99, 31), 4913: (u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'", 102, 39), 4850: (u'default_fieldset_label', 101, 30), 5248: (u'groups', 112, 34), 5339: (u'nocall:context/@@plone/normalizeString', 113, 45), 5422: (u' group/labe', 114, 43), 5477: (u"e python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_lab", 115, 41), 5621: (u'me python:normalizeString(fieldset_na', 116, 40), 5699: (u'ors group/widgets/errors|not', 117, 36), 5766: (u"irst python:repeat['group'].", 118, 33), 5841: (u'ctive python:is_first and not has_default_w', 119, 40), 5928: (u'string:${fieldset_name}-tab', 120, 36), 5994: (u' string:#${fieldset_name', 121, 37), 6058: (u"s python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link", 122, 37), 6194: (u'fieldset_label', 123, 30), 6518: (u'request/fieldset | python:None', 135, 48), 6584: (u'python:has_groups and enable_form_tabbing and current_fieldset is not None', 136, 34), 6701: (u'current_fieldset', 137, 41), 10446: (u'view/enableCSRFProtection|nothing', 217, 36), 10525: (u'context/@@authenticator/authenticator', 218, 44)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948308531536 = {u'role': u'status', u'class': u'portalMessage info', }
_static_136948308542160 = {u'role': u'tabpanel', u'class': u'tab-pane active', u'id': u'default', }
_static_136948308541008 = {u'role': u'presentation', u'class': u'nav-item', }
_static_136948309667600 = {u'data-toggle': u'tab', u'href': u'#default', u'role': u'tab', u'id': u'default-tab', u'class': u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'", }
_static_136948309643728 = {u'class': u'field error alert alert-warning', }
_static_136948308684048 = {u'class': u'field error fieldErrorBox', }
_static_136948309629008 = {u'class': u'field error alert alert-warning', }
_static_136948308582352 = {u'class': u'tab-content', }
_static_136948308539664 = {u'role': u'tablist', u'class': u'nav nav-tabs', }
_static_136948309629840 = {u'class': u'discreet text-secondary', }
_static_136948418207568 = __compile_zt_expr
_static_136948309660624 = {u'class': u'form', }
_static_136948308666128 = {u'role': u'presentation', u'class': u'nav-item', }
_static_136948418228496 = __C2ZContextWrapper
_static_136948308575120 = {u'role': u'alert', u'class': u'portalMessage alert error', }
_static_136948308696976 = {u'class': u'formControls', }
_static_136948309650064 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_136948501914768 = {}
_static_136948308668240 = {u'data-toggle': u'tab', u'href': u'string:#${fieldset_name}', u'role': u'tab', u'id': u'string:${fieldset_name}-tab', u'class': u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", }
_static_136948308634320 = u'widget_rendering'
_static_136948308581968 = {u'type': u'hidden', u'name': u'fieldset', u'value': u'current_fieldset', }
_static_136948309628048 = {u'name': u'edit_form', u'id': u'view/id', u'data-pat-autotoc': u'levels: legend; section: fieldset; className: autotabs', u'method': u'post', u'action': u'.', u'class': u'rowlike enableUnloadProtection', u'enctype': u'view/enctype', }
_static_136948308552528 = {u'type': u'submit', }
_static_136948308584720 = {u'data-fieldset': u'fieldset_name', u'role': u'tabpanel', u'class': u'tab-pane', u'id': u'string:${fieldset_name}', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_rendering(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_field = econtext[u'__slot_field'].pop()
        except:
            __slot_field = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308542928
            __attrs_136948308542928 = _static_136948501914768
            __append(u'\n                    ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308585168
            __attrs_136948308585168 = _static_136948501914768
            __backup_widget_136948308543760 = get('widget', __marker)

            # <Value u'view/widgets/values' (152:48)> -> __iterator
            __token = 7319
            try:
                __zt_tmp = __attrs_136948308585168
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_136948418207568('path', u'view/widgets/values', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            (__iterator, ____index_136948308583504, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\n                      ')
                if (__slot_field is None):

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308584656
                    __attrs_136948308584656 = _static_136948501914768
                    __append(u'\n                        ')
                    __token = None
                    render_field(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    __append(u'\n                      ')
                else:
                    __slot_field(__stream, econtext.copy(), rcontext)
                __append(u'\n                    ')
                ____index_136948308583504 -= 1
                if (____index_136948308583504 > 0):
                    __append('')
            if (__backup_widget_136948308543760 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_136948308543760
            __append(u'\n                  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_form(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_title = econtext[u'__slot_title'].pop()
        except:
            __slot_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc35993d0> name=None at 7c8dc4685a50> -> __attrs_136948309660880
            __attrs_136948309660880 = _static_136948309660624

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="form">\n\n      ')
            if (__slot_title is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309793680
                __attrs_136948309793680 = _static_136948501914768
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308577232
                __attrs_136948308577232 = _static_136948501914768

                # <Value u'view/label | nothing' (11:27)> -> __condition
                __token = 367
                try:
                    __zt_tmp = __attrs_136948308577232
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'view/label | nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <h3 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h3>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308574672
                    __default_136948308574672 = _DEFAULT_MARKER

                    # <Value u'view/label' (11:62)> -> __cache_136948309794320
                    __token = 402
                    try:
                        __zt_tmp = __attrs_136948308577232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948309794320 = _static_136948418207568('path', u'view/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'view/label' (11:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc35b9550> -> __condition
                    __expression = __cache_136948309794320

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_136948309794320
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</h3>')
                __append(u'\n      ')
            else:
                __slot_title(__stream, econtext.copy(), rcontext)
            __append(u'\n\n      ')
            __token = None
            render_titlelessform(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_fields(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308578704
            __attrs_136948308578704 = _static_136948501914768
            __backup_show_default_label_136948309665104 = get('show_default_label', __marker)

            # <Value u'show_default_label|nothing' (142:45)> -> __value
            __token = 6868
            try:
                __zt_tmp = __attrs_136948308578704
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'show_default_label|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['show_default_label'] = __value
            __backup_has_groups_136948308678672 = get('has_groups', __marker)

            # <Value u'has_groups|nothing' (143:36)> -> __value
            __token = 6932
            try:
                __zt_tmp = __attrs_136948308578704
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'has_groups|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['has_groups'] = __value
            __append(u'\n\n              <!-- tab content -->\n              ')

            # <Static value=<_ast.Dict object at 0x7c8dc3491fd0> name=None at 7c8dc3491e90> -> __attrs_136948308542544
            __attrs_136948308542544 = _static_136948308582352

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="tab-content">\n\n                <!-- Primary fieldsets -->\n                ')

            # <Static value=<_ast.Dict object at 0x7c8dc34882d0> name=None at 7c8dc34881d0> -> __attrs_136948308544848
            __attrs_136948308544848 = _static_136948308542160

            # <Value u'has_default_widgets' (150:36)> -> __condition
            __token = 7184
            try:
                __zt_tmp = __attrs_136948308544848
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'has_default_widgets', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="tab-pane active" id="default" role="tabpanel">\n                  ')
                __token = None
                render_widget_rendering(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n                </div>')
            __append(u'\n\n                <!-- Secondary fieldsets -->\n                ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308586192
            __attrs_136948308586192 = _static_136948501914768

            # <Value u'has_groups' (163:64)> -> __condition
            __token = 7841
            try:
                __zt_tmp = __attrs_136948308586192
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'has_groups', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __backup_group_136948308581328 = get('group', __marker)

                # <Value u'groups' (163:45)> -> __iterator
                __token = 7822
                try:
                    __zt_tmp = __attrs_136948308586192
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'groups', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948308582736, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7c8dc3492910> name=None at 7c8dc3492510> -> __attrs_136948308691216
                    __attrs_136948308691216 = _static_136948308584720
                    __backup_normalizeString_136948308542864 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (166:51)> -> __value
                    __token = 7984
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_136948308584272 = get('fieldset_label', __marker)

                    # <Value u'group/label' (167:49)> -> __value
                    __token = 8073
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_136948308584528 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (168:47)> -> __value
                    __token = 8134
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_136948308582928 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (169:46)> -> __value
                    __token = 8284
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_is_first_136948308584208 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (170:40)> -> __value
                    __token = 8366
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"repeat['group'].start", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_136948308583312 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (171:47)> -> __value
                    __token = 8447
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value
                    __backup_pane_class_136948308585040 = get('pane_class', __marker)

                    # <Value u"python:'tab-pane active' if should_be_active else 'tab-pane'" (172:40)> -> __value
                    __token = 8537
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"'tab-pane active' if should_be_active else 'tab-pane'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['pane_class'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308692880
                    __default_136948308692880 = _DEFAULT_MARKER

                    # <Substitution u'pane_class' (174:44)> -> __attr_class
                    __token = 8717
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136948418207568('path', u'pane_class', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'tab-pane', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u' role="tabpanel"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308692240
                    __default_136948308692240 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}' (173:42)> -> __attr_id
                    __token = 8648
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_136948418207568('string', u'${fieldset_name}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308691600
                    __default_136948308691600 = _DEFAULT_MARKER

                    # <Substitution u'fieldset_name' (175:51)> -> __attr_data_fieldset
                    __token = 8781
                    try:
                        __zt_tmp = __attrs_136948308691216
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_data_fieldset = _static_136948418207568('path', u'fieldset_name', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_data_fieldset = __quote(__attr_data_fieldset, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_data_fieldset is not None):
                        __append((u' data-fieldset="%s"' % __attr_data_fieldset))
                    __append(u'>\n\n                    ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308684304
                    __attrs_136948308684304 = _static_136948501914768
                    __backup_group_description_136948308586256 = get('group_description', __marker)

                    # <Value u'group/description|nothing' (178:52)> -> __value
                    __token = 8893
                    try:
                        __zt_tmp = __attrs_136948308684304
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/description|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['group_description'] = __value

                    # <Value u'group_description' (179:37)> -> __condition
                    __token = 8957
                    try:
                        __zt_tmp = __attrs_136948308684304
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('path', u'group_description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:

                        # <p ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<p>')

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308682960
                        __default_136948308682960 = _DEFAULT_MARKER

                        # <Value u'group_description' (180:45)> -> __cache_136948308690256
                        __token = 9021
                        try:
                            __zt_tmp = __attrs_136948308684304
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136948308690256 = _static_136948418207568('path', u'group_description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                        # <BinOp left=<Value u'group_description' (180:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34ac7d0> -> __condition
                        __expression = __cache_136948308690256

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n                      Description\n                    ')
                        else:
                            __content = __cache_136948308690256
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</p>')
                    if (__backup_group_description_136948308586256 is __marker):
                        del econtext['group_description']
                    else:
                        econtext['group_description'] = __backup_group_description_136948308586256
                    __append(u'\n\n                    <!-- Error -->\n                    ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308681296
                    __attrs_136948308681296 = _static_136948501914768
                    __backup_errors_136948308585488 = get('errors', __marker)

                    # <Value u'group/widgets/errors' (185:50)> -> __value
                    __token = 9186
                    try:
                        __zt_tmp = __attrs_136948308681296
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/widgets/errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['errors'] = __value

                    # <Value u'python:False' (186:46)> -> __condition
                    __token = 9254
                    try:
                        __zt_tmp = __attrs_136948308681296
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('python', u'False', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:
                        __backup_error_136948308690320 = get('error', __marker)

                        # <Value u'errors' (187:49)> -> __iterator
                        __token = 9317
                        try:
                            __zt_tmp = __attrs_136948308681296
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_136948418207568('path', u'errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                        (__iterator, ____index_136948308681488, ) = getitem('repeat')(u'error', __iterator)
                        econtext['error'] = None
                        for __item in __iterator:
                            econtext['error'] = __item
                            __append(u'\n                      ')

                            # <Static value=<_ast.Dict object at 0x7c8dc34aad10> name=None at 7c8dc34aacd0> -> __attrs_136948308696720
                            __attrs_136948308696720 = _static_136948308684048

                            # <Value u'not:nocall:error/widget' (189:42)> -> __condition
                            __token = 9429
                            try:
                                __zt_tmp = __attrs_136948308696720
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_136948418207568('not', u'nocall:error/widget', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div class="field error fieldErrorBox">')

                                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308683792
                                __default_136948308683792 = _DEFAULT_MARKER

                                # <Value u'error/render' (190:50)> -> __cache_136948308681552
                                __token = 9504
                                try:
                                    __zt_tmp = __attrs_136948308696720
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_136948308681552 = _static_136948418207568('path', u'error/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                                # <BinOp left=<Value u'error/render' (190:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34aa910> -> __condition
                                __expression = __cache_136948308681552

                                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    pass
                                else:
                                    __content = __cache_136948308681552
                                    __content = __convert(__content)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            __append(u'\n                    ')
                            ____index_136948308681488 -= 1
                            if (____index_136948308681488 > 0):
                                __append('')
                        if (__backup_error_136948308690320 is __marker):
                            del econtext['error']
                        else:
                            econtext['error'] = __backup_error_136948308690320
                    if (__backup_errors_136948308585488 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_136948308585488
                    __append(u'\n\n                    <!-- Widget -->\n                    ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308693392
                    __attrs_136948308693392 = _static_136948501914768
                    __backup_view_136948308683600 = get('view', __marker)

                    # <Value u'nocall:group' (194:44)> -> __value
                    __token = 9634
                    try:
                        __zt_tmp = __attrs_136948308693392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('nocall', u'group', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['view'] = __value
                    __append(u'\n                      ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308693776
                    __attrs_136948308693776 = _static_136948501914768
                    __backup_macroname_136948304377968 = get('macroname', __marker)

                    # <Static value=<_ast.Str object at 0x7c8dc349ead0> name=None at 7c8dc34ad6d0> -> __value
                    __value = _static_136948308634320
                    econtext['macroname'] = __value

                    # <Value u'context/@@ploneform-macros/widget_rendering' (195:46)> -> __macro
                    __token = 9696
                    try:
                        __zt_tmp = __attrs_136948308693776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __macro = _static_136948418207568('path', u'context/@@ploneform-macros/widget_rendering', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __token = 9696
                    __m = __macro.include
                    __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                    econtext.update(rcontext)
                    if (__backup_macroname_136948304377968 is __marker):
                        del econtext['macroname']
                    else:
                        econtext['macroname'] = __backup_macroname_136948304377968
                    __append(u'\n                    ')
                    if (__backup_view_136948308683600 is __marker):
                        del econtext['view']
                    else:
                        econtext['view'] = __backup_view_136948308683600
                    __append(u'\n\n                  </div>')
                    if (__backup_pane_class_136948308585040 is __marker):
                        del econtext['pane_class']
                    else:
                        econtext['pane_class'] = __backup_pane_class_136948308585040
                    if (__backup_should_be_active_136948308583312 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_136948308583312
                    if (__backup_is_first_136948308584208 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_136948308584208
                    if (__backup_fieldset_name_136948308582928 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_136948308582928
                    if (__backup_fieldset_name_136948308584528 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_136948308584528
                    if (__backup_fieldset_label_136948308584272 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_136948308584272
                    if (__backup_normalizeString_136948308542864 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_136948308542864
                    __append(u'\n                ')
                    ____index_136948308582736 -= 1
                    if (____index_136948308582736 > 0):
                        __append('')
                if (__backup_group_136948308581328 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_136948308581328
            __append(u'\n              </div>\n\n            ')
            if (__backup_has_groups_136948308678672 is __marker):
                del econtext['has_groups']
            else:
                econtext['has_groups'] = __backup_has_groups_136948308678672
            if (__backup_show_default_label_136948309665104 is __marker):
                del econtext['show_default_label']
            else:
                econtext['show_default_label'] = __backup_show_default_label_136948309665104
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_actions(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308680848
            __attrs_136948308680848 = _static_136948501914768
            __append(u'\n              ')

            # <Static value=<_ast.Dict object at 0x7c8dc34adf90> name=None at 7c8dc34ad390> -> __attrs_136948308695376
            __attrs_136948308695376 = _static_136948308696976

            # <Value u'view/actions/values|nothing' (209:55)> -> __condition
            __token = 10125
            try:
                __zt_tmp = __attrs_136948308695376
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/actions/values|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="formControls">\n                ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308696400
                __attrs_136948308696400 = _static_136948501914768
                __backup_action_136948308537808 = get('action', __marker)

                # <Value u'view/actions/values' (210:42)> -> __iterator
                __token = 10197
                try:
                    __zt_tmp = __attrs_136948308696400
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'view/actions/values', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948308696592, ) = getitem('repeat')(u'action', __iterator)
                econtext['action'] = None
                for __item in __iterator:
                    econtext['action'] = __item
                    __append(u'\n                  ')

                    # <Static value=<_ast.Dict object at 0x7c8dc348ab50> name=None at 7c8dc348ac50> -> __attrs_136948308550480
                    __attrs_136948308550480 = _static_136948308552528

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308550608
                    __default_136948308550608 = _DEFAULT_MARKER

                    # <Value u'action/render' (211:62)> -> __cache_136948308550160
                    __token = 10281
                    try:
                        __zt_tmp = __attrs_136948308550480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308550160 = _static_136948418207568('path', u'action/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'action/render' (211:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc348a810> -> __condition
                    __expression = __cache_136948308550160

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="submit" />')
                    else:
                        __content = __cache_136948308550160
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\n                ')
                    ____index_136948308696592 -= 1
                    if (____index_136948308696592 > 0):
                        __append('')
                if (__backup_action_136948308537808 is __marker):
                    del econtext['action']
                else:
                    econtext['action'] = __backup_action_136948308537808
                __append(u'\n              </div>')
            __append(u'\n            ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_field(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308586064
            __attrs_136948308586064 = _static_136948501914768
            __append(u'\n                          ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308690512
            __attrs_136948308690512 = _static_136948501914768

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308692304
            __default_136948308692304 = _DEFAULT_MARKER

            # <Value u'widget/@@ploneform-render-widget' (155:61)> -> __cache_136948308585680
            __token = 7522
            try:
                __zt_tmp = __attrs_136948308690512
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_136948308585680 = _static_136948418207568('path', u'widget/@@ploneform-render-widget', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

            # <BinOp left=<Value u'widget/@@ploneform-render-widget' (155:61)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34ac450> -> __condition
            __expression = __cache_136948308585680

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_136948308585680
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\n                        ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_titlelessform(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_formtop = econtext[u'__slot_formtop'].pop()
        except:
            __slot_formtop = None

        try:
            __slot_fields = econtext[u'__slot_fields'].pop()
        except:
            __slot_fields = None

        try:
            __slot_belowfields = econtext[u'__slot_belowfields'].pop()
        except:
            __slot_belowfields = None

        try:
            __slot_description = econtext[u'__slot_description'].pop()
        except:
            __slot_description = None

        try:
            __slot_actions = econtext[u'__slot_actions'].pop()
        except:
            __slot_actions = None

        try:
            __slot_formbottom = econtext[u'__slot_formbottom'].pop()
        except:
            __slot_formbottom = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308576144
            __attrs_136948308576144 = _static_136948501914768
            __append(u'\n\n        <!-- Status Message -->\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308577936
            __attrs_136948308577936 = _static_136948501914768
            __backup_status_136948309791504 = get('status', __marker)

            # <Value u'view/status' (17:35)> -> __value
            __token = 562
            try:
                __zt_tmp = __attrs_136948308577936
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/status', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['status'] = __value
            __backup_has_error_136948309792976 = get('has_error', __marker)

            # <Value u"python:view.widgets.errors or status == getattr(view, 'formErrorsMessage', None)" (18:37)> -> __value
            __token = 612
            try:
                __zt_tmp = __attrs_136948308577936
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"view.widgets.errors or status == getattr(view, 'formErrorsMessage', None)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['has_error'] = __value

            # <Value u'status' (18:131)> -> __condition
            __token = 706
            try:
                __zt_tmp = __attrs_136948308577936
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'status', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dc3490390> name=None at 7c8dc3490190> -> __attrs_136948308530768
                __attrs_136948308530768 = _static_136948308575120

                # <Value u'has_error' (19:63)> -> __condition
                __token = 778
                try:
                    __zt_tmp = __attrs_136948308530768
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'has_error', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <dl ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dl class="portalMessage alert error" role="alert">\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308531664
                    __attrs_136948308531664 = _static_136948501914768
                    __previous_i18n_domain_136948308531216 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <dt ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dt>')
                    __stream_136948308532624 = []
                    __append_136948308532624 = __stream_136948308532624.append
                    __append_136948308532624(u'\n              Error\n            ')
                    __msgid_136948308532624 = __re_whitespace(''.join(__stream_136948308532624)).strip()
                    if __msgid_136948308532624:
                        __append(translate(__msgid_136948308532624, mapping=None, default=__msgid_136948308532624, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</dt>')
                    __i18n_domain = __previous_i18n_domain_136948308531216
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308532752
                    __attrs_136948308532752 = _static_136948501914768

                    # <dd ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dd>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308532816
                    __default_136948308532816 = _DEFAULT_MARKER

                    # <Value u'status' (23:29)> -> __cache_136948308530384
                    __token = 925
                    try:
                        __zt_tmp = __attrs_136948308532752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308530384 = _static_136948418207568('path', u'status', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'status' (23:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3485f50> -> __condition
                    __expression = __cache_136948308530384

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_136948308530384
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</dd>\n          </dl>')
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dc3485950> name=None at 7c8dc34853d0> -> __attrs_136948308519120
                __attrs_136948308519120 = _static_136948308531536

                # <Value u'not:has_error' (25:56)> -> __condition
                __token = 1008
                try:
                    __zt_tmp = __attrs_136948308519120
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('not', u'has_error', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <dl ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dl class="portalMessage info" role="status">\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308626320
                    __attrs_136948308626320 = _static_136948501914768
                    __previous_i18n_domain_136948308625168 = __i18n_domain
                    __i18n_domain = u'plone'

                    # <dt ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dt>')
                    __stream_136948308518736 = []
                    __append_136948308518736 = __stream_136948308518736.append
                    __append_136948308518736(u'\n              Info\n            ')
                    __msgid_136948308518736 = __re_whitespace(''.join(__stream_136948308518736)).strip()
                    if __msgid_136948308518736:
                        __append(translate(__msgid_136948308518736, mapping=None, default=__msgid_136948308518736, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</dt>')
                    __i18n_domain = __previous_i18n_domain_136948308625168
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308623568
                    __attrs_136948308623568 = _static_136948501914768

                    # <dd ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<dd>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308624208
                    __default_136948308624208 = _DEFAULT_MARKER

                    # <Value u'status' (29:29)> -> __cache_136948308625552
                    __token = 1159
                    try:
                        __zt_tmp = __attrs_136948308623568
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308625552 = _static_136948418207568('path', u'status', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'status' (29:29)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc349cc10> -> __condition
                    __expression = __cache_136948308625552

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_136948308625552
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</dd>\n          </dl>')
                __append(u'\n        ')
            if (__backup_has_error_136948309792976 is __marker):
                del econtext['has_error']
            else:
                econtext['has_error'] = __backup_has_error_136948309792976
            if (__backup_status_136948309791504 is __marker):
                del econtext['status']
            else:
                econtext['status'] = __backup_status_136948309791504
            __append(u'\n\n        <!-- Primary Field Errors -->\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308625104
            __attrs_136948308625104 = _static_136948501914768
            __backup_errors_136948309792016 = get('errors', __marker)

            # <Value u'view/widgets/errors' (34:35)> -> __value
            __token = 1282
            try:
                __zt_tmp = __attrs_136948308625104
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/widgets/errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['errors'] = __value

            # <Value u'errors' (34:67)> -> __condition
            __token = 1314
            try:
                __zt_tmp = __attrs_136948308625104
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308626960
                __attrs_136948308626960 = _static_136948501914768
                __backup_error_136948308532560 = get('error', __marker)

                # <Value u'errors' (35:35)> -> __iterator
                __token = 1358
                try:
                    __zt_tmp = __attrs_136948308626960
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948308624400, ) = getitem('repeat')(u'error', __iterator)
                econtext['error'] = None
                for __item in __iterator:
                    econtext['error'] = __item
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7c8dc35951d0> name=None at 7c8dc3595210> -> __attrs_136948309646096
                    __attrs_136948309646096 = _static_136948309643728

                    # <Value u'not:nocall:error/widget' (37:32)> -> __condition
                    __token = 1456
                    try:
                        __zt_tmp = __attrs_136948309646096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('not', u'nocall:error/widget', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="field error alert alert-warning">')

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309643664
                        __default_136948309643664 = _DEFAULT_MARKER

                        # <Value u'error/render' (38:40)> -> __cache_136948309644496
                        __token = 1521
                        try:
                            __zt_tmp = __attrs_136948309646096
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_136948309644496 = _static_136948418207568('path', u'error/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                        # <BinOp left=<Value u'error/render' (38:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3595d90> -> __condition
                        __expression = __cache_136948309644496

                        # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\n              Error\n            ')
                        else:
                            __content = __cache_136948309644496
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    __append(u'\n          ')
                    ____index_136948308624400 -= 1
                    if (____index_136948308624400 > 0):
                        __append('')
                if (__backup_error_136948308532560 is __marker):
                    del econtext['error']
                else:
                    econtext['error'] = __backup_error_136948308532560
                __append(u'\n        ')
            if (__backup_errors_136948309792016 is __marker):
                del econtext['errors']
            else:
                econtext['errors'] = __backup_errors_136948309792016
            __append(u'\n\n        <!-- Secondary Field Errors -->\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308627152
            __attrs_136948308627152 = _static_136948501914768
            __backup_groups_136948309794128 = get('groups', __marker)

            # <Value u'view/groups|nothing' (45:35)> -> __value
            __token = 1696
            try:
                __zt_tmp = __attrs_136948308627152
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/groups|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['groups'] = __value

            # <Value u'python:bool(groups)' (46:31)> -> __condition
            __token = 1748
            try:
                __zt_tmp = __attrs_136948308627152
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('python', u'bool(groups)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:
                __backup_group_136948308575376 = get('group', __marker)

                # <Value u'groups' (47:34)> -> __iterator
                __token = 1803
                try:
                    __zt_tmp = __attrs_136948308627152
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'groups', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948309647312, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309643536
                    __attrs_136948309643536 = _static_136948501914768
                    __backup_errors_136948308575184 = get('errors', __marker)

                    # <Value u'group/widgets/errors' (48:40)> -> __value
                    __token = 1852
                    try:
                        __zt_tmp = __attrs_136948309643536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/widgets/errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['errors'] = __value

                    # <Value u'errors' (49:35)> -> __condition
                    __token = 1909
                    try:
                        __zt_tmp = __attrs_136948309643536
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_136948418207568('path', u'errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    if __condition:
                        __backup_error_136948308531920 = get('error', __marker)

                        # <Value u'errors' (50:38)> -> __iterator
                        __token = 1955
                        try:
                            __zt_tmp = __attrs_136948309643536
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_136948418207568('path', u'errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                        (__iterator, ____index_136948309643984, ) = getitem('repeat')(u'error', __iterator)
                        econtext['error'] = None
                        for __item in __iterator:
                            econtext['error'] = __item
                            __append(u'\n            ')

                            # <Static value=<_ast.Dict object at 0x7c8dc3591850> name=None at 7c8dc3591950> -> __attrs_136948309630480
                            __attrs_136948309630480 = _static_136948309629008

                            # <Value u'not:nocall:error/widget' (52:31)> -> __condition
                            __token = 2052
                            try:
                                __zt_tmp = __attrs_136948309630480
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __condition = _static_136948418207568('not', u'nocall:error/widget', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                            if __condition:

                                # <div ... (0:0)
                                # --------------------------------------------------------
                                __append(u'<div class="field error alert alert-warning">')

                                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309628880
                                __default_136948309628880 = _DEFAULT_MARKER

                                # <Value u'error/render' (53:39)> -> __cache_136948309627792
                                __token = 2116
                                try:
                                    __zt_tmp = __attrs_136948309630480
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __cache_136948309627792 = _static_136948418207568('path', u'error/render', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                                # <BinOp left=<Value u'error/render' (53:39)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3591290> -> __condition
                                __expression = __cache_136948309627792

                                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                                __value = _DEFAULT_MARKER
                                __condition = (__expression is __value)
                                if __condition:
                                    pass
                                else:
                                    __content = __cache_136948309627792
                                    __content = __convert(__content)
                                    if (__content is not None):
                                        __append(__content)
                                __append(u'</div>')
                            __append(u'\n          ')
                            ____index_136948309643984 -= 1
                            if (____index_136948309643984 > 0):
                                __append('')
                        if (__backup_error_136948308531920 is __marker):
                            del econtext['error']
                        else:
                            econtext['error'] = __backup_error_136948308531920
                    if (__backup_errors_136948308575184 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_136948308575184
                    __append(u'\n        ')
                    ____index_136948309647312 -= 1
                    if (____index_136948309647312 > 0):
                        __append('')
                if (__backup_group_136948308575376 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_136948308575376
            if (__backup_groups_136948309794128 is __marker):
                del econtext['groups']
            else:
                econtext['groups'] = __backup_groups_136948309794128
            __append(u'\n\n        <!-- Description -->\n        ')
            if (__slot_description is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309646224
                __attrs_136948309646224 = _static_136948501914768
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7c8dc3591b90> name=None at 7c8dc3591b50> -> __attrs_136948309628752
                __attrs_136948309628752 = _static_136948309629840
                __backup_description_136948308575824 = get('description', __marker)

                # <Value u'view/description | nothing' (60:37)> -> __value
                __token = 2348
                try:
                    __zt_tmp = __attrs_136948309628752
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'view/description | nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['description'] = __value

                # <Value u'description' (61:28)> -> __condition
                __token = 2404
                try:
                    __zt_tmp = __attrs_136948309628752
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'description', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p class="discreet text-secondary">')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309630096
                    __default_136948309630096 = _DEFAULT_MARKER

                    # <Value u'description|default' (62:36)> -> __cache_136948309629584
                    __token = 2453
                    try:
                        __zt_tmp = __attrs_136948309628752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948309629584 = _static_136948418207568('path', u'description|default', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description|default' (62:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc35913d0> -> __condition
                    __expression = __cache_136948309629584

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n            Description\n          ')
                    else:
                        __content = __cache_136948309629584
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</p>')
                if (__backup_description_136948308575824 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_136948308575824
                __append(u'\n        ')
            else:
                __slot_description(__stream, econtext.copy(), rcontext)
            __append(u'\n\n        <!-- Form -->\n        ')

            # <Static value=<_ast.Dict object at 0x7c8dc3591490> name=None at 7c8dc3591c50> -> __attrs_136948308634000
            __attrs_136948308634000 = _static_136948309628048
            __backup_groups_136948309649936 = get('groups', __marker)

            # <Value u'view/groups | nothing' (70:33)> -> __value
            __token = 2787
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/groups | nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['groups'] = __value
            __backup_form_name_136948308530960 = get('form_name', __marker)

            # <Value u'view/form_name | nothing' (71:35)> -> __value
            __token = 2845
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/form_name | nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['form_name'] = __value
            __backup_form_class_136948309646032 = get('form_class', __marker)

            # <Value u'view/css_class | string:' (72:35)> -> __value
            __token = 2907
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/css_class | string:', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['form_class'] = __value
            __backup_default_fieldset_label_136948308531472 = get('default_fieldset_label', __marker)

            # <Value u'view/default_fieldset_label | form_name' (73:46)> -> __value
            __token = 2981
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/default_fieldset_label | form_name', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['default_fieldset_label'] = __value
            __backup_enable_form_tabbing_136948308531152 = get('enable_form_tabbing', __marker)

            # <Value u'view/enable_form_tabbing | python:True' (74:42)> -> __value
            __token = 3067
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/enable_form_tabbing | python:True', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['enable_form_tabbing'] = __value
            __backup_enable_unload_protection_136948309627728 = get('enable_unload_protection', __marker)

            # <Value u'view/enable_unload_protection|python:True' (75:46)> -> __value
            __token = 3157
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('path', u'view/enable_unload_protection|python:True', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['enable_unload_protection'] = __value
            __backup_unload_protection_136948309647248 = get('unload_protection', __marker)

            # <Value u"python:enable_unload_protection and 'pat-formunloadalert'" (76:38)> -> __value
            __token = 3243
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"enable_unload_protection and 'pat-formunloadalert'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['unload_protection'] = __value
            __backup_has_groups_136948309646480 = get('has_groups', __marker)

            # <Value u'python:bool(groups)' (77:30)> -> __value
            __token = 3338
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u'bool(groups)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['has_groups'] = __value
            __backup_form_tabbing_136948309630288 = get('form_tabbing', __marker)

            # <Value u"python:(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autotoc' or ''" (78:31)> -> __value
            __token = 3397
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"(has_groups and enable_form_tabbing) and 'enableFormTabbing pat-autotoc' or ''", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['form_tabbing'] = __value
            __backup_default_widgets_136948310304464 = get('default_widgets', __marker)

            # <Value u'python:view.widgets.values()' (79:33)> -> __value
            __token = 3525
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u'view.widgets.values()', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['default_widgets'] = __value
            __backup_has_default_widgets_136948310304080 = get('has_default_widgets', __marker)

            # <Value u'python:bool(default_widgets)' (80:36)> -> __value
            __token = 3600
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u'bool(default_widgets)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['has_default_widgets'] = __value
            __backup_show_default_label_136948308633616 = get('show_default_label', __marker)

            # <Value u'python:has_groups and default_fieldset_label and len(view.widgets)' (81:34)> -> __value
            __token = 3674
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u'has_groups and default_fieldset_label and len(view.widgets)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['show_default_label'] = __value
            __backup_form_view_name_raw_136948308634192 = get('form_view_name_raw', __marker)

            # <Value u"python:view.__name__ or request.getURL().split('/')[-1]" (82:33)> -> __value
            __token = 3786
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"view.__name__ or request.getURL().split('/')[-1]", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['form_view_name_raw'] = __value
            __backup_form_view_name_136948308635088 = get('form_view_name', __marker)

            # <Value u"python:'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split('++') if x])" (83:28)> -> __value
            __token = 3883
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_136948418207568('python', u"'-'.join(['view', 'name'] + [x for x in form_view_name_raw.split('++') if x])", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            econtext['form_view_name'] = __value

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form data-pat-autotoc="levels: legend; section: fieldset; className: autotabs"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308596560
            __default_136948308596560 = _DEFAULT_MARKER

            # <Substitution u"python:'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_name)" (87:34)> -> __attr_class
            __token = 4161
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_136948418207568('python', u"'rowlike {0} {1} {2} kssattr-formname-{3} {4}'.format(unload_protection, form_tabbing, form_class, form_view_name_raw, form_view_name)", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'rowlike enableUnloadProtection', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308597648
            __default_136948308597648 = _DEFAULT_MARKER

            # <Substitution u'view/action|request/getURL' (85:37)> -> __attr_action
            __token = 4047
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_136948418207568('path', u'view/action|request/getURL', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'.', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308597584
            __default_136948308597584 = _DEFAULT_MARKER

            # <Substitution u'view/method|string:post' (89:33)> -> __attr_method
            __token = 4381
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_method = _static_136948418207568('path', u'view/method|string:post', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_method = __quote(__attr_method, '"', '&quot;', u'post', _DEFAULT_MARKER)
            if (__attr_method is not None):
                __append((u' method="%s"' % __attr_method))
            __append(u' name="edit_form"')

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308597136
            __default_136948308597136 = _DEFAULT_MARKER

            # <Substitution u'view/enctype' (86:37)> -> __attr_enctype
            __token = 4112
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_enctype = _static_136948418207568('path', u'view/enctype', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_enctype = __quote(__attr_enctype, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_enctype is not None):
                __append((u' enctype="%s"' % __attr_enctype))

            # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308594832
            __default_136948308594832 = _DEFAULT_MARKER

            # <Substitution u'view/id' (88:30)> -> __attr_id
            __token = 4336
            try:
                __zt_tmp = __attrs_136948308634000
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136948418207568('path', u'view/id', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n\n          ')
            if (__slot_formtop is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308635408
                __attrs_136948308635408 = _static_136948501914768
            else:
                __slot_formtop(__stream, econtext.copy(), rcontext)
            __append(u'\n\n          <!-- navigation tabs -->\n          ')

            # <Static value=<_ast.Dict object at 0x7c8dc3487910> name=None at 7c8dc34879d0> -> __attrs_136948308539984
            __attrs_136948308539984 = _static_136948308539664

            # <Value u'python: has_groups and enable_form_tabbing' (95:29)> -> __condition
            __token = 4575
            try:
                __zt_tmp = __attrs_136948308539984
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('python', u' has_groups and enable_form_tabbing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <ul ... (0:0)
                # --------------------------------------------------------
                __append(u'<ul class="nav nav-tabs" role="tablist">\n\n            <!-- primary tab -->\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc3487e50> name=None at 7c8dc3487dd0> -> __attrs_136948308539792
                __attrs_136948308539792 = _static_136948308541008
                __backup_has_errors_136948308634576 = get('has_errors', __marker)

                # <Value u'view/widgets/errors' (100:39)> -> __value
                __token = 4798
                try:
                    __zt_tmp = __attrs_136948308539792
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'view/widgets/errors', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['has_errors'] = __value

                # <Value u'has_default_widgets' (99:31)> -> __condition
                __token = 4738
                try:
                    __zt_tmp = __attrs_136948308539792
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('path', u'has_default_widgets', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\n              ')

                    # <Static value=<_ast.Dict object at 0x7c8dc359af10> name=None at 7c8dc359a3d0> -> __attrs_136948308665232
                    __attrs_136948308665232 = _static_136948309667600

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a id="default-tab" href="#default" data-toggle="tab" role="tab"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309664400
                    __default_136948309664400 = _DEFAULT_MARKER

                    # <Substitution u"python:has_errors and 'nav-link active text-danger' or 'nav-link active'" (102:39)> -> __attr_class
                    __token = 4913
                    try:
                        __zt_tmp = __attrs_136948308665232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136948418207568('python', u"has_errors and 'nav-link active text-danger' or 'nav-link active'", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309666192
                    __default_136948309666192 = _DEFAULT_MARKER

                    # <Value u'default_fieldset_label' (101:30)> -> __cache_136948309666448
                    __token = 4850
                    try:
                        __zt_tmp = __attrs_136948308665232
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948309666448 = _static_136948418207568('path', u'default_fieldset_label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'default_fieldset_label' (101:30)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc359ae90> -> __condition
                    __expression = __cache_136948309666448

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                Label\n              ')
                    else:
                        __content = __cache_136948309666448
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>\n            </li>')
                if (__backup_has_errors_136948308634576 is __marker):
                    del econtext['has_errors']
                else:
                    econtext['has_errors'] = __backup_has_errors_136948308634576
                __append(u'\n\n            <!-- secondary tabs -->\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc34a6710> name=None at 7c8dc34a6ad0> -> __attrs_136948308664592
                __attrs_136948308664592 = _static_136948308666128
                __backup_group_136948308540176 = get('group', __marker)

                # <Value u'groups' (112:34)> -> __iterator
                __token = 5248
                try:
                    __zt_tmp = __attrs_136948308664592
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_136948418207568('path', u'groups', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                (__iterator, ____index_136948308666256, ) = getitem('repeat')(u'group', __iterator)
                econtext['group'] = None
                for __item in __iterator:
                    econtext['group'] = __item

                    # <li ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<li class="nav-item" role="presentation">\n              ')

                    # <Static value=<_ast.Dict object at 0x7c8dc34a6f50> name=None at 7c8dc34a6dd0> -> __attrs_136948308677392
                    __attrs_136948308677392 = _static_136948308668240
                    __backup_normalizeString_136948308539024 = get('normalizeString', __marker)

                    # <Value u'nocall:context/@@plone/normalizeString' (113:45)> -> __value
                    __token = 5339
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('nocall', u'context/@@plone/normalizeString', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['normalizeString'] = __value
                    __backup_fieldset_label_136948308634448 = get('fieldset_label', __marker)

                    # <Value u'group/label' (114:43)> -> __value
                    __token = 5422
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_label'] = __value
                    __backup_fieldset_name_136948309664144 = get('fieldset_name', __marker)

                    # <Value u"python:getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label" (115:41)> -> __value
                    __token = 5477
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"getattr(group, '__name__', False) or getattr(group.label, 'default', False) or fieldset_label", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_fieldset_name_136948308666704 = get('fieldset_name', __marker)

                    # <Value u'python:normalizeString(fieldset_name)' (116:40)> -> __value
                    __token = 5621
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u'normalizeString(fieldset_name)', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['fieldset_name'] = __value
                    __backup_has_errors_136948308677520 = get('has_errors', __marker)

                    # <Value u'group/widgets/errors|nothing' (117:36)> -> __value
                    __token = 5699
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('path', u'group/widgets/errors|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['has_errors'] = __value
                    __backup_is_first_136948308677584 = get('is_first', __marker)

                    # <Value u"python:repeat['group'].start" (118:33)> -> __value
                    __token = 5766
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u"repeat['group'].start", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['is_first'] = __value
                    __backup_should_be_active_136948308677264 = get('should_be_active', __marker)

                    # <Value u'python:is_first and not has_default_widgets' (119:40)> -> __value
                    __token = 5841
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_136948418207568('python', u'is_first and not has_default_widgets', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    econtext['should_be_active'] = __value

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<a data-toggle="tab" role="tab"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308677904
                    __default_136948308677904 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldset_name}-tab' (120:36)> -> __attr_id
                    __token = 5928
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_136948418207568('string', u'${fieldset_name}-tab', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308678096
                    __default_136948308678096 = _DEFAULT_MARKER

                    # <Substitution u'string:#${fieldset_name}' (121:37)> -> __attr_href
                    __token = 5994
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_136948418207568('string', u'#${fieldset_name}', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append((u' href="%s"' % __attr_href))

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308677968
                    __default_136948308677968 = _DEFAULT_MARKER

                    # <Substitution u"python:has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')" (122:37)> -> __attr_class
                    __token = 6058
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_136948418207568('python', u"has_errors and 'nav-link text-danger' or (should_be_active and 'nav-link active' or 'nav-link')", econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308668176
                    __default_136948308668176 = _DEFAULT_MARKER

                    # <Value u'fieldset_label' (123:30)> -> __cache_136948308667472
                    __token = 6194
                    try:
                        __zt_tmp = __attrs_136948308677392
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_136948308667472 = _static_136948418207568('path', u'fieldset_label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                    # <BinOp left=<Value u'fieldset_label' (123:30)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc34a6e50> -> __condition
                    __expression = __cache_136948308667472

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\n                Label\n              ')
                    else:
                        __content = __cache_136948308667472
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</a>')
                    if (__backup_should_be_active_136948308677264 is __marker):
                        del econtext['should_be_active']
                    else:
                        econtext['should_be_active'] = __backup_should_be_active_136948308677264
                    if (__backup_is_first_136948308677584 is __marker):
                        del econtext['is_first']
                    else:
                        econtext['is_first'] = __backup_is_first_136948308677584
                    if (__backup_has_errors_136948308677520 is __marker):
                        del econtext['has_errors']
                    else:
                        econtext['has_errors'] = __backup_has_errors_136948308677520
                    if (__backup_fieldset_name_136948308666704 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_136948308666704
                    if (__backup_fieldset_name_136948309664144 is __marker):
                        del econtext['fieldset_name']
                    else:
                        econtext['fieldset_name'] = __backup_fieldset_name_136948309664144
                    if (__backup_fieldset_label_136948308634448 is __marker):
                        del econtext['fieldset_label']
                    else:
                        econtext['fieldset_label'] = __backup_fieldset_label_136948308634448
                    if (__backup_normalizeString_136948308539024 is __marker):
                        del econtext['normalizeString']
                    else:
                        econtext['normalizeString'] = __backup_normalizeString_136948308539024
                    __append(u'\n            </li>')
                    ____index_136948308666256 -= 1
                    if (____index_136948308666256 > 0):
                        __append('\n            ')
                if (__backup_group_136948308540176 is __marker):
                    del econtext['group']
                else:
                    econtext['group'] = __backup_group_136948308540176
                __append(u'\n          </ul>')
            __append(u'\n\n          ')
            if (__slot_fields is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308679312
                __attrs_136948308679312 = _static_136948501914768
                __append(u'\n\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dc3491e50> name=None at 7c8dc3491810> -> __attrs_136948308579728
                __attrs_136948308579728 = _static_136948308581968
                __backup_current_fieldset_136948310304016 = get('current_fieldset', __marker)

                # <Value u'request/fieldset | python:None' (135:48)> -> __value
                __token = 6518
                try:
                    __zt_tmp = __attrs_136948308579728
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_136948418207568('path', u'request/fieldset | python:None', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                econtext['current_fieldset'] = __value

                # <Value u'python:has_groups and enable_form_tabbing and current_fieldset is not None' (136:34)> -> __condition
                __token = 6584
                try:
                    __zt_tmp = __attrs_136948308579728
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_136948418207568('python', u'has_groups and enable_form_tabbing and current_fieldset is not None', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="fieldset"')

                    # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308579088
                    __default_136948308579088 = _DEFAULT_MARKER

                    # <Substitution u'current_fieldset' (137:41)> -> __attr_value
                    __token = 6701
                    try:
                        __zt_tmp = __attrs_136948308579728
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_136948418207568('path', u'current_fieldset', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />')
                if (__backup_current_fieldset_136948310304016 is __marker):
                    del econtext['current_fieldset']
                else:
                    econtext['current_fieldset'] = __backup_current_fieldset_136948310304016
                __append(u'\n\n            <!-- Default fieldset -->\n            ')
                __token = None
                render_fields(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n          ')
            else:
                __slot_fields(__stream, econtext.copy(), rcontext)
            __append(u'\n\n          ')
            if (__slot_belowfields is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308578832
                __attrs_136948308578832 = _static_136948501914768
            else:
                __slot_belowfields(__stream, econtext.copy(), rcontext)
            __append(u'\n\n          ')
            if (__slot_actions is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308544208
                __attrs_136948308544208 = _static_136948501914768
                __append(u'\n            ')
                __token = None
                render_actions(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\n          ')
            else:
                __slot_actions(__stream, econtext.copy(), rcontext)
            __append(u'\n\n          ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308696080
            __attrs_136948308696080 = _static_136948501914768

            # <Value u'view/enableCSRFProtection|nothing' (217:36)> -> __condition
            __token = 10446
            try:
                __zt_tmp = __attrs_136948308696080
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_136948418207568('path', u'view/enableCSRFProtection|nothing', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            if __condition:

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948308695824
                __default_136948308695824 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (218:44)> -> __cache_136948308681040
                __token = 10525
                try:
                    __zt_tmp = __attrs_136948308696080
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948308681040 = _static_136948418207568('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (218:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3492890> -> __condition
                __expression = __cache_136948308681040

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_136948308681040
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            __append(u'\n          ')
            if (__slot_formbottom is None):

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948308693328
                __attrs_136948308693328 = _static_136948501914768
            else:
                __slot_formbottom(__stream, econtext.copy(), rcontext)
            __append(u'\n\n        </form>')
            if (__backup_form_view_name_136948308635088 is __marker):
                del econtext['form_view_name']
            else:
                econtext['form_view_name'] = __backup_form_view_name_136948308635088
            if (__backup_form_view_name_raw_136948308634192 is __marker):
                del econtext['form_view_name_raw']
            else:
                econtext['form_view_name_raw'] = __backup_form_view_name_raw_136948308634192
            if (__backup_show_default_label_136948308633616 is __marker):
                del econtext['show_default_label']
            else:
                econtext['show_default_label'] = __backup_show_default_label_136948308633616
            if (__backup_has_default_widgets_136948310304080 is __marker):
                del econtext['has_default_widgets']
            else:
                econtext['has_default_widgets'] = __backup_has_default_widgets_136948310304080
            if (__backup_default_widgets_136948310304464 is __marker):
                del econtext['default_widgets']
            else:
                econtext['default_widgets'] = __backup_default_widgets_136948310304464
            if (__backup_form_tabbing_136948309630288 is __marker):
                del econtext['form_tabbing']
            else:
                econtext['form_tabbing'] = __backup_form_tabbing_136948309630288
            if (__backup_has_groups_136948309646480 is __marker):
                del econtext['has_groups']
            else:
                econtext['has_groups'] = __backup_has_groups_136948309646480
            if (__backup_unload_protection_136948309647248 is __marker):
                del econtext['unload_protection']
            else:
                econtext['unload_protection'] = __backup_unload_protection_136948309647248
            if (__backup_enable_unload_protection_136948309627728 is __marker):
                del econtext['enable_unload_protection']
            else:
                econtext['enable_unload_protection'] = __backup_enable_unload_protection_136948309627728
            if (__backup_enable_form_tabbing_136948308531152 is __marker):
                del econtext['enable_form_tabbing']
            else:
                econtext['enable_form_tabbing'] = __backup_enable_form_tabbing_136948308531152
            if (__backup_default_fieldset_label_136948308531472 is __marker):
                del econtext['default_fieldset_label']
            else:
                econtext['default_fieldset_label'] = __backup_default_fieldset_label_136948308531472
            if (__backup_form_class_136948309646032 is __marker):
                del econtext['form_class']
            else:
                econtext['form_class'] = __backup_form_class_136948309646032
            if (__backup_form_name_136948308530960 is __marker):
                del econtext['form_name']
            else:
                econtext['form_name'] = __backup_form_name_136948308530960
            if (__backup_groups_136948309649936 is __marker):
                del econtext['groups']
            else:
                econtext['groups'] = __backup_groups_136948309649936
            __append(u'\n      ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dc3596a90> name=None at 7c8dc3596610> -> __attrs_136948309651024
            __attrs_136948309651024 = _static_136948309650064
            __previous_i18n_domain_136948309650832 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml">\n  ')

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309648336
            __attrs_136948309648336 = _static_136948501914768

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')
            __token = None
            render_form(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_136948309650832
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_rendering': render_widget_rendering, u'render_form': render_form, u'render_fields': render_fields, u'render_actions': render_actions, u'render_field': render_field, u'render_titlelessform': render_titlelessform, 'render': render, }