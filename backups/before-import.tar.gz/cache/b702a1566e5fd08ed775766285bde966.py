# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/main_template/templates/main_template.pt'

__tokens = {5487: (u'provider:plone.abovecontenttitle', 121, 87), 5649: (u'context/@@title', 123, 55), 5799: (u'provider:plone.belowcontenttitle', 125, 87), 5974: (u'context/@@description', 128, 54), 6170: (u'provider:plone.abovecontentbody', 132, 84), 6334: (u'nothing', 134, 78), 6546: (u'provider:plone.belowcontentbody', 138, 84), 74: (u'string:&lt;!DOCTYPE ht', 2, 38), 364: (u"python:context.restrictedTraverse('@@senaite_theme')", 8, 34), 451: (u" python:context.restrictedTraverse('@@senaite_view'", 9, 32), 529: (u't nocall:senaite_view/te', 10, 23), 588: (u"te python:context.restrictedTraverse('@@plone_portal_stat", 11, 30), 681: (u"ate python:context.restrictedTraverse('@@plone_context_sta", 12, 30), 772: (u"view python:context.restrictedTraverse('@@pl", 13, 26), 851: (u"ayout python:context.restrictedTraverse('@@plone_la", 14, 27), 938: (u"apview python:context.restrictedTraverse('@@bootstra", 15, 27), 1017: (u'   lang python:portal_state.la', 16, 17), 1074: (u'    view nocall:view | nocall: p', 17, 16), 1134: (u'    dummy python: plone_layout.mark_', 18, 16), 1203: (u'portal_url python:portal_state.p', 19, 20), 1273: (u"kPermission python:context.restrictedTraverse('portal_membership').che", 20, 24), 1381: (u"e_properties python:context.restrictedTraverse('portal_properties').si", 21, 23), 1491: (u"_include_head python:request.get('ajax_include", 22, 24), 1569: (u'     ajax_lo', 23, 15), 1658: (u'lang', 25, 29), 1709: (u'provider:plone.httpheaders', 27, 40), 1781: (u'provider:plone.htmlhead', 29, 38), 1840: (u'nothing', 31, 28), 2618: (u'bootstrapview/get_viewport_values', 49, 39), 2690: (u'viewportvalues', 50, 36), 2858: (u'portal_state/is_rtl', 54, 28), 2904: (u" python:plone_layout.have_portlets('plone.leftcolumn', view", 55, 24), 2990: (u"r python:plone_layout.have_portlets('plone.rightcolumn', vie", 56, 23), 3085: (u'ss python:plone_layout.bodyClass(template, vi', 57, 30), 3158: (u'cls python:bootstrapview.get_columns_classes(v', 58, 22), 3367: (u'  python:bootstrapview.get_data_settings', 61, 24), 3243: (u'string:${body_class} senaite-body', 59, 32), 3308: (u" python:isRTL and 'rtl' or 'ltr", 60, 29), 3628: (u'provider:plone.toolbar', 69, 36), 3765: (u'provider:senaite.sidebar', 75, 36), 4034: (u'provider:plone.portaltop', 83, 44), 4264: (u'provider:plone.mainnavigation', 90, 69), 4563: (u'provider:plone.globalstatusmessage', 99, 52), 4889: (u'provider:plone.abovecontent', 108, 69), 5094: (u'cls/content', 114, 70), 6844: (u'provider:plone.belowcontent', 148, 71), 7092: (u'sl', 155, 34), 7138: (u'cls/one', 156, 41), 7259: (u'provider:plone.leftcolumn', 158, 46), 7511: (u'sr', 165, 34), 7557: (u'cls/two', 166, 41), 7678: (u'provider:plone.rightcolumn', 168, 46), 7894: (u'provider:plone.portalfooter', 175, 40)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_133838716918608 = {u'lang': u'lang', u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_133838700788624 = {u'class': u'mb-2', }
_static_133838700813136 = {u'id': u'content-core', }
_static_133838716848336 = {u'id': u'portal-footer-wrapper', }
_static_133838700631440 = {u'class': u'row', }
_static_133838716840400 = {u'class': u'col-sm-12', }
_static_133838705543376 = {u'class': u'col-sm-12', }
_static_133838705542224 = {u'class': u'row', }
_static_133838705545168 = {u'id': u'portal-mainnavigation', }
_static_133838705555216 = {u'content': u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', u'name': u'viewport', }
_static_133838716834128 = {u'id': u'viewlet-below-content-body', }
_static_133838700801872 = {u'id': u'viewlet-below-content-title', }
_static_133838700631120 = {u'id': u'portal-top', }
_static_133838700825424 = {u'id': u'viewlet-above-content-title', }
_static_133838700822800 = {u'id': u'viewlet-below-content', }
_static_133838700760464 = {u'class': u'row', }
_static_133838700779856 = {u'class': u'container-fluid', }
_static_133838700809680 = {u'id': u'portal-column-content', u'class': u'cls/content', }
_static_133838700631760 = {u'class': u'col-sm-12', }
_static_133838700830864 = {u'id': u'content', }
_static_133838686088592 = set([])
_static_133838716847312 = {u'id': u'portal-column-two', u'class': u'cls/two', }
_static_133838705555344 = {u'id': u'visual-portal-wrapper', u'dir': u"python:isRTL and 'rtl' or 'ltr'", u'class': u'string:${body_class} senaite-body', }
_static_133838700634640 = {u'content': u'SENAITE - https://www.senaite.com', u'name': u'generator', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838878659728 = {}
_static_133838700811728 = {u'id': u'viewlet-above-content-body', }
_static_133838700810192 = {u'class': u'row', }
_static_133838700777616 = {u'class': u'wrapper', }
_static_133838700760848 = {u'class': u'col-sm-12', }
_static_133838794967184 = __compile_zt_expr
_static_133838716836624 = {u'id': u'portal-column-one', u'class': u'cls/one', }
_static_133838700788112 = {u'id': u'loader', u'i18n-translate': u'', }
_static_133838700758544 = {u'id': u'global_statusmessage', }
_static_133838700806224 = {u'id': u'viewlet-above-content', }
_static_133838732992080 = {u'class': u'row', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_content(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_content_description = econtext[u'__slot_content_description'].pop()
        except:
            __slot_content_description = None

        try:
            __slot_main = econtext[u'__slot_main'].pop()
        except:
            __slot_main = None

        try:
            __slot_body = econtext[u'__slot_body'].pop()
        except:
            __slot_body = None

        try:
            __slot_content_core = econtext[u'__slot_content_core'].pop()
        except:
            __slot_content_core = None

        try:
            __slot_content_title = econtext[u'__slot_content_title'].pop()
        except:
            __slot_content_title = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700834768
            __attrs_133838700834768 = _static_133838878659728

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\r\n                  ')
            if (__slot_body is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700831888
                __attrs_133838700831888 = _static_133838878659728
                __append(u'\r\n                    ')

                # <Static value=<_ast.Dict object at 0x79b9c0386090> name=None at 79b9c0386cd0> -> __attrs_133838700823696
                __attrs_133838700823696 = _static_133838700830864

                # <article ... (0:0)
                # --------------------------------------------------------
                __append(u'<article id="content">\r\n                      ')
                if (__slot_main is None):

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700823184
                    __attrs_133838700823184 = _static_133838878659728
                    __append(u'\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700825744
                    __attrs_133838700825744 = _static_133838878659728

                    # <header ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<header>\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x79b9c0384b50> name=None at 79b9c0384ed0> -> __attrs_133838700798480
                    __attrs_133838700798480 = _static_133838700825424

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-title">')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700825104
                    __default_133838700825104 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontenttitle' (121:87)> -> __cache_133838700822608
                    __token = 5487
                    try:
                        __zt_tmp = __attrs_133838700798480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700822608 = _static_133838794967184('provider', u'plone.abovecontenttitle', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontenttitle' (121:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0384410> -> __condition
                    __expression = __cache_133838700822608

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133838700822608
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n                          ')
                    if (__slot_content_title is None):

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700800848
                        __attrs_133838700800848 = _static_133838878659728
                        __append(u'\r\n                            ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700801488
                        __attrs_133838700801488 = _static_133838878659728

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700801680
                        __default_133838700801680 = _DEFAULT_MARKER

                        # <Value u'context/@@title' (123:55)> -> __cache_133838700799504
                        __token = 5649
                        try:
                            __zt_tmp = __attrs_133838700801488
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838700799504 = _static_133838794967184('path', u'context/@@title', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@title' (123:55)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c037ed10> -> __condition
                        __expression = __cache_133838700799504

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <h1 ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<h1 />')
                        else:
                            __content = __cache_133838700799504
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n                          ')
                    else:
                        __slot_content_title(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x79b9c037ef50> name=None at 79b9c037ef10> -> __attrs_133838700799248
                    __attrs_133838700799248 = _static_133838700801872

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-title">')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700800272
                    __default_133838700800272 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontenttitle' (125:87)> -> __cache_133838700798544
                    __token = 5799
                    try:
                        __zt_tmp = __attrs_133838700799248
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700798544 = _static_133838794967184('provider', u'plone.belowcontenttitle', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontenttitle' (125:87)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c037ec10> -> __condition
                    __expression = __cache_133838700798544

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133838700798544
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n\r\n                          ')
                    if (__slot_content_description is None):

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700800528
                        __attrs_133838700800528 = _static_133838878659728
                        __append(u'\r\n                            ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700811216
                        __attrs_133838700811216 = _static_133838878659728

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700810960
                        __default_133838700810960 = _DEFAULT_MARKER

                        # <Value u'context/@@description' (128:54)> -> __cache_133838700811472
                        __token = 5974
                        try:
                            __zt_tmp = __attrs_133838700811216
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838700811472 = _static_133838794967184('path', u'context/@@description', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'context/@@description' (128:54)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c03816d0> -> __condition
                        __expression = __cache_133838700811472

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:

                            # <p ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<p />')
                        else:
                            __content = __cache_133838700811472
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n                          ')
                    else:
                        __slot_content_description(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                        </header>\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x79b9c03815d0> name=None at 79b9c0381150> -> __attrs_133838700812496
                    __attrs_133838700812496 = _static_133838700811728

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-above-content-body">')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700800720
                    __default_133838700800720 = _DEFAULT_MARKER

                    # <Value u'provider:plone.abovecontentbody' (132:84)> -> __cache_133838700800976
                    __token = 6170
                    try:
                        __zt_tmp = __attrs_133838700812496
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700800976 = _static_133838794967184('provider', u'plone.abovecontentbody', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.abovecontentbody' (132:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c037e650> -> __condition
                    __expression = __cache_133838700800976

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133838700800976
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x79b9c0381b50> name=None at 79b9c0381c10> -> __attrs_133838700811024
                    __attrs_133838700811024 = _static_133838700813136

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="content-core">\r\n                          ')
                    if (__slot_content_core is None):

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700814224
                        __attrs_133838700814224 = _static_133838878659728

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700813520
                        __default_133838700813520 = _DEFAULT_MARKER

                        # <Value u'nothing' (134:78)> -> __cache_133838700811792
                        __token = 6334
                        try:
                            __zt_tmp = __attrs_133838700814224
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838700811792 = _static_133838794967184('path', u'nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'nothing' (134:78)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0381e50> -> __condition
                        __expression = __cache_133838700811792

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n                            Page body text\r\n                          ')
                        else:
                            __content = __cache_133838700811792
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                    else:
                        __slot_content_core(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n                        </div>\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x79b9c12c9150> name=None at 79b9c12c9110> -> __attrs_133838716834896
                    __attrs_133838716834896 = _static_133838716834128

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div id="viewlet-below-content-body">')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716833936
                    __default_133838716833936 = _DEFAULT_MARKER

                    # <Value u'provider:plone.belowcontentbody' (138:84)> -> __cache_133838700813968
                    __token = 6546
                    try:
                        __zt_tmp = __attrs_133838716834896
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_133838700813968 = _static_133838794967184('provider', u'plone.belowcontentbody', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                    # <BinOp left=<Value u'provider:plone.belowcontentbody' (138:84)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0381b10> -> __condition
                    __expression = __cache_133838700813968

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_133838700813968
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</div>\r\n\r\n                      ')
                else:
                    __slot_main(__stream, econtext.copy(), rcontext)
                __append(u'\r\n                    </article>\r\n\r\n                  ')
            else:
                __slot_body(__stream, econtext.copy(), rcontext)
            __append(u'\r\n                </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_master(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_senaite_legacy_js = econtext[u'__slot_senaite_legacy_js'].pop()
        except:
            __slot_senaite_legacy_js = None

        try:
            __slot_senaite_legacy_resources = econtext[u'__slot_senaite_legacy_resources'].pop()
        except:
            __slot_senaite_legacy_resources = None

        try:
            __slot_head_slot = econtext[u'__slot_head_slot'].pop()
        except:
            __slot_head_slot = None

        try:
            __slot_column_two_slot = econtext[u'__slot_column_two_slot'].pop()
        except:
            __slot_column_two_slot = None

        try:
            __slot_column_one_slot = econtext[u'__slot_column_one_slot'].pop()
        except:
            __slot_column_one_slot = None

        try:
            __slot_global_statusmessage = econtext[u'__slot_global_statusmessage'].pop()
        except:
            __slot_global_statusmessage = None

        try:
            __slot_senaite_legacy_css = econtext[u'__slot_senaite_legacy_css'].pop()
        except:
            __slot_senaite_legacy_css = None

        try:
            __slot_top_slot = econtext[u'__slot_top_slot'].pop()
        except:
            __slot_top_slot = None

        try:
            __slot_portlets_one_slot = econtext[u'__slot_portlets_one_slot'].pop()
        except:
            __slot_portlets_one_slot = None

        try:
            __slot_portlets_two_slot = econtext[u'__slot_portlets_two_slot'].pop()
        except:
            __slot_portlets_two_slot = None

        try:
            __slot_content = econtext[u'__slot_content'].pop()
        except:
            __slot_content = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838705425488
            __attrs_133838705425488 = _static_133838878659728
            __append(u'\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716918928
            __attrs_133838716918928 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716918096
            __default_133838716918096 = _DEFAULT_MARKER

            # <Value u'string:<!DOCTYPE html>' (2:38)> -> __cache_133838716919632
            __token = 74
            try:
                __zt_tmp = __attrs_133838716918928
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838716919632 = _static_133838794967184('string', u'<!DOCTYPE html>', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'string:<!DOCTYPE html>' (2:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c12dd610> -> __condition
            __expression = __cache_133838716919632

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838716919632
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9c12ddb50> name=None at 79b9c12ddbd0> -> __attrs_133838716918352
            __attrs_133838716918352 = _static_133838716918608
            __backup_senaite_theme_133838705426128 = get('senaite_theme', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_theme')" (8:34)> -> __value
            __token = 364
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@senaite_theme')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['senaite_theme'] = __value
            __backup_senaite_view_133838705424400 = get('senaite_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@senaite_view')" (9:32)> -> __value
            __token = 451
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@senaite_view')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['senaite_view'] = __value
            __backup_test_133838705423312 = get('test', __marker)

            # <Value u'nocall:senaite_view/test' (10:23)> -> __value
            __token = 529
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('nocall', u'senaite_view/test', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['test'] = __value
            __backup_portal_state_133838716919440 = get('portal_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_portal_state')" (11:30)> -> __value
            __token = 588
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@plone_portal_state')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_context_state_133838716916496 = get('context_state', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_context_state')" (12:30)> -> __value
            __token = 681
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@plone_context_state')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['context_state'] = __value
            __backup_plone_view_133838716916752 = get('plone_view', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone')" (13:26)> -> __value
            __token = 772
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@plone')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['plone_view'] = __value
            __backup_plone_layout_133838716916304 = get('plone_layout', __marker)

            # <Value u"python:context.restrictedTraverse('@@plone_layout')" (14:27)> -> __value
            __token = 851
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@plone_layout')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['plone_layout'] = __value
            __backup_bootstrapview_133838716916944 = get('bootstrapview', __marker)

            # <Value u"python:context.restrictedTraverse('@@bootstrapview')" (15:27)> -> __value
            __token = 938
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('@@bootstrapview')", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['bootstrapview'] = __value
            __backup_lang_133838716916432 = get('lang', __marker)

            # <Value u'python:portal_state.language()' (16:17)> -> __value
            __token = 1017
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'portal_state.language()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['lang'] = __value
            __backup_view_133838716916880 = get('view', __marker)

            # <Value u'nocall:view | nocall: plone_view' (17:16)> -> __value
            __token = 1074
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('nocall', u'view | nocall: plone_view', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['view'] = __value
            __backup_dummy_133838716917008 = get('dummy', __marker)

            # <Value u'python: plone_layout.mark_view(view)' (18:16)> -> __value
            __token = 1134
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u' plone_layout.mark_view(view)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['dummy'] = __value
            __backup_portal_url_133838716917072 = get('portal_url', __marker)

            # <Value u'python:portal_state.portal_url()' (19:20)> -> __value
            __token = 1203
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'portal_state.portal_url()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['portal_url'] = __value
            __backup_checkPermission_133838716917136 = get('checkPermission', __marker)

            # <Value u"python:context.restrictedTraverse('portal_membership').checkPermission" (20:24)> -> __value
            __token = 1273
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('portal_membership').checkPermission", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['checkPermission'] = __value
            __backup_site_properties_133838716917712 = get('site_properties', __marker)

            # <Value u"python:context.restrictedTraverse('portal_properties').site_properties" (21:23)> -> __value
            __token = 1381
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"context.restrictedTraverse('portal_properties').site_properties", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['site_properties'] = __value
            __backup_ajax_include_head_133838716916112 = get('ajax_include_head', __marker)

            # <Value u"python:request.get('ajax_include_head', False)" (22:24)> -> __value
            __token = 1491
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"request.get('ajax_include_head', False)", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['ajax_include_head'] = __value
            __backup_ajax_load_133838716915984 = get('ajax_load', __marker)

            # <Value u'python:False' (23:15)> -> __value
            __token = 1569
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'False', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['ajax_load'] = __value
            __previous_i18n_domain_133838780065360 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716917200
            __default_133838716917200 = _DEFAULT_MARKER

            # <Substitution u'lang' (25:29)> -> __attr_lang
            __token = 1658
            try:
                __zt_tmp = __attrs_133838716918352
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_133838794967184('path', u'lang', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))
            __append(u'>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838701268624
            __attrs_133838701268624 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838701267664
            __default_133838701267664 = _DEFAULT_MARKER

            # <Value u'provider:plone.httpheaders' (27:40)> -> __cache_133838701267088
            __token = 1709
            try:
                __zt_tmp = __attrs_133838701268624
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838701267088 = _static_133838794967184('provider', u'plone.httpheaders', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.httpheaders' (27:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c03f0bd0> -> __condition
            __expression = __cache_133838701267088

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838701267088
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838701268816
            __attrs_133838701268816 = _static_133838878659728

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700635216
            __attrs_133838700635216 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700634512
            __default_133838700634512 = _DEFAULT_MARKER

            # <Value u'provider:plone.htmlhead' (29:38)> -> __cache_133838701268176
            __token = 1781
            try:
                __zt_tmp = __attrs_133838700635216
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838701268176 = _static_133838794967184('provider', u'plone.htmlhead', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.htmlhead' (29:38)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0356050> -> __condition
            __expression = __cache_133838701268176

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_133838701268176
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700637264
            __attrs_133838700637264 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700636496
            __default_133838700636496 = _DEFAULT_MARKER

            # <Value u'nothing' (31:28)> -> __cache_133838700636048
            __token = 1840
            try:
                __zt_tmp = __attrs_133838700637264
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700636048 = _static_133838794967184('path', u'nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'nothing' (31:28)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0356b90> -> __condition
            __expression = __cache_133838700636048

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\r\n        Various slots where you can insert elements in the header from a template.\r\n      ')
            else:
                __content = __cache_133838700636048
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n      ')
            if (__slot_top_slot is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700636368
                __attrs_133838700636368 = _static_133838878659728
            else:
                __slot_top_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      ')
            if (__slot_head_slot is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700637456
                __attrs_133838700637456 = _static_133838878659728
            else:
                __slot_head_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n      <!-- Disable all Plone JS/CSS -->\r\n      <!-- <div tal:replace="structure provider:plone.scripts" /> -->\r\n      <!-- <metal:javascriptslot define-slot="javascript_head_slot" /> -->\r\n      <!-- <link tal:replace="structure provider:plone.htmlhead.links" /> -->\r\n      <!-- <metal:styleslot define-slot="style_slot" /> -->\r\n\r\n      <!-- NOTE: All Legacy JS/CSS are rendered at the bottom of the page! -->\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0356210> name=None at 79b9c0356810> -> __attrs_133838780070736
            __attrs_133838780070736 = _static_133838700634640

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="generator" content="SENAITE - https://www.senaite.com" />\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0807710> name=None at 79b9c0807e50> -> __attrs_133838681094224
            __attrs_133838681094224 = _static_133838705555216
            __backup_viewportvalues_133838780065232 = get('viewportvalues', __marker)

            # <Value u'bootstrapview/get_viewport_values' (49:39)> -> __value
            __token = 2618
            try:
                __zt_tmp = __attrs_133838681094224
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'bootstrapview/get_viewport_values', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['viewportvalues'] = __value

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta name="viewport"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838681093712
            __default_133838681093712 = _DEFAULT_MARKER

            # <Substitution u'viewportvalues' (50:36)> -> __attr_content
            __token = 2690
            try:
                __zt_tmp = __attrs_133838681094224
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_content = _static_133838794967184('path', u'viewportvalues', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_content = __quote(__attr_content, '"', '&quot;', u'width=device-width, initial-scale=0.6666, maximum-scale=1.0, minimum-scale=0.6666', _DEFAULT_MARKER)
            if (__attr_content is not None):
                __append((u'             content="%s"' % __attr_content))
            __append(u' />')
            if (__backup_viewportvalues_133838780065232 is __marker):
                del econtext['viewportvalues']
            else:
                econtext['viewportvalues'] = __backup_viewportvalues_133838780065232
            __append(u'\r\n    </head>\r\n\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9c0807790> name=None at 79b9c0356f90> -> __attrs_133838733001488
            __attrs_133838733001488 = _static_133838705555344
            __backup_isRTL_133838780024528 = get('isRTL', __marker)

            # <Value u'portal_state/is_rtl' (54:28)> -> __value
            __token = 2858
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'portal_state/is_rtl', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['isRTL'] = __value
            __backup_sl_133838701265872 = get('sl', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.leftcolumn', view)" (55:24)> -> __value
            __token = 2904
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"plone_layout.have_portlets('plone.leftcolumn', view)", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['sl'] = __value
            __backup_sr_133838701268112 = get('sr', __marker)

            # <Value u"python:plone_layout.have_portlets('plone.rightcolumn', view)" (56:23)> -> __value
            __token = 2990
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u"plone_layout.have_portlets('plone.rightcolumn', view)", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['sr'] = __value
            __backup_body_class_133838701267280 = get('body_class', __marker)

            # <Value u'python:plone_layout.bodyClass(template, view)' (57:30)> -> __value
            __token = 3085
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'plone_layout.bodyClass(template, view)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['body_class'] = __value
            __backup_cls_133838700636432 = get('cls', __marker)

            # <Value u'python:bootstrapview.get_columns_classes(view)' (58:22)> -> __value
            __token = 3158
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('python', u'bootstrapview.get_columns_classes(view)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['cls'] = __value

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body')

            # <Value u'python:bootstrapview.get_data_settings()' (61:24)> -> __cache_133838733001616
            __token = 3367
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838733001616 = _static_133838794967184('python', u'bootstrapview.get_data_settings()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            if (u'id' not in __chain(__cache_133838733001616)):
                __append(u'           id="visual-portal-wrapper"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838733003856
            __default_133838733003856 = _DEFAULT_MARKER

            # <Substitution u'string:${body_class} senaite-body' (59:32)> -> __attr_class
            __token = 3243
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_133838794967184('string', u'${body_class} senaite-body', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_class is not None) and (u'class' not in __chain(__cache_133838733001616))):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838733002768
            __default_133838733002768 = _DEFAULT_MARKER

            # <Substitution u"python:isRTL and 'rtl' or 'ltr'" (60:29)> -> __attr_dir
            __token = 3308
            try:
                __zt_tmp = __attrs_133838733001488
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_dir = _static_133838794967184('python', u"isRTL and 'rtl' or 'ltr'", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_dir = __quote(__attr_dir, '"', '&quot;', None, _DEFAULT_MARKER)
            if ((__attr_dir is not None) and (u'dir' not in __chain(__cache_133838733001616))):
                __append((u' dir="%s"' % __attr_dir))
            __attr_133838733003920 = __cache_133838733001616
            for (name, value, ) in __attr_133838733003920.items():
                if ((name not in _static_133838686088592) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\r\n\r\n      <!-- Ajax Loader -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c037b990> name=None at 79b9c037b8d0> -> __attrs_133838700787600
            __attrs_133838700787600 = _static_133838700788112

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="loader" i18n-translate="">Loading...</div>\r\n\r\n      <!-- Toolbar -->\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c037bb90> name=None at 79b9c037b910> -> __attrs_133838700788560
            __attrs_133838700788560 = _static_133838700788624

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="mb-2">\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700778512
            __attrs_133838700778512 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700778384
            __default_133838700778384 = _DEFAULT_MARKER

            # <Value u'provider:plone.toolbar' (69:36)> -> __cache_133838687988752
            __token = 3628
            try:
                __zt_tmp = __attrs_133838700778512
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838687988752 = _static_133838794967184('provider', u'plone.toolbar', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.toolbar' (69:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf746bd0> -> __condition
            __expression = __cache_133838687988752

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_133838687988752
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n      </div>\r\n\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0379090> name=None at 79b9c037bc90> -> __attrs_133838700780432
            __attrs_133838700780432 = _static_133838700777616

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="wrapper">\r\n\r\n        <!-- Sidebar -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700778896
            __attrs_133838700778896 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700781264
            __default_133838700781264 = _DEFAULT_MARKER

            # <Value u'provider:senaite.sidebar' (75:36)> -> __cache_133838700781392
            __token = 3765
            try:
                __zt_tmp = __attrs_133838700778896
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700781392 = _static_133838794967184('provider', u'senaite.sidebar', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:senaite.sidebar' (75:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0379fd0> -> __condition
            __expression = __cache_133838700781392

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_133838700781392
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n        <!-- Content -->\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9c0379950> name=None at 79b9c0379910> -> __attrs_133838700779600
            __attrs_133838700779600 = _static_133838700779856

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c2231e50> name=None at 79b9c2231110> -> __attrs_133838732990352
            __attrs_133838732990352 = _static_133838732992080

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9c03556d0> name=None at 79b9c0355410> -> __attrs_133838700632272
            __attrs_133838700632272 = _static_133838700631760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9c0355450> name=None at 79b9c0355b10> -> __attrs_133838700630288
            __attrs_133838700630288 = _static_133838700631120
            __previous_i18n_domain_133838700633552 = __i18n_domain
            __i18n_domain = u'plone'

            # <header ... (0:0)
            # --------------------------------------------------------
            __append(u'<header id="portal-top">\r\n                ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838705541904
            __attrs_133838705541904 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705541392
            __default_133838705541392 = _DEFAULT_MARKER

            # <Value u'provider:plone.portaltop' (83:44)> -> __cache_133838700632976
            __token = 4034
            try:
                __zt_tmp = __attrs_133838705541904
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700632976 = _static_133838794967184('provider', u'plone.portaltop', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portaltop' (83:44)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0355b50> -> __condition
            __expression = __cache_133838700632976

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_133838700632976
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n              </header>')
            __i18n_domain = __previous_i18n_domain_133838700633552
            __append(u'\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c0355590> name=None at 79b9c03559d0> -> __attrs_133838705542480
            __attrs_133838705542480 = _static_133838700631440

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9c08048d0> name=None at 79b9c0804790> -> __attrs_133838705543632
            __attrs_133838705543632 = _static_133838705543376

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9c0804fd0> name=None at 79b9c0804150> -> __attrs_133838705544016
            __attrs_133838705544016 = _static_133838705545168

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="portal-mainnavigation">')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838705544528
            __default_133838705544528 = _DEFAULT_MARKER

            # <Value u'provider:plone.mainnavigation' (90:69)> -> __cache_133838705542288
            __token = 4264
            try:
                __zt_tmp = __attrs_133838705544016
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838705542288 = _static_133838794967184('provider', u'plone.mainnavigation', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.mainnavigation' (90:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0804f10> -> __condition
            __expression = __cache_133838705542288

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'\r\n                The main navigation\r\n              ')
            else:
                __content = __cache_133838705542288
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c0804450> name=None at 79b9c0804a10> -> __attrs_133838700758352
            __attrs_133838700758352 = _static_133838705542224

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9c0374f10> name=None at 79b9c0374b50> -> __attrs_133838700760592
            __attrs_133838700760592 = _static_133838700760848

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9c0374610> name=None at 79b9c0374150> -> __attrs_133838700758800
            __attrs_133838700758800 = _static_133838700758544

            # <aside ... (0:0)
            # --------------------------------------------------------
            __append(u'<aside id="global_statusmessage">\r\n                ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716838352
            __attrs_133838716838352 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716838928
            __default_133838716838928 = _DEFAULT_MARKER

            # <Value u'provider:plone.globalstatusmessage' (99:52)> -> __cache_133838716838672
            __token = 4563
            try:
                __zt_tmp = __attrs_133838716838352
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838716838672 = _static_133838794967184('provider', u'plone.globalstatusmessage', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.globalstatusmessage' (99:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c12ca110> -> __condition
            __expression = __cache_133838716838672

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838716838672
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n                ')
            if (__slot_global_statusmessage is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716840016
                __attrs_133838716840016 = _static_133838878659728

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\r\n                </div>')
            else:
                __slot_global_statusmessage(__stream, econtext.copy(), rcontext)
            __append(u'\r\n              </aside>\r\n            </div>\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c0374d90> name=None at 79b9c0374590> -> __attrs_133838716841744
            __attrs_133838716841744 = _static_133838700760464

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9c12ca9d0> name=None at 79b9c12cac10> -> __attrs_133838716839696
            __attrs_133838716839696 = _static_133838716840400

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-12">\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9c0380050> name=None at 79b9c0380110> -> __attrs_133838700807824
            __attrs_133838700807824 = _static_133838700806224

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-above-content">')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700806672
            __default_133838700806672 = _DEFAULT_MARKER

            # <Value u'provider:plone.abovecontent' (108:69)> -> __cache_133838700806480
            __token = 4889
            try:
                __zt_tmp = __attrs_133838700807824
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700806480 = _static_133838794967184('provider', u'plone.abovecontent', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.abovecontent' (108:69)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c03802d0> -> __condition
            __expression = __cache_133838700806480

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838700806480
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n            </div>\r\n          </div>\r\n\r\n          <!-- Main content -->\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c0380fd0> name=None at 79b9c0380d10> -> __attrs_133838700809232
            __attrs_133838700809232 = _static_133838700810192

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9c0380dd0> name=None at 79b9c03803d0> -> __attrs_133838700834128
            __attrs_133838700834128 = _static_133838700809680

            # <article ... (0:0)
            # --------------------------------------------------------
            __append(u'<article id="portal-column-content"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700807632
            __default_133838700807632 = _DEFAULT_MARKER

            # <Substitution u'cls/content' (114:70)> -> __attr_class
            __token = 5094
            try:
                __zt_tmp = __attrs_133838700834128
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_133838794967184('path', u'cls/content', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))
            __append(u'>\r\n              ')
            if (__slot_content is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700832528
                __attrs_133838700832528 = _static_133838878659728
                __append(u'\r\n                ')
                __token = None
                render_content(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n\r\n              ')
            else:
                __slot_content(__stream, econtext.copy(), rcontext)
            __append(u'\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700834576
            __attrs_133838700834576 = _static_133838878659728

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer>\r\n                ')

            # <Static value=<_ast.Dict object at 0x79b9c0384110> name=None at 79b9c0384190> -> __attrs_133838716836304
            __attrs_133838716836304 = _static_133838700822800

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="viewlet-below-content">')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700825936
            __default_133838700825936 = _DEFAULT_MARKER

            # <Value u'provider:plone.belowcontent' (148:71)> -> __cache_133838700834512
            __token = 6844
            try:
                __zt_tmp = __attrs_133838716836304
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700834512 = _static_133838794967184('provider', u'plone.belowcontent', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.belowcontent' (148:71)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0384690> -> __condition
            __expression = __cache_133838700834512

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838700834512
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'</div>\r\n              </footer>\r\n            </article>\r\n\r\n            <!-- Column 1 -->\r\n            ')
            if (__slot_column_one_slot is None):

                # <Static value=<_ast.Dict object at 0x79b9c12c9b10> name=None at 79b9c0386b50> -> __attrs_133838716837776
                __attrs_133838716837776 = _static_133838716836624

                # <Value u'sl' (155:34)> -> __condition
                __token = 7092
                try:
                    __zt_tmp = __attrs_133838716837776
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133838794967184('path', u'sl', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-one"')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716837264
                    __default_133838716837264 = _DEFAULT_MARKER

                    # <Substitution u'cls/one' (156:41)> -> __attr_class
                    __token = 7138
                    try:
                        __zt_tmp = __attrs_133838716837776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('path', u'cls/one', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')
                    if (__slot_portlets_one_slot is None):

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716834448
                        __attrs_133838716834448 = _static_133838878659728
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716846352
                        __attrs_133838716846352 = _static_133838878659728

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716846544
                        __default_133838716846544 = _DEFAULT_MARKER

                        # <Value u'provider:plone.leftcolumn' (158:46)> -> __cache_133838716847696
                        __token = 7259
                        try:
                            __zt_tmp = __attrs_133838716846352
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838716847696 = _static_133838794967184('provider', u'plone.leftcolumn', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.leftcolumn' (158:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c12cc710> -> __condition
                        __expression = __cache_133838716847696

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133838716847696
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n              ')
                    else:
                        __slot_portlets_one_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n            </aside>')
            else:
                __slot_column_one_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n            <!-- Column 2 -->\r\n            ')
            if (__slot_column_two_slot is None):

                # <Static value=<_ast.Dict object at 0x79b9c12cc4d0> name=None at 79b9c12cc610> -> __attrs_133838716849744
                __attrs_133838716849744 = _static_133838716847312

                # <Value u'sr' (165:34)> -> __condition
                __token = 7511
                try:
                    __zt_tmp = __attrs_133838716849744
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133838794967184('path', u'sr', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                if __condition:

                    # <aside ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<aside id="portal-column-two"')

                    # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838716848208
                    __default_133838716848208 = _DEFAULT_MARKER

                    # <Substitution u'cls/two' (166:41)> -> __attr_class
                    __token = 7557
                    try:
                        __zt_tmp = __attrs_133838716849744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_133838794967184('path', u'cls/two', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n              ')
                    if (__slot_portlets_two_slot is None):

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716849616
                        __attrs_133838716849616 = _static_133838878659728
                        __append(u'\r\n                ')

                        # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700647440
                        __attrs_133838700647440 = _static_133838878659728

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700647568
                        __default_133838700647568 = _DEFAULT_MARKER

                        # <Value u'provider:plone.rightcolumn' (168:46)> -> __cache_133838700646544
                        __token = 7678
                        try:
                            __zt_tmp = __attrs_133838700647440
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_133838700646544 = _static_133838794967184('provider', u'plone.rightcolumn', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                        # <BinOp left=<Value u'provider:plone.rightcolumn' (168:46)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c03590d0> -> __condition
                        __expression = __cache_133838700646544

                        # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_133838700646544
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'\r\n              ')
                    else:
                        __slot_portlets_two_slot(__stream, econtext.copy(), rcontext)
                    __append(u'\r\n            </aside>')
            else:
                __slot_column_two_slot(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n          </div>\r\n\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9c12cc8d0> name=None at 79b9c12cce90> -> __attrs_133838700647312
            __attrs_133838700647312 = _static_133838716848336
            __previous_i18n_domain_133838700648592 = __i18n_domain
            __i18n_domain = u'plone'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer id="portal-footer-wrapper">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700648464
            __attrs_133838700648464 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700648784
            __default_133838700648784 = _DEFAULT_MARKER

            # <Value u'provider:plone.portalfooter' (175:40)> -> __cache_133838700650192
            __token = 7894
            try:
                __zt_tmp = __attrs_133838700648464
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838700650192 = _static_133838794967184('provider', u'plone.portalfooter', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'provider:plone.portalfooter' (175:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0359ad0> -> __condition
            __expression = __cache_133838700650192

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div />')
            else:
                __content = __cache_133838700650192
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n          </footer>')
            __i18n_domain = __previous_i18n_domain_133838700648592
            __append(u'\r\n\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <!-- NOTE:\r\n           We define all legacy resource slots at the bottom to ensure these are\r\n           loaded *after* the JS/CSS from the resources viewlet (rendered in the\r\n           IHtmlHead viewlet manager) and the HTML is completely loaded.\r\n      -->\r\n\r\n      <!-- SENAITE legacy resouces -->\r\n      ')
            if (__slot_senaite_legacy_resources is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700648080
                __attrs_133838700648080 = _static_133838878659728
            else:
                __slot_senaite_legacy_resources(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      <!-- SENAITE legacy JS -->\r\n      ')
            if (__slot_senaite_legacy_js is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700647504
                __attrs_133838700647504 = _static_133838878659728
            else:
                __slot_senaite_legacy_js(__stream, econtext.copy(), rcontext)
            __append(u'\r\n      <!-- SENAITE legacy CSS -->\r\n      ')
            if (__slot_senaite_legacy_css is None):

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700650256
                __attrs_133838700650256 = _static_133838878659728
            else:
                __slot_senaite_legacy_css(__stream, econtext.copy(), rcontext)
            __append(u'\r\n\r\n    </body>')
            if (__backup_cls_133838700636432 is __marker):
                del econtext['cls']
            else:
                econtext['cls'] = __backup_cls_133838700636432
            if (__backup_body_class_133838701267280 is __marker):
                del econtext['body_class']
            else:
                econtext['body_class'] = __backup_body_class_133838701267280
            if (__backup_sr_133838701268112 is __marker):
                del econtext['sr']
            else:
                econtext['sr'] = __backup_sr_133838701268112
            if (__backup_sl_133838701265872 is __marker):
                del econtext['sl']
            else:
                econtext['sl'] = __backup_sl_133838701265872
            if (__backup_isRTL_133838780024528 is __marker):
                del econtext['isRTL']
            else:
                econtext['isRTL'] = __backup_isRTL_133838780024528
            __append(u'\r\n  </html>')
            __i18n_domain = __previous_i18n_domain_133838780065360
            if (__backup_ajax_load_133838716915984 is __marker):
                del econtext['ajax_load']
            else:
                econtext['ajax_load'] = __backup_ajax_load_133838716915984
            if (__backup_ajax_include_head_133838716916112 is __marker):
                del econtext['ajax_include_head']
            else:
                econtext['ajax_include_head'] = __backup_ajax_include_head_133838716916112
            if (__backup_site_properties_133838716917712 is __marker):
                del econtext['site_properties']
            else:
                econtext['site_properties'] = __backup_site_properties_133838716917712
            if (__backup_checkPermission_133838716917136 is __marker):
                del econtext['checkPermission']
            else:
                econtext['checkPermission'] = __backup_checkPermission_133838716917136
            if (__backup_portal_url_133838716917072 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_133838716917072
            if (__backup_dummy_133838716917008 is __marker):
                del econtext['dummy']
            else:
                econtext['dummy'] = __backup_dummy_133838716917008
            if (__backup_view_133838716916880 is __marker):
                del econtext['view']
            else:
                econtext['view'] = __backup_view_133838716916880
            if (__backup_lang_133838716916432 is __marker):
                del econtext['lang']
            else:
                econtext['lang'] = __backup_lang_133838716916432
            if (__backup_bootstrapview_133838716916944 is __marker):
                del econtext['bootstrapview']
            else:
                econtext['bootstrapview'] = __backup_bootstrapview_133838716916944
            if (__backup_plone_layout_133838716916304 is __marker):
                del econtext['plone_layout']
            else:
                econtext['plone_layout'] = __backup_plone_layout_133838716916304
            if (__backup_plone_view_133838716916752 is __marker):
                del econtext['plone_view']
            else:
                econtext['plone_view'] = __backup_plone_view_133838716916752
            if (__backup_context_state_133838716916496 is __marker):
                del econtext['context_state']
            else:
                econtext['context_state'] = __backup_context_state_133838716916496
            if (__backup_portal_state_133838716919440 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_133838716919440
            if (__backup_test_133838705423312 is __marker):
                del econtext['test']
            else:
                econtext['test'] = __backup_test_133838705423312
            if (__backup_senaite_view_133838705424400 is __marker):
                del econtext['senaite_view']
            else:
                econtext['senaite_view'] = __backup_senaite_view_133838705424400
            if (__backup_senaite_theme_133838705426128 is __marker):
                del econtext['senaite_theme']
            else:
                econtext['senaite_theme'] = __backup_senaite_theme_133838705426128
            __append(u'\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_master(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_content': render_content, u'render_master': render_master, 'render': render, }