# -*- coding: utf-8 -*-
__filename = 'index_html'

__tokens = {56: (u'template/title', 4, 24), 170: (u'context/title_or_id', 9, 27), 247: (u'template/title', 10, 29), 290: (u'template/title', 11, 27), 386: (u'template/id', 13, 43)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757132716432 = {u'charset': u'utf-8', }
_static_135757327983760 = {}
_static_135757244280656 = __compile_zt_expr
_static_135757244301584 = __C2ZContextWrapper

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!DOCTYPE html>\n')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757132503312
            __attrs_135757132503312 = _static_135757327983760

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757138290192
            __attrs_135757138290192 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>\n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757132572944
            __attrs_135757132572944 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title>')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757132570896
            __default_135757132570896 = _DEFAULT_MARKER

            # <Value u'template/title' (4:24)> -> __cache_135757138291472
            __token = 56
            try:
                __zt_tmp = __attrs_135757132572944
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757138291472 = _static_135757244280656('path', u'template/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'template/title' (4:24)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ba9aa50> -> __condition
            __expression = __cache_135757138291472

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'The title')
            else:
                __content = __cache_135757138291472
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</title>\n    ')

            # <Static value=<_ast.Dict object at 0x7b786babd990> name=None at 7b786ba9afd0> -> __attrs_135757132716112
            __attrs_135757132716112 = _static_135757132716432

            # <meta ... (0:0)
            # --------------------------------------------------------
            __append(u'<meta charset="utf-8" />\n  </head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757132717776
            __attrs_135757132717776 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n    \n    ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757231987024
            __attrs_135757231987024 = _static_135757327983760

            # <h2 ... (0:0)
            # --------------------------------------------------------
            __append(u'<h2>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757231988176
            __attrs_135757231988176 = _static_135757327983760

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757231988048
            __default_135757231988048 = _DEFAULT_MARKER

            # <Value u'context/title_or_id' (9:27)> -> __cache_135757231987728
            __token = 170
            try:
                __zt_tmp = __attrs_135757231988176
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757231987728 = _static_135757244280656('path', u'context/title_or_id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'context/title_or_id' (9:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871969c90> -> __condition
            __expression = __cache_135757231987728

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>content title or id</span>')
            else:
                __content = __cache_135757231987728
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232018128
            __attrs_135757232018128 = _static_135757327983760

            # <Value u'template/title' (10:29)> -> __condition
            __token = 247
            try:
                __zt_tmp = __attrs_135757232018128
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'template/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232018000
                __default_135757232018000 = _DEFAULT_MARKER

                # <Value u'template/title' (11:27)> -> __cache_135757232017616
                __token = 290
                try:
                    __zt_tmp = __attrs_135757232018128
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757232017616 = _static_135757244280656('path', u'template/title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'template/title' (11:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871971190> -> __condition
                __expression = __cache_135757232017616

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>optional template title</span>')
                else:
                    __content = __cache_135757232017616
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
            __append(u'</h2>\n\n    This is Page Template ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757232019088
            __attrs_135757232019088 = _static_135757327983760

            # <em ... (0:0)
            # --------------------------------------------------------
            __append(u'<em>')

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757232018704
            __default_135757232018704 = _DEFAULT_MARKER

            # <Value u'template/id' (13:43)> -> __cache_135757231987216
            __token = 386
            try:
                __zt_tmp = __attrs_135757232019088
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_135757231987216 = _static_135757244280656('path', u'template/id', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

            # <BinOp left=<Value u'template/id' (13:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7871971450> -> __condition
            __expression = __cache_135757231987216

            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                __append(u'template id')
            else:
                __content = __cache_135757231987216
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'</em>.\n  </body>\n</html>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }