# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/footer.pt'

__tokens = {220: (u'view/render_footer_portlets', 8, 57), 188: (u'nothing', 8, 25), 399: (u'view/year', 12, 33)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from chameleon.tal import ErrorInfo as _ErrorInfo

_static_124525732501136 = {u'href': u'https://tppc.ir', u'target': u'_blank', }
_static_124525732570128 = {u'class': u'row', }
_static_124525732520144 = {u'class': u'fas fa-globe', }
_static_124525979686032 = {}
_static_124525732503248 = {u'class': u'nav nav-pills', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525732513552 = {u'href': u'https://tppc.ir', u'target': u'_blank', u'class': u'nav-link', u'title': u'tppc.ir', }
_static_124525732474704 = {u'id': u'senaite-footer', }
_static_124525732485840 = {u'class': u'float-right', }
_static_124525732486864 = {u'title': u'Copyright', }
_static_124525732484688 = {u'class': u'float-left', }
_static_124525732571408 = {u'class': u'col-md-12', }
_static_124525896001680 = __compile_zt_expr

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7141680caf50> name=None at 7141680caf10> -> __attrs_124525732569424
            __attrs_124525732569424 = _static_124525732474704
            __previous_i18n_domain_124525732569552 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer         id="senaite-footer">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x7141680e2410> name=None at 7141680e23d0> -> __attrs_124525732570704
            __attrs_124525732570704 = _static_124525732570128

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n    ')

            # <Static value=<_ast.Dict object at 0x7141680e2910> name=None at 7141680e2890> -> __attrs_124525732571984
            __attrs_124525732571984 = _static_124525732571408

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\r\n      ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732572816
            __attrs_124525732572816 = _static_124525979686032

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\r\n      <!-- footer portlets -->\r\n      ')
            ____fallback_124525979578512 = len(__stream)
            try:

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732483856
                __attrs_124525732483856 = _static_124525979686032

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732483728
                __default_124525732483728 = _DEFAULT_MARKER

                # <Value u'view/render_footer_portlets' (8:57)> -> __cache_124525732483408
                __token = 220
                try:
                    __zt_tmp = __attrs_124525732483856
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525732483408 = _static_124525896001680('path', u'view/render_footer_portlets', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/render_footer_portlets' (8:57)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680cd1d0> -> __condition
                __expression = __cache_124525732483408

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_124525732483408
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            except (Exception, ) as __exc:
                econtext['error'] = _ErrorInfo(__exc, __tokens[__token][1:3])
                if (on_error_handler is not None):
                    on_error_handler(__exc)
                del __stream[____fallback_124525979578512:]

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>')

                # <Value u'nothing' (8:25)> -> __content
                __token = 188
                try:
                    __zt_tmp = __attrs_124525732571984
                except get('NameError', NameError):
                    __zt_tmp = None

                __content = _static_124525896001680('path', u'nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
                __append(u'</div>')

            __append(u'\r\n      ')

            # <Static value=<_ast.Dict object at 0x7141680cd650> name=None at 7141680cd5d0> -> __attrs_124525732485264
            __attrs_124525732485264 = _static_124525732484688

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-left">\r\n        ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732486032
            __attrs_124525732486032 = _static_124525979686032
            __append(u'\r\n          ')

            # <Static value=<_ast.Dict object at 0x7141680cded0> name=None at 7141680cde50> -> __attrs_124525732499792
            __attrs_124525732499792 = _static_124525732486864

            # <abbr ... (0:0)
            # --------------------------------------------------------
            __append(u'<abbr title="Copyright">&copy;</abbr>\r\n          ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732500880
            __attrs_124525732500880 = _static_124525979686032

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732500560
            __default_124525732500560 = _DEFAULT_MARKER

            # <Value u'view/year' (12:33)> -> __cache_124525732500240
            __token = 399
            try:
                __zt_tmp = __attrs_124525732500880
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_124525732500240 = _static_124525896001680('path', u'view/year', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/year' (12:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680d1390> -> __condition
            __expression = __cache_124525732500240

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_124525732500240
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n          ')

            # <Static value=<_ast.Dict object at 0x7141680d1690> name=None at 7141680d15d0> -> __attrs_124525732502160
            __attrs_124525732502160 = _static_124525732501136

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a href="https://tppc.ir"               target="_blank">\u0622\u0632\u0645\u0627\u06cc\u0634\u06af\u0627\u0647 \u067e\u062a\u0631\u0648\u0634\u06cc\u0645\u06cc \u062a\u0646\u062f\u06cc\u0633 \u067e\u0627\u0631\u0633 (TPPC)</a>\r\n        \r\n      </div>\r\n      ')

            # <Static value=<_ast.Dict object at 0x7141680cdad0> name=None at 7141680cdb50> -> __attrs_124525732502608
            __attrs_124525732502608 = _static_124525732485840

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-right">\r\n        ')

            # <Static value=<_ast.Dict object at 0x7141680d1ed0> name=None at 7141680d1e90> -> __attrs_124525732512144
            __attrs_124525732512144 = _static_124525732503248

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="nav nav-pills">\r\n          ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732512976
            __attrs_124525732512976 = _static_124525979686032

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x7141680d4710> name=None at 7141680d4750> -> __attrs_124525732515216
            __attrs_124525732515216 = _static_124525732513552

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://tppc.ir" title="tppc.ir" target="_blank">')

            # <Static value=<_ast.Dict object at 0x7141680d60d0> name=None at 7141680d6090> -> __attrs_124525732520720
            __attrs_124525732520720 = _static_124525732520144

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-globe"></i></a></li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</footer>')
            __i18n_domain = __previous_i18n_domain_124525732569552
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }