# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/z3c.form-3.7.1-py2.7.egg/z3c/form/browser/password_input.pt'

__tokens = {299: (u'view/id', 7, 26), 335: (u' view/nam', 8, 27), 374: (u's view/kla', 9, 27), 454: (u'tle view/t', 11, 25), 493: (u'lang view', 12, 23), 1025: (u'       disabl', 23, 16), 1249: (u'            r', 28, 11), 1290: (u'        ', 29, 5), 1071: (u'        tabin', 24, 15), 1332: (u'             a', 30, 10), 1421: (u'         ', 32, 3), 1464: (u'              ', 33, 7), 414: (u'le view/st', 10, 26), 534: (u'click view/o', 13, 25), 581: (u'lclick view/ond', 14, 27), 632: (u'usedown view/onm', 15, 27), 682: (u'nmouseup view/', 16, 24), 732: (u'mouseover view/o', 17, 25), 784: (u'nmousemove view/', 18, 24), 835: (u' onmouseout vie', 19, 22), 885: (u'  onkeypress vi', 20, 21), 934: (u'    onkeydown ', 21, 19), 980: (u'       onkey', 22, 16), 1116: (u'          on', 25, 13), 1159: (u'           ', 26, 11), 1203: (u'           on', 27, 12), 1379: (u'             ', 31, 8), 1514: (u'               p', 34, 8), 1569: (u'             autoca', 35, 10)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136289745497936 = __compile_zt_expr
_static_136289638451280 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_136289745510672 = __C2ZContextWrapper
_static_136289653827920 = {u'accesskey': u'', u'onmousedown': u'view/onmousedown', u'disabled': u'', u'autocapitalize': u'view/autocapitalize', u'alt': u'', u'onchange': u'view/onchange', u'id': u'', u'size': u'', u'style': u'view/style', u'title': u'', u'readonly': u'', u'onselect': u'view/onselect', u'onmousemove': u'view/onmousemove', u'onmouseup': u'view/onmouseup', u'onfocus': u'view/onfocus', u'type': u'password', u'onblur': u'view/onblur', u'onclick': u'view/onclick', u'onmouseout': u'view/onmouseout', u'onkeypress': u'view/onkeypress', u'onkeydown': u'view/onkeydown', u'onmouseover': u'view/onmouseover', u'placeholder': u'view/placeholder', u'class': u'', u'lang': u'', u'name': u'', u'maxlength': u'', u'onkeyup': u'view/onkeyup', u'ondblclick': u'view/ondblclick', u'tabindex': u'', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7bf4677c8850> name=None at 7bf4677c8550> -> __attrs_136289638451152
            __attrs_136289638451152 = _static_136289638451280
            __append(u'\n')

            # <Static value=<_ast.Dict object at 0x7bf468672950> name=None at 7bf468672f10> -> __attrs_136289667556880
            __attrs_136289667556880 = _static_136289653827920

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input')

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653800272
            __default_136289653800272 = _DEFAULT_MARKER

            # <Substitution u'view/id' (7:26)> -> __attr_id
            __token = 299
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_136289745497936('path', u'view/id', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653800208
            __default_136289653800208 = _DEFAULT_MARKER

            # <Substitution u'view/name' (8:27)> -> __attr_name
            __token = 335
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_136289745497936('path', u'view/name', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653798800
            __default_136289653798800 = _DEFAULT_MARKER

            # <Substitution u'view/klass' (9:27)> -> __attr_class
            __token = 374
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_136289745497936('path', u'view/klass', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653798480
            __default_136289653798480 = _DEFAULT_MARKER

            # <Substitution u'view/title' (11:25)> -> __attr_title
            __token = 454
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_title = _static_136289745497936('path', u'view/title', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_title = __quote(__attr_title, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_title is not None):
                __append((u' title="%s"' % __attr_title))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653797840
            __default_136289653797840 = _DEFAULT_MARKER

            # <Substitution u'view/lang' (12:23)> -> __attr_lang
            __token = 493
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_lang = _static_136289745497936('path', u'view/lang', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_lang = __quote(__attr_lang, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_lang is not None):
                __append((u' lang="%s"' % __attr_lang))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653800656
            __default_136289653800656 = _DEFAULT_MARKER

            # <Boolean u'view/disabled' (23:16)> -> __attr_disabled
            __token = 1025
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_disabled = _static_136289745497936('path', u'view/disabled', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            if (__attr_disabled is _DEFAULT_MARKER):
                __attr_disabled = u''
            else:
                if __attr_disabled:
                    __attr_disabled = u'disabled'
                else:
                    __attr_disabled = None
            if (__attr_disabled is not None):
                __append((u' disabled="%s"' % __attr_disabled))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653797520
            __default_136289653797520 = _DEFAULT_MARKER

            # <Boolean u'view/readonly' (28:11)> -> __attr_readonly
            __token = 1249
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_readonly = _static_136289745497936('path', u'view/readonly', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            if (__attr_readonly is _DEFAULT_MARKER):
                __attr_readonly = u''
            else:
                if __attr_readonly:
                    __attr_readonly = u'readonly'
                else:
                    __attr_readonly = None
            if (__attr_readonly is not None):
                __append((u' readonly="%s"' % __attr_readonly))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653798672
            __default_136289653798672 = _DEFAULT_MARKER

            # <Substitution u'view/alt' (29:5)> -> __attr_alt
            __token = 1290
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_alt = _static_136289745497936('path', u'view/alt', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_alt = __quote(__attr_alt, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_alt is not None):
                __append((u' alt="%s"' % __attr_alt))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653799248
            __default_136289653799248 = _DEFAULT_MARKER

            # <Substitution u'view/tabindex' (24:15)> -> __attr_tabindex
            __token = 1071
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_tabindex = _static_136289745497936('path', u'view/tabindex', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_tabindex = __quote(__attr_tabindex, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_tabindex is not None):
                __append((u' tabindex="%s"' % __attr_tabindex))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653797328
            __default_136289653797328 = _DEFAULT_MARKER

            # <Substitution u'view/accesskey' (30:10)> -> __attr_accesskey
            __token = 1332
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_accesskey = _static_136289745497936('path', u'view/accesskey', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_accesskey = __quote(__attr_accesskey, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_accesskey is not None):
                __append((u' accesskey="%s"' % __attr_accesskey))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653796944
            __default_136289653796944 = _DEFAULT_MARKER

            # <Substitution u'view/size' (32:3)> -> __attr_size
            __token = 1421
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_size = _static_136289745497936('path', u'view/size', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_size = __quote(__attr_size, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_size is not None):
                __append((u' size="%s"' % __attr_size))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653762000
            __default_136289653762000 = _DEFAULT_MARKER

            # <Substitution u'view/maxlength' (33:7)> -> __attr_maxlength
            __token = 1464
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_maxlength = _static_136289745497936('path', u'view/maxlength', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_maxlength = __quote(__attr_maxlength, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_maxlength is not None):
                __append((u' maxlength="%s"' % __attr_maxlength))
            __append(u' type="password"')

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653760272
            __default_136289653760272 = _DEFAULT_MARKER

            # <Substitution u'view/style' (10:26)> -> __attr_style
            __token = 414
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_style = _static_136289745497936('path', u'view/style', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_style = __quote(__attr_style, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_style is not None):
                __append((u' style="%s"' % __attr_style))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653760464
            __default_136289653760464 = _DEFAULT_MARKER

            # <Substitution u'view/onclick' (13:25)> -> __attr_onclick
            __token = 534
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onclick = _static_136289745497936('path', u'view/onclick', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onclick = __quote(__attr_onclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onclick is not None):
                __append((u' onclick="%s"' % __attr_onclick))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653763600
            __default_136289653763600 = _DEFAULT_MARKER

            # <Substitution u'view/ondblclick' (14:27)> -> __attr_ondblclick
            __token = 581
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_ondblclick = _static_136289745497936('path', u'view/ondblclick', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_ondblclick = __quote(__attr_ondblclick, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_ondblclick is not None):
                __append((u' ondblclick="%s"' % __attr_ondblclick))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653761936
            __default_136289653761936 = _DEFAULT_MARKER

            # <Substitution u'view/onmousedown' (15:27)> -> __attr_onmousedown
            __token = 632
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousedown = _static_136289745497936('path', u'view/onmousedown', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onmousedown = __quote(__attr_onmousedown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousedown is not None):
                __append((u' onmousedown="%s"' % __attr_onmousedown))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653762640
            __default_136289653762640 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseup' (16:24)> -> __attr_onmouseup
            __token = 682
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseup = _static_136289745497936('path', u'view/onmouseup', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onmouseup = __quote(__attr_onmouseup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseup is not None):
                __append((u' onmouseup="%s"' % __attr_onmouseup))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653763664
            __default_136289653763664 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseover' (17:25)> -> __attr_onmouseover
            __token = 732
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseover = _static_136289745497936('path', u'view/onmouseover', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onmouseover = __quote(__attr_onmouseover, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseover is not None):
                __append((u' onmouseover="%s"' % __attr_onmouseover))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653763024
            __default_136289653763024 = _DEFAULT_MARKER

            # <Substitution u'view/onmousemove' (18:24)> -> __attr_onmousemove
            __token = 784
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmousemove = _static_136289745497936('path', u'view/onmousemove', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onmousemove = __quote(__attr_onmousemove, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmousemove is not None):
                __append((u' onmousemove="%s"' % __attr_onmousemove))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653760080
            __default_136289653760080 = _DEFAULT_MARKER

            # <Substitution u'view/onmouseout' (19:22)> -> __attr_onmouseout
            __token = 835
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onmouseout = _static_136289745497936('path', u'view/onmouseout', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onmouseout = __quote(__attr_onmouseout, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onmouseout is not None):
                __append((u' onmouseout="%s"' % __attr_onmouseout))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289653760528
            __default_136289653760528 = _DEFAULT_MARKER

            # <Substitution u'view/onkeypress' (20:21)> -> __attr_onkeypress
            __token = 885
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeypress = _static_136289745497936('path', u'view/onkeypress', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onkeypress = __quote(__attr_onkeypress, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeypress is not None):
                __append((u' onkeypress="%s"' % __attr_onkeypress))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667558288
            __default_136289667558288 = _DEFAULT_MARKER

            # <Substitution u'view/onkeydown' (21:19)> -> __attr_onkeydown
            __token = 934
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeydown = _static_136289745497936('path', u'view/onkeydown', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onkeydown = __quote(__attr_onkeydown, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeydown is not None):
                __append((u' onkeydown="%s"' % __attr_onkeydown))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667556304
            __default_136289667556304 = _DEFAULT_MARKER

            # <Substitution u'view/onkeyup' (22:16)> -> __attr_onkeyup
            __token = 980
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onkeyup = _static_136289745497936('path', u'view/onkeyup', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onkeyup = __quote(__attr_onkeyup, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onkeyup is not None):
                __append((u' onkeyup="%s"' % __attr_onkeyup))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667558800
            __default_136289667558800 = _DEFAULT_MARKER

            # <Substitution u'view/onfocus' (25:13)> -> __attr_onfocus
            __token = 1116
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onfocus = _static_136289745497936('path', u'view/onfocus', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onfocus = __quote(__attr_onfocus, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onfocus is not None):
                __append((u' onfocus="%s"' % __attr_onfocus))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667559248
            __default_136289667559248 = _DEFAULT_MARKER

            # <Substitution u'view/onblur' (26:11)> -> __attr_onblur
            __token = 1159
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onblur = _static_136289745497936('path', u'view/onblur', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onblur = __quote(__attr_onblur, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onblur is not None):
                __append((u' onblur="%s"' % __attr_onblur))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667556240
            __default_136289667556240 = _DEFAULT_MARKER

            # <Substitution u'view/onchange' (27:12)> -> __attr_onchange
            __token = 1203
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onchange = _static_136289745497936('path', u'view/onchange', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onchange = __quote(__attr_onchange, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onchange is not None):
                __append((u' onchange="%s"' % __attr_onchange))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667557136
            __default_136289667557136 = _DEFAULT_MARKER

            # <Substitution u'view/onselect' (31:8)> -> __attr_onselect
            __token = 1379
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_onselect = _static_136289745497936('path', u'view/onselect', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_onselect = __quote(__attr_onselect, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_onselect is not None):
                __append((u' onselect="%s"' % __attr_onselect))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667556816
            __default_136289667556816 = _DEFAULT_MARKER

            # <Substitution u'view/placeholder' (34:8)> -> __attr_placeholder
            __token = 1514
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_placeholder = _static_136289745497936('path', u'view/placeholder', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_placeholder = __quote(__attr_placeholder, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_placeholder is not None):
                __append((u' placeholder="%s"' % __attr_placeholder))

            # <Symbol value=<DEFAULT> at 7bf472dce110> -> __default_136289667556176
            __default_136289667556176 = _DEFAULT_MARKER

            # <Substitution u'view/autocapitalize' (35:10)> -> __attr_autocapitalize
            __token = 1569
            try:
                __zt_tmp = __attrs_136289667556880
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_autocapitalize = _static_136289745497936('path', u'view/autocapitalize', econtext=econtext)(_static_136289745510672(econtext, __zt_tmp))
            __attr_autocapitalize = __quote(__attr_autocapitalize, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_autocapitalize is not None):
                __append((u' autocapitalize="%s"' % __attr_autocapitalize))
            __append(u' />\n\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }