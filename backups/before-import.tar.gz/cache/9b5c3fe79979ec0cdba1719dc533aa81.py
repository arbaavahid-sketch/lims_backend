# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dexterity/templates/widget.pt'

__tokens = {92: (u'nocall:context', 3, 24), 138: (u' python:widget.__class__.__name_', 4, 29), 206: (u"s python:'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ", 5, 32), 317: (u"en python:widget.mode == 'hidd", 6, 21), 372: (u'ror widget/e', 7, 19), 415: (u"lass python:error and ' error' ", 8, 24), 478: (u"alues python: (None, '', [], ('', '', '', '00', '00', ''), ('', ''", 9, 24), 575: (u"_class python: (widget.value in empty_values) and ' empty", 10, 22), 670: (u'_class  widget/wrapper_css_class', 11, 28), 737: (u'me_class string:kssattr-fieldname-${wid', 12, 24), 816: (u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', 13, 27), 955: (u' widget/nam', 14, 35), 992: (u'd string:formfield-${widget/i', 15, 22), 1080: (u'python:view.is_input_mode()', 18, 28), 1239: (u'python: not hidden and widget.label', 22, 24), 1203: (u'widget/id', 21, 29), 1321: (u'widget/label', 23, 43), 1436: (u"python:widget.required and widget.mode == 'input'", 26, 27), 1633: (u'error/render|nothing', 31, 32), 1772: (u"python: getattr(widget, 'description', widget.field.description)", 36, 34), 1940: (u'python:description and not hidden', 39, 25), 1901: (u'description', 38, 33), 2183: (u'python:view.get_prepend_text()', 46, 28), 2240: (u' python:view.get_append_text(', 47, 24), 2129: (u'python:widget_css_class', 45, 31), 2300: (u'python:prefix', 48, 26), 2407: (u'python:prefix', 49, 62), 2501: (u'widget/render', 52, 36), 2587: (u'python:appendix', 54, 26), 2695: (u'python:appendix', 55, 62), 2815: (u'python:view.is_view_mode()', 62, 28), 3217: (u'python: not hidden and widget.label', 74, 30), 3175: (u'widget/id', 73, 35), 3300: (u"python: getattr(widget, 'description', widget.field.description)", 76, 42), 3407: (u'python:description', 77, 40), 3559: (u'widget/label', 80, 53), 3709: (u"python:widget.required and widget.mode == 'input'", 85, 33), 3917: (u'python:view.get_prepend_text()', 91, 34), 3985: (u' python:view.get_append_text(', 92, 35), 4095: (u'python:prefix', 94, 41), 4214: (u'widget/render', 96, 42), 4358: (u'python:appendix', 99, 41)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_124525521706704 = {u'type': u'text', }
_static_124525731966224 = {u'type': u'text', }
_static_124525734985872 = {u'class': u'field-prefix', }
_static_124525521826512 = {u'class': u'required horizontal', u'title': u'Required', }
_static_124525521696080 = {u'style': u'min-width:150px;max-width:200px;', }
_static_124525521696592 = {u'style': u'width:100%', }
_static_124525732568336 = {u'style': u'width:auto', u'class': u'input-group input-group-sm d-flex', }
_static_124525521675344 = {u'class': u'table table-borderless table-hover table-sm', }
_static_124525521683216 = {u'class': u'horizontal font-weight-bold', u'for': u'', }
_static_124525731966736 = {u'class': u'input-group-append', }
_static_124525732571152 = {u'data-fieldname': u'widget/name', u'class': u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', u'id': u'string:formfield-${widget/id}', }
_static_124525731917904 = {u'class': u'horizontal font-weight-bold', u'for': u'', }
_static_124525735012240 = {u'class': u'fieldErrorBox', }
_static_124525979686032 = {}
_static_124525731873424 = {u'class': u'required horizontal', u'title': u'Required', }
_static_124525734547728 = {u'class': u'input-group-prepend', }
_static_124525896002064 = __C2ZContextWrapper
_static_124525521705104 = {u'class': u'field-prefix', }
_static_124525896001680 = __compile_zt_expr
_static_124525731963536 = {u'class': u'input-group-text', }
_static_124525732566992 = {u'class': u'formHelp text-secondary text-muted', }
_static_124525521675152 = {u'class': u'input-group-text', }
_static_124525521685008 = {u'data-toggle': u'tooltip', u'title': u'python:description', u'data-html': u'true', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_widget_wrapper(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_widget = econtext[u'__slot_widget'].pop()
        except:
            __slot_widget = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7141680e2810> name=None at 7141680e2150> -> __attrs_124525731919312
            __attrs_124525731919312 = _static_124525732571152
            __backup_widget_124525732571664 = get('widget', __marker)

            # <Value u'nocall:context' (3:24)> -> __value
            __token = 92
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('nocall', u'context', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['widget'] = __value
            __backup_widget_clazz_124525734987664 = get('widget_clazz', __marker)

            # <Value u'python:widget.__class__.__name__' (4:29)> -> __value
            __token = 138
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u'widget.__class__.__name__', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['widget_clazz'] = __value
            __backup_widget_css_class_124525732649168 = get('widget_css_class', __marker)

            # <Value u"python:'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ''" (5:32)> -> __value
            __token = 206
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"'input-group input-group-sm d-flex' if widget_clazz != 'ListingWidget' else ''", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['widget_css_class'] = __value
            __backup_hidden_124525733988944 = get('hidden', __marker)

            # <Value u"python:widget.mode == 'hidden'" (6:21)> -> __value
            __token = 317
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"widget.mode == 'hidden'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['hidden'] = __value
            __backup_error_124526054659408 = get('error', __marker)

            # <Value u'widget/error' (7:19)> -> __value
            __token = 372
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'widget/error', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['error'] = __value
            __backup_error_class_124525521711888 = get('error_class', __marker)

            # <Value u"python:error and ' error' or ''" (8:24)> -> __value
            __token = 415
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u"error and ' error' or ''", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['error_class'] = __value
            __backup_empty_values_124525521612496 = get('empty_values', __marker)

            # <Value u"python: (None, '', [], ('', '', '', '00', '00', ''), ('', '', ''))" (9:24)> -> __value
            __token = 478
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u" (None, '', [], ('', '', '', '00', '00', ''), ('', '', ''))", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['empty_values'] = __value
            __backup_empty_class_124525521762512 = get('empty_class', __marker)

            # <Value u"python: (widget.value in empty_values) and ' empty' or ''" (10:22)> -> __value
            __token = 575
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('python', u" (widget.value in empty_values) and ' empty' or ''", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['empty_class'] = __value
            __backup_wrapper_css_class_124525732551248 = get('wrapper_css_class', __marker)

            # <Value u'widget/wrapper_css_class|nothing' (11:28)> -> __value
            __token = 670
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('path', u'widget/wrapper_css_class|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['wrapper_css_class'] = __value
            __backup_fieldname_class_124525521675664 = get('fieldname_class', __marker)

            # <Value u'string:kssattr-fieldname-${widget/name}' (12:24)> -> __value
            __token = 737
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_124525896001680('string', u'kssattr-fieldname-${widget/name}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            econtext['fieldname_class'] = __value
            __previous_i18n_domain_124525731918096 = __i18n_domain
            __i18n_domain = u'plone'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732571856
            __default_124525732571856 = _DEFAULT_MARKER

            # <Substitution u'string:field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}' (13:27)> -> __attr_class
            __token = 816
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_class = _static_124525896001680('string', u'field pat-inlinevalidation ${fieldname_class}${error_class}${empty_class} ${wrapper_css_class}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_class is not None):
                __append((u' class="%s"' % __attr_class))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732572112
            __default_124525732572112 = _DEFAULT_MARKER

            # <Substitution u'widget/name' (14:35)> -> __attr_data_fieldname
            __token = 955
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_data_fieldname = _static_124525896001680('path', u'widget/name', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_data_fieldname = __quote(__attr_data_fieldname, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_data_fieldname is not None):
                __append((u' data-fieldname="%s"' % __attr_data_fieldname))

            # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731919952
            __default_124525731919952 = _DEFAULT_MARKER

            # <Substitution u'string:formfield-${widget/id}' (15:22)> -> __attr_id
            __token = 992
            try:
                __zt_tmp = __attrs_124525731919312
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_124525896001680('string', u'formfield-${widget/id}', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\r\n\r\n  <!-- EDIT MODE -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731920528
            __attrs_124525731920528 = _static_124525979686032

            # <Value u'python:view.is_input_mode()' (18:28)> -> __condition
            __token = 1080
            try:
                __zt_tmp = __attrs_124525731920528
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u'view.is_input_mode()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x714168043050> name=None at 714168043cd0> -> __attrs_124525521827472
                __attrs_124525521827472 = _static_124525731917904

                # <Value u'python: not hidden and widget.label' (22:24)> -> __condition
                __token = 1239
                try:
                    __zt_tmp = __attrs_124525521827472
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u' not hidden and widget.label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521829072
                    __default_124525521829072 = _DEFAULT_MARKER

                    # <Substitution u'widget/id' (21:29)> -> __attr_for
                    __token = 1203
                    try:
                        __zt_tmp = __attrs_124525521827472
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_124525896001680('path', u'widget/id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'          class="horizontal font-weight-bold">\r\n      ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521829776
                    __attrs_124525521829776 = _static_124525979686032

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521829392
                    __default_124525521829392 = _DEFAULT_MARKER

                    # <Value u'widget/label' (23:43)> -> __cache_124525521826768
                    __token = 1321
                    try:
                        __zt_tmp = __attrs_124525521829776
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525521826768 = _static_124525896001680('path', u'widget/label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/label' (23:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7e7ed0> -> __condition
                    __expression = __cache_124525521826768

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>label</span>')
                    else:
                        __content = __cache_124525521826768
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n\r\n      ')

                    # <Static value=<_ast.Dict object at 0x71415b7e72d0> name=None at 71415b7e78d0> -> __attrs_124525521759952
                    __attrs_124525521759952 = _static_124525521826512

                    # <Value u"python:widget.required and widget.mode == 'input'" (26:27)> -> __condition
                    __token = 1436
                    try:
                        __zt_tmp = __attrs_124525521759952
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('python', u"widget.required and widget.mode == 'input'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required horizontal"')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734724048
                        __default_124525734724048 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x71415b7e7910> at 7141682f0310> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\r\n    </div>')
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x714168336790> name=None at 714168336f50> -> __attrs_124525825447952
                __attrs_124525825447952 = _static_124525735012240

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="fieldErrorBox">')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525886963088
                __default_124525886963088 = _DEFAULT_MARKER

                # <Value u'error/render|nothing' (31:32)> -> __cache_124525521826192
                __token = 1633
                try:
                    __zt_tmp = __attrs_124525825447952
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521826192 = _static_124525896001680('path', u'error/render|nothing', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'error/render|nothing' (31:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141682d8090> -> __condition
                __expression = __cache_124525521826192

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\r\n      Error\r\n    ')
                else:
                    __content = __cache_124525521826192
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</div>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7141680e17d0> name=None at 7141680e1410> -> __attrs_124525732566160
                __attrs_124525732566160 = _static_124525732566992
                __backup_description_124525785151440 = get('description', __marker)

                # <Value u"python: getattr(widget, 'description', widget.field.description)" (36:34)> -> __value
                __token = 1772
                try:
                    __zt_tmp = __attrs_124525732566160
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u" getattr(widget, 'description', widget.field.description)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['description'] = __value

                # <Value u'python:description and not hidden' (39:25)> -> __condition
                __token = 1940
                try:
                    __zt_tmp = __attrs_124525732566160
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u'description and not hidden', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="formHelp text-secondary text-muted">')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732565776
                    __default_124525732565776 = _DEFAULT_MARKER

                    # <Value u'description' (38:33)> -> __cache_124525732566096
                    __token = 1901
                    try:
                        __zt_tmp = __attrs_124525732566160
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525732566096 = _static_124525896001680('path', u'description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'description' (38:33)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 7141680e1bd0> -> __condition
                    __expression = __cache_124525732566096

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append(u'\r\n      field description\r\n    ')
                    else:
                        __content = __cache_124525732566096
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>')
                if (__backup_description_124525785151440 is __marker):
                    del econtext['description']
                else:
                    econtext['description'] = __backup_description_124525785151440
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x7141680e1d10> name=None at 7141680e1d50> -> __attrs_124525732566416
                __attrs_124525732566416 = _static_124525732568336
                __backup_prefix_124525521783504 = get('prefix', __marker)

                # <Value u'python:view.get_prepend_text()' (46:28)> -> __value
                __token = 2183
                try:
                    __zt_tmp = __attrs_124525732566416
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u'view.get_prepend_text()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['prefix'] = __value
                __backup_appendix_124525521609872 = get('appendix', __marker)

                # <Value u'python:view.get_append_text()' (47:24)> -> __value
                __token = 2240
                try:
                    __zt_tmp = __attrs_124525732566416
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u'view.get_append_text()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['appendix'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525732567312
                __default_124525732567312 = _DEFAULT_MARKER

                # <Substitution u'python:widget_css_class' (45:31)> -> __attr_class
                __token = 2129
                try:
                    __zt_tmp = __attrs_124525732566416
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_124525896001680('python', u'widget_css_class', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', u'input-group input-group-sm d-flex', _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'          style="width:auto">\r\n      ')

                # <Static value=<_ast.Dict object at 0x7141682c5110> name=None at 7141682c5cd0> -> __attrs_124525731963792
                __attrs_124525731963792 = _static_124525734547728

                # <Value u'python:prefix' (48:26)> -> __condition
                __token = 2300
                try:
                    __zt_tmp = __attrs_124525731963792
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u'prefix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x71416804e290> name=None at 71416804e2d0> -> __attrs_124525731965008
                    __attrs_124525731965008 = _static_124525731963536

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731964816
                    __default_124525731964816 = _DEFAULT_MARKER

                    # <Value u'python:prefix' (49:62)> -> __cache_124525731964048
                    __token = 2407
                    try:
                        __zt_tmp = __attrs_124525731965008
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525731964048 = _static_124525896001680('python', u'prefix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:prefix' (49:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71416804e650> -> __condition
                    __expression = __cache_124525731964048

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_124525731964048
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n      </div>')
                __append(u'\r\n      ')
                if (__slot_widget is None):

                    # <Static value=<_ast.Dict object at 0x71416804ed10> name=None at 71416804ee10> -> __attrs_124525731966928
                    __attrs_124525731966928 = _static_124525731966224

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731965264
                    __default_124525731965264 = _DEFAULT_MARKER

                    # <Value u'widget/render' (52:36)> -> __cache_124525731965776
                    __token = 2501
                    try:
                        __zt_tmp = __attrs_124525731966928
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525731965776 = _static_124525896001680('path', u'widget/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (52:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71416804ea90> -> __condition
                    __expression = __cache_124525731965776

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_124525731965776
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                else:
                    __slot_widget(__stream, econtext.copy(), rcontext)
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x71416804ef10> name=None at 71416804e890> -> __attrs_124525521674448
                __attrs_124525521674448 = _static_124525731966736

                # <Value u'python:appendix' (54:26)> -> __condition
                __token = 2587
                try:
                    __zt_tmp = __attrs_124525521674448
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u'appendix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-append">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x71415b7c2390> name=None at 71415b7c23d0> -> __attrs_124525521674384
                    __attrs_124525521674384 = _static_124525521675152

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="input-group-text">')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521675600
                    __default_124525521675600 = _DEFAULT_MARKER

                    # <Value u'python:appendix' (55:62)> -> __cache_124525521677072
                    __token = 2695
                    try:
                        __zt_tmp = __attrs_124525521674384
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525521677072 = _static_124525896001680('python', u'appendix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:appendix' (55:62)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c2bd0> -> __condition
                    __expression = __cache_124525521677072

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        pass
                    else:
                        __content = __cache_124525521677072
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'</span>\r\n      </div>')
                __append(u'\r\n    </div>')
                if (__backup_appendix_124525521609872 is __marker):
                    del econtext['appendix']
                else:
                    econtext['appendix'] = __backup_appendix_124525521609872
                if (__backup_prefix_124525521783504 is __marker):
                    del econtext['prefix']
                else:
                    econtext['prefix'] = __backup_prefix_124525521783504
                __append(u'\r\n  ')
            __append(u'\r\n\r\n\r\n  <!-- VIEW MODE -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525732567952
            __attrs_124525732567952 = _static_124525979686032

            # <Value u'python:view.is_view_mode()' (62:28)> -> __condition
            __token = 2815
            try:
                __zt_tmp = __attrs_124525732567952
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_124525896001680('python', u'view.is_view_mode()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x71415b7c2450> name=None at 71415b7c2850> -> __attrs_124525521755536
                __attrs_124525521755536 = _static_124525521675344

                # <table ... (0:0)
                # --------------------------------------------------------
                __append(u'<table class="table table-borderless table-hover table-sm">\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521697744
                __attrs_124525521697744 = _static_124525979686032

                # <colgroup ... (0:0)
                # --------------------------------------------------------
                __append(u'<colgroup>\r\n        ')

                # <Static value=<_ast.Dict object at 0x71415b7c7550> name=None at 71415b7c7b50> -> __attrs_124525521694992
                __attrs_124525521694992 = _static_124525521696080

                # <col ... (0:0)
                # --------------------------------------------------------
                __append(u'<col style="min-width:150px;max-width:200px;">\r\n        ')

                # <Static value=<_ast.Dict object at 0x71415b7c7750> name=None at 71415b7c77d0> -> __attrs_124525521695632
                __attrs_124525521695632 = _static_124525521696592

                # <col ... (0:0)
                # --------------------------------------------------------
                __append(u'<col style="width:100%">\r\n      </colgroup>\r\n      ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521696656
                __attrs_124525521696656 = _static_124525979686032

                # <tr ... (0:0)
                # --------------------------------------------------------
                __append(u'<tr>\r\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521684688
                __attrs_124525521684688 = _static_124525979686032

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\r\n          ')

                # <Static value=<_ast.Dict object at 0x71415b7c4310> name=None at 71415b7c4350> -> __attrs_124525521684752
                __attrs_124525521684752 = _static_124525521683216

                # <Value u'python: not hidden and widget.label' (74:30)> -> __condition
                __token = 3217
                try:
                    __zt_tmp = __attrs_124525521684752
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_124525896001680('python', u' not hidden and widget.label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521683664
                    __default_124525521683664 = _DEFAULT_MARKER

                    # <Substitution u'widget/id' (73:35)> -> __attr_for
                    __token = 3175
                    try:
                        __zt_tmp = __attrs_124525521684752
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_for = _static_124525896001680('path', u'widget/id', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_for is not None):
                        __append((u' for="%s"' % __attr_for))
                    __append(u'                class="horizontal font-weight-bold">\r\n\r\n            ')

                    # <Static value=<_ast.Dict object at 0x71415b7c4a10> name=None at 71415b7c4650> -> __attrs_124525731874064
                    __attrs_124525731874064 = _static_124525521685008
                    __backup_description_124525734987984 = get('description', __marker)

                    # <Value u"python: getattr(widget, 'description', widget.field.description)" (76:42)> -> __value
                    __token = 3300
                    try:
                        __zt_tmp = __attrs_124525731874064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_124525896001680('python', u" getattr(widget, 'description', widget.field.description)", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span                   data-toggle="tooltip"                   data-html="true"')

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731873872
                    __default_124525731873872 = _DEFAULT_MARKER

                    # <Substitution u'python:description' (77:40)> -> __attr_title
                    __token = 3407
                    try:
                        __zt_tmp = __attrs_124525731874064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_title = _static_124525896001680('python', u'description', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    __attr_title = __quote(__attr_title, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_title is not None):
                        __append((u' title="%s"' % __attr_title))
                    __append(u'>\r\n                ')

                    # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731875024
                    __attrs_124525731875024 = _static_124525979686032

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731876240
                    __default_124525731876240 = _DEFAULT_MARKER

                    # <Value u'widget/label' (80:53)> -> __cache_124525731874576
                    __token = 3559
                    try:
                        __zt_tmp = __attrs_124525731875024
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525731874576 = _static_124525896001680('path', u'widget/label', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/label' (80:53)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168038650> -> __condition
                    __expression = __cache_124525731874576

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>label</span>')
                    else:
                        __content = __cache_124525731874576
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n            </span>')
                    if (__backup_description_124525734987984 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_124525734987984
                    __append(u'\r\n\r\n\r\n            ')

                    # <Static value=<_ast.Dict object at 0x714168038290> name=None at 714168038910> -> __attrs_124525731874768
                    __attrs_124525731874768 = _static_124525731873424

                    # <Value u"python:widget.required and widget.mode == 'input'" (85:33)> -> __condition
                    __token = 3709
                    try:
                        __zt_tmp = __attrs_124525731874768
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_124525896001680('python', u"widget.required and widget.mode == 'input'", econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                    if __condition:

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span class="required horizontal"')

                        # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525731874832
                        __default_124525731874832 = _DEFAULT_MARKER

                        # <Translate msgid=u'title_required' node=<_ast.Str object at 0x714168038a10> at 7141680389d0> -> __attr_title
                        __attr_title = u'Required'
                        __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_title is not None):
                            __append((u' title="%s"' % __attr_title))
                        __append(u'>&nbsp;</span>')
                    __append(u'\r\n          </div>')
                __append(u'\r\n\r\n        </td>\r\n        ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525731876624
                __attrs_124525731876624 = _static_124525979686032

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td>\r\n          ')

                # <Static value=<_ast.Dict object at 0x714176c8d490> name=None at 714176c8ded0> -> __attrs_124525521706448
                __attrs_124525521706448 = _static_124525979686032
                __backup_prefix_124525521783952 = get('prefix', __marker)

                # <Value u'python:view.get_prepend_text()' (91:34)> -> __value
                __token = 3917
                try:
                    __zt_tmp = __attrs_124525521706448
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u'view.get_prepend_text()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['prefix'] = __value
                __backup_appendix_124525732550544 = get('appendix', __marker)

                # <Value u'python:view.get_append_text()' (92:35)> -> __value
                __token = 3985
                try:
                    __zt_tmp = __attrs_124525521706448
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_124525896001680('python', u'view.get_append_text()', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))
                econtext['appendix'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\r\n            <!-- field prefix -->\r\n            ')

                # <Static value=<_ast.Dict object at 0x71415b7c9890> name=None at 71415b7c9ad0> -> __attrs_124525521703376
                __attrs_124525521703376 = _static_124525521705104

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="field-prefix">')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525521704272
                __default_124525521704272 = _DEFAULT_MARKER

                # <Value u'python:prefix' (94:41)> -> __cache_124525521704656
                __token = 4095
                try:
                    __zt_tmp = __attrs_124525521703376
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525521704656 = _static_124525896001680('python', u'prefix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:prefix' (94:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c9250> -> __condition
                __expression = __cache_124525521704656

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_124525521704656
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n            ')
                if (__slot_widget is None):

                    # <Static value=<_ast.Dict object at 0x71415b7c9ed0> name=None at 71415b7c9c50> -> __attrs_124525732471504
                    __attrs_124525732471504 = _static_124525521706704

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734990544
                    __default_124525734990544 = _DEFAULT_MARKER

                    # <Value u'widget/render' (96:42)> -> __cache_124525521704464
                    __token = 4214
                    try:
                        __zt_tmp = __attrs_124525732471504
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_124525521704464 = _static_124525896001680('path', u'widget/render', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (96:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 71415b7c9c90> -> __condition
                    __expression = __cache_124525521704464

                    # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_124525521704464
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                else:
                    __slot_widget(__stream, econtext.copy(), rcontext)
                __append(u'\r\n            <!-- field appendix -->\r\n            ')

                # <Static value=<_ast.Dict object at 0x714168330090> name=None at 7141683304d0> -> __attrs_124525734926032
                __attrs_124525734926032 = _static_124525734985872

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span class="field-prefix">')

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __default_124525734988176
                __default_124525734988176 = _DEFAULT_MARKER

                # <Value u'python:appendix' (99:41)> -> __cache_124525734987792
                __token = 4358
                try:
                    __zt_tmp = __attrs_124525734926032
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_124525734987792 = _static_124525896001680('python', u'appendix', econtext=econtext)(_static_124525896002064(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:appendix' (99:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 714176ca2110> at 714168330b90> -> __condition
                __expression = __cache_124525734987792

                # <Symbol value=<DEFAULT> at 714176ca2110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_124525734987792
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\r\n          </div>')
                if (__backup_appendix_124525732550544 is __marker):
                    del econtext['appendix']
                else:
                    econtext['appendix'] = __backup_appendix_124525732550544
                if (__backup_prefix_124525521783952 is __marker):
                    del econtext['prefix']
                else:
                    econtext['prefix'] = __backup_prefix_124525521783952
                __append(u'\r\n\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  ')
            __append(u'\r\n\r\n</div>')
            __i18n_domain = __previous_i18n_domain_124525731918096
            if (__backup_fieldname_class_124525521675664 is __marker):
                del econtext['fieldname_class']
            else:
                econtext['fieldname_class'] = __backup_fieldname_class_124525521675664
            if (__backup_wrapper_css_class_124525732551248 is __marker):
                del econtext['wrapper_css_class']
            else:
                econtext['wrapper_css_class'] = __backup_wrapper_css_class_124525732551248
            if (__backup_empty_class_124525521762512 is __marker):
                del econtext['empty_class']
            else:
                econtext['empty_class'] = __backup_empty_class_124525521762512
            if (__backup_empty_values_124525521612496 is __marker):
                del econtext['empty_values']
            else:
                econtext['empty_values'] = __backup_empty_values_124525521612496
            if (__backup_error_class_124525521711888 is __marker):
                del econtext['error_class']
            else:
                econtext['error_class'] = __backup_error_class_124525521711888
            if (__backup_error_124526054659408 is __marker):
                del econtext['error']
            else:
                econtext['error'] = __backup_error_124526054659408
            if (__backup_hidden_124525733988944 is __marker):
                del econtext['hidden']
            else:
                econtext['hidden'] = __backup_hidden_124525733988944
            if (__backup_widget_css_class_124525732649168 is __marker):
                del econtext['widget_css_class']
            else:
                econtext['widget_css_class'] = __backup_widget_css_class_124525732649168
            if (__backup_widget_clazz_124525734987664 is __marker):
                del econtext['widget_clazz']
            else:
                econtext['widget_clazz'] = __backup_widget_clazz_124525734987664
            if (__backup_widget_124525732571664 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_124525732571664
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __token = None
            render_widget_wrapper(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_widget_wrapper': render_widget_wrapper, 'render': render, }