# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/eggs/cp27mu/plone.app.registry-1.7.9-py2.7.egg/plone/app/registry/browser/templates/controlpanel_layout.pt'

__tokens = {453: (u'view/control_panel_url', 13, 28), 582: (u'view/label', 18, 50), 637: (u'context/global_statusmessage/macros/portal_message', 20, 26), 637: (u'context/global_statusmessage/macros/portal_message', 20, 26), 834: (u'view/contents', 26, 41), 261: (u'here/prefs_main_template/macros/master', 6, 23), 261: (u'here/prefs_main_template/macros/master', 6, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_136948418207568 = __compile_zt_expr
_static_136948301941200 = {u'id': u'content-core', }
_static_136948323749136 = u'master'
_static_136948501914768 = {}
_static_136948301941072 = u'portal_message'
_static_136948418228496 = __C2ZContextWrapper
_static_136948301942288 = {u'class': u'documentFirstHeading', }
_static_136948283562192 = {u'href': u'view/control_panel_url', u'id': u'setup-link', u'class': u'link-parent', }
_static_136948309651280 = {u'id': u'layout-contents', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948323746640
            __attrs_136948323746640 = _static_136948501914768
            __previous_i18n_domain_136948323746384 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_136948290164128 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7c8dc4308d10> name=None at 7c8dc4308410> -> __value
            __value = _static_136948323749136
            econtext['macroname'] = __value

            def __fill_prefs_configlet_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948283562448
                __attrs_136948283562448 = _static_136948501914768

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc1cb58d0> name=None at 7c8dc1cb5310> -> __attrs_136948309513360
                __attrs_136948309513360 = _static_136948283562192

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a id="setup-link" class="link-parent"')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948283562832
                __default_136948283562832 = _DEFAULT_MARKER

                # <Substitution u'view/control_panel_url' (13:28)> -> __attr_href
                __token = 453
                try:
                    __zt_tmp = __attrs_136948309513360
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_136948418207568('path', u'view/control_panel_url', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'>')
                __stream_136948283563984 = []
                __append_136948283563984 = __stream_136948283563984.append
                __append_136948283563984(u'\n        Site Setup\n    ')
                __msgid_136948283563984 = __re_whitespace(''.join(__stream_136948283563984)).strip()
                if __msgid_136948283563984:
                    __append(translate(__msgid_136948283563984, mapping=None, default=__msgid_136948283563984, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</a>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc2e3ce10> name=None at 7c8dc2e3c350> -> __attrs_136948301940688
                __attrs_136948301940688 = _static_136948301942288

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948301942672
                __default_136948301942672 = _DEFAULT_MARKER

                # <Value u'view/label' (18:50)> -> __cache_136948301941584
                __token = 582
                try:
                    __zt_tmp = __attrs_136948301940688
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948301941584 = _static_136948418207568('path', u'view/label', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/label' (18:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc2e3cf10> -> __condition
                __expression = __cache_136948301941584

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'View Title')
                else:
                    __content = __cache_136948301941584
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</h1>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948301939408
                __attrs_136948301939408 = _static_136948501914768
                __backup_macroname_136948292205696 = get('macroname', __marker)

                # <Static value=<_ast.Str object at 0x7c8dc2e3c950> name=None at 7c8dc2e3c3d0> -> __value
                __value = _static_136948301941072
                econtext['macroname'] = __value

                # <Value u'context/global_statusmessage/macros/portal_message' (20:26)> -> __macro
                __token = 637
                try:
                    __zt_tmp = __attrs_136948301939408
                except get('NameError', NameError):
                    __zt_tmp = None

                __macro = _static_136948418207568('path', u'context/global_statusmessage/macros/portal_message', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
                __token = 637
                __m = __macro.include
                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                if (__backup_macroname_136948292205696 is __marker):
                    del econtext['macroname']
                else:
                    econtext['macroname'] = __backup_macroname_136948292205696
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7c8dc2e3c9d0> name=None at 7c8dc2e3c510> -> __attrs_136948301939792
                __attrs_136948301939792 = _static_136948301941200

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="content-core">\n        ')

                # <Static value=<_ast.Dict object at 0x7c8dc3596f50> name=None at 7c8dc3596790> -> __attrs_136948309649424
                __attrs_136948309649424 = _static_136948309651280

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="layout-contents">\n            ')

                # <Static value=<_ast.Dict object at 0x7c8dcecf2490> name=None at 7c8dcecf2ed0> -> __attrs_136948309648912
                __attrs_136948309648912 = _static_136948501914768

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __default_136948309648208
                __default_136948309648208 = _DEFAULT_MARKER

                # <Value u'view/contents' (26:41)> -> __cache_136948309649232
                __token = 834
                try:
                    __zt_tmp = __attrs_136948309648912
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_136948309649232 = _static_136948418207568('path', u'view/contents', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/contents' (26:41)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7c8dced07110> at 7c8dc3596ad0> -> __condition
                __expression = __cache_136948309649232

                # <Symbol value=<DEFAULT> at 7c8dced07110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span />')
                else:
                    __content = __cache_136948309649232
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n        </div>\n    </div>\n\n</div>')
            _slots = econtext[u'__slot_prefs_configlet_main'] = _deque((__fill_prefs_configlet_main, ))

            # <Value u'here/prefs_main_template/macros/master' (6:23)> -> __macro
            __token = 261
            try:
                __zt_tmp = __attrs_136948323746640
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_136948418207568('path', u'here/prefs_main_template/macros/master', econtext=econtext)(_static_136948418228496(econtext, __zt_tmp))
            __token = 261
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_136948290164128 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_136948290164128
            __i18n_domain = __previous_i18n_domain_136948323746384
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }