# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/portlets/templates/manage-contextual.pt'

__tokens = {369: (u'context/@@plone', 9, 56), 571: (u'context/Title', 14, 50), 753: (u'string:${context/absolute_url}', 20, 32), 959: (u'context/@@plone_context_state/is_portal_root', 25, 46), 1041: (u'not:is_portal_root', 26, 34), 1124: (u'plone_view/getParentObject|nothing', 28, 48), 1195: (u"python:plone_view.getParentObject().absolute_url()+'/@@manage-portlets'", 29, 34), 1489: (u'plone_view/isDefaultPageInFolder|nothing', 37, 28), 2059: (u'string:${context/aq_inner/aq_parent/absolute_url}/@@manage-portlets', 48, 36), 2929: (u'view/has_legacy_portlets', 65, 28), 3309: (u'string:${context/absolute_url}/@@convert-legacy-portlets', 75, 39), 235: (u'context/main_template/macros/master', 5, 23), 235: (u'context/main_template/macros/master', 5, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133987185474384 = {u'id': u'content-core', }
_static_133987184250960 = {u'href': u"python:plone_view.getParentObject().absolute_url()+'/@@manage-portlets'", u'class': u'link-parent', }
_static_133987276028048 = __compile_zt_expr
_static_133987186760016 = {u'href': u'', }
_static_133987186680144 = {u'type': u'submit', u'class': u'context btn btn-outline-secondary', u'value': u'Convert portlets', u'name': u'convert', }
_static_133987186760528 = {u'class': u'form-text text-muted', }
_static_133987184253904 = {u'role': u'status', u'class': u'portalMessage info alert alert-info', }
_static_133987276028432 = __C2ZContextWrapper
_static_133987185275472 = {u'class': u'documentFirstHeading', }
_static_133987359720592 = {}
_static_133987185379024 = {u'class': u'fas fa-chevron-left', }
_static_133987186665232 = u'master'
_static_133987185499088 = {u'action': u'string:${context/absolute_url}/@@convert-legacy-portlets', u'method': u'post', }
_static_133987186757712 = {u'class': u'form-text text-muted', }
_static_133987185471632 = {u'href': u'', u'class': u'link-parent btn btn-outline-secondary', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186664784
            __attrs_133987186664784 = _static_133987359720592
            __previous_i18n_domain_133987186665040 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_133987148892352 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x79dc52aa6710> name=None at 79dc52aa64d0> -> __value
            __value = _static_133987186665232
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186667344
                __attrs_133987186667344 = _static_133987359720592
                __backup_plone_view_133987186666768 = get('plone_view', __marker)

                # <Value u'context/@@plone' (9:56)> -> __value
                __token = 369
                try:
                    __zt_tmp = __attrs_133987186667344
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133987276028048('path', u'context/@@plone', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                econtext['plone_view'] = __value
                __append(u'\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52953250> name=None at 79dc52aa6490> -> __attrs_133987185472528
                __attrs_133987185472528 = _static_133987185275472

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">')
                __stream_133987180695632_context_title = ''
                __stream_133987186663696 = []
                __append_133987186663696 = __stream_133987186663696.append
                __append_133987186663696(u'\r\n        Manage portlets for\r\n        ')
                __stream_133987180695632_context_title = []
                __append_133987180695632_context_title = __stream_133987180695632_context_title.append

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185475344
                __attrs_133987185475344 = _static_133987359720592

                # <q ... (0:0)
                # --------------------------------------------------------
                __append_133987180695632_context_title(u'<q>')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185473872
                __default_133987185473872 = _DEFAULT_MARKER

                # <Value u'context/Title' (14:50)> -> __cache_133987185472912
                __token = 571
                try:
                    __zt_tmp = __attrs_133987185475344
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133987185472912 = _static_133987276028048('path', u'context/Title', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/Title' (14:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79dc5cfc5110> at 79dc52983cd0> -> __condition
                __expression = __cache_133987185472912

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append_133987180695632_context_title(u'title')
                else:
                    __content = __cache_133987185472912
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append_133987180695632_context_title(__content)
                __append_133987180695632_context_title(u'</q>')
                __append_133987186663696(u'${context_title}')
                __stream_133987180695632_context_title = ''.join(__stream_133987180695632_context_title)
                __append_133987186663696(u'\r\n      ')
                __msgid_133987186663696 = __re_whitespace(''.join(__stream_133987186663696)).strip()
                if u'title_manage_contextual_portlets':
                    __append(translate(u'title_manage_contextual_portlets', mapping={u'context_title': __stream_133987180695632_context_title, }, default=__msgid_133987186663696, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</h1>\r\n\r\n      ')

                # <Static value=<_ast.Dict object at 0x79dc52983b50> name=None at 79dc52983b90> -> __attrs_133987185474832
                __attrs_133987185474832 = _static_133987185474384

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="content-core">\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc52983090> name=None at 79dc52983910> -> __attrs_133987185381008
                __attrs_133987185381008 = _static_133987185471632

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987185377680
                __default_133987185377680 = _DEFAULT_MARKER

                # <Substitution u'string:${context/absolute_url}' (20:32)> -> __attr_href
                __token = 753
                try:
                    __zt_tmp = __attrs_133987185381008
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_133987276028048('string', u'${context/absolute_url}', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u'            class="link-parent btn btn-outline-secondary">\r\n          ')

                # <Static value=<_ast.Dict object at 0x79dc5296c6d0> name=None at 79dc5296cd50> -> __attrs_133987185377936
                __attrs_133987185377936 = _static_133987185379024

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-chevron-left"></i>\r\n          ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185380560
                __attrs_133987185380560 = _static_133987359720592

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_133987185380880 = []
                __append_133987185380880 = __stream_133987185380880.append
                __append_133987185380880(u'Return')
                __msgid_133987185380880 = __re_whitespace(''.join(__stream_133987185380880)).strip()
                if u'return_to_view':
                    __append(translate(u'return_to_view', mapping=None, default=__msgid_133987185380880, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\r\n        </a>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185378000
                __attrs_133987185378000 = _static_133987359720592
                __backup_is_portal_root_133987185473040 = get('is_portal_root', __marker)

                # <Value u'context/@@plone_context_state/is_portal_root' (25:46)> -> __value
                __token = 959
                try:
                    __zt_tmp = __attrs_133987185378000
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133987276028048('path', u'context/@@plone_context_state/is_portal_root', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                econtext['is_portal_root'] = __value

                # <Value u'not:is_portal_root' (26:34)> -> __condition
                __token = 1041
                try:
                    __zt_tmp = __attrs_133987185378000
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('not', u'is_portal_root', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:
                    __append(u'\r\n          -\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc52859050> name=None at 79dc528596d0> -> __attrs_133987184251344
                    __attrs_133987184251344 = _static_133987184250960

                    # <Value u'plone_view/getParentObject|nothing' (28:48)> -> __condition
                    __token = 1124
                    try:
                        __zt_tmp = __attrs_133987184251344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_133987276028048('path', u'plone_view/getParentObject|nothing', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    if __condition:

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a class="link-parent"')

                        # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987184254480
                        __default_133987184254480 = _DEFAULT_MARKER

                        # <Substitution u"python:plone_view.getParentObject().absolute_url()+'/@@manage-portlets'" (29:34)> -> __attr_href
                        __token = 1195
                        try:
                            __zt_tmp = __attrs_133987184251344
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_133987276028048('python', u"plone_view.getParentObject().absolute_url()+'/@@manage-portlets'", econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'>')
                        __stream_133987184251024 = []
                        __append_133987184251024 = __stream_133987184251024.append
                        __append_133987184251024(u'\r\n            Go to parent folder\r\n          ')
                        __msgid_133987184251024 = __re_whitespace(''.join(__stream_133987184251024)).strip()
                        if __msgid_133987184251024:
                            __append(translate(__msgid_133987184251024, mapping=None, default=__msgid_133987184251024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</a>')
                    __append(u'\r\n        ')
                if (__backup_is_portal_root_133987185473040 is __marker):
                    del econtext['is_portal_root']
                else:
                    econtext['is_portal_root'] = __backup_is_portal_root_133987185473040
                __append(u'\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc52859bd0> name=None at 79dc52859cd0> -> __attrs_133987184251408
                __attrs_133987184251408 = _static_133987184253904

                # <Value u'plone_view/isDefaultPageInFolder|nothing' (37:28)> -> __condition
                __token = 1489
                try:
                    __zt_tmp = __attrs_133987184251408
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'plone_view/isDefaultPageInFolder|nothing', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="portalMessage info alert alert-info"              role="status">\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186758288
                    __attrs_133987186758288 = _static_133987359720592

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_133987186759568 = []
                    __append_133987186759568 = __stream_133987186759568.append
                    __append_133987186759568(u'\r\n            Info\r\n          ')
                    __msgid_133987186759568 = __re_whitespace(''.join(__stream_133987186759568)).strip()
                    if __msgid_133987186759568:
                        __append(translate(__msgid_133987186759568, mapping=None, default=__msgid_133987186759568, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987186758928
                    __attrs_133987186758928 = _static_133987359720592
                    __stream_133987180696352_go_here = ''
                    __stream_133987186758352 = []
                    __append_133987186758352 = __stream_133987186758352.append
                    __append_133987186758352(u'\r\n            You are managing the portlets of the default view of a container. If\r\n            you wanted to manage the portlets of the container itself,\r\n            ')
                    __stream_133987180696352_go_here = []
                    __append_133987180696352_go_here = __stream_133987180696352_go_here.append

                    # <Static value=<_ast.Dict object at 0x79dc52abd950> name=None at 79dc52abd450> -> __attrs_133987186760208
                    __attrs_133987186760208 = _static_133987186760016

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_133987180696352_go_here(u'<a')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186760848
                    __default_133987186760848 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/aq_inner/aq_parent/absolute_url}/@@manage-portlets' (48:36)> -> __attr_href
                    __token = 2059
                    try:
                        __zt_tmp = __attrs_133987186760208
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_133987276028048('string', u'${context/aq_inner/aq_parent/absolute_url}/@@manage-portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_133987180696352_go_here((u' href="%s"' % __attr_href))
                    __append_133987180696352_go_here(u'>')
                    __stream_133987186758800 = []
                    __append_133987186758800 = __stream_133987186758800.append
                    __append_133987186758800(u'go here')
                    __msgid_133987186758800 = __re_whitespace(''.join(__stream_133987186758800)).strip()
                    if u'label_manage_portlets_default_view_container_go_here':
                        __append_133987180696352_go_here(translate(u'label_manage_portlets_default_view_container_go_here', mapping=None, default=__msgid_133987186758800, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_133987180696352_go_here(u'</a>')
                    __append_133987186758352(u'${go_here}')
                    __stream_133987180696352_go_here = ''.join(__stream_133987180696352_go_here)
                    __append_133987186758352(u'.\r\n          ')
                    __msgid_133987186758352 = __re_whitespace(''.join(__stream_133987186758352)).strip()
                    if u'label_manage_portlets_default_view_container':
                        __append(translate(u'label_manage_portlets_default_view_container', mapping={u'go_here': __stream_133987180696352_go_here, }, default=__msgid_133987186758352, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'\r\n        </div>')
                __append(u'\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc52abd050> name=None at 79dc52abd1d0> -> __attrs_133987186760656
                __attrs_133987186760656 = _static_133987186757712

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="form-text text-muted">')
                __stream_133987186758160 = []
                __append_133987186758160 = __stream_133987186758160.append
                __append_133987186758160(u'\r\n          The portlet columns will first display portlets\r\n          explicitly assigned in this context. Use the buttons on each portlet\r\n          to move them up or down, delete or edit them. To add a new portlet,\r\n          use the drop-down list at the top of the column.\r\n        ')
                __msgid_133987186758160 = __re_whitespace(''.join(__stream_133987186758160)).strip()
                if u'description_manage_contextual_portlets':
                    __append(translate(u'description_manage_contextual_portlets', mapping=None, default=__msgid_133987186758160, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc52abdb50> name=None at 79dc52abda50> -> __attrs_133987185496912
                __attrs_133987185496912 = _static_133987186760528

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="form-text text-muted">')
                __stream_133987186761424 = []
                __append_133987186761424 = __stream_133987186761424.append
                __append_133987186761424(u'\r\n          If you wish to block or unblock certain categories of portlets, you can\r\n          do so using the drop-down boxes. Portlets that are included by these categories\r\n          are shown below the selection box.\r\n        ')
                __msgid_133987186761424 = __re_whitespace(''.join(__stream_133987186761424)).strip()
                if u'description_portlets_block_unblock':
                    __append(translate(u'description_portlets_block_unblock', mapping=None, default=__msgid_133987186761424, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</p>\r\n\r\n        ')

                # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185499344
                __attrs_133987185499344 = _static_133987359720592

                # <Value u'view/has_legacy_portlets' (65:28)> -> __condition
                __token = 2929
                try:
                    __zt_tmp = __attrs_133987185499344
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_133987276028048('path', u'view/has_legacy_portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div>\r\n\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185498896
                    __attrs_133987185498896 = _static_133987359720592

                    # <h2 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h2>')
                    __stream_133987185499024 = []
                    __append_133987185499024 = __stream_133987185499024.append
                    __append_133987185499024(u'Legacy portlets')
                    __msgid_133987185499024 = __re_whitespace(''.join(__stream_133987185499024)).strip()
                    if u'title_legacy_portlets':
                        __append(translate(u'title_legacy_portlets', mapping=None, default=__msgid_133987185499024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h2>\r\n\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc5cfb0490> name=None at 79dc5cfb0ed0> -> __attrs_133987185499728
                    __attrs_133987185499728 = _static_133987359720592

                    # <p ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<p>')
                    __stream_133987185498832 = []
                    __append_133987185498832 = __stream_133987185498832.append
                    __append_133987185498832(u'\r\n            There are legacy portlets defined here. Click the button to\r\n            convert them to new-style portlets.\r\n          ')
                    __msgid_133987185498832 = __re_whitespace(''.join(__stream_133987185498832)).strip()
                    if u'action_convert_legacy_portlets':
                        __append(translate(u'action_convert_legacy_portlets', mapping=None, default=__msgid_133987185498832, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</p>\r\n\r\n          ')

                    # <Static value=<_ast.Dict object at 0x79dc52989bd0> name=None at 79dc52989850> -> __attrs_133987186682768
                    __attrs_133987186682768 = _static_133987185499088

                    # <form ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<form method="post"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186683472
                    __default_133987186683472 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/absolute_url}/@@convert-legacy-portlets' (75:39)> -> __attr_action
                    __token = 3309
                    try:
                        __zt_tmp = __attrs_133987186682768
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_action = _static_133987276028048('string', u'${context/absolute_url}/@@convert-legacy-portlets', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
                    __attr_action = __quote(__attr_action, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_action is not None):
                        __append((u' action="%s"' % __attr_action))
                    __append(u'>\r\n\r\n            ')

                    # <Static value=<_ast.Dict object at 0x79dc52aaa150> name=None at 79dc52aaadd0> -> __attrs_133987186682192
                    __attrs_133987186682192 = _static_133987186680144

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="submit"                    class="context btn btn-outline-secondary"')

                    # <Symbol value=<DEFAULT> at 79dc5cfc5110> -> __default_133987186683600
                    __default_133987186683600 = _DEFAULT_MARKER

                    # <Translate msgid=u'label_convert_portlets' node=<_ast.Str object at 0x79dc52aaa610> at 79dc52aaa0d0> -> __attr_value
                    __attr_value = u'Convert portlets'
                    __attr_value = translate(u'label_convert_portlets', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u'                    value="%s"' % __attr_value))
                    __append(u'                    name="convert" />\r\n\r\n          </form>\r\n\r\n        </div>')
                __append(u'\r\n      </div>\r\n\r\n    ')
                if (__backup_plone_view_133987186666768 is __marker):
                    del econtext['plone_view']
                else:
                    econtext['plone_view'] = __backup_plone_view_133987186666768
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'context/main_template/macros/master' (5:23)> -> __macro
            __token = 235
            try:
                __zt_tmp = __attrs_133987186664784
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_133987276028048('path', u'context/main_template/macros/master', econtext=econtext)(_static_133987276028432(econtext, __zt_tmp))
            __token = 235
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_133987148892352 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_133987148892352
            __i18n_domain = __previous_i18n_domain_133987186665040
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }