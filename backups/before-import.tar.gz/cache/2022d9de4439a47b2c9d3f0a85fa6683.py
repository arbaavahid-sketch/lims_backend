# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/z3cform/widgets/datagrid/datagridrow_input.pt'

__tokens = {292: (u'view/subform/widgets/values', 8, 32), 353: (u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", 9, 30), 525: (u'widget/render', 10, 34), 570: (u'widget/error', 11, 26), 648: (u'widget/error/render', 12, 36), 887: (u'string:${view/name}-empty-marker', 20, 32), 1030: (u'view/isInsertEnabled', 25, 21), 1339: (u'view/isDeleteEnabled', 36, 21), 1668: (u'view/isReorderEnabled', 47, 21), 1994: (u'view/isReorderEnabled', 58, 21)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_140402101439184 = {u'class': u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", }
_static_140402099604816 = {u'type': u'hidden', u'name': u'field-empty-marker', u'value': u'1', }
_static_140402101418704 = {u'class': u'datagridwidget-manipulator delete-row', }
_static_140402356200592 = {}
_static_140402272508048 = __compile_zt_expr
_static_140402099800144 = {u'class': u'datagridwidget-manipulator dgf--row-moveup', }
_static_140402102515536 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-movedown', u'title': u'Move down', }
_static_140402099282384 = {u'xmlns': u'http://www.w3.org/1999/xhtml', }
_static_140402099470864 = {u'class': u'datagridwidget-manipulator dgf--row-movedown', }
_static_140402101749648 = {u'class': u'small text-danger', }
_static_140402272508432 = __C2ZContextWrapper
_static_140402101900880 = {u'class': u'datagridwidget-hidden-data', }
_static_140402101416656 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-add', u'title': u'Add row', }
_static_140402101416272 = {u'class': u'datagridwidget-manipulator insert-row', }
_static_140402099801936 = {u'class': u'fas fa-trash', }
_static_140402099798608 = {u'href': u'', u'class': u'btn btn-sm btn-outline-secondary dgf--row-delete', u'title': u'Delete row', }
_static_140402099355152 = {u'class': u'fas fa-arrow-down', }
_static_140402099470928 = {u'class': u'fas fa-arrow-up', }
_static_140402099471184 = {u'class': u'btn btn-sm btn-outline-secondary dgf--row-moveup', u'title': u'Move up', }
_static_140402102642064 = {u'class': u'fas fa-plus', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7fb1e940e1d0> name=None at 7fb1e940e890> -> __attrs_140402099282832
            __attrs_140402099282832 = _static_140402099282384
            __append(u'\r\n\r\n  <!-- Data rows -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099285200
            __attrs_140402099285200 = _static_140402356200592
            __backup_widget_140402100147152 = get('widget', __marker)

            # <Value u'view/subform/widgets/values' (8:32)> -> __iterator
            __token = 292
            try:
                __zt_tmp = __attrs_140402099285200
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_140402272508048('path', u'view/subform/widgets/values', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            (__iterator, ____index_140402101900560, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e961cad0> name=None at 7fb1e961c110> -> __attrs_140402102396816
                __attrs_140402102396816 = _static_140402101439184

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101439632
                __default_140402101439632 = _DEFAULT_MARKER

                # <Substitution u"python:('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')" (9:30)> -> __attr_class
                __token = 353
                try:
                    __zt_tmp = __attrs_140402102396816
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_140402272508048('python', u"('cell-%d ' % repeat['widget'].number()) + ('datagridwidget-hidden-data' if widget.mode == 'hidden' else 'datagridwidget-cell')", econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402101749008
                __attrs_140402101749008 = _static_140402356200592

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101719312
                __default_140402101719312 = _DEFAULT_MARKER

                # <Value u'widget/render' (10:34)> -> __cache_140402102710416
                __token = 525
                try:
                    __zt_tmp = __attrs_140402101749008
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_140402102710416 = _static_140402272508048('path', u'widget/render', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                # <BinOp left=<Value u'widget/render' (10:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e93e4990> -> __condition
                __expression = __cache_140402102710416

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_140402102710416
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e9668790> name=None at 7fb1e96682d0> -> __attrs_140402099602512
                __attrs_140402099602512 = _static_140402101749648

                # <Value u'widget/error' (11:26)> -> __condition
                __token = 570
                try:
                    __zt_tmp = __attrs_140402099602512
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_140402272508048('path', u'widget/error', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="small text-danger">\r\n        ')

                    # <Static value=<_ast.Dict object at 0x7fb1f8912490> name=None at 7fb1f8912ed0> -> __attrs_140402099602064
                    __attrs_140402099602064 = _static_140402356200592

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099603920
                    __default_140402099603920 = _DEFAULT_MARKER

                    # <Value u'widget/error/render' (12:36)> -> __cache_140402099604496
                    __token = 648
                    try:
                        __zt_tmp = __attrs_140402099602064
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_140402099604496 = _static_140402272508048('path', u'widget/error/render', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/error/render' (12:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7fb1f8927110> at 7fb1e945c810> -> __condition
                    __expression = __cache_140402099604496

                    # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>error</div>')
                    else:
                        __content = __cache_140402099604496
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n      </div>')
                __append(u'\r\n    </td>\r\n  ')
                ____index_140402101900560 -= 1
                if (____index_140402101900560 > 0):
                    __append('')
            if (__backup_widget_140402100147152 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_140402100147152
            __append(u'\r\n\r\n  <!-- Empty marker -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e968d650> name=None at 7fb1e968d110> -> __attrs_140402099603152
            __attrs_140402099603152 = _static_140402101900880

            # <td ... (0:0)
            # --------------------------------------------------------
            __append(u'<td class="datagridwidget-hidden-data">\r\n    ')

            # <Static value=<_ast.Dict object at 0x7fb1e945cd50> name=None at 7fb1e945cf10> -> __attrs_140402101419152
            __attrs_140402101419152 = _static_140402099604816

            # <input ... (0:0)
            # --------------------------------------------------------
            __append(u'<input')

            # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099601936
            __default_140402099601936 = _DEFAULT_MARKER

            # <Substitution u'string:${view/name}-empty-marker' (20:32)> -> __attr_name
            __token = 887
            try:
                __zt_tmp = __attrs_140402101419152
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_name = _static_140402272508048('string', u'${view/name}-empty-marker', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            __attr_name = __quote(__attr_name, '"', '&quot;', u'field-empty-marker', _DEFAULT_MARKER)
            if (__attr_name is not None):
                __append((u' name="%s"' % __attr_name))
            __append(u' type="hidden" value="1" />\r\n  </td>\r\n\r\n  <!-- Add row -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9617150> name=None at 7fb1e9617510> -> __attrs_140402101416144
            __attrs_140402101416144 = _static_140402101416272

            # <Value u'view/isInsertEnabled' (25:21)> -> __condition
            __token = 1030
            try:
                __zt_tmp = __attrs_140402101416144
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/isInsertEnabled', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator insert-row">\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e96172d0> name=None at 7fb1e9617b90> -> __attrs_140402101417424
                __attrs_140402101417424 = _static_140402101416656

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button       class="btn btn-sm btn-outline-secondary dgf--row-add"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402101417936
                __default_140402101417936 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7fb1e9617610> at 7fb1e96179d0> -> __attr_title
                __attr_title = u'Add row'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'       title="%s"' % __attr_title))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e9742590> name=None at 7fb1e9617f10> -> __attrs_140402164205328
                __attrs_140402164205328 = _static_140402102642064

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-plus" />\r\n    </button>\r\n  </td>')
            __append(u'\r\n\r\n  <!-- Delete row -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e9617ad0> name=None at 7fb1e9617850> -> __attrs_140402099800656
            __attrs_140402099800656 = _static_140402101418704

            # <Value u'view/isDeleteEnabled' (36:21)> -> __condition
            __token = 1339
            try:
                __zt_tmp = __attrs_140402099800656
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/isDeleteEnabled', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator delete-row">\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e948c250> name=None at 7fb1e948ca10> -> __attrs_140402099800272
                __attrs_140402099800272 = _static_140402099798608

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button href=""        class="btn btn-sm btn-outline-secondary dgf--row-delete"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099801168
                __default_140402099801168 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7fb1e948c2d0> at 7fb1e948c450> -> __attr_title
                __attr_title = u'Delete row'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'        title="%s"' % __attr_title))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e948cf50> name=None at 7fb1e948c0d0> -> __attrs_140402103275792
                __attrs_140402103275792 = _static_140402099801936

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-trash" />\r\n    </button>\r\n  </td>')
            __append(u'\r\n\r\n  <!-- Move up -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e948c850> name=None at 7fb1e948c410> -> __attrs_140402099471824
            __attrs_140402099471824 = _static_140402099800144

            # <Value u'view/isReorderEnabled' (47:21)> -> __condition
            __token = 1668
            try:
                __zt_tmp = __attrs_140402099471824
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/isReorderEnabled', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator dgf--row-moveup">\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e943c350> name=None at 7fb1e943cd10> -> __attrs_140402099472976
                __attrs_140402099472976 = _static_140402099471184

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button        class="btn btn-sm btn-outline-secondary dgf--row-moveup"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402099473552
                __default_140402099473552 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7fb1e943ca10> at 7fb1e943c8d0> -> __attr_title
                __attr_title = u'Move up'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'        title="%s"' % __attr_title))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e943c250> name=None at 7fb1e943c510> -> __attrs_140402099471888
                __attrs_140402099471888 = _static_140402099470928

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-arrow-up" />\r\n    </button>\r\n  </td>')
            __append(u'\r\n\r\n  <!-- Move down -->\r\n  ')

            # <Static value=<_ast.Dict object at 0x7fb1e943c210> name=None at 7fb1e943c150> -> __attrs_140402102514064
            __attrs_140402102514064 = _static_140402099470864

            # <Value u'view/isReorderEnabled' (58:21)> -> __condition
            __token = 1994
            try:
                __zt_tmp = __attrs_140402102514064
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_140402272508048('path', u'view/isReorderEnabled', econtext=econtext)(_static_140402272508432(econtext, __zt_tmp))
            if __condition:

                # <td ... (0:0)
                # --------------------------------------------------------
                __append(u'<td class="datagridwidget-manipulator dgf--row-movedown">\r\n    ')

                # <Static value=<_ast.Dict object at 0x7fb1e9723750> name=None at 7fb1e97237d0> -> __attrs_140402102514320
                __attrs_140402102514320 = _static_140402102515536

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button        class="btn btn-sm btn-outline-secondary dgf--row-movedown"')

                # <Symbol value=<DEFAULT> at 7fb1f8927110> -> __default_140402102514704
                __default_140402102514704 = _DEFAULT_MARKER

                # <Translate msgid=None node=<_ast.Str object at 0x7fb1e9723dd0> at 7fb1e9723c90> -> __attr_title
                __attr_title = u'Move down'
                __attr_title = translate(__attr_title, default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                if (__attr_title is not None):
                    __append((u'        title="%s"' % __attr_title))
                __append(u'>\r\n      ')

                # <Static value=<_ast.Dict object at 0x7fb1e941fe10> name=None at 7fb1e941f890> -> __attrs_140402099352592
                __attrs_140402099352592 = _static_140402099355152

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-arrow-down" />\r\n    </button>\r\n  </td>')
            __append(u'\r\n\r\n\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }