# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/footer.pt'

__tokens = {220: (u'view/render_footer_portlets', 8, 57), 188: (u'nothing', 8, 25), 531: (u'view/year', 12, 63)}

from chameleon.tal import ErrorInfo as _ErrorInfo
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133838716871696 = {u'class': u'fas fa-book', }
_static_133838700838480 = {u'class': u'float-left', }
_static_133838716957264 = {u'class': u'fa fa-code-branch', }
_static_133838698817168 = {u'class': u'row', }
_static_133838716959824 = {u'href': u'https://twitter.com/senaitelims', u'target': u'_blank', u'class': u'nav-link', u'title': u'Spread the word on Twitter', }
_static_133838698815760 = {u'class': u'col-md-12', }
_static_133838685989392 = {u'href': u'https://www.senaite.com', u'target': u'_blank', }
_static_133838698931024 = {u'class': u'float-right', }
_static_133838698933200 = {u'title': u'Copyright', }
_static_133838794967184 = __compile_zt_expr
_static_133838698920528 = {u'href': u'https://www.senaite.com', u'target': u'_blank', u'class': u'nav-link', u'title': u'Visit the Website', }
_static_133838686043920 = {u'class': u'fas fa-globe', }
_static_133838681383440 = {u'class': u'fa fa-hashtag', }
_static_133838716872208 = {u'href': u'https://github.com/senaite/senaite.lims', u'target': u'_blank', u'class': u'nav-link', u'title': u'Browse the code on GitHub', }
_static_133838698817808 = {u'id': u'senaite-footer', }
_static_133838698919952 = {u'class': u'nav nav-pills', }
_static_133838794967568 = __C2ZContextWrapper
_static_133838686042448 = {u'href': u'https://www.senaite.com/docs/quickstart.html', u'target': u'_blank', u'class': u'nav-link', u'title': u'Browse the Docs', }
_static_133838681385808 = {u'href': u'https://gitter.im/senaite', u'target': u'_blank', u'class': u'nav-link', u'title': u'Talk with us on Gitter', }
_static_133838878659728 = {}
_static_133838685943120 = {u'class': u'fas fa-comments', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9c019a910> name=None at 79b9c019a810> -> __attrs_133838681336976
            __attrs_133838681336976 = _static_133838698817808
            __previous_i18n_domain_133838698816272 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <footer ... (0:0)
            # --------------------------------------------------------
            __append(u'<footer         id="senaite-footer">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9c019a690> name=None at 79b9c019a9d0> -> __attrs_133838698816720
            __attrs_133838698816720 = _static_133838698817168

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9c019a110> name=None at 79b9c019a790> -> __attrs_133838700837392
            __attrs_133838700837392 = _static_133838698815760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700835600
            __attrs_133838700835600 = _static_133838878659728

            # <hr ... (0:0)
            # --------------------------------------------------------
            __append(u'<hr/>\r\n      <!-- footer portlets -->\r\n      ')
            ____fallback_133838878548112 = len(__stream)
            try:

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838700836368
                __attrs_133838700836368 = _static_133838878659728

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838700837328
                __default_133838700837328 = _DEFAULT_MARKER

                # <Value u'view/render_footer_portlets' (8:57)> -> __cache_133838700838800
                __token = 220
                try:
                    __zt_tmp = __attrs_133838700836368
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838700838800 = _static_133838794967184('path', u'view/render_footer_portlets', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'view/render_footer_portlets' (8:57)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9c0387d10> -> __condition
                __expression = __cache_133838700838800

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_133838700838800
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
            except (Exception, ) as __exc:
                econtext['error'] = _ErrorInfo(__exc, __tokens[__token][1:3])
                if (on_error_handler is not None):
                    on_error_handler(__exc)
                del __stream[____fallback_133838878548112:]

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>')

                # <Value u'nothing' (8:25)> -> __content
                __token = 188
                try:
                    __zt_tmp = __attrs_133838700837392
                except get('NameError', NameError):
                    __zt_tmp = None

                __content = _static_133838794967184('path', u'nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append(__content)
                __append(u'</div>')

            __append(u'\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c0387e50> name=None at 79b9c0387210> -> __attrs_133838698930768
            __attrs_133838698930768 = _static_133838700838480

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-left">\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698932752
            __attrs_133838698932752 = _static_133838878659728
            __stream_133838714010512_senaitelims = ''
            __stream_133838714010512_copyright = ''
            __stream_133838714010512_current_year = ''
            __stream_133838698931536 = []
            __append_133838698931536 = __stream_133838698931536.append
            __append_133838698931536(u'\r\n          ')
            __stream_133838714010512_copyright = []
            __append_133838714010512_copyright = __stream_133838714010512_copyright.append

            # <Static value=<_ast.Dict object at 0x79b9c01b6bd0> name=None at 79b9c01b69d0> -> __attrs_133838698931152
            __attrs_133838698931152 = _static_133838698933200

            # <abbr ... (0:0)
            # --------------------------------------------------------
            __append_133838714010512_copyright(u'<abbr')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838698930896
            __default_133838698930896 = _DEFAULT_MARKER

            # <Translate msgid=u'title_copyright' node=<_ast.Str object at 0x79b9c01b6e90> at 79b9c01b6b90> -> __attr_title
            __attr_title = u'Copyright'
            __attr_title = translate(u'title_copyright', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_title is not None):
                __append_133838714010512_copyright((u' title="%s"' % __attr_title))
            __append_133838714010512_copyright(u'>&copy;</abbr>')
            __append_133838698931536(u'${copyright}')
            __stream_133838714010512_copyright = ''.join(__stream_133838714010512_copyright)
            __append_133838698931536(u'\r\n          2017-')
            __stream_133838714010512_current_year = []
            __append_133838714010512_current_year = __stream_133838714010512_current_year.append

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838685989200
            __attrs_133838685989200 = _static_133838878659728

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838685989712
            __default_133838685989712 = _DEFAULT_MARKER

            # <Value u'view/year' (12:63)> -> __cache_133838685990480
            __token = 531
            try:
                __zt_tmp = __attrs_133838685989200
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_133838685990480 = _static_133838794967184('path', u'view/year', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

            # <BinOp left=<Value u'view/year' (12:63)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf55e910> -> __condition
            __expression = __cache_133838685990480

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:
                pass
            else:
                __content = __cache_133838685990480
                __content = __quote(__content, None, '\xad', None, None)
                if (__content is not None):
                    __append_133838714010512_current_year(__content)
            __append_133838698931536(u'${current_year}')
            __stream_133838714010512_current_year = ''.join(__stream_133838714010512_current_year)
            __append_133838698931536(u'\r\n          ')
            __stream_133838714010512_senaitelims = []
            __append_133838714010512_senaitelims = __stream_133838714010512_senaitelims.append

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838685988176
            __attrs_133838685988176 = _static_133838878659728
            __append_133838714010512_senaitelims(u'\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9bf55ea10> name=None at 79b9bf55e7d0> -> __attrs_133838685989840
            __attrs_133838685989840 = _static_133838685989392

            # <a ... (0:0)
            # --------------------------------------------------------
            __append_133838714010512_senaitelims(u'<a href="https://www.senaite.com"                 target="_blank">')
            __stream_133838685988432 = []
            __append_133838685988432 = __stream_133838685988432.append
            __append_133838685988432(u'SENAITE LIMS')
            __msgid_133838685988432 = __re_whitespace(''.join(__stream_133838685988432)).strip()
            if u'label_senaite':
                __append_133838714010512_senaitelims(translate(u'label_senaite', mapping=None, default=__msgid_133838685988432, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append_133838714010512_senaitelims(u'</a>\r\n          ')
            __append_133838698931536(u'${senaitelims}')
            __stream_133838714010512_senaitelims = ''.join(__stream_133838714010512_senaitelims)
            __append_133838698931536(u'\r\n        ')
            __msgid_133838698931536 = __re_whitespace(''.join(__stream_133838698931536)).strip()
            if u'description_copyright':
                __append(translate(u'description_copyright', mapping={u'current_year': __stream_133838714010512_current_year, u'copyright': __stream_133838714010512_copyright, u'senaitelims': __stream_133838714010512_senaitelims, }, default=__msgid_133838698931536, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\r\n      </div>\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c01b6350> name=None at 79b9c01b6690> -> __attrs_133838685986960
            __attrs_133838685986960 = _static_133838698931024

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="float-right">\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9c01b3810> name=None at 79b9c01b3550> -> __attrs_133838698921296
            __attrs_133838698921296 = _static_133838698919952

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="nav nav-pills">\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838698921872
            __attrs_133838698921872 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x79b9c01b3a50> name=None at 79b9c01b3e10> -> __attrs_133838686041808
            __attrs_133838686041808 = _static_133838698920528

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://www.senaite.com" title="Visit the Website" target="_blank">')

            # <Static value=<_ast.Dict object at 0x79b9bf56bf10> name=None at 79b9bf56b810> -> __attrs_133838686041360
            __attrs_133838686041360 = _static_133838686043920

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-globe"></i></a></li>\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686040464
            __attrs_133838686040464 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x79b9bf56b950> name=None at 79b9bf56b0d0> -> __attrs_133838716870864
            __attrs_133838716870864 = _static_133838686042448

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://www.senaite.com/docs/quickstart.html" title="Browse the Docs" target="_blank">')

            # <Static value=<_ast.Dict object at 0x79b9c12d2410> name=None at 79b9c12d2cd0> -> __attrs_133838716871888
            __attrs_133838716871888 = _static_133838716871696

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-book"></i></a></li>\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716872016
            __attrs_133838716872016 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x79b9c12d2610> name=None at 79b9c12d2050> -> __attrs_133838716956944
            __attrs_133838716956944 = _static_133838716872208

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://github.com/senaite/senaite.lims" title="Browse the code on GitHub" target="_blank">')

            # <Static value=<_ast.Dict object at 0x79b9c12e7250> name=None at 79b9c12e7790> -> __attrs_133838716958288
            __attrs_133838716958288 = _static_133838716957264

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fa fa-code-branch"></i></a></li>\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838716959056
            __attrs_133838716959056 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x79b9c12e7c50> name=None at 79b9c12e74d0> -> __attrs_133838681386512
            __attrs_133838681386512 = _static_133838716959824

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://twitter.com/senaitelims" title="Spread the word on Twitter" target="_blank">')

            # <Static value=<_ast.Dict object at 0x79b9bf0fa210> name=None at 79b9bf0faad0> -> __attrs_133838681383184
            __attrs_133838681383184 = _static_133838681383440

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fa fa-hashtag"></i></a></li>\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681384144
            __attrs_133838681384144 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>')

            # <Static value=<_ast.Dict object at 0x79b9bf0fab50> name=None at 79b9bf0fa3d0> -> __attrs_133838681386192
            __attrs_133838681386192 = _static_133838681385808

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a class="nav-link" href="https://gitter.im/senaite" title="Talk with us on Gitter" target="_blank">')

            # <Static value=<_ast.Dict object at 0x79b9bf553550> name=None at 79b9bf553bd0> -> __attrs_133838685945296
            __attrs_133838685945296 = _static_133838685943120

            # <i ... (0:0)
            # --------------------------------------------------------
            __append(u'<i class="fas fa-comments"></i></a></li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</footer>')
            __i18n_domain = __previous_i18n_domain_133838698816272
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }