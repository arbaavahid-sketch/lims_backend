# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/login/templates/login.pt'

__tokens = {1051: (u'python:view.show_lab_name', 28, 46), 1132: (u'python:view.lab_name', 29, 52), 1380: (u'view/action', 36, 43), 1400: (u' view/enctyp', 36, 63), 1463: (u'view/widgets/values', 38, 44), 1536: (u"python:widget.mode == 'hidden'", 40, 48), 1623: (u'not:hidden', 41, 53), 1737: (u'widget/error', 44, 45), 1801: (u"python:'field' + (error and ' error' or '')", 45, 49), 1998: (u'not:hidden', 49, 46), 1940: (u'widget/id', 48, 51), 2108: (u'widget/label', 51, 45), 2261: (u'python:widget.required and not hidden', 53, 47), 2545: (u'widget/field/description', 58, 53), 2720: (u'description', 61, 44), 2662: (u'description', 60, 42), 3060: (u'python:view.get_icon_class_for(widget)', 68, 55), 3244: (u'python:widget.render()', 71, 68), 3416: (u'error', 75, 44), 3476: (u'error/render', 76, 52), 3705: (u'hidden', 85, 42), 3764: (u'widget/render', 86, 50), 3894: (u'context/@@authenticator/authenticator', 90, 45), 4032: (u'view/actions/values|nothing', 93, 50), 4127: (u'action/render', 94, 64), 4335: (u'context/@@plone_portal_state', 101, 42), 4400: (u' portal_state/portal_ur', 102, 34), 4638: (u'string:${portal_url}/@@login-help', 105, 60), 4831: (u'python:view.self_registration_enabled()', 108, 32), 5028: (u'string:${portal_url}/@@register', 110, 58), 293: (u'here/main_template/macros/master', 7, 23), 293: (u'here/main_template/macros/master', 7, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_138366755942032 = u'master'
_static_138366755925776 = {u'class': u'input-group-prepend', }
_static_138366839387408 = {u'style': u'display:none', u'class': u'portalMessage error pat-cookietrigger alert alert-danger m-1', }
_static_138366755253008 = {u'class': u'input-group-text', }
_static_138366756045392 = {u'class': u'field form-group', }
_static_138366756133456 = {u'href': u'@@register', u'class': u'emph', }
_static_138366756287760 = {u'class': u'required horizontal', u'title': u'Required', }
_static_138366756048016 = {u'type': u'hidden', }
_static_138366755925520 = {u'class': u'formHelp form-text text-muted', }
_static_138366755729232 = {u'id': u'login-form', u'class': u'card my-4', }
_static_138366756270800 = {u'class': u'form-text small text-danger', }
_static_138366930725392 = __C2ZContextWrapper
_static_138366755861264 = {u'class': u'card-footer small', }
_static_138367014417552 = {}
_static_138366753819792 = {u'action': u'.', u'enctype': u'view/enctype', u'method': u'post', u'class': u'loginform', }
_static_138366756048208 = {u'for': u'', }
_static_138366756234064 = {u'class': u'form-text text-muted', }
_static_138366756045968 = {u'class': u'mb-3', }
_static_138366756132048 = {u'class': u'form-text text-muted', }
_static_138366755727696 = {u'class': u'col-sm-4 offset-sm-4', }
_static_138366930725008 = __compile_zt_expr
_static_138366756131536 = {u'href': u'@@login-help', }
_static_138366753818576 = {u'class': u'dashed', }
_static_138366755923472 = {u'class': u'widget input-group flex-nowrap', }
_static_138366756237200 = {u'type': u'submit', }
_static_138366756272528 = {u'class': u'formControls', }
_static_138366753817168 = {u'class': u'card-title', }
_static_138366753837136 = {u'class': u'card-body', }
_static_138366755253904 = {u'class': u'python:view.get_icon_class_for(widget)', }
_static_138366755253520 = {u'type': u'text', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_main(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755728144
            __attrs_138366755728144 = _static_138367014417552
            __append(u'\r\n\r\n        ')

            # <Static value=<_ast.Dict object at 0x7dd80552e950> name=None at 7dd80552e990> -> __attrs_138366755728528
            __attrs_138366755728528 = _static_138366755727696

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-sm-4 offset-sm-4">\r\n          ')

            # <Static value=<_ast.Dict object at 0x7dd80552ef50> name=None at 7dd80552e790> -> __attrs_138366756546832
            __attrs_138366756546832 = _static_138366755729232

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="login-form" class="card my-4">\r\n\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80a4f7510> name=None at 7dd80558b990> -> __attrs_138366753837776
            __attrs_138366753837776 = _static_138366839387408

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="portalMessage error pat-cookietrigger alert alert-danger m-1" style="display:none">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366753838800
            __attrs_138366753838800 = _static_138367014417552

            # <strong ... (0:0)
            # --------------------------------------------------------
            __append(u'<strong>')
            __stream_138366753840400 = []
            __append_138366753840400 = __stream_138366753840400.append
            __append_138366753840400(u'\r\n                Error\r\n              ')
            __msgid_138366753840400 = __re_whitespace(''.join(__stream_138366753840400)).strip()
            if __msgid_138366753840400:
                __append(translate(__msgid_138366753840400, mapping=None, default=__msgid_138366753840400, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</strong>\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366753837712
            __attrs_138366753837712 = _static_138367014417552
            __stream_138366753838288 = []
            __append_138366753838288 = __stream_138366753838288.append
            __append_138366753838288(u'\r\n                Cookies are not enabled. You must enable cookies before you can log in.\r\n              ')
            __msgid_138366753838288 = __re_whitespace(''.join(__stream_138366753838288)).strip()
            if u'enable_cookies_message_before_login':
                __append(translate(u'enable_cookies_message_before_login', mapping=None, default=__msgid_138366753838288, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\r\n            </div>\r\n\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd805361050> name=None at 7dd805361150> -> __attrs_138366753819472
            __attrs_138366753819472 = _static_138366753837136

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="card-body">\r\n\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366753820432
            __attrs_138366753820432 = _static_138367014417552

            # <Value u'python:view.show_lab_name' (28:46)> -> __condition
            __token = 1051
            try:
                __zt_tmp = __attrs_138366753820432
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_138366930725008('python', u'view.show_lab_name', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if __condition:
                __append(u'\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd80535c250> name=None at 7dd80535ca90> -> __attrs_138366753818896
                __attrs_138366753818896 = _static_138366753817168

                # <h5 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h5 class="card-title">')

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366753820304
                __default_138366753820304 = _DEFAULT_MARKER

                # <Value u'python:view.lab_name' (29:52)> -> __cache_138366753818320
                __token = 1132
                try:
                    __zt_tmp = __attrs_138366753818896
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_138366753818320 = _static_138366930725008('python', u'view.lab_name', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.lab_name' (29:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80535c110> -> __condition
                __expression = __cache_138366753818320

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    pass
                else:
                    __content = __cache_138366753818320
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</h5>\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd80535c7d0> name=None at 7dd80535c290> -> __attrs_138366753820112
                __attrs_138366753820112 = _static_138366753818576

                # <hr ... (0:0)
                # --------------------------------------------------------
                __append(u'<hr class="dashed"/>\r\n              ')
            __append(u'\r\n\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd80535cc90> name=None at 7dd80535c990> -> __attrs_138366755861456
            __attrs_138366755861456 = _static_138366753819792

            # <form ... (0:0)
            # --------------------------------------------------------
            __append(u'<form')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755863760
            __default_138366755863760 = _DEFAULT_MARKER

            # <Substitution u'view/action' (36:43)> -> __attr_action
            __token = 1380
            try:
                __zt_tmp = __attrs_138366755861456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_action = _static_138366930725008('path', u'view/action', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_action = __quote(__attr_action, '"', '&quot;', u'.', _DEFAULT_MARKER)
            if (__attr_action is not None):
                __append((u' action="%s"' % __attr_action))
            __append(u'                     method="post"                     class="loginform"')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755861776
            __default_138366755861776 = _DEFAULT_MARKER

            # <Substitution u'view/enctype' (36:63)> -> __attr_enctype
            __token = 1400
            try:
                __zt_tmp = __attrs_138366755861456
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_enctype = _static_138366930725008('path', u'view/enctype', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_enctype = __quote(__attr_enctype, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_enctype is not None):
                __append((u' enctype="%s"' % __attr_enctype))
            __append(u'>\r\n\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755863184
            __attrs_138366755863184 = _static_138367014417552
            __backup_widget_138366756623248 = get('widget', __marker)

            # <Value u'view/widgets/values' (38:44)> -> __iterator
            __token = 1463
            try:
                __zt_tmp = __attrs_138366755863184
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_138366930725008('path', u'view/widgets/values', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            (__iterator, ____index_138366755863312, ) = getitem('repeat')(u'widget', __iterator)
            econtext['widget'] = None
            for __item in __iterator:
                econtext['widget'] = __item
                __append(u'\r\n\r\n                  ')

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755860688
                __attrs_138366755860688 = _static_138367014417552
                __backup_hidden_138366755862160 = get('hidden', __marker)

                # <Value u"python:widget.mode == 'hidden'" (40:48)> -> __value
                __token = 1536
                try:
                    __zt_tmp = __attrs_138366755860688
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_138366930725008('python', u"widget.mode == 'hidden'", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                econtext['hidden'] = __value
                __append(u'\r\n                    ')

                # <Static value=<_ast.Dict object at 0x7dd80557c490> name=None at 7dd80557cf10> -> __attrs_138366756048464
                __attrs_138366756048464 = _static_138366756045968

                # <Value u'not:hidden' (41:53)> -> __condition
                __token = 1623
                try:
                    __zt_tmp = __attrs_138366756048464
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('not', u'hidden', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="mb-3">\r\n\r\n                      ')

                    # <Static value=<_ast.Dict object at 0x7dd80557c250> name=None at 7dd80557c210> -> __attrs_138366756047888
                    __attrs_138366756047888 = _static_138366756045392
                    __backup_error_138366756271312 = get('error', __marker)

                    # <Value u'widget/error' (44:45)> -> __value
                    __token = 1737
                    try:
                        __zt_tmp = __attrs_138366756047888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_138366930725008('path', u'widget/error', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    econtext['error'] = __value

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756047120
                    __default_138366756047120 = _DEFAULT_MARKER

                    # <Substitution u"python:'field' + (error and ' error' or '')" (45:49)> -> __attr_class
                    __token = 1801
                    try:
                        __zt_tmp = __attrs_138366756047888
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_138366930725008('python', u"'field' + (error and ' error' or '')", econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', u'field form-group', _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'>\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd80557cd50> name=None at 7dd80557c710> -> __attrs_138366756136400
                    __attrs_138366756136400 = _static_138366756048208

                    # <Value u'not:hidden' (49:46)> -> __condition
                    __token = 1998
                    try:
                        __zt_tmp = __attrs_138366756136400
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_138366930725008('not', u'hidden', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    if __condition:

                        # <label ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<label')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756048336
                        __default_138366756048336 = _DEFAULT_MARKER

                        # <Substitution u'widget/id' (48:51)> -> __attr_for
                        __token = 1940
                        try:
                            __zt_tmp = __attrs_138366756136400
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_for = _static_138366930725008('path', u'widget/id', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        __attr_for = __quote(__attr_for, '"', '&quot;', u'', _DEFAULT_MARKER)
                        if (__attr_for is not None):
                            __append((u' for="%s"' % __attr_for))
                        __append(u'>\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756290256
                        __attrs_138366756290256 = _static_138367014417552

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756287504
                        __default_138366756287504 = _DEFAULT_MARKER

                        # <Value u'widget/label' (51:45)> -> __cache_138366756138128
                        __token = 2108
                        try:
                            __zt_tmp = __attrs_138366756290256
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366756138128 = _static_138366930725008('path', u'widget/label', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'widget/label' (51:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd805592f90> -> __condition
                        __expression = __cache_138366756138128

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'label')
                        else:
                            __content = __cache_138366756138128
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>\r\n                          ')

                        # <Static value=<_ast.Dict object at 0x7dd8055b7510> name=None at 7dd8055b7cd0> -> __attrs_138366755924816
                        __attrs_138366755924816 = _static_138366756287760

                        # <Value u'python:widget.required and not hidden' (53:47)> -> __condition
                        __token = 2261
                        try:
                            __zt_tmp = __attrs_138366755924816
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __condition = _static_138366930725008('python', u'widget.required and not hidden', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                        if __condition:

                            # <span ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<span class="required horizontal"')

                            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756290384
                            __default_138366756290384 = _DEFAULT_MARKER

                            # <Translate msgid=u'title_required' node=<_ast.Str object at 0x7dd8055b7110> at 7dd8055b77d0> -> __attr_title
                            __attr_title = u'Required'
                            __attr_title = translate(u'title_required', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            if (__attr_title is not None):
                                __append((u' title="%s"' % __attr_title))
                            __append(u'>&nbsp;</span>')
                        __append(u'\r\n                        </label>')
                    __append(u'\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd80555ee10> name=None at 7dd80555e7d0> -> __attrs_138366755922128
                    __attrs_138366755922128 = _static_138366755925520
                    __backup_description_138366755922192 = get('description', __marker)

                    # <Value u'widget/field/description' (58:53)> -> __value
                    __token = 2545
                    try:
                        __zt_tmp = __attrs_138366755922128
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_138366930725008('path', u'widget/field/description', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    econtext['description'] = __value

                    # <Value u'description' (61:44)> -> __condition
                    __token = 2720
                    try:
                        __zt_tmp = __attrs_138366755922128
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_138366930725008('path', u'description', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="formHelp form-text text-muted">')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755924432
                        __default_138366755924432 = _DEFAULT_MARKER

                        # <Value u'description' (60:42)> -> __cache_138366756137168
                        __token = 2662
                        try:
                            __zt_tmp = __attrs_138366755922128
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366756137168 = _static_138366930725008('path', u'description', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'description' (60:42)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80555ef50> -> __condition
                        __expression = __cache_138366756137168

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n                          field description\r\n                        ')
                        else:
                            __content = __cache_138366756137168
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    if (__backup_description_138366755922192 is __marker):
                        del econtext['description']
                    else:
                        econtext['description'] = __backup_description_138366755922192
                    __append(u'\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd80555e610> name=None at 7dd80555e410> -> __attrs_138366755925712
                    __attrs_138366755925712 = _static_138366755923472

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="widget input-group flex-nowrap">\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x7dd80555ef10> name=None at 7dd80555ec90> -> __attrs_138366755250640
                    __attrs_138366755250640 = _static_138366755925776

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-prepend">\r\n                            ')

                    # <Static value=<_ast.Dict object at 0x7dd8054bab10> name=None at 7dd8054bab50> -> __attrs_138366755253328
                    __attrs_138366755253328 = _static_138366755253008

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="input-group-text">\r\n                              ')

                    # <Static value=<_ast.Dict object at 0x7dd8054bae90> name=None at 7dd8054bae50> -> __attrs_138366755251152
                    __attrs_138366755251152 = _static_138366755253904

                    # <i ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<i')

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755251600
                    __default_138366755251600 = _DEFAULT_MARKER

                    # <Substitution u'python:view.get_icon_class_for(widget)' (68:55)> -> __attr_class
                    __token = 3060
                    try:
                        __zt_tmp = __attrs_138366755251152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_class = _static_138366930725008('python', u'view.get_icon_class_for(widget)', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_class is not None):
                        __append((u' class="%s"' % __attr_class))
                    __append(u'></i>\r\n                            </div>\r\n                          </div>\r\n                          ')

                    # <Static value=<_ast.Dict object at 0x7dd8054bad10> name=None at 7dd8054bad50> -> __attrs_138366756272656
                    __attrs_138366756272656 = _static_138366755253520

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755254032
                    __default_138366755254032 = _DEFAULT_MARKER

                    # <Value u'python:widget.render()' (71:68)> -> __cache_138366755252368
                    __token = 3244
                    try:
                        __zt_tmp = __attrs_138366756272656
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366755252368 = _static_138366930725008('python', u'widget.render()', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'python:widget.render()' (71:68)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8054ba950> -> __condition
                    __expression = __cache_138366755252368

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="text" />')
                    else:
                        __content = __cache_138366755252368
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                    __append(u'\r\n                        </div>\r\n\r\n                        ')

                    # <Static value=<_ast.Dict object at 0x7dd8055b32d0> name=None at 7dd8055b33d0> -> __attrs_138366756272720
                    __attrs_138366756272720 = _static_138366756270800

                    # <Value u'error' (75:44)> -> __condition
                    __token = 3416
                    try:
                        __zt_tmp = __attrs_138366756272720
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_138366930725008('path', u'error', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                    if __condition:

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="form-text small text-danger">')

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756272272
                        __default_138366756272272 = _DEFAULT_MARKER

                        # <Value u'error/render' (76:52)> -> __cache_138366755924240
                        __token = 3476
                        try:
                            __zt_tmp = __attrs_138366756272720
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_138366755924240 = _static_138366930725008('path', u'error/render', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                        # <BinOp left=<Value u'error/render' (76:52)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8055b37d0> -> __condition
                        __expression = __cache_138366755924240

                        # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            __append(u'\r\n                          Error\r\n                        ')
                        else:
                            __content = __cache_138366755924240
                            __content = __convert(__content)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</div>')
                    __append(u'\r\n\r\n                      </div>')
                    if (__backup_error_138366756271312 is __marker):
                        del econtext['error']
                    else:
                        econtext['error'] = __backup_error_138366756271312
                    __append(u'\r\n\r\n                    </div>')
                __append(u'\r\n\r\n                    ')

                # <Static value=<_ast.Dict object at 0x7dd80557cc90> name=None at 7dd80557c5d0> -> __attrs_138366756272592
                __attrs_138366756272592 = _static_138366756048016

                # <Value u'hidden' (85:42)> -> __condition
                __token = 3705
                try:
                    __zt_tmp = __attrs_138366756272592
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_138366930725008('path', u'hidden', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                if __condition:

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756270928
                    __default_138366756270928 = _DEFAULT_MARKER

                    # <Value u'widget/render' (86:50)> -> __cache_138366756272976
                    __token = 3764
                    try:
                        __zt_tmp = __attrs_138366756272592
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_138366756272976 = _static_138366930725008('path', u'widget/render', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                    # <BinOp left=<Value u'widget/render' (86:50)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8055b3390> -> __condition
                    __expression = __cache_138366756272976

                    # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden" />')
                    else:
                        __content = __cache_138366756272976
                        __content = __convert(__content)
                        if (__content is not None):
                            __append(__content)
                __append(u'\r\n                  ')
                if (__backup_hidden_138366755862160 is __marker):
                    del econtext['hidden']
                else:
                    econtext['hidden'] = __backup_hidden_138366755862160
                __append(u'\r\n\r\n                ')
                ____index_138366755863312 -= 1
                if (____index_138366755863312 > 0):
                    __append('')
            if (__backup_widget_138366756623248 is __marker):
                del econtext['widget']
            else:
                econtext['widget'] = __backup_widget_138366756623248
            __append(u'\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755862672
            __attrs_138366755862672 = _static_138367014417552

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366755861072
            __default_138366755861072 = _DEFAULT_MARKER

            # <Value u'context/@@authenticator/authenticator' (90:45)> -> __cache_138366755864144
            __token = 3894
            try:
                __zt_tmp = __attrs_138366755862672
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_138366755864144 = _static_138366930725008('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

            # <BinOp left=<Value u'context/@@authenticator/authenticator' (90:45)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd80554f7d0> -> __condition
            __expression = __cache_138366755864144

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
            __value = _DEFAULT_MARKER
            __condition = (__expression is __value)
            if __condition:

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span/>')
            else:
                __content = __cache_138366755864144
                __content = __convert(__content)
                if (__content is not None):
                    __append(__content)
            __append(u'\r\n\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd8055b3990> name=None at 7dd8055b3fd0> -> __attrs_138366756234192
            __attrs_138366756234192 = _static_138366756272528

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="formControls">\r\n                  ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756233296
            __attrs_138366756233296 = _static_138367014417552
            __backup_action_138366756547408 = get('action', __marker)

            # <Value u'view/actions/values|nothing' (93:50)> -> __iterator
            __token = 4032
            try:
                __zt_tmp = __attrs_138366756233296
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_138366930725008('path', u'view/actions/values|nothing', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            (__iterator, ____index_138366756235856, ) = getitem('repeat')(u'action', __iterator)
            econtext['action'] = None
            for __item in __iterator:
                econtext['action'] = __item
                __append(u'\r\n                    ')

                # <Static value=<_ast.Dict object at 0x7dd8055aaf90> name=None at 7dd8055aa850> -> __attrs_138366756235152
                __attrs_138366756235152 = _static_138366756237200

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756234832
                __default_138366756234832 = _DEFAULT_MARKER

                # <Value u'action/render' (94:64)> -> __cache_138366756233808
                __token = 4127
                try:
                    __zt_tmp = __attrs_138366756235152
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_138366756233808 = _static_138366930725008('path', u'action/render', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))

                # <BinOp left=<Value u'action/render' (94:64)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7dd814bf8110> at 7dd8055aa4d0> -> __condition
                __expression = __cache_138366756233808

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="submit" />')
                else:
                    __content = __cache_138366756233808
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n                  ')
                ____index_138366756235856 -= 1
                if (____index_138366756235856 > 0):
                    __append('')
            if (__backup_action_138366756547408 is __marker):
                del econtext['action']
            else:
                econtext['action'] = __backup_action_138366756547408
            __append(u'\r\n                </div>\r\n              </form>\r\n            </div>\r\n\r\n            ')

            # <Static value=<_ast.Dict object at 0x7dd80554f310> name=None at 7dd80535ccd0> -> __attrs_138366756234512
            __attrs_138366756234512 = _static_138366755861264
            __backup_portal_state_138366756137232 = get('portal_state', __marker)

            # <Value u'context/@@plone_portal_state' (101:42)> -> __value
            __token = 4335
            try:
                __zt_tmp = __attrs_138366756234512
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('path', u'context/@@plone_portal_state', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['portal_state'] = __value
            __backup_portal_url_138366755941264 = get('portal_url', __marker)

            # <Value u'portal_state/portal_url' (102:34)> -> __value
            __token = 4400
            try:
                __zt_tmp = __attrs_138366756234512
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_138366930725008('path', u'portal_state/portal_url', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            econtext['portal_url'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="card-footer small">\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd8055aa350> name=None at 7dd8055aa410> -> __attrs_138366756130000
            __attrs_138366756130000 = _static_138366756234064

            # <p ... (0:0)
            # --------------------------------------------------------
            __append(u'<p class="form-text text-muted">\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756131856
            __attrs_138366756131856 = _static_138367014417552
            __stream_138366756131600 = []
            __append_138366756131600 = __stream_138366756131600.append
            __append_138366756131600(u'Trouble logging in?')
            __msgid_138366756131600 = __re_whitespace(''.join(__stream_138366756131600)).strip()
            if u'trouble_logging_in':
                __append(translate(u'trouble_logging_in', mapping=None, default=__msgid_138366756131600, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'\r\n                ')

            # <Static value=<_ast.Dict object at 0x7dd8055912d0> name=None at 7dd8055911d0> -> __attrs_138366756132560
            __attrs_138366756132560 = _static_138366756131536

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a')

            # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756132304
            __default_138366756132304 = _DEFAULT_MARKER

            # <Substitution u'string:${portal_url}/@@login-help' (105:60)> -> __attr_href
            __token = 4638
            try:
                __zt_tmp = __attrs_138366756132560
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_138366930725008('string', u'${portal_url}/@@login-help', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'@@login-help', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'>')
            __stream_138366756132176 = []
            __append_138366756132176 = __stream_138366756132176.append
            __append_138366756132176(u'Get help')
            __msgid_138366756132176 = __re_whitespace(''.join(__stream_138366756132176)).strip()
            if u'footer_login_link_get_help':
                __append(translate(u'footer_login_link_get_help', mapping=None, default=__msgid_138366756132176, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>.\r\n              </p>\r\n              ')

            # <Static value=<_ast.Dict object at 0x7dd8055914d0> name=None at 7dd805591790> -> __attrs_138366756134544
            __attrs_138366756134544 = _static_138366756132048

            # <Value u'python:view.self_registration_enabled()' (108:32)> -> __condition
            __token = 4831
            try:
                __zt_tmp = __attrs_138366756134544
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_138366930725008('python', u'view.self_registration_enabled()', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            if __condition:

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="form-text text-muted">\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366756133392
                __attrs_138366756133392 = _static_138367014417552
                __stream_138366756133904 = []
                __append_138366756133904 = __stream_138366756133904.append
                __append_138366756133904(u'Need an account?')
                __msgid_138366756133904 = __re_whitespace(''.join(__stream_138366756133904)).strip()
                if u'need_an_account':
                    __append(translate(u'need_an_account', mapping=None, default=__msgid_138366756133904, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'\r\n                ')

                # <Static value=<_ast.Dict object at 0x7dd805591a50> name=None at 7dd805591b50> -> __attrs_138366754874960
                __attrs_138366754874960 = _static_138366756133456

                # <a ... (0:0)
                # --------------------------------------------------------
                __append(u'<a')

                # <Symbol value=<DEFAULT> at 7dd814bf8110> -> __default_138366756131472
                __default_138366756131472 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/@@register' (110:58)> -> __attr_href
                __token = 5028
                try:
                    __zt_tmp = __attrs_138366754874960
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_138366930725008('string', u'${portal_url}/@@register', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', u'@@register', _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' class="emph">')
                __stream_138366756133264 = []
                __append_138366756133264 = __stream_138366756133264.append
                __append_138366756133264(u'Sign up here')
                __msgid_138366756133264 = __re_whitespace(''.join(__stream_138366756133264)).strip()
                if u'footer_login_link_signup':
                    __append(translate(u'footer_login_link_signup', mapping=None, default=__msgid_138366756133264, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</a>.\r\n              </p>')
            __append(u'\r\n            </div>')
            if (__backup_portal_url_138366755941264 is __marker):
                del econtext['portal_url']
            else:
                econtext['portal_url'] = __backup_portal_url_138366755941264
            if (__backup_portal_state_138366756137232 is __marker):
                del econtext['portal_state']
            else:
                econtext['portal_state'] = __backup_portal_state_138366756137232
            __append(u'\r\n\r\n          </div>\r\n        </div>\r\n\r\n      ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755939664
            __attrs_138366755939664 = _static_138367014417552
            __previous_i18n_domain_138366755941200 = __i18n_domain
            __i18n_domain = u'plone'
            __backup_macroname_138366803450208 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7dd805562e90> name=None at 7dd805562f10> -> __value
            __value = _static_138366755942032
            econtext['macroname'] = __value

            def __fill_main(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7dd814be3490> name=None at 7dd814be3ed0> -> __attrs_138366755725584
                __attrs_138366755725584 = _static_138367014417552
                __append(u'\r\n      ')
                __token = None
                render_main(__stream, econtext.copy(), rcontext, __i18n_domain)
                econtext.update(rcontext)
                __append(u'\r\n    ')
            _slots = econtext[u'__slot_main'] = _deque((__fill_main, ))

            # <Value u'here/main_template/macros/master' (7:23)> -> __macro
            __token = 293
            try:
                __zt_tmp = __attrs_138366755939664
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_138366930725008('path', u'here/main_template/macros/master', econtext=econtext)(_static_138366930725392(econtext, __zt_tmp))
            __token = 293
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_138366803450208 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_138366803450208
            __i18n_domain = __previous_i18n_domain_138366755941200
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_main': render_main, 'render': render, }