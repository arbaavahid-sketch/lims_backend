# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/edit_macros.pt'

__tokens = {3331: (u'portal_type|string:unknowntype', 87, 33), 3284: (u'not:isLocked', 86, 24), 3518: (u"python:context.absolute_url()+'/'+template.id", 92, 35), 3595: (u' string:${portal_type}-base-edi', 93, 30), 3717: (u'provider:archetypes.edit.beforefieldsets', 97, 36), 3910: (u'options/state/getErrors', 101, 41), 3984: (u' python:[context.getField(field).schemata for field in errors.keys()', 102, 49), 3844: (u'allow_tabbing | nothing', 100, 37), 4201: (u'fieldsets', 105, 46), 4425: (u'python:view.normalizeString(fieldset)', 111, 36), 4506: (u" python:repeat['fieldset'].start and 'nav-link active' or 'nav-link", 112, 42), 4623: (u"s python:'text-danger' if  fieldset in error_fieldsets else ", 113, 47), 4868: (u' string:#${id', 116, 41), 4925: (u's string:${css_class} ${error_css_clas', 117, 41), 4809: (u'string:${id}-tab', 115, 40), 4721: (u'python:view.getTranslatedSchemaLabel(fieldset)', 114, 34), 5185: (u'fieldsets', 124, 46), 5233: (u'python:view.normalizeString(fieldset)', 125, 36), 5312: (u'string:${id}', 126, 40), 5368: (u" python:repeat['fieldset'].start and 'tab-pane fade show active' or 'tab-pane fade", 127, 42), 5535: (u'python:schematas[fieldset].editableFields(here, visible_only=True)', 129, 44), 5653: (u"python:context.widget(field.getName(), mode='edit')", 130, 49), 5653: (u"python:context.widget(field.getName(), mode='edit')", 130, 49), 5879: (u'not: allow_tabbing | nothing', 137, 40), 5948: (u'python:schematas[fieldset].editableFields(here, visible_only=True)', 138, 38), 6060: (u"python:context.widget(field.getName(), mode='edit')", 139, 43), 6060: (u"python:context.widget(field.getName(), mode='edit')", 139, 43), 6230: (u'provider:archetypes.edit.afterfieldsets', 145, 36), 6404: (u'fieldsets', 150, 42), 6566: (u'fieldset', 154, 41), 6752: (u'python: fieldsets', 160, 32), 6710: (u'fieldset', 159, 39), 7248: (u'request/controller_state/kwargs', 178, 31), 7320: (u"python:('reference_source_url', 'reference_source_field', 'reference_source_fieldset')", 179, 38), 7452: (u'python:env.get(varname, request.get(varname))', 180, 43), 7539: (u'items', 181, 40), 7587: (u'items', 182, 40), 7830: (u' string:form_env.${varname}:list:recor', 187, 39), 7785: (u'item', 186, 45), 7999: (u'nothing', 193, 32), 8139: (u'request/controller_state/kwargs/items', 196, 31), 8310: (u'python:env[0]', 200, 35), 8355: (u' python:env[1', 201, 30), 8405: (u"python:key.startswith('persistent_')", 202, 34), 8483: (u'string:form_env.${key}:record', 203, 40), 8544: (u' valu', 204, 30), 8621: (u'nothing', 208, 32), 8761: (u'request/form', 211, 31), 8815: (u"python:key.startswith('persistent_')", 212, 39), 8996: (u'request/?key', 216, 39), 9052: (u'string:form_env.${key}:record', 217, 42), 9115: (u' valu', 218, 32), 9224: (u'nothing', 223, 32), 9425: (u"python:request.form.get('last_referer', request.get('HTTP_REFERER'))", 228, 42), 9534: (u"python:(last_referer and '%s/%s' % (context.absolute_url(), template.id) not in last_referer) and last_referer or (context.getParentNode() and context.getParentNode().absolute_url())", 229, 39), 9890: (u'python:fieldset in fieldsets and fieldsets.index(fieldset)', 236, 52), 9998: (u' python:len(fieldsets', 237, 48), 10062: (u'python:fieldset_index &gt', 239, 38), 10389: (u"python:test(isLocked, 'disabled', None)", 245, 47), 10488: (u'python:not allow_tabbing and (fieldset_index &lt; n_fieldsets -', 247, 38), 10841: (u"python:test(isLocked, 'disabled', None)", 253, 47), 11178: (u"python:test(isLocked, 'disabled', None)", 260, 47), 677: (u'python:context.checkCreationFlag()', 22, 27), 797: (u'python:context.portal_types.getTypeInfo(here)', 25, 32), 912: (u'fti/Title', 27, 31), 1109: (u'python: not context.checkCreationFlag()', 32, 27), 1235: (u'python:context.portal_types.getTypeInfo(here)', 35, 32), 1350: (u'fti/Title', 37, 31), 1511: (u'context/@@plone/isDefaultPageInFolder|nothing', 43, 28), 2020: (u'string:${context/aq_inner/aq_parent/absolute_url}/edit', 53, 36), 2213: (u'python: fieldsets and not allow_tabbing', 60, 26), 2287: (u'fieldsets', 61, 32), 2333: (u"python:fset == fieldset and fieldsets != ['default']", 62, 34), 2428: (u'fset', 63, 40), 2523: (u'python:fset != fieldset', 65, 33), 2594: (u'string:${context/absolute_url}/${template/getId}?fieldset=${fset}', 66, 45), 2696: (u'fset', 67, 34), 2932: (u'python:context.portal_types.getTypeInfo(here)', 76, 39), 3018: (u' fti/Descriptio', 77, 39), 3075: (u'desc', 78, 38), 3141: (u'desc', 79, 59)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757071477584 = {u'lang': u'en', u'xmlns': u'http://www.w3.org/1999/xhtml', u'xml:lang': u'en', }
_static_135757074793680 = {u'action': u'', u'id': u'string:${portal_type}-base-edit', u'enctype': u'multipart/form-data', u'name': u'edit_form', u'method': u'post', }
_static_135757071413840 = {u'type': u'hidden', u'name': u'add_reference.destination:record', u'value': u'', }
_static_135757074659984 = {u'type': u'hidden', u'name': u'last_referer', u'value': u"python:(last_referer and '%s/%s' % (context.absolute_url(), template.id) not in last_referer) and last_referer or (context.getParentNode() and context.getParentNode().absolute_url())", }
_static_135756868937872 = {u'class': u'nav-item', }
_static_135757074548752 = {u'href': u'', u'class': u'alert-link', }
_static_135757071473168 = {u'disabled': u"python:test(isLocked, 'disabled', None)", u'type': u'submit', u'class': u'btn btn-sm btn-outline-secondary', u'value': u'Previous', u'name': u'form.button.previous', }
_static_135757075872336 = {u'type': u'hidden', u'name': u'form_env.reference_source_url:list:record', u'value': u'value', }
_static_135757075202576 = u"python:context.widget(field.getName(), mode='edit')"
_static_135756868939152 = {u'class': u'tab-content', }
_static_135757075196880 = {u'type': u'hidden', u'name': u'form.submitted', u'value': u'1', }
_static_135757075203408 = {u'type': u'hidden', u'name': u'fieldset', u'value': u'fieldset', }
_static_135757075204880 = u"python:context.widget(field.getName(), mode='edit')"
_static_135757327983760 = {}
_static_135757071417040 = {u'type': u'hidden', u'name': u'add_reference.type:record', u'value': u'', }
_static_135757075195984 = {u'type': u'hidden', u'name': u'add_reference.field:record', u'value': u'', }
_static_135757075202960 = {u'class': u'formControls', }
_static_135757074657680 = {u'type': u'hidden', u'name': u'key', u'value': u'value', }
_static_135757244280656 = __compile_zt_expr
_static_135757074925200 = {u'role': u'tablist', u'class': u'nav nav-tabs', }
_static_135757071472784 = {u'disabled': u"python:test(isLocked, 'disabled', None)", u'type': u'submit', u'class': u'btn btn-sm btn-outline-secondary', u'value': u'Next', u'name': u'form.button.next', }
_static_135757075857232 = {u'disabled': u"python:test(isLocked, 'disabled', None)", u'type': u'submit', u'class': u'btn btn-sm btn-primary', u'value': u'Save', u'name': u'form.button.save', }
_static_135757073363792 = {u'role': u'tabpanel', u'id': u'string:${id}', u'class': u"python:repeat['fieldset'].start and 'tab-pane fade show active' or 'tab-pane fade'", }
_static_135756868937488 = {u'data-toggle': u'tab', u'href': u'', u'role': u'tab', u'class': u'nav-link', u'id': u'string:${id}-tab', }
_static_135757074550672 = {u'omit-tag': u'', }
_static_135757075920656 = {u'class': u'alert alert-info', }
_static_135757075854160 = {u'type': u'submit', u'class': u'btn btn-sm btn-secondary', u'value': u'Cancel', u'name': u'form.button.cancel', }
_static_135757150056144 = {u'class': u'documentFirstHeading', }
_static_135757075749840 = {u'type': u'hidden', u'name': u'fieldsets:list', u'value': u'default', }
_static_135757075193680 = {u'type': u'hidden', u'name': u'key', u'value': u'value', }
_static_135757074879248 = {u'href': u'#', }
_static_135757153162128 = {u'class': u'mt-2', }
_static_135757074792656 = {u'class': u'discreet', }
_static_135757073377680 = {u'class': u'documentFirstHeading', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757075919632 = {u'id': u'archetypes-schemata-links', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_body(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_widgets = econtext[u'__slot_widgets'].pop()
        except:
            __slot_widgets = None

        try:
            __slot_extra_top = econtext[u'__slot_extra_top'].pop()
        except:
            __slot_extra_top = None

        try:
            __slot_buttons = econtext[u'__slot_buttons'].pop()
        except:
            __slot_buttons = None

        try:
            __slot_extra_inline_buttons = econtext[u'__slot_extra_inline_buttons'].pop()
        except:
            __slot_extra_inline_buttons = None

        try:
            __slot_extra_bottom = econtext[u'__slot_extra_bottom'].pop()
        except:
            __slot_extra_bottom = None

        try:
            __slot_extra_buttons = econtext[u'__slot_extra_buttons'].pop()
        except:
            __slot_extra_buttons = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074879760
            __attrs_135757074879760 = _static_135757327983760
            __backup_portal_type_135757073378896 = get('portal_type', __marker)

            # <Value u'portal_type|string:unknowntype' (87:33)> -> __value
            __token = 3331
            try:
                __zt_tmp = __attrs_135757074879760
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'portal_type|string:unknowntype', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['portal_type'] = __value

            # <Value u'not:isLocked' (86:24)> -> __condition
            __token = 3284
            try:
                __zt_tmp = __attrs_135757074879760
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('not', u'isLocked', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div>\n      ')

                # <Static value=<_ast.Dict object at 0x7b78683804d0> name=None at 7b78683805d0> -> __attrs_135757073611792
                __attrs_135757073611792 = _static_135757074793680

                # <form ... (0:0)
                # --------------------------------------------------------
                __append(u'<form name="edit_form" method="post" enctype="multipart/form-data"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074796112
                __default_135757074796112 = _DEFAULT_MARKER

                # <Substitution u"python:context.absolute_url()+'/'+template.id" (92:35)> -> __attr_action
                __token = 3518
                try:
                    __zt_tmp = __attrs_135757073611792
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_action = _static_135757244280656('python', u"context.absolute_url()+'/'+template.id", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_action = __quote(__attr_action, '"', '&quot;', u'', _DEFAULT_MARKER)
                if (__attr_action is not None):
                    __append((u' action="%s"' % __attr_action))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074795728
                __default_135757074795728 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_type}-base-edit' (93:30)> -> __attr_id
                __token = 3595
                try:
                    __zt_tmp = __attrs_135757073611792
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_135757244280656('string', u'${portal_type}-base-edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'>\n\n        ')
                if (__slot_extra_top is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073611728
                    __attrs_135757073611728 = _static_135757327983760
                else:
                    __slot_extra_top(__stream, econtext.copy(), rcontext)
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073610704
                __attrs_135757073610704 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073612112
                __default_135757073612112 = _DEFAULT_MARKER

                # <Value u'provider:archetypes.edit.beforefieldsets' (97:36)> -> __cache_135757073611280
                __token = 3717
                try:
                    __zt_tmp = __attrs_135757073610704
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757073611280 = _static_135757244280656('provider', u'archetypes.edit.beforefieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:archetypes.edit.beforefieldsets' (97:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786825f650> -> __condition
                __expression = __cache_135757073611280

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_135757073611280
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n\n        ')
                if (__slot_widgets is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073610256
                    __attrs_135757073610256 = _static_135757327983760
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074927056
                    __attrs_135757074927056 = _static_135757327983760
                    __backup_errors_135757150054160 = get('errors', __marker)

                    # <Value u'options/state/getErrors' (101:41)> -> __value
                    __token = 3910
                    try:
                        __zt_tmp = __attrs_135757074927056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('path', u'options/state/getErrors', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['errors'] = __value
                    __backup_error_fieldsets_135757075694672 = get('error_fieldsets', __marker)

                    # <Value u'python:[context.getField(field).schemata for field in errors.keys()]' (102:49)> -> __value
                    __token = 3984
                    try:
                        __zt_tmp = __attrs_135757074927056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'[context.getField(field).schemata for field in errors.keys()]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['error_fieldsets'] = __value

                    # <Value u'allow_tabbing | nothing' (100:37)> -> __condition
                    __token = 3844
                    try:
                        __zt_tmp = __attrs_135757074927056
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'allow_tabbing | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            <!-- Bootstrapped schema tabs -->\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78683a0690> name=None at 7b78683a0610> -> __attrs_135757074925456
                        __attrs_135757074925456 = _static_135757074925200

                        # <ul ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<ul class="nav nav-tabs" role="tablist">\n              ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074926416
                        __attrs_135757074926416 = _static_135757327983760
                        __backup_fieldset_135757153179280 = get('fieldset', __marker)

                        # <Value u'fieldsets' (105:46)> -> __iterator
                        __token = 4201
                        try:
                            __zt_tmp = __attrs_135757074926416
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_135757244280656('path', u'fieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        (__iterator, ____index_135757074927248, ) = getitem('repeat')(u'fieldset', __iterator)
                        econtext['fieldset'] = None
                        for __item in __iterator:
                            econtext['fieldset'] = __item
                            __append(u'\n                ')

                            # <Static value=<_ast.Dict object at 0x7b785bf2e890> name=None at 7b785bf2ee50> -> __attrs_135756868937104
                            __attrs_135756868937104 = _static_135756868937872

                            # <li ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<li class="nav-item">\n                  ')

                            # <Static value=<_ast.Dict object at 0x7b785bf2e710> name=None at 7b785bf2e750> -> __attrs_135757153146384
                            __attrs_135757153146384 = _static_135756868937488
                            __backup_id_135756868938128 = get('id', __marker)

                            # <Value u'python:view.normalizeString(fieldset)' (111:36)> -> __value
                            __token = 4425
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'view.normalizeString(fieldset)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['id'] = __value
                            __backup_css_class_135757074927504 = get('css_class', __marker)

                            # <Value u"python:repeat['fieldset'].start and 'nav-link active' or 'nav-link'" (112:42)> -> __value
                            __token = 4506
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"repeat['fieldset'].start and 'nav-link active' or 'nav-link'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['css_class'] = __value
                            __backup_error_css_class_135756868936272 = get('error_css_class', __marker)

                            # <Value u"python:'text-danger' if  fieldset in error_fieldsets else ''" (113:47)> -> __value
                            __token = 4623
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u"'text-danger' if  fieldset in error_fieldsets else ''", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['error_css_class'] = __value

                            # <a ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<a')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153147472
                            __default_135757153147472 = _DEFAULT_MARKER

                            # <Substitution u'string:#${id}' (116:41)> -> __attr_href
                            __token = 4868
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_href = _static_135757244280656('string', u'#${id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                            if (__attr_href is not None):
                                __append((u' href="%s"' % __attr_href))
                            __append(u' data-toggle="tab"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153147344
                            __default_135757153147344 = _DEFAULT_MARKER

                            # <Substitution u'string:${css_class} ${error_css_class}' (117:41)> -> __attr_class
                            __token = 4925
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_class = _static_135757244280656('string', u'${css_class} ${error_css_class}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_class = __quote(__attr_class, '"', '&quot;', u'nav-link', _DEFAULT_MARKER)
                            if (__attr_class is not None):
                                __append((u' class="%s"' % __attr_class))
                            __append(u' role="tab"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153147792
                            __default_135757153147792 = _DEFAULT_MARKER

                            # <Substitution u'string:${id}-tab' (115:40)> -> __attr_id
                            __token = 4809
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('string', u'${id}-tab', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))
                            __append(u'>')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135756868939216
                            __default_135756868939216 = _DEFAULT_MARKER

                            # <Value u'python:view.getTranslatedSchemaLabel(fieldset)' (114:34)> -> __cache_135756868938320
                            __token = 4721
                            try:
                                __zt_tmp = __attrs_135757153146384
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __cache_135756868938320 = _static_135757244280656('python', u'view.getTranslatedSchemaLabel(fieldset)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                            # <BinOp left=<Value u'python:view.getTranslatedSchemaLabel(fieldset)' (114:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b785bf2ec50> -> __condition
                            __expression = __cache_135756868938320

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                            __value = _DEFAULT_MARKER
                            __condition = (__expression is __value)
                            if __condition:
                                __append(u'\n                  ')
                            else:
                                __content = __cache_135756868938320
                                __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                                __content = __quote(__content, None, '\xad', None, None)
                                if (__content is not None):
                                    __append(__content)
                            __append(u'</a>')
                            if (__backup_error_css_class_135756868936272 is __marker):
                                del econtext['error_css_class']
                            else:
                                econtext['error_css_class'] = __backup_error_css_class_135756868936272
                            if (__backup_css_class_135757074927504 is __marker):
                                del econtext['css_class']
                            else:
                                econtext['css_class'] = __backup_css_class_135757074927504
                            if (__backup_id_135756868938128 is __marker):
                                del econtext['id']
                            else:
                                econtext['id'] = __backup_id_135756868938128
                            __append(u'\n                </li>\n              ')
                            ____index_135757074927248 -= 1
                            if (____index_135757074927248 > 0):
                                __append('')
                        if (__backup_fieldset_135757153179280 is __marker):
                            del econtext['fieldset']
                        else:
                            econtext['fieldset'] = __backup_fieldset_135757153179280
                        __append(u'\n            </ul>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b785bf2ed90> name=None at 7b78683a0a90> -> __attrs_135757153148048
                        __attrs_135757153148048 = _static_135756868939152

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="tab-content">\n              ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757150166672
                        __attrs_135757150166672 = _static_135757327983760
                        __backup_fieldset_135757074624144 = get('fieldset', __marker)

                        # <Value u'fieldsets' (124:46)> -> __iterator
                        __token = 5185
                        try:
                            __zt_tmp = __attrs_135757150166672
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_135757244280656('path', u'fieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        (__iterator, ____index_135757150166032, ) = getitem('repeat')(u'fieldset', __iterator)
                        econtext['fieldset'] = None
                        for __item in __iterator:
                            econtext['fieldset'] = __item
                            __append(u'\n                ')

                            # <Static value=<_ast.Dict object at 0x7b7868223350> name=None at 7b786cb61b90> -> __attrs_135757073363600
                            __attrs_135757073363600 = _static_135757073363792
                            __backup_id_135757074926096 = get('id', __marker)

                            # <Value u'python:view.normalizeString(fieldset)' (125:36)> -> __value
                            __token = 5233
                            try:
                                __zt_tmp = __attrs_135757073363600
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __value = _static_135757244280656('python', u'view.normalizeString(fieldset)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            econtext['id'] = __value

                            # <div ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<div role="tabpanel"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073363920
                            __default_135757073363920 = _DEFAULT_MARKER

                            # <Substitution u'string:${id}' (126:40)> -> __attr_id
                            __token = 5312
                            try:
                                __zt_tmp = __attrs_135757073363600
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_id = _static_135757244280656('string', u'${id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_id is not None):
                                __append((u' id="%s"' % __attr_id))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073364816
                            __default_135757073364816 = _DEFAULT_MARKER

                            # <Substitution u"python:repeat['fieldset'].start and 'tab-pane fade show active' or 'tab-pane fade'" (127:42)> -> __attr_class
                            __token = 5368
                            try:
                                __zt_tmp = __attrs_135757073363600
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_class = _static_135757244280656('python', u"repeat['fieldset'].start and 'tab-pane fade show active' or 'tab-pane fade'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_class = __quote(__attr_class, '"', '&quot;', None, _DEFAULT_MARKER)
                            if (__attr_class is not None):
                                __append((u' class="%s"' % __attr_class))
                            __append(u'>\n                  ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073365968
                            __attrs_135757073365968 = _static_135757327983760
                            __backup_field_135757153148112 = get('field', __marker)

                            # <Value u'python:schematas[fieldset].editableFields(here, visible_only=True)' (129:44)> -> __iterator
                            __token = 5535
                            try:
                                __zt_tmp = __attrs_135757073365968
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __iterator = _static_135757244280656('python', u'schematas[fieldset].editableFields(here, visible_only=True)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            (__iterator, ____index_135757073365328, ) = getitem('repeat')(u'field', __iterator)
                            econtext['field'] = None
                            for __item in __iterator:
                                econtext['field'] = __item
                                __append(u'\n                    ')

                                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075205136
                                __attrs_135757075205136 = _static_135757327983760
                                __backup_macroname_135757115923664 = get('macroname', __marker)

                                # <Static value=<_ast.Str object at 0x7b78683e4210> name=None at 7b78683e4f10> -> __value
                                __value = _static_135757075202576
                                econtext['macroname'] = __value

                                # <Value u"python:context.widget(field.getName(), mode='edit')" (130:49)> -> __macro
                                __token = 5653
                                try:
                                    __zt_tmp = __attrs_135757075205136
                                except get('NameError', NameError):
                                    __zt_tmp = None

                                __macro = _static_135757244280656('python', u"context.widget(field.getName(), mode='edit')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                                __token = 5653
                                __m = __macro.include
                                __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                                econtext.update(rcontext)
                                if (__backup_macroname_135757115923664 is __marker):
                                    del econtext['macroname']
                                else:
                                    econtext['macroname'] = __backup_macroname_135757115923664
                                __append(u'\n                  ')
                                ____index_135757073365328 -= 1
                                if (____index_135757073365328 > 0):
                                    __append('')
                            if (__backup_field_135757153148112 is __marker):
                                del econtext['field']
                            else:
                                econtext['field'] = __backup_field_135757153148112
                            __append(u'\n                </div>')
                            if (__backup_id_135757074926096 is __marker):
                                del econtext['id']
                            else:
                                econtext['id'] = __backup_id_135757074926096
                            __append(u'\n              ')
                            ____index_135757150166032 -= 1
                            if (____index_135757150166032 > 0):
                                __append('')
                        if (__backup_fieldset_135757074624144 is __marker):
                            del econtext['fieldset']
                        else:
                            econtext['fieldset'] = __backup_fieldset_135757074624144
                        __append(u'\n            </div>\n          ')
                    if (__backup_error_fieldsets_135757075694672 is __marker):
                        del econtext['error_fieldsets']
                    else:
                        econtext['error_fieldsets'] = __backup_error_fieldsets_135757075694672
                    if (__backup_errors_135757150054160 is __marker):
                        del econtext['errors']
                    else:
                        econtext['errors'] = __backup_errors_135757150054160
                    __append(u'\n\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153145872
                    __attrs_135757153145872 = _static_135757327983760

                    # <Value u'not: allow_tabbing | nothing' (137:40)> -> __condition
                    __token = 5879
                    try:
                        __zt_tmp = __attrs_135757153145872
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('not', u' allow_tabbing | nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073363664
                        __attrs_135757073363664 = _static_135757327983760
                        __backup_field_135757075921488 = get('field', __marker)

                        # <Value u'python:schematas[fieldset].editableFields(here, visible_only=True)' (138:38)> -> __iterator
                        __token = 5948
                        try:
                            __zt_tmp = __attrs_135757073363664
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_135757244280656('python', u'schematas[fieldset].editableFields(here, visible_only=True)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        (__iterator, ____index_135757073365264, ) = getitem('repeat')(u'field', __iterator)
                        econtext['field'] = None
                        for __item in __iterator:
                            econtext['field'] = __item
                            __append(u'\n              ')

                            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075203152
                            __attrs_135757075203152 = _static_135757327983760
                            __backup_macroname_135757116166048 = get('macroname', __marker)

                            # <Static value=<_ast.Str object at 0x7b78683e4b10> name=None at 7b78683e4510> -> __value
                            __value = _static_135757075204880
                            econtext['macroname'] = __value

                            # <Value u"python:context.widget(field.getName(), mode='edit')" (139:43)> -> __macro
                            __token = 6060
                            try:
                                __zt_tmp = __attrs_135757075203152
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __macro = _static_135757244280656('python', u"context.widget(field.getName(), mode='edit')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __token = 6060
                            __m = __macro.include
                            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
                            econtext.update(rcontext)
                            if (__backup_macroname_135757116166048 is __marker):
                                del econtext['macroname']
                            else:
                                econtext['macroname'] = __backup_macroname_135757116166048
                            __append(u'\n            ')
                            ____index_135757073365264 -= 1
                            if (____index_135757073365264 > 0):
                                __append('')
                        if (__backup_field_135757075921488 is __marker):
                            del econtext['field']
                        else:
                            econtext['field'] = __backup_field_135757075921488
                        __append(u'\n          ')
                    __append(u'\n\n        ')
                else:
                    __slot_widgets(__stream, econtext.copy(), rcontext)
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073364176
                __attrs_135757073364176 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073366864
                __default_135757073366864 = _DEFAULT_MARKER

                # <Value u'provider:archetypes.edit.afterfieldsets' (145:36)> -> __cache_135757074926352
                __token = 6230
                try:
                    __zt_tmp = __attrs_135757073364176
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074926352 = _static_135757244280656('provider', u'archetypes.edit.afterfieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'provider:archetypes.edit.afterfieldsets' (145:36)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78683a0990> -> __condition
                __expression = __cache_135757074926352

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div />')
                else:
                    __content = __cache_135757074926352
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n\n        ')
                if (__slot_extra_bottom is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075205072
                    __attrs_135757075205072 = _static_135757327983760
                else:
                    __slot_extra_bottom(__stream, econtext.copy(), rcontext)
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b78683e4390> name=None at 7b78683e4610> -> __attrs_135757075204816
                __attrs_135757075204816 = _static_135757075202960

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="formControls">\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075204048
                __attrs_135757075204048 = _static_135757327983760
                __backup_fieldset_135757153179024 = get('fieldset', __marker)

                # <Value u'fieldsets' (150:42)> -> __iterator
                __token = 6404
                try:
                    __zt_tmp = __attrs_135757075204048
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'fieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757075203024, ) = getitem('repeat')(u'fieldset', __iterator)
                econtext['fieldset'] = None
                for __item in __iterator:
                    econtext['fieldset'] = __item
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7b7868469bd0> name=None at 7b78684696d0> -> __attrs_135757075750096
                    __attrs_135757075750096 = _static_135757075749840

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="fieldsets:list"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075749968
                    __default_135757075749968 = _DEFAULT_MARKER

                    # <Substitution u'fieldset' (154:41)> -> __attr_value
                    __token = 6566
                    try:
                        __zt_tmp = __attrs_135757075750096
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'fieldset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', u'default', _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\n          ')
                    ____index_135757075203024 -= 1
                    if (____index_135757075203024 > 0):
                        __append('')
                if (__backup_fieldset_135757153179024 is __marker):
                    del econtext['fieldset']
                else:
                    econtext['fieldset'] = __backup_fieldset_135757153179024
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78683e4550> name=None at 7b7868469e10> -> __attrs_135757075195344
                __attrs_135757075195344 = _static_135757075203408

                # <Value u'python: fieldsets' (160:32)> -> __condition
                __token = 6752
                try:
                    __zt_tmp = __attrs_135757075195344
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u' fieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="hidden" name="fieldset"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075195216
                    __default_135757075195216 = _DEFAULT_MARKER

                    # <Substitution u'fieldset' (159:39)> -> __attr_value
                    __token = 6710
                    try:
                        __zt_tmp = __attrs_135757075195344
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_135757244280656('path', u'fieldset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />')
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78683e2bd0> name=None at 7b78683e2c90> -> __attrs_135757075196496
                __attrs_135757075196496 = _static_135757075196880

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="form.submitted" value="1" />\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78683e2850> name=None at 7b78683e2cd0> -> __attrs_135757071415440
                __attrs_135757071415440 = _static_135757075195984

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="add_reference.field:record" value="" />\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b7868047ed0> name=None at 7b7868047b50> -> __attrs_135757071416848
                __attrs_135757071416848 = _static_135757071417040

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="add_reference.type:record" value="" />\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b7868047250> name=None at 7b7868047e50> -> __attrs_135757075872848
                __attrs_135757075872848 = _static_135757071413840

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="add_reference.destination:record" value="" />\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075871696
                __attrs_135757075871696 = _static_135757327983760
                __backup_env_135757073379024 = get('env', __marker)

                # <Value u'request/controller_state/kwargs' (178:31)> -> __value
                __token = 7248
                try:
                    __zt_tmp = __attrs_135757075871696
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('path', u'request/controller_state/kwargs', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['env'] = __value
                __append(u'\n            ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075871568
                __attrs_135757075871568 = _static_135757327983760
                __backup_varname_135757074926736 = get('varname', __marker)

                # <Value u"python:('reference_source_url', 'reference_source_field', 'reference_source_fieldset')" (179:38)> -> __iterator
                __token = 7320
                try:
                    __zt_tmp = __attrs_135757075871568
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('python', u"('reference_source_url', 'reference_source_field', 'reference_source_fieldset')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757075870160, ) = getitem('repeat')(u'varname', __iterator)
                econtext['varname'] = None
                for __item in __iterator:
                    econtext['varname'] = __item
                    __append(u'\n              ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075870480
                    __attrs_135757075870480 = _static_135757327983760
                    __backup_items_135757074926992 = get('items', __marker)

                    # <Value u'python:env.get(varname, request.get(varname))' (180:43)> -> __value
                    __token = 7452
                    try:
                        __zt_tmp = __attrs_135757075870480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'env.get(varname, request.get(varname))', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['items'] = __value

                    # <Value u'items' (181:40)> -> __condition
                    __token = 7539
                    try:
                        __zt_tmp = __attrs_135757075870480
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('path', u'items', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n                ')

                        # <Static value=<_ast.Dict object at 0x7b7868487a50> name=None at 7b7868487ad0> -> __attrs_135757075191120
                        __attrs_135757075191120 = _static_135757075872336
                        __backup_item_135757073366416 = get('item', __marker)

                        # <Value u'items' (182:40)> -> __iterator
                        __token = 7587
                        try:
                            __zt_tmp = __attrs_135757075191120
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __iterator = _static_135757244280656('path', u'items', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        (__iterator, ____index_135757075191888, ) = getitem('repeat')(u'item', __iterator)
                        econtext['item'] = None
                        for __item in __iterator:
                            econtext['item'] = __item

                            # <input ... (0:0)
                            # --------------------------------------------------------
                            __append(u'<input type="hidden"')

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075192144
                            __default_135757075192144 = _DEFAULT_MARKER

                            # <Substitution u'string:form_env.${varname}:list:record' (187:39)> -> __attr_name
                            __token = 7830
                            try:
                                __zt_tmp = __attrs_135757075191120
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_name = _static_135757244280656('string', u'form_env.${varname}:list:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_name = __quote(__attr_name, '"', '&quot;', u'form_env.reference_source_url:list:record', _DEFAULT_MARKER)
                            if (__attr_name is not None):
                                __append((u' name="%s"' % __attr_name))

                            # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075191952
                            __default_135757075191952 = _DEFAULT_MARKER

                            # <Substitution u'item' (186:45)> -> __attr_value
                            __token = 7785
                            try:
                                __zt_tmp = __attrs_135757075191120
                            except get('NameError', NameError):
                                __zt_tmp = None

                            __attr_value = _static_135757244280656('path', u'item', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                            __attr_value = __quote(__attr_value, '"', '&quot;', u'value', _DEFAULT_MARKER)
                            if (__attr_value is not None):
                                __append((u' value="%s"' % __attr_value))
                            __append(u' />')
                            ____index_135757075191888 -= 1
                            if (____index_135757075191888 > 0):
                                __append('\n                ')
                        if (__backup_item_135757073366416 is __marker):
                            del econtext['item']
                        else:
                            econtext['item'] = __backup_item_135757073366416
                        __append(u'\n              ')
                    if (__backup_items_135757074926992 is __marker):
                        del econtext['items']
                    else:
                        econtext['items'] = __backup_items_135757074926992
                    __append(u'\n            ')
                    ____index_135757075870160 -= 1
                    if (____index_135757075870160 > 0):
                        __append('')
                if (__backup_varname_135757074926736 is __marker):
                    del econtext['varname']
                else:
                    econtext['varname'] = __backup_varname_135757074926736
                __append(u'\n          ')
                if (__backup_env_135757073379024 is __marker):
                    del econtext['env']
                else:
                    econtext['env'] = __backup_env_135757073379024
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075871888
                __attrs_135757075871888 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075871760
                __default_135757075871760 = _DEFAULT_MARKER

                # <Value u'nothing' (193:32)> -> __cache_135757075872080
                __token = 7999
                try:
                    __zt_tmp = __attrs_135757075871888
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075872080 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'nothing' (193:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b78684872d0> -> __condition
                __expression = __cache_135757075872080

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u"\n            Turn 'persistent_' variables from controller_state persistent\n          ")
                else:
                    __content = __cache_135757075872080
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075192784
                __attrs_135757075192784 = _static_135757327983760
                __backup_env_135757073377104 = get('env', __marker)

                # <Value u'request/controller_state/kwargs/items' (196:31)> -> __iterator
                __token = 8139
                try:
                    __zt_tmp = __attrs_135757075192784
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'request/controller_state/kwargs/items', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757075190224, ) = getitem('repeat')(u'env', __iterator)
                econtext['env'] = None
                for __item in __iterator:
                    econtext['env'] = __item
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78683e1f50> name=None at 7b78683e1050> -> __attrs_135757151805648
                    __attrs_135757151805648 = _static_135757075193680
                    __backup_key_135757153145936 = get('key', __marker)

                    # <Value u'python:env[0]' (200:35)> -> __value
                    __token = 8310
                    try:
                        __zt_tmp = __attrs_135757151805648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'env[0]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['key'] = __value
                    __backup_value_135757153146128 = get('value', __marker)

                    # <Value u'python:env[1]' (201:30)> -> __value
                    __token = 8355
                    try:
                        __zt_tmp = __attrs_135757151805648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'env[1]', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['value'] = __value

                    # <Value u"python:key.startswith('persistent_')" (202:34)> -> __condition
                    __token = 8405
                    try:
                        __zt_tmp = __attrs_135757151805648
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"key.startswith('persistent_')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151808144
                        __default_135757151808144 = _DEFAULT_MARKER

                        # <Substitution u'string:form_env.${key}:record' (203:40)> -> __attr_name
                        __token = 8483
                        try:
                            __zt_tmp = __attrs_135757151805648
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_135757244280656('string', u'form_env.${key}:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', u'key', _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151809488
                        __default_135757151809488 = _DEFAULT_MARKER

                        # <Substitution u'value' (204:30)> -> __attr_value
                        __token = 8544
                        try:
                            __zt_tmp = __attrs_135757151805648
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', u'value', _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u' />')
                    if (__backup_value_135757153146128 is __marker):
                        del econtext['value']
                    else:
                        econtext['value'] = __backup_value_135757153146128
                    if (__backup_key_135757153145936 is __marker):
                        del econtext['key']
                    else:
                        econtext['key'] = __backup_key_135757153145936
                    __append(u'\n          ')
                    ____index_135757075190224 -= 1
                    if (____index_135757075190224 > 0):
                        __append('')
                if (__backup_env_135757073377104 is __marker):
                    del econtext['env']
                else:
                    econtext['env'] = __backup_env_135757073377104
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757151806480
                __attrs_135757151806480 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757151807696
                __default_135757151807696 = _DEFAULT_MARKER

                # <Value u'nothing' (208:32)> -> __cache_135757075870224
                __token = 8621
                try:
                    __zt_tmp = __attrs_135757151806480
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757075870224 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'nothing' (208:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ccf2e10> -> __condition
                __expression = __cache_135757075870224

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u"\n            Turn 'persistent_' variables from forms (GET/POST) persistent\n          ")
                else:
                    __content = __cache_135757075870224
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757151807888
                __attrs_135757151807888 = _static_135757327983760
                __backup_key_135757075192528 = get('key', __marker)

                # <Value u'request/form' (211:31)> -> __iterator
                __token = 8761
                try:
                    __zt_tmp = __attrs_135757151807888
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'request/form', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757151807120, ) = getitem('repeat')(u'key', __iterator)
                econtext['key'] = None
                for __item in __iterator:
                    econtext['key'] = __item
                    __append(u'\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074659920
                    __attrs_135757074659920 = _static_135757327983760

                    # <Value u"python:key.startswith('persistent_')" (212:39)> -> __condition
                    __token = 8815
                    try:
                        __zt_tmp = __attrs_135757074659920
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"key.startswith('persistent_')", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n              ')

                        # <Static value=<_ast.Dict object at 0x7b786835f190> name=None at 7b786835fcd0> -> __attrs_135757074660496
                        __attrs_135757074660496 = _static_135757074657680
                        __backup_value_135757073378832 = get('value', __marker)

                        # <Value u'request/?key' (216:39)> -> __value
                        __token = 8996
                        try:
                            __zt_tmp = __attrs_135757074660496
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __value = _static_135757244280656('path', u'request/?key', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        econtext['value'] = __value

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input type="hidden"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074659536
                        __default_135757074659536 = _DEFAULT_MARKER

                        # <Substitution u'string:form_env.${key}:record' (217:42)> -> __attr_name
                        __token = 9052
                        try:
                            __zt_tmp = __attrs_135757074660496
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_name = _static_135757244280656('string', u'form_env.${key}:record', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_name = __quote(__attr_name, '"', '&quot;', u'key', _DEFAULT_MARKER)
                        if (__attr_name is not None):
                            __append((u' name="%s"' % __attr_name))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074658576
                        __default_135757074658576 = _DEFAULT_MARKER

                        # <Substitution u'value' (218:32)> -> __attr_value
                        __token = 9115
                        try:
                            __zt_tmp = __attrs_135757074660496
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_value = _static_135757244280656('path', u'value', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_value = __quote(__attr_value, '"', '&quot;', u'value', _DEFAULT_MARKER)
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))
                        __append(u' />')
                        if (__backup_value_135757073378832 is __marker):
                            del econtext['value']
                        else:
                            econtext['value'] = __backup_value_135757073378832
                        __append(u'\n            ')
                    __append(u'\n          ')
                    ____index_135757151807120 -= 1
                    if (____index_135757151807120 > 0):
                        __append('')
                if (__backup_key_135757075192528 is __marker):
                    del econtext['key']
                else:
                    econtext['key'] = __backup_key_135757075192528
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074657360
                __attrs_135757074657360 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074658896
                __default_135757074658896 = _DEFAULT_MARKER

                # <Value u'nothing' (223:32)> -> __cache_135757074661264
                __token = 9224
                try:
                    __zt_tmp = __attrs_135757074657360
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074661264 = _static_135757244280656('path', u'nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'nothing' (223:32)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786835fa10> -> __condition
                __expression = __cache_135757074661264

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n            Store referrer to remember where to go back\n          ')
                else:
                    __content = __cache_135757074661264
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n          ')

                # <Static value=<_ast.Dict object at 0x7b786835fa90> name=None at 7b786835fdd0> -> __attrs_135757153162704
                __attrs_135757153162704 = _static_135757074659984
                __backup_last_referer_135757073365904 = get('last_referer', __marker)

                # <Value u"python:request.form.get('last_referer', request.get('HTTP_REFERER'))" (228:42)> -> __value
                __token = 9425
                try:
                    __zt_tmp = __attrs_135757153162704
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_135757244280656('python', u"request.form.get('last_referer', request.get('HTTP_REFERER'))", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                econtext['last_referer'] = __value

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden" name="last_referer"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757153163344
                __default_135757153163344 = _DEFAULT_MARKER

                # <Substitution u"python:(last_referer and '%s/%s' % (context.absolute_url(), template.id) not in last_referer) and last_referer or (context.getParentNode() and context.getParentNode().absolute_url())" (229:39)> -> __attr_value
                __token = 9534
                try:
                    __zt_tmp = __attrs_135757153162704
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_135757244280656('python', u"(last_referer and '%s/%s' % (context.absolute_url(), template.id) not in last_referer) and last_referer or (context.getParentNode() and context.getParentNode().absolute_url())", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u' />')
                if (__backup_last_referer_135757073365904 is __marker):
                    del econtext['last_referer']
                else:
                    econtext['last_referer'] = __backup_last_referer_135757073365904
                __append(u'\n\n          ')

                # <Static value=<_ast.Dict object at 0x7b786ce3d390> name=None at 7b786ce3d790> -> __attrs_135757153162064
                __attrs_135757153162064 = _static_135757153162128

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="mt-2">\n\n            <!-- Buttons -->\n            ')
                if (__slot_buttons is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153163408
                    __attrs_135757153163408 = _static_135757327983760
                    __backup_fieldset_index_135757073365648 = get('fieldset_index', __marker)

                    # <Value u'python:fieldset in fieldsets and fieldsets.index(fieldset)' (236:52)> -> __value
                    __token = 9890
                    try:
                        __zt_tmp = __attrs_135757153163408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'fieldset in fieldsets and fieldsets.index(fieldset)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['fieldset_index'] = __value
                    __backup_n_fieldsets_135757074659280 = get('n_fieldsets', __marker)

                    # <Value u'python:len(fieldsets)' (237:48)> -> __value
                    __token = 9998
                    try:
                        __zt_tmp = __attrs_135757153163408
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'len(fieldsets)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['n_fieldsets'] = __value
                    __append(u'\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b7868055a10> name=None at 7b78680559d0> -> __attrs_135757071470672
                    __attrs_135757071470672 = _static_135757071473168

                    # <Value u'python:fieldset_index > 0' (239:38)> -> __condition
                    __token = 10062
                    try:
                        __zt_tmp = __attrs_135757071470672
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'fieldset_index > 0', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input class="btn btn-sm btn-outline-secondary" type="submit" name="form.button.previous"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071472464
                        __default_135757071472464 = _DEFAULT_MARKER

                        # <Translate msgid=u'label_previous' node=<_ast.Str object at 0x7b78680550d0> at 7b7868055d50> -> __attr_value
                        __attr_value = u'Previous'
                        __attr_value = translate(u'label_previous', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757071473360
                        __default_135757071473360 = _DEFAULT_MARKER

                        # <Boolean u"python:test(isLocked, 'disabled', None)" (245:47)> -> __attr_disabled
                        __token = 10389
                        try:
                            __zt_tmp = __attrs_135757071470672
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_disabled = _static_135757244280656('python', u"test(isLocked, 'disabled', None)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_disabled is _DEFAULT_MARKER):
                            __attr_disabled = None
                        else:
                            if __attr_disabled:
                                __attr_disabled = u'disabled'
                            else:
                                __attr_disabled = None
                        if (__attr_disabled is not None):
                            __append((u' disabled="%s"' % __attr_disabled))
                        __append(u' />')
                    __append(u'\n                ')

                    # <Static value=<_ast.Dict object at 0x7b7868055890> name=None at 7b7868055310> -> __attrs_135757075713872
                    __attrs_135757075713872 = _static_135757071472784

                    # <Value u'python:not allow_tabbing and (fieldset_index < n_fieldsets - 1)' (247:38)> -> __condition
                    __token = 10488
                    try:
                        __zt_tmp = __attrs_135757075713872
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'not allow_tabbing and (fieldset_index < n_fieldsets - 1)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:

                        # <input ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<input class="btn btn-sm btn-outline-secondary" type="submit" name="form.button.next"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075711504
                        __default_135757075711504 = _DEFAULT_MARKER

                        # <Translate msgid=u'label_next' node=<_ast.Str object at 0x7b7868460b10> at 7b7868460210> -> __attr_value
                        __attr_value = u'Next'
                        __attr_value = translate(u'label_next', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        if (__attr_value is not None):
                            __append((u' value="%s"' % __attr_value))

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075712976
                        __default_135757075712976 = _DEFAULT_MARKER

                        # <Boolean u"python:test(isLocked, 'disabled', None)" (253:47)> -> __attr_disabled
                        __token = 10841
                        try:
                            __zt_tmp = __attrs_135757075713872
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_disabled = _static_135757244280656('python', u"test(isLocked, 'disabled', None)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        if (__attr_disabled is _DEFAULT_MARKER):
                            __attr_disabled = None
                        else:
                            if __attr_disabled:
                                __attr_disabled = u'disabled'
                            else:
                                __attr_disabled = None
                        if (__attr_disabled is not None):
                            __append((u' disabled="%s"' % __attr_disabled))
                        __append(u' />')
                    __append(u'\n                ')

                    # <Static value=<_ast.Dict object at 0x7b7868483f50> name=None at 7b7868460a10> -> __attrs_135757075855632
                    __attrs_135757075855632 = _static_135757075857232

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="btn btn-sm btn-primary" type="submit" name="form.button.save"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075853520
                    __default_135757075853520 = _DEFAULT_MARKER

                    # <Translate msgid=u'label_save' node=<_ast.Str object at 0x7b7868483f90> at 7b7868483e90> -> __attr_value
                    __attr_value = u'Save'
                    __attr_value = translate(u'label_save', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075856976
                    __default_135757075856976 = _DEFAULT_MARKER

                    # <Boolean u"python:test(isLocked, 'disabled', None)" (260:47)> -> __attr_disabled
                    __token = 11178
                    try:
                        __zt_tmp = __attrs_135757075855632
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_disabled = _static_135757244280656('python', u"test(isLocked, 'disabled', None)", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if (__attr_disabled is _DEFAULT_MARKER):
                        __attr_disabled = None
                    else:
                        if __attr_disabled:
                            __attr_disabled = u'disabled'
                        else:
                            __attr_disabled = None
                    if (__attr_disabled is not None):
                        __append((u' disabled="%s"' % __attr_disabled))
                    __append(u' />\n\n                ')

                    # <Static value=<_ast.Dict object at 0x7b7868483350> name=None at 7b7868483310> -> __attrs_135757075222288
                    __attrs_135757075222288 = _static_135757075854160

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input class="btn btn-sm btn-secondary" type="submit" name="form.button.cancel"')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075222416
                    __default_135757075222416 = _DEFAULT_MARKER

                    # <Translate msgid=u'label_cancel' node=<_ast.Str object at 0x7b78683e8cd0> at 7b78683e86d0> -> __attr_value
                    __attr_value = u'Cancel'
                    __attr_value = translate(u'label_cancel', default=__attr_value, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u' />\n            ')
                    if (__backup_n_fieldsets_135757074659280 is __marker):
                        del econtext['n_fieldsets']
                    else:
                        econtext['n_fieldsets'] = __backup_n_fieldsets_135757074659280
                    if (__backup_fieldset_index_135757073365648 is __marker):
                        del econtext['fieldset_index']
                    else:
                        econtext['fieldset_index'] = __backup_fieldset_index_135757073365648
                else:
                    __slot_buttons(__stream, econtext.copy(), rcontext)
                __append(u'\n\n            <!-- Extra In-line Button Slot -->\n            ')
                if (__slot_extra_inline_buttons is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075218704
                    __attrs_135757075218704 = _static_135757327983760
                else:
                    __slot_extra_inline_buttons(__stream, econtext.copy(), rcontext)
                __append(u'\n\n          </div>\n\n          <!-- Extra Button Slot -->\n          ')
                if (__slot_extra_buttons is None):

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075222160
                    __attrs_135757075222160 = _static_135757327983760
                else:
                    __slot_extra_buttons(__stream, econtext.copy(), rcontext)
                __append(u'\n\n        </div>\n\n      </form>\n    </div>')
            if (__backup_portal_type_135757073378896 is __marker):
                del econtext['portal_type']
            else:
                econtext['portal_type'] = __backup_portal_type_135757073378896
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_header(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_title = econtext[u'__slot_title'].pop()
        except:
            __slot_title = None

        try:
            __slot_extra_info = econtext[u'__slot_extra_info'].pop()
        except:
            __slot_extra_info = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153180368
            __attrs_135757153180368 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')
            if (__slot_title is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153179216
                __attrs_135757153179216 = _static_135757327983760
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b786cb46ed0> name=None at 7b786cb463d0> -> __attrs_135757150054352
                __attrs_135757150054352 = _static_135757150056144

                # <Value u'python:context.checkCreationFlag()' (22:27)> -> __condition
                __token = 677
                try:
                    __zt_tmp = __attrs_135757150054352
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'context.checkCreationFlag()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <h1 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h1 class="documentFirstHeading">')
                    __stream_135757071612096_itemtype = ''
                    __stream_135757150055632 = []
                    __append_135757150055632 = __stream_135757150055632.append
                    __append_135757150055632(u'\n          Add\n          ')
                    __stream_135757071612096_itemtype = []
                    __append_135757071612096_itemtype = __stream_135757071612096_itemtype.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073378576
                    __attrs_135757073378576 = _static_135757327983760
                    __backup_fti_135757150054608 = get('fti', __marker)

                    # <Value u'python:context.portal_types.getTypeInfo(here)' (25:32)> -> __value
                    __token = 797
                    try:
                        __zt_tmp = __attrs_135757073378576
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'context.portal_types.getTypeInfo(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['fti'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757071612096_itemtype(u'<span>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757073378128
                    __attrs_135757073378128 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757073377488
                    __default_135757073377488 = _DEFAULT_MARKER

                    # <Value u'fti/Title' (27:31)> -> __cache_135757073375824
                    __token = 912
                    try:
                        __zt_tmp = __attrs_135757073378128
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757073375824 = _static_135757244280656('path', u'fti/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'fti/Title' (27:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868226a90> -> __condition
                    __expression = __cache_135757073375824

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append_135757071612096_itemtype(u'Item type')
                    else:
                        __content = __cache_135757073375824
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757071612096_itemtype(__content)
                    __append_135757071612096_itemtype(u'\n          </span>')
                    if (__backup_fti_135757150054608 is __marker):
                        del econtext['fti']
                    else:
                        econtext['fti'] = __backup_fti_135757150054608
                    __append_135757150055632(u'${itemtype}')
                    __stream_135757071612096_itemtype = ''.join(__stream_135757071612096_itemtype)
                    __append_135757150055632(u'\n        ')
                    __msgid_135757150055632 = __re_whitespace(''.join(__stream_135757150055632)).strip()
                    if u'heading_add_item':
                        __append(translate(u'heading_add_item', mapping={u'itemtype': __stream_135757071612096_itemtype, }, default=__msgid_135757150055632, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h1>')
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b7868226990> name=None at 7b7868226dd0> -> __attrs_135757075922896
                __attrs_135757075922896 = _static_135757073377680

                # <Value u'python: not context.checkCreationFlag()' (32:27)> -> __condition
                __token = 1109
                try:
                    __zt_tmp = __attrs_135757075922896
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u' not context.checkCreationFlag()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <h1 ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<h1 class="documentFirstHeading">')
                    __stream_135757071612096_itemtype = ''
                    __stream_135757073375504 = []
                    __append_135757073375504 = __stream_135757073375504.append
                    __append_135757073375504(u'\n          Edit\n          ')
                    __stream_135757071612096_itemtype = []
                    __append_135757071612096_itemtype = __stream_135757071612096_itemtype.append

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075921744
                    __attrs_135757075921744 = _static_135757327983760
                    __backup_fti_135757150056272 = get('fti', __marker)

                    # <Value u'python:context.portal_types.getTypeInfo(here)' (35:32)> -> __value
                    __token = 1235
                    try:
                        __zt_tmp = __attrs_135757075921744
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __value = _static_135757244280656('python', u'context.portal_types.getTypeInfo(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    econtext['fti'] = __value

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append_135757071612096_itemtype(u'<span>\n            ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075919824
                    __attrs_135757075919824 = _static_135757327983760

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757075919184
                    __default_135757075919184 = _DEFAULT_MARKER

                    # <Value u'fti/Title' (37:31)> -> __cache_135757075920144
                    __token = 1350
                    try:
                        __zt_tmp = __attrs_135757075919824
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_135757075920144 = _static_135757244280656('path', u'fti/Title', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                    # <BinOp left=<Value u'fti/Title' (37:31)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868493bd0> -> __condition
                    __expression = __cache_135757075920144

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                    __value = _DEFAULT_MARKER
                    __condition = (__expression is __value)
                    if __condition:
                        __append_135757071612096_itemtype(u'Item type')
                    else:
                        __content = __cache_135757075920144
                        __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                        __content = __quote(__content, None, '\xad', None, None)
                        if (__content is not None):
                            __append_135757071612096_itemtype(__content)
                    __append_135757071612096_itemtype(u'\n          </span>')
                    if (__backup_fti_135757150056272 is __marker):
                        del econtext['fti']
                    else:
                        econtext['fti'] = __backup_fti_135757150056272
                    __append_135757073375504(u'${itemtype}')
                    __stream_135757071612096_itemtype = ''.join(__stream_135757071612096_itemtype)
                    __append_135757073375504(u'\n        ')
                    __msgid_135757073375504 = __re_whitespace(''.join(__stream_135757073375504)).strip()
                    if u'heading_edit_item':
                        __append(translate(u'heading_edit_item', mapping={u'itemtype': __stream_135757071612096_itemtype, }, default=__msgid_135757073375504, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</h1>')
                __append(u'\n\n        ')

                # <Static value=<_ast.Dict object at 0x7b7868493710> name=None at 7b78684936d0> -> __attrs_135757075922320
                __attrs_135757075922320 = _static_135757075920656

                # <Value u'context/@@plone/isDefaultPageInFolder|nothing' (43:28)> -> __condition
                __token = 1511
                try:
                    __zt_tmp = __attrs_135757075922320
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('path', u'context/@@plone/isDefaultPageInFolder|nothing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div class="alert alert-info">\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074547024
                    __attrs_135757074547024 = _static_135757327983760

                    # <strong ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<strong>')
                    __stream_135757073219920 = []
                    __append_135757073219920 = __stream_135757073219920.append
                    __append_135757073219920(u'\n            Info\n          ')
                    __msgid_135757073219920 = __re_whitespace(''.join(__stream_135757073219920)).strip()
                    if __msgid_135757073219920:
                        __append(translate(__msgid_135757073219920, mapping=None, default=__msgid_135757073219920, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</strong>\n          ')

                    # <Static value=<_ast.Dict object at 0x7b7868344f90> name=None at 7b7868344d50> -> __attrs_135757074549712
                    __attrs_135757074549712 = _static_135757074550672

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span omit-tag="">')
                    __stream_135757071612576_go_here = ''
                    __stream_135757074549008 = []
                    __append_135757074549008 = __stream_135757074549008.append
                    __append_135757074549008(u'\n            You are editing the default view of a container. If you wanted to edit the container itself,\n            ')
                    __stream_135757071612576_go_here = []
                    __append_135757071612576_go_here = __stream_135757071612576_go_here.append

                    # <Static value=<_ast.Dict object at 0x7b7868344810> name=None at 7b7868344b90> -> __attrs_135757074547152
                    __attrs_135757074547152 = _static_135757074548752

                    # <a ... (0:0)
                    # --------------------------------------------------------
                    __append_135757071612576_go_here(u'<a')

                    # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074548880
                    __default_135757074548880 = _DEFAULT_MARKER

                    # <Substitution u'string:${context/aq_inner/aq_parent/absolute_url}/edit' (53:36)> -> __attr_href
                    __token = 2020
                    try:
                        __zt_tmp = __attrs_135757074547152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_href = _static_135757244280656('string', u'${context/aq_inner/aq_parent/absolute_url}/edit', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
                    if (__attr_href is not None):
                        __append_135757071612576_go_here((u' href="%s"' % __attr_href))
                    __append_135757071612576_go_here(u' class="alert-link">')
                    __stream_135757074549968 = []
                    __append_135757074549968 = __stream_135757074549968.append
                    __append_135757074549968(u'go here')
                    __msgid_135757074549968 = __re_whitespace(''.join(__stream_135757074549968)).strip()
                    if u'label_edit_default_view_container_go_here':
                        __append_135757071612576_go_here(translate(u'label_edit_default_view_container_go_here', mapping=None, default=__msgid_135757074549968, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append_135757071612576_go_here(u'</a>')
                    __append_135757074549008(u'${go_here}')
                    __stream_135757071612576_go_here = ''.join(__stream_135757071612576_go_here)
                    __append_135757074549008(u'.\n          ')
                    __msgid_135757074549008 = __re_whitespace(''.join(__stream_135757074549008)).strip()
                    if u'label_edit_default_view_container':
                        __append(translate(u'label_edit_default_view_container', mapping={u'go_here': __stream_135757071612576_go_here, }, default=__msgid_135757074549008, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                    __append(u'</span>\n        </div>')
                __append(u'\n\n      ')
            else:
                __slot_title(__stream, econtext.copy(), rcontext)
            __append(u'\n\n      ')

            # <Static value=<_ast.Dict object at 0x7b7868493310> name=None at 7b786ce41f90> -> __attrs_135757074546960
            __attrs_135757074546960 = _static_135757075919632

            # <Value u'python: fieldsets and not allow_tabbing' (60:26)> -> __condition
            __token = 2213
            try:
                __zt_tmp = __attrs_135757074546960
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('python', u' fieldsets and not allow_tabbing', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="archetypes-schemata-links">\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074621456
                __attrs_135757074621456 = _static_135757327983760
                __backup_fset_135756868964240 = get('fset', __marker)

                # <Value u'fieldsets' (61:32)> -> __iterator
                __token = 2287
                try:
                    __zt_tmp = __attrs_135757074621456
                except get('NameError', NameError):
                    __zt_tmp = None

                __iterator = _static_135757244280656('path', u'fieldsets', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                (__iterator, ____index_135757074622608, ) = getitem('repeat')(u'fset', __iterator)
                econtext['fset'] = None
                for __item in __iterator:
                    econtext['fset'] = __item
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074621200
                    __attrs_135757074621200 = _static_135757327983760

                    # <Value u"python:fset == fieldset and fieldsets != ['default']" (62:34)> -> __condition
                    __token = 2333
                    try:
                        __zt_tmp = __attrs_135757074621200
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u"fset == fieldset and fieldsets != ['default']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074623568
                        __attrs_135757074623568 = _static_135757327983760

                        # <strong ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<strong>[')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074621840
                        __attrs_135757074621840 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074621712
                        __default_135757074621712 = _DEFAULT_MARKER

                        # <Value u'fset' (63:40)> -> __cache_135757074623760
                        __token = 2428
                        try:
                            __zt_tmp = __attrs_135757074621840
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757074623760 = _static_135757244280656('path', u'fset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'fset' (63:40)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868356810> -> __condition
                        __expression = __cache_135757074623760

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757074623760
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>]</strong>\n          ')
                    __append(u'\n          ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074624016
                    __attrs_135757074624016 = _static_135757327983760

                    # <Value u'python:fset != fieldset' (65:33)> -> __condition
                    __token = 2523
                    try:
                        __zt_tmp = __attrs_135757074624016
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __condition = _static_135757244280656('python', u'fset != fieldset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    if __condition:
                        __append(u'\n            ')

                        # <Static value=<_ast.Dict object at 0x7b7868395310> name=None at 7b78683950d0> -> __attrs_135757074881936
                        __attrs_135757074881936 = _static_135757074879248

                        # <a ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<a')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074881296
                        __default_135757074881296 = _DEFAULT_MARKER

                        # <Substitution u'string:${context/absolute_url}/${template/getId}?fieldset=${fset}' (66:45)> -> __attr_href
                        __token = 2594
                        try:
                            __zt_tmp = __attrs_135757074881936
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_href = _static_135757244280656('string', u'${context/absolute_url}/${template/getId}?fieldset=${fset}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_href = __quote(__attr_href, '"', '&quot;', u'#', _DEFAULT_MARKER)
                        if (__attr_href is not None):
                            __append((u' href="%s"' % __attr_href))
                        __append(u'>\n              [')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074880912
                        __attrs_135757074880912 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074881424
                        __default_135757074881424 = _DEFAULT_MARKER

                        # <Value u'fset' (67:34)> -> __cache_135757074882384
                        __token = 2696
                        try:
                            __zt_tmp = __attrs_135757074880912
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __cache_135757074882384 = _static_135757244280656('path', u'fset', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                        # <BinOp left=<Value u'fset' (67:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868395b50> -> __condition
                        __expression = __cache_135757074882384

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                        __value = _DEFAULT_MARKER
                        __condition = (__expression is __value)
                        if __condition:
                            pass
                        else:
                            __content = __cache_135757074882384
                            __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                            __content = __quote(__content, None, '\xad', None, None)
                            if (__content is not None):
                                __append(__content)
                        __append(u'</span>]</a>\n          ')
                    __append(u'\n        ')
                    ____index_135757074622608 -= 1
                    if (____index_135757074622608 > 0):
                        __append('')
                if (__backup_fset_135756868964240 is __marker):
                    del econtext['fset']
                else:
                    econtext['fset'] = __backup_fset_135756868964240
                __append(u'\n      </div>')
            __append(u'\n      ')
            if (__slot_extra_info is None):

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074621904
                __attrs_135757074621904 = _static_135757327983760
            else:
                __slot_extra_info(__stream, econtext.copy(), rcontext)
            __append(u'\n\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_footer(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075204240
            __attrs_135757075204240 = _static_135757327983760
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_typedescription(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074622096
            __attrs_135757074622096 = _static_135757327983760

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div>\n      ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757074880528
            __attrs_135757074880528 = _static_135757327983760
            __backup_fti_135757071477072 = get('fti', __marker)

            # <Value u'python:context.portal_types.getTypeInfo(here)' (76:39)> -> __value
            __token = 2932
            try:
                __zt_tmp = __attrs_135757074880528
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('python', u'context.portal_types.getTypeInfo(here)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['fti'] = __value
            __backup_desc_135757153179856 = get('desc', __marker)

            # <Value u'fti/Description' (77:39)> -> __value
            __token = 3018
            try:
                __zt_tmp = __attrs_135757074880528
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_135757244280656('path', u'fti/Description', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            econtext['desc'] = __value

            # <Value u'desc' (78:38)> -> __condition
            __token = 3075
            try:
                __zt_tmp = __attrs_135757074880528
            except get('NameError', NameError):
                __zt_tmp = None

            __condition = _static_135757244280656('path', u'desc', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            if __condition:
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x7b78683800d0> name=None at 7b78683802d0> -> __attrs_135757074796432
                __attrs_135757074796432 = _static_135757074792656

                # <p ... (0:0)
                # --------------------------------------------------------
                __append(u'<p class="discreet">')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757074878800
                __default_135757074878800 = _DEFAULT_MARKER

                # <Value u'desc' (79:59)> -> __cache_135757074879952
                __token = 3141
                try:
                    __zt_tmp = __attrs_135757074796432
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757074879952 = _static_135757244280656('path', u'desc', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'desc' (79:59)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b7868395650> -> __condition
                __expression = __cache_135757074879952

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\n          type description\n        ')
                else:
                    __content = __cache_135757074879952
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</p>\n      ')
            if (__backup_desc_135757153179856 is __marker):
                del econtext['desc']
            else:
                econtext['desc'] = __backup_desc_135757153179856
            if (__backup_fti_135757071477072 is __marker):
                del econtext['fti']
            else:
                econtext['fti'] = __backup_fti_135757071477072
            __append(u'\n    </div>')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get
            __append(u'<!-- SENAITE bootstrapped edit_macros.pt\n\n  - Customized fieldsets to bootstrap nav-tabs:\n    https://getbootstrap.com/docs/4.4/components/navs/#tabs\n\n  - Customized input buttons\n\n-->\n')

            # <Static value=<_ast.Dict object at 0x7b7868056b50> name=None at 7b7868056390> -> __attrs_135757071477520
            __attrs_135757071477520 = _static_135757071477584
            __previous_i18n_domain_135757071475408 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757075682512
            __attrs_135757075682512 = _static_135757327983760

            # <head ... (0:0)
            # --------------------------------------------------------
            __append(u'<head>')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153179088
            __attrs_135757153179088 = _static_135757327983760

            # <title ... (0:0)
            # --------------------------------------------------------
            __append(u'<title></title></head>\n  ')

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757153180176
            __attrs_135757153180176 = _static_135757327983760

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n\n    ')
            __token = None
            render_header(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_typedescription(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_body(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_footer(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n</html>')
            __i18n_domain = __previous_i18n_domain_135757071475408
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_body': render_body, u'render_header': render_header, u'render_footer': render_footer, u'render_typedescription': render_typedescription, 'render': render, }