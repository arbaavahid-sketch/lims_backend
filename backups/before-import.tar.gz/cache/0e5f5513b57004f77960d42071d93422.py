# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/dashboard/templates/dashboard.pt'

__tokens = {294: (u'python:view.get_user_fullname()', 8, 25), 511: (u'python:view.get_current_date()', 14, 25), 611: (u'python:view.get_current_time()', 16, 25), 806: (u'string:${portal_url}/++resource++senaite.core.dashboard.css', 23, 31), 1015: (u'string:${view/portal_url}/senaite-dashboard-data', 28, 39), 1106: (u' view/periodicit', 29, 41), 1168: (u"s python:'true' if view.can_view_statistics() else 'fals", 30, 43), 1266: (u'rl view/portal_', 31, 38), 1322: (u'rom python:plone_view.toLocalizedTime(view.date_f', 32, 36), 1410: (u'e-to python:plone_view.toLocalizedTime(view.dat', 33, 33), 1820: (u'python:view.can_view_statistics()', 45, 31), 1890: (u"python:['analysisrequests', 'analyses', 'worksheets']", 46, 34), 1978: (u'string:dashboard-section-${section_id}', 47, 32), 2308: (u'string:${portal_url}/++resource++senaite.core.dashboard.js', 57, 32), 2413: (u'context/@@authenticator/authenticator', 59, 34), 66: (u'here/main_template/macros/master', 2, 23), 66: (u'here/main_template/macros/master', 2, 23)}

from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_135757152275920 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_135757137880592 = {u'href': u'string:${portal_url}/++resource++senaite.core.dashboard.css', u'rel': u'stylesheet', }
_static_135757152263120 = {u'class': u'dashboard-section', u'id': u'string:dashboard-section-${section_id}', }
_static_135757152273488 = {u'class': u'text-muted', }
_static_135757152190800 = {u'class': u'text-muted py-3', }
_static_135757244280656 = __compile_zt_expr
_static_135757166283920 = {u'id': u'dashboard-overview', u'class': u'mt-4', }
_static_135757166289744 = {u'class': u'fas fa-spinner fa-spin mr-2', }
_static_135757136409808 = {u'class': u'documentFirstHeading', }
_static_135757136198544 = {u'class': u'documentDescription text-muted', }
_static_135757163231056 = u'master'
_static_135757327983760 = {}
_static_135757152261328 = {u'src': u'string:${portal_url}/++resource++senaite.core.dashboard.js', }
_static_135757244301584 = __C2ZContextWrapper
_static_135757137882832 = {u'data-can-view-stats': u"python:'true' if view.can_view_statistics() else 'false'", u'style': u'display:none', u'data-periodicity': u'view/periodicity', u'data-date-from': u'python:plone_view.toLocalizedTime(view.date_from)', u'data-date-to': u'python:plone_view.toLocalizedTime(view.date_to)', u'data-portal-url': u'view/portal_url', u'id': u'dashboard-config', u'data-base-url': u'string:${view/portal_url}/senaite-dashboard-data', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757237124880
            __attrs_135757237124880 = _static_135757327983760
            __previous_i18n_domain_135757152254032 = __i18n_domain
            __i18n_domain = u'senaite.core'
            __backup_macroname_135757129738672 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x7b786d7d7750> name=None at 7b786d044090> -> __value
            __value = _static_135757163231056
            econtext['macroname'] = __value

            def __fill_content_title(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152253776
                __attrs_135757152253776 = _static_135757327983760
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b786be434d0> name=None at 7b786be437d0> -> __attrs_135757073012560
                __attrs_135757073012560 = _static_135757136409808

                # <h1 ... (0:0)
                # --------------------------------------------------------
                __append(u'<h1 class="documentFirstHeading">\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136252752
                __attrs_135757136252752 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_135757136251664 = []
                __append_135757136251664 = __stream_135757136251664.append
                __append_135757136251664(u'Welcome')
                __msgid_135757136251664 = __re_whitespace(''.join(__stream_135757136251664)).strip()
                if __msgid_135757136251664:
                    __append(translate(__msgid_135757136251664, mapping=None, default=__msgid_135757136251664, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>,\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136252048
                __attrs_135757136252048 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136250768
                __default_135757136250768 = _DEFAULT_MARKER

                # <Value u'python:view.get_user_fullname()' (8:25)> -> __cache_135757136249488
                __token = 294
                try:
                    __zt_tmp = __attrs_135757136252048
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757136249488 = _static_135757244280656('python', u'view.get_user_fullname()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_user_fullname()' (8:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786be1ca10> -> __condition
                __expression = __cache_135757136249488

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'User')
                else:
                    __content = __cache_135757136249488
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n    </h1>\n  ')
            _slots = econtext[u'__slot_content_title'] = _deque((__fill_content_title, ))

            def __fill_content_description(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757365919184
                __attrs_135757365919184 = _static_135757327983760
                __append(u'\n    ')

                # <Static value=<_ast.Dict object at 0x7b786be0fb90> name=None at 7b786be0f9d0> -> __attrs_135757136196624
                __attrs_135757136196624 = _static_135757136198544

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="documentDescription text-muted">\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136198416
                __attrs_135757136198416 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136197072
                __default_135757136197072 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_date()' (14:25)> -> __cache_135757136196816
                __token = 511
                try:
                    __zt_tmp = __attrs_135757136198416
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757136196816 = _static_135757244280656('python', u'view.get_current_date()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_date()' (14:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786be0f190> -> __condition
                __expression = __cache_135757136196816

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'Monday, 22 April 2026')
                else:
                    __content = __cache_135757136196816
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n      &mdash;\n      ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136198736
                __attrs_135757136198736 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757136199120
                __default_135757136199120 = _DEFAULT_MARKER

                # <Value u'python:view.get_current_time()' (16:25)> -> __cache_135757136199312
                __token = 611
                try:
                    __zt_tmp = __attrs_135757136198736
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757136199312 = _static_135757244280656('python', u'view.get_current_time()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:view.get_current_time()' (16:25)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786be0ff50> -> __condition
                __expression = __cache_135757136199312

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'14:30')
                else:
                    __content = __cache_135757136199312
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</span>\n    </div>\n  ')
            _slots = econtext[u'__slot_content_description'] = _deque((__fill_content_description, ))

            def __fill_content_core(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757136197968
                __attrs_135757136197968 = _static_135757327983760
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b786bfaa610> name=None at 7b786bfaad10> -> __attrs_135757137880720
                __attrs_135757137880720 = _static_135757137880592

                # <link ... (0:0)
                # --------------------------------------------------------
                __append(u'<link rel="stylesheet"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757137881936
                __default_135757137881936 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.css' (23:31)> -> __attr_href
                __token = 806
                try:
                    __zt_tmp = __attrs_135757137880720
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_href = _static_135757244280656('string', u'${portal_url}/++resource++senaite.core.dashboard.css', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_href = __quote(__attr_href, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_href is not None):
                    __append((u' href="%s"' % __attr_href))
                __append(u' />\n\n    <!-- Configuration for dashboard.js -->\n    ')

                # <Static value=<_ast.Dict object at 0x7b786bfaaed0> name=None at 7b786bfaa190> -> __attrs_135757166283536
                __attrs_135757166283536 = _static_135757137882832

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-config" style="display:none"')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757155063120
                __default_135757155063120 = _DEFAULT_MARKER

                # <Substitution u'string:${view/portal_url}/senaite-dashboard-data' (28:39)> -> __attr_data_base_url
                __token = 1015
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_base_url = _static_135757244280656('string', u'${view/portal_url}/senaite-dashboard-data', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_base_url = __quote(__attr_data_base_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_base_url is not None):
                    __append((u' data-base-url="%s"' % __attr_data_base_url))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757155065616
                __default_135757155065616 = _DEFAULT_MARKER

                # <Substitution u'view/periodicity' (29:41)> -> __attr_data_periodicity
                __token = 1106
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_periodicity = _static_135757244280656('path', u'view/periodicity', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_periodicity = __quote(__attr_data_periodicity, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_periodicity is not None):
                    __append((u' data-periodicity="%s"' % __attr_data_periodicity))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166282384
                __default_135757166282384 = _DEFAULT_MARKER

                # <Substitution u"python:'true' if view.can_view_statistics() else 'false'" (30:43)> -> __attr_data_can_view_stats
                __token = 1168
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_can_view_stats = _static_135757244280656('python', u"'true' if view.can_view_statistics() else 'false'", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_can_view_stats = __quote(__attr_data_can_view_stats, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_can_view_stats is not None):
                    __append((u' data-can-view-stats="%s"' % __attr_data_can_view_stats))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166282576
                __default_135757166282576 = _DEFAULT_MARKER

                # <Substitution u'view/portal_url' (31:38)> -> __attr_data_portal_url
                __token = 1266
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_portal_url = _static_135757244280656('path', u'view/portal_url', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_portal_url = __quote(__attr_data_portal_url, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_portal_url is not None):
                    __append((u' data-portal-url="%s"' % __attr_data_portal_url))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166282960
                __default_135757166282960 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_from)' (32:36)> -> __attr_data_date_from
                __token = 1322
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_from = _static_135757244280656('python', u'plone_view.toLocalizedTime(view.date_from)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_date_from = __quote(__attr_data_date_from, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_from is not None):
                    __append((u' data-date-from="%s"' % __attr_data_date_from))

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757166283216
                __default_135757166283216 = _DEFAULT_MARKER

                # <Substitution u'python:plone_view.toLocalizedTime(view.date_to)' (33:33)> -> __attr_data_date_to
                __token = 1410
                try:
                    __zt_tmp = __attrs_135757166283536
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_data_date_to = _static_135757244280656('python', u'plone_view.toLocalizedTime(view.date_to)', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_data_date_to = __quote(__attr_data_date_to, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_data_date_to is not None):
                    __append((u' data-date-to="%s"' % __attr_data_date_to))
                __append(u'>\n    </div>\n\n    <!-- Status Cards + Quick Links (async) -->\n    ')

                # <Static value=<_ast.Dict object at 0x7b786dac0c90> name=None at 7b786dac0cd0> -> __attrs_135757166282128
                __attrs_135757166282128 = _static_135757166283920

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div id="dashboard-overview" class="mt-4">\n      ')

                # <Static value=<_ast.Dict object at 0x7b786cd64450> name=None at 7b786cd64a90> -> __attrs_135757152273360
                __attrs_135757152273360 = _static_135757152273488

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="text-muted">\n        ')

                # <Static value=<_ast.Dict object at 0x7b786cd64dd0> name=None at 7b786cd64c10> -> __attrs_135757152260368
                __attrs_135757152260368 = _static_135757152275920

                # <i ... (0:0)
                # --------------------------------------------------------
                __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\n        ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152260944
                __attrs_135757152260944 = _static_135757327983760

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span>')
                __stream_135757152260624 = []
                __append_135757152260624 = __stream_135757152260624.append
                __append_135757152260624(u'Loading...')
                __msgid_135757152260624 = __re_whitespace(''.join(__stream_135757152260624)).strip()
                if __msgid_135757152260624:
                    __append(translate(__msgid_135757152260624, mapping=None, default=__msgid_135757152260624, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                __append(u'</span>\n      </div>\n    </div>\n\n    <!-- Statistics Sections (async, permission-gated) -->\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152261200
                __attrs_135757152261200 = _static_135757327983760

                # <Value u'python:view.can_view_statistics()' (45:31)> -> __condition
                __token = 1820
                try:
                    __zt_tmp = __attrs_135757152261200
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_135757244280656('python', u'view.can_view_statistics()', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                if __condition:
                    __append(u'\n      ')

                    # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757152262416
                    __attrs_135757152262416 = _static_135757327983760
                    __backup_section_id_135757075995536 = get('section_id', __marker)

                    # <Value u"python:['analysisrequests', 'analyses', 'worksheets']" (46:34)> -> __iterator
                    __token = 1890
                    try:
                        __zt_tmp = __attrs_135757152262416
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __iterator = _static_135757244280656('python', u"['analysisrequests', 'analyses', 'worksheets']", econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                    (__iterator, ____index_135757152262608, ) = getitem('repeat')(u'section_id', __iterator)
                    econtext['section_id'] = None
                    for __item in __iterator:
                        econtext['section_id'] = __item

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div>\n        ')

                        # <Static value=<_ast.Dict object at 0x7b786cd61bd0> name=None at 7b786cd61b90> -> __attrs_135757152264144
                        __attrs_135757152264144 = _static_135757152263120

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="dashboard-section"')

                        # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152263824
                        __default_135757152263824 = _DEFAULT_MARKER

                        # <Substitution u'string:dashboard-section-${section_id}' (47:32)> -> __attr_id
                        __token = 1978
                        try:
                            __zt_tmp = __attrs_135757152264144
                        except get('NameError', NameError):
                            __zt_tmp = None

                        __attr_id = _static_135757244280656('string', u'dashboard-section-${section_id}', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                        __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                        if (__attr_id is not None):
                            __append((u' id="%s"' % __attr_id))
                        __append(u'>\n          ')

                        # <Static value=<_ast.Dict object at 0x7b786cd50150> name=None at 7b786cd50110> -> __attrs_135757166292560
                        __attrs_135757166292560 = _static_135757152190800

                        # <div ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<div class="text-muted py-3">\n            ')

                        # <Static value=<_ast.Dict object at 0x7b786dac2350> name=None at 7b786dac2290> -> __attrs_135757148778704
                        __attrs_135757148778704 = _static_135757166289744

                        # <i ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<i class="fas fa-spinner fa-spin mr-2"></i>\n            ')

                        # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148779344
                        __attrs_135757148779344 = _static_135757327983760

                        # <span ... (0:0)
                        # --------------------------------------------------------
                        __append(u'<span>')
                        __stream_135757148779024 = []
                        __append_135757148779024 = __stream_135757148779024.append
                        __append_135757148779024(u'Loading...')
                        __msgid_135757148779024 = __re_whitespace(''.join(__stream_135757148779024)).strip()
                        if __msgid_135757148779024:
                            __append(translate(__msgid_135757148779024, mapping=None, default=__msgid_135757148779024, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
                        __append(u'</span>\n          </div>\n        </div>\n      </div>')
                        ____index_135757152262608 -= 1
                        if (____index_135757152262608 > 0):
                            __append('\n      ')
                    if (__backup_section_id_135757075995536 is __marker):
                        del econtext['section_id']
                    else:
                        econtext['section_id'] = __backup_section_id_135757075995536
                    __append(u'\n    ')
                __append(u'\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b786cd614d0> name=None at 7b786cd61150> -> __attrs_135757148778896
                __attrs_135757148778896 = _static_135757152261328

                # <script ... (0:0)
                # --------------------------------------------------------
                __append(u'<script')

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757152261584
                __default_135757152261584 = _DEFAULT_MARKER

                # <Substitution u'string:${portal_url}/++resource++senaite.core.dashboard.js' (57:32)> -> __attr_src
                __token = 2308
                try:
                    __zt_tmp = __attrs_135757148778896
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_src = _static_135757244280656('string', u'${portal_url}/++resource++senaite.core.dashboard.js', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
                __attr_src = __quote(__attr_src, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_src is not None):
                    __append((u' src="%s"' % __attr_src))
                __append(u'></script>\n\n    ')

                # <Static value=<_ast.Dict object at 0x7b78774f6490> name=None at 7b78774f6ed0> -> __attrs_135757148780304
                __attrs_135757148780304 = _static_135757327983760

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __default_135757148780176
                __default_135757148780176 = _DEFAULT_MARKER

                # <Value u'context/@@authenticator/authenticator' (59:34)> -> __cache_135757148779856
                __token = 2413
                try:
                    __zt_tmp = __attrs_135757148780304
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_135757148779856 = _static_135757244280656('path', u'context/@@authenticator/authenticator', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))

                # <BinOp left=<Value u'context/@@authenticator/authenticator' (59:34)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 7b787750b110> at 7b786ca0f5d0> -> __condition
                __expression = __cache_135757148779856

                # <Symbol value=<DEFAULT> at 7b787750b110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input/>')
                else:
                    __content = __cache_135757148779856
                    __content = __convert(__content)
                    if (__content is not None):
                        __append(__content)
                __append(u'\n  ')
            _slots = econtext[u'__slot_content_core'] = _deque((__fill_content_core, ))

            # <Value u'here/main_template/macros/master' (2:23)> -> __macro
            __token = 66
            try:
                __zt_tmp = __attrs_135757237124880
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_135757244280656('path', u'here/main_template/macros/master', econtext=econtext)(_static_135757244301584(econtext, __zt_tmp))
            __token = 66
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_135757129738672 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_135757129738672
            __i18n_domain = __previous_i18n_domain_135757152254032
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }