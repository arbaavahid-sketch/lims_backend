# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/remarkswidget.pt'

__tokens = {946: (u'field|python:context.Schema()[fieldName]', 23, 30), 1021: (u" python:'portal_factory' in\n                                  context.absolute_url(", 24, 33), 1330: (u'temporary', 30, 35), 1423: (u'fieldName', 32, 41), 1436: (u' fieldNam', 32, 54), 1552: (u'not:temporary', 35, 30), 1655: (u'python:field.get_input_widget_attributes(context,request)', 37, 31), 802: (u'field_macro | context/widgets/field/macros/edit', 20, 26), 802: (u'field_macro | context/widgets/field/macros/edit', 20, 26), 2081: (u'fieldName', 49, 39), 2094: (u' fieldNam', 49, 52), 1924: (u'context/widgets/field/macros/edit', 46, 26), 1924: (u'context/widgets/field/macros/edit', 46, 26), 316: (u'context/UID|nothing', 8, 25), 363: (u' field|python:context.Schema()[fieldName', 9, 26), 434: (u'string:parent-fieldname-$fieldName-$uid', 10, 28), 588: (u'python:field.get_input_widget_attributes(context,request)', 13, 27)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_127045738586000 = {u'class': u'senaite-remarks-widget-input my-4', }
_static_127045886978576 = __C2ZContextWrapper
_static_127045641720976 = {u'class': u'remarks-widget my-4', u'id': u'string:parent-fieldname-$fieldName-$uid', }
_static_127045739280336 = {u'id': u'fieldName', u'class': u'form-control', u'name': u'fieldName', }
_static_127045643454160 = u'edit'
_static_127045970670736 = {}
_static_127045640776848 = {u'class': u'senaite-remarks-widget-input', }
_static_127045642747984 = set([])
_static_127045642561552 = set([])
_static_127045643453136 = {u'id': u'fieldName', u'class': u'form-control', u'name': u'fieldName', }
_static_127045886978192 = __compile_zt_expr
_static_127045640777552 = u'edit'

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640776080
            __attrs_127045640776080 = _static_127045970670736
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640774544
            __attrs_127045640774544 = _static_127045970670736
            __backup_macroname_127046031955760 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e49ef50> name=None at 738c1e49e750> -> __value
            __value = _static_127045640777552
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640774800
                __attrs_127045640774800 = _static_127045970670736
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643456400
                __attrs_127045643456400 = _static_127045970670736
                __backup_field_127045737972112 = get('field', __marker)

                # <Value u'field|python:context.Schema()[fieldName]' (23:30)> -> __value
                __token = 946
                try:
                    __zt_tmp = __attrs_127045643456400
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'field|python:context.Schema()[fieldName]', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['field'] = __value
                __backup_temporary_127045640089488 = get('temporary', __marker)

                # <Value u"python:'portal_factory' in\n                                  context.absolute_url()" (24:33)> -> __value
                __token = 1021
                try:
                    __zt_tmp = __attrs_127045643456400
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u"'portal_factory' in\n                                  context.absolute_url()", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['temporary'] = __value
                __append(u'\n\n          <!-- Temporary object (add form): keep a plain textarea so the value\n               is captured on creation; React in-place editing needs a\n               persisted object -->\n          ')

                # <Static value=<_ast.Dict object at 0x738c1e72c2d0> name=None at 738c1e72ce90> -> __attrs_127045740723152
                __attrs_127045740723152 = _static_127045643453136

                # <Value u'temporary' (30:35)> -> __condition
                __token = 1330
                try:
                    __zt_tmp = __attrs_127045740723152
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('path', u'temporary', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <textarea ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<textarea class="form-control"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045643453712
                    __default_127045643453712 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (32:41)> -> __attr_name
                    __token = 1423
                    try:
                        __zt_tmp = __attrs_127045740723152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045643455440
                    __default_127045643455440 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (32:54)> -> __attr_id
                    __token = 1436
                    try:
                        __zt_tmp = __attrs_127045740723152
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_id = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_id is not None):
                        __append((u' id="%s"' % __attr_id))
                    __append(u'></textarea>')
                __append(u'\n\n          <!-- Persisted object: mount the React widget -->\n          ')

                # <Static value=<_ast.Dict object at 0x738c241e5f90> name=None at 738c241e5ad0> -> __attrs_127046034734992
                __attrs_127046034734992 = _static_127045738586000

                # <Value u'not:temporary' (35:30)> -> __condition
                __token = 1552
                try:
                    __zt_tmp = __attrs_127046034734992
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('not', u'temporary', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <div ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<div')

                    # <Value u'python:field.get_input_widget_attributes(context,request)' (37:31)> -> __cache_127045738049104
                    __token = 1655
                    try:
                        __zt_tmp = __attrs_127046034734992
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __cache_127045738049104 = _static_127045886978192('python', u'field.get_input_widget_attributes(context,request)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    if (u'class' not in __chain(__cache_127045738049104)):
                        __append(u' class="senaite-remarks-widget-input my-4"')
                    __attr_127045738812240 = __cache_127045738049104
                    for (name, value, ) in __attr_127045738812240.items():
                        if ((name not in _static_127045642747984) and (value is not None)):
                            __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
                    __append(u'>\n            <!-- ReactJS controlled component -->\n          </div>')
                __append(u'\n        ')
                if (__backup_temporary_127045640089488 is __marker):
                    del econtext['temporary']
                else:
                    econtext['temporary'] = __backup_temporary_127045640089488
                if (__backup_field_127045737972112 is __marker):
                    del econtext['field']
                else:
                    econtext['field'] = __backup_field_127045737972112
                __append(u'\n      ')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | context/widgets/field/macros/edit' (20:26)> -> __macro
            __token = 802
            try:
                __zt_tmp = __attrs_127045640774544
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'field_macro | context/widgets/field/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 802
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127046031955760 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127046031955760
            __append(u'\n  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045640775632
            __attrs_127045640775632 = _static_127045970670736
            __append(u'\n    ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045643454032
            __attrs_127045643454032 = _static_127045970670736
            __backup_macroname_127045757367232 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c1e72c6d0> name=None at 738c1e72ca90> -> __value
            __value = _static_127045643454160
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045739278800
                __attrs_127045739278800 = _static_127045970670736
                __append(u'\n        ')

                # <Static value=<_ast.Dict object at 0x738c2428f7d0> name=None at 738c2428f250> -> __attrs_127045640571024
                __attrs_127045640571024 = _static_127045739280336

                # <textarea ... (0:0)
                # --------------------------------------------------------
                __append(u'<textarea class="form-control"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045739278544
                __default_127045739278544 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (49:39)> -> __attr_name
                __token = 2081
                try:
                    __zt_tmp = __attrs_127045640571024
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640571600
                __default_127045640571600 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (49:52)> -> __attr_id
                __token = 2094
                try:
                    __zt_tmp = __attrs_127045640571024
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_id = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_id is not None):
                    __append((u' id="%s"' % __attr_id))
                __append(u'></textarea>\n      ')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'context/widgets/field/macros/edit' (46:26)> -> __macro
            __token = 1924
            try:
                __zt_tmp = __attrs_127045643454032
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'context/widgets/field/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 1924
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045757367232 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045757367232
            __append(u'\n  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_textarea_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c1e585490> name=None at 738c1e585c90> -> __attrs_127045640775120
            __attrs_127045640775120 = _static_127045641720976
            __backup_uid_127045640889616 = get('uid', __marker)

            # <Value u'context/UID|nothing' (8:25)> -> __value
            __token = 316
            try:
                __zt_tmp = __attrs_127045640775120
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'context/UID|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['uid'] = __value
            __backup_field_127045739359376 = get('field', __marker)

            # <Value u'field|python:context.Schema()[fieldName]' (9:26)> -> __value
            __token = 363
            try:
                __zt_tmp = __attrs_127045640775120
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'field|python:context.Schema()[fieldName]', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['field'] = __value

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="remarks-widget my-4"')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045640773840
            __default_127045640773840 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName-$uid' (10:28)> -> __attr_id
            __token = 434
            try:
                __zt_tmp = __attrs_127045640775120
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_127045886978192('string', u'parent-fieldname-$fieldName-$uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n      ')

            # <Static value=<_ast.Dict object at 0x738c1e49ec90> name=None at 738c1e49ed10> -> __attrs_127045640776144
            __attrs_127045640776144 = _static_127045640776848

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div')

            # <Value u'python:field.get_input_widget_attributes(context,request)' (13:27)> -> __cache_127045640775568
            __token = 588
            try:
                __zt_tmp = __attrs_127045640776144
            except get('NameError', NameError):
                __zt_tmp = None

            __cache_127045640775568 = _static_127045886978192('python', u'field.get_input_widget_attributes(context,request)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            if (u'class' not in __chain(__cache_127045640775568)):
                __append(u' class="senaite-remarks-widget-input"')
            __attr_127045640773968 = __cache_127045640775568
            for (name, value, ) in __attr_127045640773968.items():
                if ((name not in _static_127045642561552) and (value is not None)):
                    __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
            __append(u'>\n        <!-- ReactJS controlled component -->\n      </div>\n    </div>')
            if (__backup_field_127045739359376 is __marker):
                del econtext['field']
            else:
                econtext['field'] = __backup_field_127045739359376
            if (__backup_uid_127045640889616 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_127045640889616
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641721040
            __attrs_127045641721040 = _static_127045970670736
            __append(u'\n    ')
            __token = None
            render_textarea_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n  ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045641720272
            __attrs_127045641720272 = _static_127045970670736
            __previous_i18n_domain_127045641721104 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html>\n\n  ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n</html>')
            __i18n_domain = __previous_i18n_domain_127045641721104
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_textarea_field_view': render_textarea_field_view, u'render_view': render_view, 'render': render, }