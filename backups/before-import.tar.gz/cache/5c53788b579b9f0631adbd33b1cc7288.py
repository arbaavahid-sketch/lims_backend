# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/globalstatusmessage.pt'

__tokens = {36: (u'view/messages', 1, 36), 87: (u'messages', 2, 35), 159: (u'message/type | nothing', 5, 25), 210: (u" python:{'error': 'danger'", 6, 26), 266: (u'y python:mapping.get(mtype, mtyp', 7, 26), 333: (u'string:alert alert-dismissible alert-${facility}', 8, 29), 577: (u'python:mtype.capitalize()', 14, 43), 683: (u'message/message | nothing', 18, 23)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr

_static_133838701330512 = {u'aria-label': u'Close', u'data-dismiss': u'alert', u'type': u'button', u'class': u'close', }
_static_133838794967184 = __compile_zt_expr
_static_133838794967568 = __C2ZContextWrapper
_static_133838686152144 = {u'aria-hidden': u'true', }
_static_133838878659728 = {}
_static_133838701332112 = {u'class': u'alert alert-info', }
_static_133838686044368 = {u'class': u'content', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686002640
            __attrs_133838686002640 = _static_133838878659728
            __backup_messages_133838681335184 = get('messages', __marker)

            # <Value u'view/messages' (1:36)> -> __value
            __token = 36
            try:
                __zt_tmp = __attrs_133838686002640
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_133838794967184('path', u'view/messages', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            econtext['messages'] = __value
            __backup_message_133838686057616 = get('message', __marker)

            # <Value u'messages' (2:35)> -> __iterator
            __token = 87
            try:
                __zt_tmp = __attrs_133838686002640
            except get('NameError', NameError):
                __zt_tmp = None

            __iterator = _static_133838794967184('path', u'messages', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
            (__iterator, ____index_133838701333904, ) = getitem('repeat')(u'message', __iterator)
            econtext['message'] = None
            for __item in __iterator:
                econtext['message'] = __item
                __append(u'\r\n\r\n  ')

                # <Static value=<_ast.Dict object at 0x79b9c0400690> name=None at 79b9c0400a50> -> __attrs_133838701331856
                __attrs_133838701331856 = _static_133838701332112
                __backup_mtype_133838698808656 = get('mtype', __marker)

                # <Value u'message/type | nothing' (5:25)> -> __value
                __token = 159
                try:
                    __zt_tmp = __attrs_133838701331856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('path', u'message/type | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['mtype'] = __value
                __backup_mapping_133838698895888 = get('mapping', __marker)

                # <Value u"python:{'error': 'danger'}" (6:26)> -> __value
                __token = 210
                try:
                    __zt_tmp = __attrs_133838701331856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u"{'error': 'danger'}", econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['mapping'] = __value
                __backup_facility_133838716893584 = get('facility', __marker)

                # <Value u'python:mapping.get(mtype, mtype)' (7:26)> -> __value
                __token = 266
                try:
                    __zt_tmp = __attrs_133838701331856
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_133838794967184('python', u'mapping.get(mtype, mtype)', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                econtext['facility'] = __value

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838701331216
                __default_133838701331216 = _DEFAULT_MARKER

                # <Substitution u'string:alert alert-dismissible alert-${facility}' (8:29)> -> __attr_class
                __token = 333
                try:
                    __zt_tmp = __attrs_133838701331856
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_class = _static_133838794967184('string', u'alert alert-dismissible alert-${facility}', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))
                __attr_class = __quote(__attr_class, '"', '&quot;', u'alert alert-info', _DEFAULT_MARKER)
                if (__attr_class is not None):
                    __append((u' class="%s"' % __attr_class))
                __append(u'>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9c0400050> name=None at 79b9c04002d0> -> __attrs_133838686099344
                __attrs_133838686099344 = _static_133838701330512

                # <button ... (0:0)
                # --------------------------------------------------------
                __append(u'<button type="button" class="close" data-dismiss="alert" aria-label="Close">\r\n      ')

                # <Static value=<_ast.Dict object at 0x79b9bf5865d0> name=None at 79b9bf586190> -> __attrs_133838686100752
                __attrs_133838686100752 = _static_133838686152144

                # <span ... (0:0)
                # --------------------------------------------------------
                __append(u'<span aria-hidden="true">&times;</span>\r\n    </button>\r\n\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838686101008
                __attrs_133838686101008 = _static_133838878659728

                # <strong ... (0:0)
                # --------------------------------------------------------
                __append(u'<strong>')

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686100304
                __default_133838686100304 = _DEFAULT_MARKER

                # <Value u'python:mtype.capitalize()' (14:43)> -> __cache_133838686097744
                __token = 577
                try:
                    __zt_tmp = __attrs_133838686101008
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838686097744 = _static_133838794967184('python', u'mtype.capitalize()', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'python:mtype.capitalize()' (14:43)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf579410> -> __condition
                __expression = __cache_133838686097744

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:
                    __append(u'\r\n      Info\r\n    ')
                else:
                    __content = __cache_133838686097744
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'</strong>\r\n    ')

                # <Static value=<_ast.Dict object at 0x79b9bf56c0d0> name=None at 79b9bf56c410> -> __attrs_133838686046096
                __attrs_133838686046096 = _static_133838686044368

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838686045328
                __default_133838686045328 = _DEFAULT_MARKER

                # <Value u'message/message | nothing' (18:23)> -> __cache_133838686044496
                __token = 683
                try:
                    __zt_tmp = __attrs_133838686046096
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_133838686044496 = _static_133838794967184('path', u'message/message | nothing', econtext=econtext)(_static_133838794967568(econtext, __zt_tmp))

                # <BinOp left=<Value u'message/message | nothing' (18:23)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 79b9cad32110> at 79b9bf56cdd0> -> __condition
                __expression = __cache_133838686044496

                # <Symbol value=<DEFAULT> at 79b9cad32110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span class="content">\r\n      The status message.\r\n    </span>')
                else:
                    __content = __cache_133838686044496
                    __content = translate(__content, default=None, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                __append(u'\r\n  </div>')
                if (__backup_facility_133838716893584 is __marker):
                    del econtext['facility']
                else:
                    econtext['facility'] = __backup_facility_133838716893584
                if (__backup_mapping_133838698895888 is __marker):
                    del econtext['mapping']
                else:
                    econtext['mapping'] = __backup_mapping_133838698895888
                if (__backup_mtype_133838698808656 is __marker):
                    del econtext['mtype']
                else:
                    econtext['mtype'] = __backup_mtype_133838698808656
                __append(u'\r\n\r\n')
                ____index_133838701333904 -= 1
                if (____index_133838701333904 > 0):
                    __append('')
            if (__backup_message_133838686057616 is __marker):
                del econtext['message']
            else:
                econtext['message'] = __backup_message_133838686057616
            if (__backup_messages_133838681335184 is __marker):
                del econtext['messages']
            else:
                econtext['messages'] = __backup_messages_133838681335184
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }