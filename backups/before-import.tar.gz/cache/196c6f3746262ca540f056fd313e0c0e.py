# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/browser/viewlets/templates/colophon.pt'

__tokens = {}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from sys import exc_info as _exc_info

_static_133838698698960 = {u'class': u'col-md-12', }
_static_133838681382992 = {u'href': u'http://plone.org', u'title': u'This site was built using the Plone Open Source CMS/WCM.', }
_static_133838685913424 = {u'class': u'row', }
_static_133838685916112 = {u'id': u'senaite-colophon', }
_static_133838681386448 = {u'class': u'list-inline', }
_static_133838698698384 = {u'class': u'text-center text-muted', }
_static_133838685915728 = {u'class': u'container-fluid', }
_static_133838878659728 = {}

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x79b9bf54cbd0> name=None at 79b9bf54cd10> -> __attrs_133838685915280
            __attrs_133838685915280 = _static_133838685916112
            __previous_i18n_domain_133838685915600 = __i18n_domain
            __i18n_domain = u'senaite.core'

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div id="senaite-colophon">\r\n\r\n  ')

            # <Static value=<_ast.Dict object at 0x79b9bf54ca50> name=None at 79b9bf54c1d0> -> __attrs_133838685915792
            __attrs_133838685915792 = _static_133838685915728

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="container-fluid">\r\n    ')

            # <Static value=<_ast.Dict object at 0x79b9bf54c150> name=None at 79b9bf54ce10> -> __attrs_133838698697616
            __attrs_133838698697616 = _static_133838685913424

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="row">\r\n      ')

            # <Static value=<_ast.Dict object at 0x79b9c017d8d0> name=None at 79b9c017d7d0> -> __attrs_133838698699024
            __attrs_133838698699024 = _static_133838698698960

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="col-md-12">\r\n\r\n        ')

            # <Static value=<_ast.Dict object at 0x79b9c017d690> name=None at 79b9c017dcd0> -> __attrs_133838698698576
            __attrs_133838698698576 = _static_133838698698384

            # <div ... (0:0)
            # --------------------------------------------------------
            __append(u'<div class="text-center text-muted">\r\n          ')

            # <Static value=<_ast.Dict object at 0x79b9bf0fadd0> name=None at 79b9bf0fa490> -> __attrs_133838681386640
            __attrs_133838681386640 = _static_133838681386448

            # <ul ... (0:0)
            # --------------------------------------------------------
            __append(u'<ul class="list-inline">\r\n            ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681385680
            __attrs_133838681385680 = _static_133838878659728

            # <li ... (0:0)
            # --------------------------------------------------------
            __append(u'<li>\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9cad1d490> name=None at 79b9cad1ded0> -> __attrs_133838681384656
            __attrs_133838681384656 = _static_133838878659728

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span>')
            __stream_133838681385040 = []
            __append_133838681385040 = __stream_133838681385040.append
            __append_133838681385040(u'SENAITE is powered by')
            __msgid_133838681385040 = __re_whitespace(''.join(__stream_133838681385040)).strip()
            if u'label_powered_by':
                __append(translate(u'label_powered_by', mapping=None, default=__msgid_133838681385040, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</span>\r\n              ')

            # <Static value=<_ast.Dict object at 0x79b9bf0fa050> name=None at 79b9bf0fa890> -> __attrs_133838681184016
            __attrs_133838681184016 = _static_133838681382992

            # <a ... (0:0)
            # --------------------------------------------------------
            __append(u'<a href="http://plone.org"')

            # <Symbol value=<DEFAULT> at 79b9cad32110> -> __default_133838701347408
            __default_133838701347408 = _DEFAULT_MARKER

            # <Translate msgid=u'title_built_with_plone' node=<_ast.Str object at 0x79b9bf54a210> at 79b9bf54a690> -> __attr_title
            __attr_title = u'This site was built using the Plone Open Source CMS/WCM.'
            __attr_title = translate(u'title_built_with_plone', default=__attr_title, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language'))
            if (__attr_title is not None):
                __append((u'                  title="%s"' % __attr_title))
            __append(u'>')
            __stream_133838681383120 = []
            __append_133838681383120 = __stream_133838681383120.append
            __append_133838681383120(u'\r\n                Plone &amp; Python')
            __msgid_133838681383120 = __re_whitespace(''.join(__stream_133838681383120)).strip()
            if u'label_powered_by_plone':
                __append(translate(u'label_powered_by_plone', mapping=None, default=__msgid_133838681383120, domain=__i18n_domain, context=__i18n_context, target_language=getitem('target_language')))
            __append(u'</a>\r\n            </li>\r\n          </ul>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</div>')
            __i18n_domain = __previous_i18n_domain_133838685915600
            __append(u'\r\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {'render': render, }