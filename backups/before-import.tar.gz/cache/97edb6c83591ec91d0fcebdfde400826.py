# -*- coding: utf-8 -*-
__filename = '/home/senaite/senaitelims/src/senaite.core/src/senaite/core/skins/senaite_templates/senaite_widgets/datetimewidget.pt'

__tokens = {860: (u'context/@@plone_portal_state/portal', 23, 33), 934: (u' string:${portal/absolute_url}/senaite_widget', 24, 37), 1085: (u'string:${static_path}/datetimewidget.css', 26, 35), 1781: (u'python:widget.attrs(context, field)', 39, 39), 2030: (u'   python:widget_at', 44, 17), 1877: (u'fieldName', 41, 27), 1912: (u' string:${fieldName}-dat', 42, 24), 1963: (u'e python:widget.get_date(value) if value else ', 43, 24), 2208: (u'python:widget.show_time', 49, 29), 2291: (u'fieldName', 51, 27), 2326: (u' string:${fieldName}-tim', 52, 24), 2377: (u'e python:widget.get_time(value) if value else ', 53, 24), 2608: (u'string:${fieldName}', 59, 23), 2652: (u" python:widget.to_local_date(value, context=context, request=request) if value else '", 60, 23), 1177: (u'field_macro | context/widgets/field/macros/edit', 28, 28), 1177: (u'field_macro | context/widgets/field/macros/edit', 28, 28), 722: (u'here/widgets/string/macros/edit', 19, 28), 722: (u'here/widgets/string/macros/edit', 19, 28), 263: (u'context/UID|nothing', 9, 28), 315: (u'string:parent-fieldname-$fieldName-$uid', 10, 31), 430: (u'accessor', 12, 32), 471: (u" python: widget.ulocalized_time(value, context=context, request=request) if value else '", 13, 31), 589: (u'value', 14, 27)}

from chameleon.tales import DEFAULT_MARKER as _DEFAULT_MARKER
from Products.PageTemplates.engine import _compile_zt_expr as __compile_zt_expr
from sys import exc_info as _exc_info
from collections import deque as _deque
from Products.PageTemplates.engine import _C2ZContextWrapper as __C2ZContextWrapper

_static_127045738036176 = {u'class': u'text-left', }
_static_127045738034832 = {u'class': u'input-group flex-nowrap d-inline-flex w-auto datetimewidget', }
_static_127045886978576 = __C2ZContextWrapper
_static_127045736775568 = {u'id': u'string:parent-fieldname-$fieldName-$uid', }
_static_127045970670736 = {}
_static_127045737525136 = {u'type': u'hidden', u'name': u'string:${fieldName}', u'value': u"python:widget.to_local_date(value, context=context, request=request) if value else ''", }
_static_127045736892880 = {u'media': u'all', u'href': u'', u'type': u'text/css', u'rel': u'stylesheet', }
_static_127045644109136 = set([])
_static_127045736893456 = u'edit'
_static_127045737521872 = {u'value': u"python:widget.get_time(value) if value else ''", u'type': u'time', u'class': u'form-control form-control-sm', u'name': u'string:${fieldName}-time', u'target': u'fieldName', }
_static_127045736891344 = u'edit'
_static_127045886978192 = __compile_zt_expr
_static_127045738034128 = {u'value': u"python:widget.get_date(value) if value else ''", u'type': u'date', u'class': u'form-control form-control-sm', u'name': u'string:${fieldName}-date', u'target': u'fieldName', }

import re
import functools
from itertools import chain as __chain
from sys import exc_clear as __exc_clear
__default = intern('__default__')
__marker = object()
g_re_amp = re.compile('&(?!([A-Za-z]+|#[0-9]+);)')
g_re_needs_escape = re.compile('[&<>\\"\\\']').search
__re_whitespace = functools.partial(re.compile('\\s+').sub, ' ')

def initialize(modules, nothing, tales, zope_version_4_8_10_):

    def render_edit(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736891984
            __attrs_127045736891984 = _static_127045970670736
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736890576
            __attrs_127045736890576 = _static_127045970670736
            __backup_portal_127045738197584 = get('portal', __marker)

            # <Value u'context/@@plone_portal_state/portal' (23:33)> -> __value
            __token = 860
            try:
                __zt_tmp = __attrs_127045736890576
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'context/@@plone_portal_state/portal', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['portal'] = __value
            __backup_static_path_127045738142608 = get('static_path', __marker)

            # <Value u'string:${portal/absolute_url}/senaite_widgets' (24:37)> -> __value
            __token = 934
            try:
                __zt_tmp = __attrs_127045736890576
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('string', u'${portal/absolute_url}/senaite_widgets', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['static_path'] = __value
            __append(u'\n        ')

            # <Static value=<_ast.Dict object at 0x738c240489d0> name=None at 738c24048e10> -> __attrs_127045738330192
            __attrs_127045738330192 = _static_127045736892880

            # <link ... (0:0)
            # --------------------------------------------------------
            __append(u'<link rel="stylesheet" type="text/css" media="all"')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045736892688
            __default_127045736892688 = _DEFAULT_MARKER

            # <Substitution u'string:${static_path}/datetimewidget.css' (26:35)> -> __attr_href
            __token = 1085
            try:
                __zt_tmp = __attrs_127045738330192
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_href = _static_127045886978192('string', u'${static_path}/datetimewidget.css', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_href = __quote(__attr_href, '"', '&quot;', u'', _DEFAULT_MARKER)
            if (__attr_href is not None):
                __append((u' href="%s"' % __attr_href))
            __append(u'/>\n      ')
            if (__backup_static_path_127045738142608 is __marker):
                del econtext['static_path']
            else:
                econtext['static_path'] = __backup_static_path_127045738142608
            if (__backup_portal_127045738197584 is __marker):
                del econtext['portal']
            else:
                econtext['portal'] = __backup_portal_127045738197584
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045738331600
            __attrs_127045738331600 = _static_127045970670736
            __backup_macroname_127045756210704 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c24048c10> name=None at 738c24048a90> -> __value
            __value = _static_127045736893456
            econtext['macroname'] = __value

            def __fill_widget_body(__stream, econtext, rcontext, __i18n_domain=__i18n_domain, __i18n_context=__i18n_context):
                getitem = econtext.__getitem__
                get = econtext.get

                # <Static value=<_ast.Dict object at 0x738c2415fbd0> name=None at 738c2415f2d0> -> __attrs_127045738035920
                __attrs_127045738035920 = _static_127045738036176

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="text-left">\n          ')

                # <Static value=<_ast.Dict object at 0x738c2415f690> name=None at 738c2415f6d0> -> __attrs_127045738036880
                __attrs_127045738036880 = _static_127045738034832

                # <div ... (0:0)
                # --------------------------------------------------------
                __append(u'<div class="input-group flex-nowrap d-inline-flex w-auto datetimewidget">\n            <!-- date -->\n            ')

                # <Static value=<_ast.Dict object at 0x738c2415f3d0> name=None at 738c2415f390> -> __attrs_127045737522704
                __attrs_127045737522704 = _static_127045738034128
                __backup_widget_attrs_127045738143696 = get('widget_attrs', __marker)

                # <Value u'python:widget.attrs(context, field)' (39:39)> -> __value
                __token = 1781
                try:
                    __zt_tmp = __attrs_127045737522704
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u'widget.attrs(context, field)', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['widget_attrs'] = __value

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input')

                # <Value u'python:widget_attrs' (44:17)> -> __cache_127045737521360
                __token = 2030
                try:
                    __zt_tmp = __attrs_127045737522704
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_127045737521360 = _static_127045886978192('python', u'widget_attrs', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if (u'type' not in __chain(__cache_127045737521360)):
                    __append(u' type="date"')
                if (u'class' not in __chain(__cache_127045737521360)):
                    __append(u' class="form-control form-control-sm"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737909776
                __default_127045737909776 = _DEFAULT_MARKER

                # <Substitution u'fieldName' (41:27)> -> __attr_target
                __token = 1877
                try:
                    __zt_tmp = __attrs_127045737522704
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_target = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_target = __quote(__attr_target, '"', '&quot;', None, _DEFAULT_MARKER)
                if ((__attr_target is not None) and (u'target' not in __chain(__cache_127045737521360))):
                    __append((u' target="%s"' % __attr_target))

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737907920
                __default_127045737907920 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}-date' (42:24)> -> __attr_name
                __token = 1912
                try:
                    __zt_tmp = __attrs_127045737522704
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_127045886978192('string', u'${fieldName}-date', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if ((__attr_name is not None) and (u'name' not in __chain(__cache_127045737521360))):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737521552
                __default_127045737521552 = _DEFAULT_MARKER

                # <Substitution u"python:widget.get_date(value) if value else ''" (43:24)> -> __attr_value
                __token = 1963
                try:
                    __zt_tmp = __attrs_127045737522704
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('python', u"widget.get_date(value) if value else ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if ((__attr_value is not None) and (u'value' not in __chain(__cache_127045737521360))):
                    __append((u' value="%s"' % __attr_value))
                __attr_127045737521296 = __cache_127045737521360
                for (name, value, ) in __attr_127045737521296.items():
                    if ((name not in _static_127045644109136) and (value is not None)):
                        __append((((((' ' + name) + '=') + '"') + __quote(value, '"', '&quot;', None, None)) + '"'))
                __append(u'/>')
                if (__backup_widget_attrs_127045738143696 is __marker):
                    del econtext['widget_attrs']
                else:
                    econtext['widget_attrs'] = __backup_widget_attrs_127045738143696
                __append(u'\n            <!-- time -->\n            ')

                # <Static value=<_ast.Dict object at 0x738c240e22d0> name=None at 738c240e2490> -> __attrs_127045737521936
                __attrs_127045737521936 = _static_127045737521872

                # <Value u'python:widget.show_time' (49:29)> -> __condition
                __token = 2208
                try:
                    __zt_tmp = __attrs_127045737521936
                except get('NameError', NameError):
                    __zt_tmp = None

                __condition = _static_127045886978192('python', u'widget.show_time', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                if __condition:

                    # <input ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<input type="time" class="form-control form-control-sm"')

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737523664
                    __default_127045737523664 = _DEFAULT_MARKER

                    # <Substitution u'fieldName' (51:27)> -> __attr_target
                    __token = 2291
                    try:
                        __zt_tmp = __attrs_127045737521936
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_target = _static_127045886978192('path', u'fieldName', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_target = __quote(__attr_target, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_target is not None):
                        __append((u' target="%s"' % __attr_target))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737525200
                    __default_127045737525200 = _DEFAULT_MARKER

                    # <Substitution u'string:${fieldName}-time' (52:24)> -> __attr_name
                    __token = 2326
                    try:
                        __zt_tmp = __attrs_127045737521936
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_name = _static_127045886978192('string', u'${fieldName}-time', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_name is not None):
                        __append((u' name="%s"' % __attr_name))

                    # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737521680
                    __default_127045737521680 = _DEFAULT_MARKER

                    # <Substitution u"python:widget.get_time(value) if value else ''" (53:24)> -> __attr_value
                    __token = 2377
                    try:
                        __zt_tmp = __attrs_127045737521936
                    except get('NameError', NameError):
                        __zt_tmp = None

                    __attr_value = _static_127045886978192('python', u"widget.get_time(value) if value else ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                    __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                    if (__attr_value is not None):
                        __append((u' value="%s"' % __attr_value))
                    __append(u'/>')
                __append(u'\n          </div>\n          <!-- datetime value (outside to avoid style issues) -->\n          ')

                # <Static value=<_ast.Dict object at 0x738c240e2f90> name=None at 738c240e2850> -> __attrs_127045737071376
                __attrs_127045737071376 = _static_127045737525136

                # <input ... (0:0)
                # --------------------------------------------------------
                __append(u'<input type="hidden"')

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737070992
                __default_127045737070992 = _DEFAULT_MARKER

                # <Substitution u'string:${fieldName}' (59:23)> -> __attr_name
                __token = 2608
                try:
                    __zt_tmp = __attrs_127045737071376
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_name = _static_127045886978192('string', u'${fieldName}', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_name = __quote(__attr_name, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_name is not None):
                    __append((u' name="%s"' % __attr_name))

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737071568
                __default_127045737071568 = _DEFAULT_MARKER

                # <Substitution u"python:widget.to_local_date(value, context=context, request=request) if value else ''" (60:23)> -> __attr_value
                __token = 2652
                try:
                    __zt_tmp = __attrs_127045737071376
                except get('NameError', NameError):
                    __zt_tmp = None

                __attr_value = _static_127045886978192('python', u"widget.to_local_date(value, context=context, request=request) if value else ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                __attr_value = __quote(__attr_value, '"', '&quot;', None, _DEFAULT_MARKER)
                if (__attr_value is not None):
                    __append((u' value="%s"' % __attr_value))
                __append(u'/>\n        </div>')
            _slots = econtext[u'__slot_widget_body'] = _deque((__fill_widget_body, ))

            # <Value u'field_macro | context/widgets/field/macros/edit' (28:28)> -> __macro
            __token = 1177
            try:
                __zt_tmp = __attrs_127045738331600
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'field_macro | context/widgets/field/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 1177
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756210704 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756210704
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_search(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737867728
            __attrs_127045737867728 = _static_127045970670736
            __append(u'\n      ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736891664
            __attrs_127045736891664 = _static_127045970670736
            __backup_macroname_127045756317120 = get('macroname', __marker)

            # <Static value=<_ast.Str object at 0x738c240483d0> name=None at 738c24048390> -> __value
            __value = _static_127045736891344
            econtext['macroname'] = __value

            # <Value u'here/widgets/string/macros/edit' (19:28)> -> __macro
            __token = 722
            try:
                __zt_tmp = __attrs_127045736891664
            except get('NameError', NameError):
                __zt_tmp = None

            __macro = _static_127045886978192('path', u'here/widgets/string/macros/edit', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __token = 722
            __m = __macro.include
            __m(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            if (__backup_macroname_127045756317120 is __marker):
                del econtext['macroname']
            else:
                econtext['macroname'] = __backup_macroname_127045756317120
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_string_field_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            __slot_inside = econtext[u'__slot_inside'].pop()
        except:
            __slot_inside = None

        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c2402bf90> name=None at 738c2402bf50> -> __attrs_127045736774864
            __attrs_127045736774864 = _static_127045736775568
            __backup_uid_127045738143312 = get('uid', __marker)

            # <Value u'context/UID|nothing' (9:28)> -> __value
            __token = 263
            try:
                __zt_tmp = __attrs_127045736774864
            except get('NameError', NameError):
                __zt_tmp = None

            __value = _static_127045886978192('path', u'context/UID|nothing', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            econtext['uid'] = __value

            # <span ... (0:0)
            # --------------------------------------------------------
            __append(u'<span')

            # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737353104
            __default_127045737353104 = _DEFAULT_MARKER

            # <Substitution u'string:parent-fieldname-$fieldName-$uid' (10:31)> -> __attr_id
            __token = 315
            try:
                __zt_tmp = __attrs_127045736774864
            except get('NameError', NameError):
                __zt_tmp = None

            __attr_id = _static_127045886978192('string', u'parent-fieldname-$fieldName-$uid', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
            __attr_id = __quote(__attr_id, '"', '&quot;', None, _DEFAULT_MARKER)
            if (__attr_id is not None):
                __append((u' id="%s"' % __attr_id))
            __append(u'>\n        ')
            if (__slot_inside is None):

                # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045737867472
                __attrs_127045737867472 = _static_127045970670736
                __backup_value_127045738197520 = get('value', __marker)

                # <Value u'accessor' (12:32)> -> __value
                __token = 430
                try:
                    __zt_tmp = __attrs_127045737867472
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('path', u'accessor', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['value'] = __value
                __backup_value_127045738197904 = get('value', __marker)

                # <Value u"python: widget.ulocalized_time(value, context=context, request=request) if value else ''" (13:31)> -> __value
                __token = 471
                try:
                    __zt_tmp = __attrs_127045737867472
                except get('NameError', NameError):
                    __zt_tmp = None

                __value = _static_127045886978192('python', u" widget.ulocalized_time(value, context=context, request=request) if value else ''", econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))
                econtext['value'] = __value

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __default_127045737865808
                __default_127045737865808 = _DEFAULT_MARKER

                # <Value u'value' (14:27)> -> __cache_127045737868176
                __token = 589
                try:
                    __zt_tmp = __attrs_127045737867472
                except get('NameError', NameError):
                    __zt_tmp = None

                __cache_127045737868176 = _static_127045886978192('path', u'value', econtext=econtext)(_static_127045886978576(econtext, __zt_tmp))

                # <BinOp left=<Value u'value' (14:27)> op=<class 'chameleon.nodes.Is'> right=<Symbol value=<DEFAULT> at 738c31f50110> at 738c24136e10> -> __condition
                __expression = __cache_127045737868176

                # <Symbol value=<DEFAULT> at 738c31f50110> -> __value
                __value = _DEFAULT_MARKER
                __condition = (__expression is __value)
                if __condition:

                    # <span ... (0:0)
                    # --------------------------------------------------------
                    __append(u'<span>Date</span>')
                else:
                    __content = __cache_127045737868176
                    __content = __quote(__content, None, '\xad', None, None)
                    if (__content is not None):
                        __append(__content)
                if (__backup_value_127045738197904 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_127045738197904
                if (__backup_value_127045738197520 is __marker):
                    del econtext['value']
                else:
                    econtext['value'] = __backup_value_127045738197520
            else:
                __slot_inside(__stream, econtext.copy(), rcontext)
            __append(u'\n      </span>')
            if (__backup_uid_127045738143312 is __marker):
                del econtext['uid']
            else:
                econtext['uid'] = __backup_uid_127045738143312
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render_view(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736774096
            __attrs_127045736774096 = _static_127045970670736
            __append(u'\n      ')
            __token = None
            render_string_field_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n    ')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise


    def render(__stream, econtext, rcontext, __i18n_domain=None, __i18n_context=None):
        __append = __stream.append
        __re_amp = g_re_amp
        __token = None
        __re_needs_escape = g_re_needs_escape

        def __convert(target):
            if (target is None):
                return
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except AttributeError:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            target = target()
            return target

        def __quote(target, quote, quote_entity, default, default_marker):
            if (target is None):
                return
            if (target is default_marker):
                return default
            __tt = type(target)
            if ((__tt is int) or (__tt is float) or (__tt is long)):
                target = unicode(target)
            else:
                if (__tt is str):
                    target = decode(target)
                else:
                    if (__tt is not unicode):
                        try:
                            target = target.__html__
                        except:
                            __converted = convert(target)
                            target = (unicode(target) if (target is __converted) else __converted)
                        else:
                            return target()
                if (target is not None):
                    try:
                        escape = (__re_needs_escape(target) is not None)
                    except TypeError:
                        pass
                    else:
                        if escape:
                            if ('&' in target):
                                target = target.replace('&', '&amp;')
                            if ('<' in target):
                                target = target.replace('<', '&lt;')
                            if ('>' in target):
                                target = target.replace('>', '&gt;')
                            if ((quote is not None) and (quote in target)):
                                target = target.replace(quote, quote_entity)
            return target
        decode = econtext['__decode']
        convert = econtext['__convert']
        translate = econtext['__translate']
        on_error_handler = econtext['__on_error_handler']
        try:
            getitem = econtext.__getitem__
            get = econtext.get

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736772176
            __attrs_127045736772176 = _static_127045970670736
            __previous_i18n_domain_127045736772112 = __i18n_domain
            __i18n_domain = u'plone'

            # <html ... (0:0)
            # --------------------------------------------------------
            __append(u'<html>\n\n  ')

            # <Static value=<_ast.Dict object at 0x738c31f3b490> name=None at 738c31f3bed0> -> __attrs_127045736773648
            __attrs_127045736773648 = _static_127045970670736

            # <body ... (0:0)
            # --------------------------------------------------------
            __append(u'<body>\n    ')
            __token = None
            render_view(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_search(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n    ')
            __token = None
            render_edit(__stream, econtext.copy(), rcontext, __i18n_domain)
            econtext.update(rcontext)
            __append(u'\n\n  </body>\n\n</html>')
            __i18n_domain = __previous_i18n_domain_127045736772112
            __append(u'\n')
        except:
            if (__token is not None):
                rcontext.setdefault('__error__', []).append((__tokens[__token] + (__filename, _exc_info()[1], )))
            raise

    return {u'render_edit': render_edit, u'render_search': render_search, u'render_string_field_view': render_string_field_view, u'render_view': render_view, 'render': render, }